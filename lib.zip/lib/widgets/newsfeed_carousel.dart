import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/reaction.dart';
import 'package:werfieapp/models/retweet.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/chewie_videoplayer.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/react_retweet_dialog.dart';
import 'package:werfieapp/widgets/video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:get/get.dart';

import '../network/controller/mobile_comments_controller.dart';
import '../network/firebase_deeplinking.dart';
import '../network/singleTone.dart';
import '../screens/replay_module/mobile_replay_module.dart';
import '../screens/replay_module/web_replay_module.dart';
import '../utils/asset_string.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import 'comments_screen.dart';
import 'package:http/http.dart' as http;
import 'dart:io';

class NewsFeedCarousel extends StatefulWidget {
  NewsFeedCarousel({this.controller,
    this.post,
    this.imagesListForCarousel,
    this.mediaIndex,
    this.videoListForCarousel,
    this.check,
    this.chatCheck,
    this.postList,
    this.commentScreen,
    this.replyPageId,
    this.commentId
  });

  final List imagesListForCarousel;
  final int mediaIndex;
  final List videoListForCarousel;
  final Post post;
  List<Post> postList;
  bool commentScreen = false;

  final NewsfeedController controller;
  int check;

  int chatCheck = 0;
  int replyPageId;
  final int commentId;

  @override
  State<NewsFeedCarousel> createState() => _NewsFeedCarouselState();
}

class _NewsFeedCarouselState extends State<NewsFeedCarousel> {
  Focus focus;

  Widget build(BuildContext context) {
    // FocusNode myFocusNode = Focus();
    print("<PICTURE DETAIL PAGE ======= >");

    int currentSwiperImgIndex = 0;
    if (widget.commentScreen == true) {
      return AlertDialog(
        insetPadding: kIsWeb
            ? EdgeInsets.symmetric(horizontal: 40.0, vertical: 24.0)
            : EdgeInsets.symmetric(horizontal: 0.0, vertical: 0.0),
        titlePadding: EdgeInsets.zero,
        title: Row(
          children: [
            IconButton(
              onPressed: () {
                Navigator.of(context).pop();
                widget.post.reactionCheck.value = false;
              },
              icon: Actions(
                actions: {
                  EscIntent: CallbackAction<EscIntent>(
                      onInvoke: (Intent) => Navigator.of(context).pop()),
                },
                child: Focus(
                  // focusNode: focus,
                  autofocus: true,
                  child: Icon(Icons.close, color: Colors.white),
                ),
              ),
            ),
            const Spacer(),
            !kIsWeb ? IconButton(
              onPressed: () async{
                saveAsImageAndShare(widget.imagesListForCarousel[currentSwiperImgIndex]);
              },
              icon: Icon(
                Icons.share_outlined, size: 20, color: Theme
                  .of(context)
                  .brightness == Brightness.dark
                  ? Colors.white
                  : Colors.grey,),
            ) : SizedBox(),
          ],
        ),
        backgroundColor: Colors.black,
        contentPadding: EdgeInsets.zero,
        content: kIsWeb
            ? Stack(
          children: [
            Container(
              color: Colors.black,
              width: Get.width,
              height: kIsWeb ? Get.height : Get.height,
              child: Stack(
                children: [
                  Swiper(
                    onIndexChanged: (index) => currentSwiperImgIndex = index,
                    loop: false,
// layout: SwiperLayout.TINDER,
                    index: widget.mediaIndex,
                    containerWidth: kIsWeb ? Get.width * 0.4 : Get.width,
                    itemWidth: kIsWeb ? Get.width * 0.4 : Get.width,
                    itemBuilder: (BuildContext context, int index) {
                      return widget.imagesListForCarousel != null
                          ? Center(
                        child: InteractiveViewer(
                          minScale: 0.0001,
                          maxScale: 0.0001,
                          child: Image.network(
                            widget.imagesListForCarousel[index],
                            fit: BoxFit.contain,
                            height:
                            kIsWeb ? Get.height : Get.height,
                            width: kIsWeb
                                ? Get.width * 0.4
                                : Get.width,
                          ),
                        ),
                      )
                          : SizedBox();
                      // : ChewieVideoPlayer(
                      // videoUrl: widget.videoListForCarousel[index]);
                    },
                    itemCount: widget.imagesListForCarousel != null
                        ? widget.imagesListForCarousel.length
                        : widget.videoListForCarousel.length,
                    control: SwiperControl(
                      padding: EdgeInsets.only(left: 28, right: 20),
                      size: 50,
                      color: Color(0xFFedab30),
                    ),
                  ),

                  ///

                  widget.chatCheck != 1 ?
                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        alignment: Alignment.center,
                        width: Get.width * 0.4,
                        height: 74,
                        color: Colors.black87,
                        // margin: EdgeInsets.symmetric(horizontal: 20),
                        ///reaction row
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: 20, right: 20, bottom: 20),
                          child: Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() {
                                return Row(
                                  children: [
                                    SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: Tooltip(
                                        message: 'React',
                                        child: InkWell(
                                          onLongPress: () {},
                                          onTap: () async {
                                            if (widget.post
                                                .reactionCheck ==
                                                false) {
                                              if (widget.check == 1) {} else {
                                                widget.postList
                                                    .forEach(
                                                        (element) {
                                                      element
                                                          .reactionCheck
                                                          .value = false;
                                                    });
                                                widget
                                                    .post
                                                    .reactionCheck
                                                    .value = true;

                                                
                                              }
                                            } else if (widget.post
                                                .reactionCheck ==
                                                true) {
                                              widget
                                                  .post
                                                  .reactionCheck
                                                  .value = false;

                                            }

                                            // post.reactionCheck.value = false;
                                            // if(post.like.value == true)
                                            //   {
                                            //
                                            //
                                            //     post.reactionType.value = "like_simple_like";
                                            //   }
                                            // else if(post.like.value == false)
                                            //   {
                                            //     post.reactionType.value = "dislike_simple_dislike";
                                            //   }
                                            //
                                            // controller.likeUnlike(
                                            //   post.reactionType.value,
                                            //   post.postId,
                                            //   {
                                            //     'isLikedSocket': post.like.value,
                                            //     'totalLikes': post.likeCount.value
                                            //   },
                                            // );
                                            //
                                            // // ignore: unused_local_variable
                                            // 
                                            // if (post.like.value) {
                                            //   post.like.value = false;
                                            //
                                            //   if (post.likeCount.value > 0) {
                                            //     // post.likeCount.value--;
                                            //   } else {
                                            //     post.likeCount.value = 0;
                                            //   }
                                            //
                                            //   post.likeCount.refresh();
                                            //   // controller.update();
                                            //   print(
                                            //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                            // }
                                            // else {
                                            //   post.like.value = true;
                                            //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                            //   // post.simpleLikeCount++;
                                            //   // post.likeCount.value++;
                                            //   post.likeCount.refresh();
                                            //   // controller.update();
                                            // }
                                            // // ignore: unused_local_variable
                                            //
                                            //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                            //
                                            // // if (await UtilsMethods.checkInternet()) {
                                            // //
                                            // //   //   log('like response>>> $response'); //number of likes
                                            // //   //   var  postDetails= post;
                                            // //   //   postDetails.likeCount.value=response;
                                            // //   // var dbRes = await  DatabaseHelper.instance
                                            // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                            // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                            // // }
                                            // controller.postIndex = index;
                                            // controller.update();
                                          },
                                          child: widget
                                              .post
                                              .reactionType
                                              .value ==
                                              "love"
                                              ? Image.asset(
                                            'assets/reaction_gif/love-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget
                                              .post
                                              .reactionType
                                              .value ==
                                              "like_simple_like"
                                              ? Image.asset(
                                            'assets/reaction_gif/like-min.png',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget
                                              .post
                                              .reactionType
                                              .value ==
                                              null
                                              ? Image.asset(
                                            'assets/drawer_icons/not_like.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 25,
                                            height: 25,
                                            color: Colors
                                                .white,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "lough"
                                              ? Image
                                              .asset(
                                            'assets/reaction_gif/laugh-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width:
                                            30,
                                            height:
                                            30,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "smile"
                                              ? Image
                                              .asset(
                                            'assets/reaction_gif/smile-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width:
                                            30,
                                            height:
                                            30,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "thanks"
                                              ? Image.asset(
                                            'assets/reaction_gif/thanks-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget.post.reactionType
                                              .value == "excited"
                                              ? Image.asset(
                                            'assets/reaction_gif/excited-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget.post.reactionType
                                              .value == "cry"
                                              ? Image.asset(
                                            'assets/reaction_gif/cry-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : Image.asset(
                                            'assets/drawer_icons/not_like.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 25,
                                            height: 25,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    GestureDetector(
                                      onTap: () async {
                                        // List<Reaction1> data =
                                        // await widget
                                        //     .controller
                                        //     .getWhoReacted(widget.post.postId);
                                        // // 
                                        // showDialog(
                                        //     context: context,
                                        //     builder: (context) {
                                        //       return ReactRetweetDialog(
                                        //         'People who reacted',
                                        //         // reactions: data,
                                        //       );
                                        //     });

                                        if (kIsWeb) {
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return ReactRetweetDialog(
                                                  'People who reacted',
                                                  post: widget.post,

                                                  // reactions: data,
                                                );
                                              });

                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget
                                                  .post.postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        } else {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ReactRetweetDialog(
                                                      'People who reacted',
                                                      post: widget
                                                          .post,
                                                      // reactions: data,
                                                    )),
                                          );
                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget
                                                  .post.postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        }
                                      },
                                      child: Container(
                                        padding: const EdgeInsets
                                            .symmetric(
                                          horizontal: 5,
                                          vertical: 1,
                                        ),
                                        // decoration: BoxDecoration(
                                        //   color: Colors.grey[100],
                                        //   borderRadius: BorderRadius.circular(20),
                                        // ),
                                        child: Text(
                                          "${widget.post.likeCount.value}",
                                          // style: TextStyle(
                                          //   color: Colors.grey[600],
                                          //   fontSize: 14,
                                          // ),
                                          style: Styles.baseTextTheme.headline2
                                              .copyWith(
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              }),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  Tooltip(
                                    message: 'Reply',
                                    child: InkWell(
                                      onTap: () {
                                        if (!kIsWeb) {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                      CommentsScreen(
                                                          postId: widget
                                                              .post
                                                              .postId)));
                                          widget.controller.postId =
                                              widget.post.postId;
                                          // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                          //   "postId": post.postId,
                                          //   "controller": controller
                                          // });
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (BuildContext context) => CommentsScreen(),
                                          //   ),
                                          // );
                                        } else {
                                          widget.postList
                                              .forEach((element) {
                                            element.isComment
                                                .value = false;
                                          });
                                          // controller.postIndex = ;
                                          widget.post.isComment
                                              .value = true;
                                          Navigator.of(context)
                                              .pop();
                                          // controller.getNewsFeed(reload: false);
                                          // controller.update();
                                          // controller.isCommentClick = false;
                                          if (Get.isRegistered<
                                              BrowseController>()) {
                                            if (Get
                                                .find<
                                                BrowseController>()
                                                .browsePostList
                                                .isNotEmpty &&
                                                Get
                                                    .find<BrowseController>()
                                                    .browsePostList
                                                    .length >
                                                    0) {
                                              Get
                                                  .find<
                                                  BrowseController>()
                                                  .browsePostList
                                                  .forEach(
                                                      (element) {
                                                    element.isComment
                                                        .value = false;
                                                  });
                                              // controller.postIndex = ;
                                              widget.post.isComment
                                                  .value = true;
                                            }
                                          }
                                        }
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: Icon(
                                          Icons.mode_comment_outlined, size: 20,
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.grey,),
                                        // Icon(Icons.comment_outlined,
                                        //     color: post.isRetweeted
                                        //         ? Theme.of(context).iconTheme.color
                                        //         : Colors.grey)
                                        // Text(
                                        //   Strings.comments,
                                        //   style: Theme.of(context).textTheme.bodyText2,
                                      ),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () async {
                                      // List<Retweet> data =
                                      //     await controller.getWhoRetweeted(post.postId);
                                      // 
                                      // showDialog(
                                      //     context: context,
                                      //     builder: (context) {
                                      //       return ReactRetweetDialog(
                                      //         Strings.peopleWhoRetweeted,
                                      //         retweets: data,
                                      //       );
                                      //     });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget
                                            .post.commentCount.value
                                            .toString(),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  widget.post.isRetweeted == null
                                      ? SizedBox()
                                      : Tooltip(
                                    message: Strings.rewerf,
                                    child: InkWell(
                                      onTap: widget.post
                                          .rebuzz.value
                                          ? () async {
                                        widget
                                            .controller
                                            .createDeleteBuzz(
                                            "undo_retweet",
                                            widget
                                                .post);

                                        // var response =
                                        //     await controller.undoRetweet(post.postId);
                                        // if (response == 'Undo retweeted Successfully')
                                        widget.post
                                            .isRetweeted =
                                        false;
                                        widget
                                            .post
                                            .rebuzz
                                            .value =
                                        false;
                                        // post.rebuzzCount.value--;
                                        widget.post
                                            .rebuzzCount
                                            .refresh();
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .undoRetweet(
                                            widget
                                                .post
                                                .postId);
                                        setState(() {});
                                        // controller.update();
                                      }
                                          : () async {
                                        widget.controller.createDeleteBuzz(
                                            "retweet",
                                            widget
                                                .post);
                                        // var response =
                                        //     await controller.addRetweet(post.postId);
                                        // if (response == 'Add retweet Successfully')
                                        widget.post
                                            .isRetweeted =
                                        true;
                                        // post.rebuzzCount.value++;
                                        widget.post
                                            .rebuzzCount
                                            .refresh();
                                        widget
                                            .post
                                            .rebuzz
                                            .value =
                                        true;
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .addRetweet(
                                            widget
                                                .post
                                                .postId);
                                        setState(() {});
                                        // controller.update();
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: Icon(
                                          Icons.repeat, size: 20, color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.grey,),
                                      ),
                                      // Icon(Icons.repeat,Ftext
                                      //     color: post.isRetweeted
                                      //         ? Theme.of(context).iconTheme.color
                                      //         : Colors.grey),
                                    ),
                                  ),
                                  // Text(
                                  //   Strings.reBuzz,
                                  //   style: Theme.of(context).textTheme.bodyText2,
                                  // ),
                                  GestureDetector(
                                    onTap: () async {
                                      List<Retweet> data =
                                      await widget.controller
                                          .getWhoRetweeted(
                                          widget
                                              .post.postId);
                                      
                                      showDialog(
                                          context: context,
                                          builder: (context) {
                                            return ReactRetweetDialog(
                                              Strings
                                                  .peopleWhoRetweeted,
                                              retweets: data,
                                            );
                                          });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget.post.rebuzzCount.value
                                            .toString(),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),


                              PopupMenuButton(
                                  tooltip: "Share",
                                  position: PopupMenuPosition.under,
                                  padding: EdgeInsets.zero,
                                  icon: Icon(
                                    Icons.share_outlined, size: 20, color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.grey,),

                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark ? Colors
                                      .black : Colors.white,
                                  // Callback that sets the selected popup menu item.
                                  onSelected: (value) async {
                                    if (value == 1) {
                                      // ignore: unused_local_variable
                                      bool isSuccess = await widget.controller
                                          .savePost(widget.post.postId);
                                      if (isSuccess) {
                                        widget.post.saved = true;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'Werf saved successfully!');
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in saving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in saving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme
                                        //           .of(context)
                                        //           .brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }

                                      // Get.showSnackbar(buildSnackBar(
                                      //     isSuccess
                                      //         ? 'Your Update is saved Successfull'
                                      //         : 'An Error Occured While Saving your update',
                                      //     context));
                                      // controller.update();
                                    }
                                    else if (value == 2) {
                                      bool isSuccess = await widget.controller
                                          .unSavePost(widget.post.postId);


                                      if (isSuccess) {
                                        widget.post.saved = false;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.werfUnsaved);
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in Unsaving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in Unsaving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme.of(context).brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }
                                    }
//done
                                    else if (value == 3) {
                                      // kIsWeb ?
                                      // showReposrtUserDialog(
                                      //     context, post.authorId.toString(), controller) :

                                      // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                      String genterate = 'https://werfie.com/home/postDetail/' +
                                          widget.post.postId.toString();
                                      // toStringpost.postId.toString());

                                      // UtilsMethods.share(genterate, 'Werf');


                                      Clipboard.setData(
                                          ClipboardData(text: genterate)).then((
                                          _) {
                                        Fluttertoast.showToast(
                                            msg: 'Werf link copied successfully',
                                            toastLength:
                                            Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.TOP,
                                            timeInSecForIosWeb:
                                            1,
                                            backgroundColor: widget.controller
                                                .displayColor,

                                            textColor: Colors.white,
                                            webPosition: "center",
                                            webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                            fontSize: 16.0);
                                      });

                                      // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                      // UtilsMethods.share(
                                      //     genterate,
                                      //     'post');
                                      // print('post Id at share' + post.postId.toString());
                                      // print('linkgenerate:${genterate}');


                                      // UtilsMethods.toastMessageShow(
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     message: 'Werf link copied successfully');


                                      widget.controller.update();
                                    }
                                    else if (value == 4) {
                                      if (!kIsWeb) {
                                        // kIsWeb ?
                                        // showReposrtUserDialog(
                                        //     context, post.authorId.toString(), controller) :

                                        String genterate = await FirebaseDeepLink()
                                            .createDynamicLink(
                                            short: true, link: '/post?postId=' +
                                            widget.post.postId.toString());

                                        UtilsMethods.share(genterate, 'Werf');


                                        // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                        // UtilsMethods.share(
                                        //     genterate,
                                        //     'post');
                                        // print('post Id at share' + post.postId.toString());
                                        // print('linkgenerate:${genterate}');


                                        widget.controller.update();
                                      }
                                      else {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.shareWerf);
                                      }
                                    }
                                  },
                                  itemBuilder: (BuildContext context) =>
                                  [
                                    if(widget.post.saved == false ||
                                        widget.post.saved == null)
                                      PopupMenuItem(
                                        value: 1,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text(Strings.bookmark,
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    if(widget.post.saved == true)
                                      PopupMenuItem(
                                        value: 2,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text(Strings.removeWerfFromBookMark,
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    PopupMenuItem(
                                      value: 3,
                                      child: Row(
                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: Image.asset(
                                                  AppImages.copylink,
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5),
                                            Text(
                                              Strings.copylinkToWerf,
                                              style:
                                              TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),),
                                          ]),),
                                    if(!kIsWeb)

                                      PopupMenuItem(
                                        value: 4,
                                        child: Row(
                                            children: [
                                              Container(
                                                  width: 20,
                                                  height: 20,
                                                  child: Image.asset(
                                                    AppImages.share,
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  )
                                              ),
                                              SizedBox(width: 5),
                                              Text(
                                                Strings.shareWerf,
                                                style:
                                                TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors
                                                        .black,
                                                    fontSize: 14
                                                ),),
                                            ]),),
                                  ]
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                      : SizedBox()
                ],
              ),
            ),


            widget.chatCheck != 1
                ? Obx(() {
              return GestureDetector(
                onTap: () {
                  widget.post.reactionCheck.value = false;
                },
                child: Container(
                  color: Colors.black,
                  width: Get.width,
                  height: kIsWeb ? Get.height : Get.height,
                  child: Stack(
                    children: [
                      Swiper(
                        onIndexChanged: (index) => currentSwiperImgIndex = index,
                        loop: false,
// layout: SwiperLayout.TINDER,
                        index: widget.mediaIndex,
                        containerWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemBuilder:
                            (BuildContext context, int index) {
                          return widget.imagesListForCarousel != null
                              ? Center(
                            child: InteractiveViewer(
                              minScale: 0.0001,
                              maxScale: 0.0001,
                              child: Image.network(
                                widget.imagesListForCarousel[
                                index],
                                fit: BoxFit.contain,
                                height: kIsWeb
                                    ? Get.height
                                    : Get.height,
                                width: kIsWeb
                                    ? Get.width * 0.4
                                    : Get.width,
                              ),
                            ),
                          )
                              : SizedBox();
                          // : ChewieVideoPlayer(
                          // videoUrl: widget.videoListForCarousel[index]);
                        },
                        itemCount:
                        widget.imagesListForCarousel != null
                            ? widget.imagesListForCarousel.length
                            : widget.videoListForCarousel.length,
                        control: SwiperControl(
                          padding:
                          EdgeInsets.only(left: 28, right: 20),
                          size: 50,
                          color: Color(0xFFedab30),
                        ),
                      ),
                      widget.chatCheck != 1
                          ? Positioned.fill(
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            alignment: Alignment.center,
                            width: Get.width * 0.4,
                            height: 74,
                            color: Colors.black87,
                            // margin: EdgeInsets.symmetric(horizontal: 20),
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: 20,
                                  right: 20,
                                  bottom: 20),

                              ///reaction row for web
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .spaceBetween,
                                children: [
                                  Obx(() {
                                    return Row(
                                      children: [
                                        Tooltip(
                                          message: 'React',
                                          child: InkWell(
                                            onLongPress: () {},
                                            onTap: () async {
                                              print('sdfsdf');
                                              if (widget.post.reactionCheck ==
                                                  false) {
                                                if (widget.check == 1) {

                                                }
                                                else {
                                                  widget.postList.forEach((
                                                      element) {
                                                    element.reactionCheck
                                                        .value = false;
                                                  });
                                                  widget.post.reactionCheck
                                                      .value = true;


                                                }
                                              } else
                                              if (widget.post.reactionCheck ==
                                                  true) {
                                                widget.post.reactionCheck
                                                    .value = false;

                                              }

                                              // post.reactionCheck.value = false;
                                              // if(post.like.value == true)
                                              //   {
                                              //
                                              //
                                              //     post.reactionType.value = "like_simple_like";
                                              //   }
                                              // else if(post.like.value == false)
                                              //   {
                                              //     post.reactionType.value = "dislike_simple_dislike";
                                              //   }
                                              //
                                              // controller.likeUnlike(
                                              //   post.reactionType.value,
                                              //   post.postId,
                                              //   {
                                              //     'isLikedSocket': post.like.value,
                                              //     'totalLikes': post.likeCount.value
                                              //   },
                                              // );
                                              //
                                              // // ignore: unused_local_variable
                                              // 
                                              // if (post.like.value) {
                                              //   post.like.value = false;
                                              //
                                              //   if (post.likeCount.value > 0) {
                                              //     // post.likeCount.value--;
                                              //   } else {
                                              //     post.likeCount.value = 0;
                                              //   }
                                              //
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              //   print(
                                              //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                              // }
                                              // else {
                                              //   post.like.value = true;
                                              //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                              //   // post.simpleLikeCount++;
                                              //   // post.likeCount.value++;
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              // }
                                              // // ignore: unused_local_variable
                                              //
                                              //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                              //
                                              // // if (await UtilsMethods.checkInternet()) {
                                              // //
                                              // //   //   log('like response>>> $response'); //number of likes
                                              // //   //   var  postDetails= post;
                                              // //   //   postDetails.likeCount.value=response;
                                              // //   // var dbRes = await  DatabaseHelper.instance
                                              // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                              // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                              // // }
                                              // controller.postIndex = index;
                                              // controller.update();
                                            },
                                            child: widget
                                                .post
                                                .reactionType
                                                .value ==
                                                "love"
                                                ? Image.asset(
                                              'assets/reaction_gif/love-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "like_simple_like"
                                                ? Image
                                                .asset(
                                              'assets/reaction_gif/like-min.png',
                                              width:
                                              30,
                                              height:
                                              30,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                null
                                                ? Image
                                                .asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width:
                                              25,
                                              height:
                                              25,
                                              color:
                                              Colors.white,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "lough"
                                                ? Image.asset(
                                              'assets/reaction_gif/laugh-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "smile"
                                                ? Image.asset(
                                              'assets/reaction_gif/smile-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "thanks"
                                                ? Image.asset(
                                              'assets/reaction_gif/thanks-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "excited"
                                                ? Image.asset(
                                              'assets/reaction_gif/excited-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "cry"
                                                ? Image.asset(
                                              'assets/reaction_gif/cry-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : Image.asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 25,
                                              height: 25,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 5),
                                        GestureDetector(
                                          onTap: () async {
                                            // List<Reaction1> data =
                                            // await widget
                                            //     .controller
                                            //     .getWhoReacted(widget.post.postId);
                                            // // 
                                            // showDialog(
                                            //     context: context,
                                            //     builder: (context) {
                                            //       return ReactRetweetDialog(
                                            //         'People who reacted',
                                            //         // reactions: data,
                                            //       );
                                            //     });

                                            if (kIsWeb) {
                                              showDialog(
                                                  context:
                                                  context,
                                                  builder:
                                                      (context) {
                                                    return ReactRetweetDialog(
                                                      'People who reacted',
                                                      post: widget
                                                          .post,

                                                      // reactions: data,
                                                    );
                                                  });

                                              // List<Reaction1> data =
                                              await widget
                                                  .controller
                                                  .getWhoReacted(
                                                  widget
                                                      .post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes:
                                                  0);
                                            } else {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder:
                                                        (context) =>
                                                        ReactRetweetDialog(
                                                          'People who reacted',
                                                          post: widget.post,
                                                          // reactions: data,
                                                        )),
                                              );
                                              // List<Reaction1> data =
                                              await widget
                                                  .controller
                                                  .getWhoReacted(
                                                  widget
                                                      .post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes:
                                                  0);
                                            }
                                          },
                                          child: Container(
                                            padding:
                                            const EdgeInsets
                                                .symmetric(
                                              horizontal: 5,
                                              vertical: 1,
                                            ),
                                            // decoration: BoxDecoration(
                                            //   color: Colors.grey[100],
                                            //   borderRadius: BorderRadius.circular(20),
                                            // ),
                                            child: Text(
                                              "${widget.post.likeCount.value}",
                                              // style: TextStyle(
                                              //   color: Colors.grey[600],
                                              //   fontSize: 14,
                                              // ),
                                              style: Styles.baseTextTheme
                                                  .headline2.copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  }),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      Tooltip(
                                        message: 'Reply',
                                        child: InkWell(
                                          onTap: () {
                                            if (!kIsWeb) {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (BuildContext
                                                      context) =>
                                                          CommentsScreen(
                                                              postId: widget
                                                                  .post
                                                                  .postId)));
                                              widget.controller
                                                  .postId =
                                                  widget.post
                                                      .postId;
                                              // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                              //   "postId": post.postId,
                                              //   "controller": controller
                                              // });
                                              // Navigator.push(
                                              //   context,
                                              //   MaterialPageRoute(
                                              //     builder: (BuildContext context) => CommentsScreen(),
                                              //   ),
                                              // );
                                            } else {
                                              widget.postList.forEach(
                                                      (element) {
                                                    element.isComment
                                                        .value =
                                                    false;
                                                  });
                                              // controller.postIndex = ;
                                              widget
                                                  .post
                                                  .isComment
                                                  .value = true;
                                              Navigator.of(
                                                  context)
                                                  .pop();
                                              // controller.getNewsFeed(reload: false);
                                              // controller.update();
                                              // controller.isCommentClick = false;
                                              if (Get.isRegistered<
                                                  BrowseController>()) {
                                                if (Get
                                                    .find<
                                                    BrowseController>()
                                                    .browsePostList
                                                    .isNotEmpty &&
                                                    Get
                                                        .find<
                                                        BrowseController>()
                                                        .browsePostList
                                                        .length >
                                                        0) {
                                                  Get
                                                      .find<
                                                      BrowseController>()
                                                      .browsePostList
                                                      .forEach(
                                                          (element) {
                                                        element
                                                            .isComment
                                                            .value = false;
                                                      });
                                                  // controller.postIndex = ;
                                                  widget
                                                      .post
                                                      .isComment
                                                      .value = true;
                                                }
                                              }
                                            }
                                          },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            child:
                                            new Image.asset(
                                              'assets/drawer_icons/comments.png',

                                              // post.isRetweeted
                                              //     ? Theme.of(context).iconTheme.color
                                              //     :

                                              color:
                                              Colors.white,
                                            ),
                                            // Icon(Icons.comment_outlined,
                                            //     color: post.isRetweeted
                                            //         ? Theme.of(context).iconTheme.color
                                            //         : Colors.grey)
                                            // Text(
                                            //   Strings.comments,
                                            //   style: Theme.of(context).textTheme.bodyText2,
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          // List<Retweet> data =
                                          //     await controller.getWhoRetweeted(post.postId);
                                          // 
                                          // showDialog(
                                          //     context: context,
                                          //     builder: (context) {
                                          //       return ReactRetweetDialog(
                                          //         Strings.peopleWhoRetweeted,
                                          //         retweets: data,
                                          //       );
                                          //     });
                                        },
                                        child: Container(
                                          padding:
                                          const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget
                                                .post
                                                .commentCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      widget.post.isRetweeted ==
                                          null
                                          ? SizedBox()
                                          : Tooltip(
                                        message: Strings.rewerf,
                                        child: InkWell(
                                          onTap: widget.post.rebuzz.value
                                              ? () async {
                                            widget.controller.createDeleteBuzz(
                                                "undo_retweet",
                                                widget.post);

                                            // var response =
                                            //     await controller.undoRetweet(post.postId);
                                            // if (response == 'Undo retweeted Successfully')
                                            widget
                                                .post
                                                .isRetweeted = false;
                                            widget
                                                .post
                                                .rebuzz
                                                .value = false;
                                            // post.rebuzzCount.value--;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .undoRetweet(
                                                widget.post.postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          }
                                              : () async {
                                            widget.controller.createDeleteBuzz(
                                                "retweet",
                                                widget.post);
                                            // var response =
                                            //     await controller.addRetweet(post.postId);
                                            // if (response == 'Add retweet Successfully')
                                            widget
                                                .post
                                                .isRetweeted = true;
                                            // post.rebuzzCount.value++;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            widget
                                                .post
                                                .rebuzz
                                                .value = true;
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .addRetweet(widget.post.postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          },
                                          child:
                                          Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              'assets/drawer_icons/rebuzz.png',
                                              color: widget.post.rebuzz.value
                                                  ? Colors.white
                                                  : Colors
                                                  .white,
                                            ),
                                          ),
                                          // Icon(Icons.repeat,Ftext
                                          //     color: post.isRetweeted
                                          //         ? Theme.of(context).iconTheme.color
                                          //         : Colors.grey),
                                        ),
                                      ),
                                      // Text(
                                      //   Strings.reBuzz,
                                      //   style: Theme.of(context).textTheme.bodyText2,
                                      // ),
                                      GestureDetector(
                                        onTap: () async {
                                          List<Retweet> data =
                                          await widget
                                              .controller
                                              .getWhoRetweeted(
                                              widget
                                                  .post
                                                  .postId);
                                          
                                          showDialog(
                                              context: context,
                                              builder:
                                                  (context) {
                                                return ReactRetweetDialog(
                                                  Strings
                                                      .peopleWhoRetweeted,
                                                  retweets:
                                                  data,
                                                );
                                              });
                                        },
                                        child: Container(
                                          padding:
                                          const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget
                                                .post
                                                .rebuzzCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  PopupMenuButton(
                                      tooltip: "Share",
                                      position: PopupMenuPosition.under,
                                      padding: EdgeInsets.zero,
                                      icon: Image.asset(
                                        AppImages.share,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.white,
                                        height: 25,
                                        width: 25,
                                      ),

                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.black
                                          : Colors.white,
                                      // Callback that sets the selected popup menu item.
                                      onSelected: (value) async {
                                        if (value == 1) {
                                          // ignore: unused_local_variable
                                          bool isSuccess = await widget
                                              .controller.savePost(
                                              widget.post.postId);
                                          if (isSuccess) {
                                            widget.post.saved = true;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'Werf saved successfully!');
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in saving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in saving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme
                                            //           .of(context)
                                            //           .brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }

                                          // Get.showSnackbar(buildSnackBar(
                                          //     isSuccess
                                          //         ? 'Your Update is saved Successfull'
                                          //         : 'An Error Occured While Saving your update',
                                          //     context));
                                          // controller.update();
                                        }
                                        else if (value == 2) {
                                          bool isSuccess = await widget
                                              .controller.unSavePost(
                                              widget.post.postId);


                                          if (isSuccess) {
                                            widget.post.saved = false;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: Strings.werfUnsaved);
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in Unsaving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in Unsaving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme.of(context).brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }
                                        }

                                        else if (value == 3) {
                                          // kIsWeb ?
                                          // showReposrtUserDialog(
                                          //     context, post.authorId.toString(), controller) :

                                          // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                          String genterate = 'https://werfie.com/home/postDetail/' +
                                              widget.post.postId.toString();
                                          // toStringpost.postId.toString());

                                          // UtilsMethods.share(genterate, 'Werf');


                                          Clipboard.setData(
                                              ClipboardData(text: genterate))
                                              .then((_) {
                                            Fluttertoast.showToast(
                                                msg: 'Werf link copied successfully',
                                                toastLength:
                                                Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.TOP,
                                                timeInSecForIosWeb:
                                                1,
                                                backgroundColor: widget
                                                    .controller.displayColor,

                                                textColor: Colors.white,
                                                webPosition: "center",
                                                webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                                fontSize: 16.0);
                                          });

                                          // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                          // UtilsMethods.share(
                                          //     genterate,
                                          //     'post');
                                          // print('post Id at share' + post.postId.toString());
                                          // print('linkgenerate:${genterate}');


                                          // UtilsMethods.toastMessageShow(
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     message: 'Werf link copied successfully');


                                          widget.controller.update();
                                        }
                                        else if (value == 4) {
                                          if (!kIsWeb) {
                                            // kIsWeb ?
                                            // showReposrtUserDialog(
                                            //     context, post.authorId.toString(), controller) :

                                            String genterate = await FirebaseDeepLink()
                                                .createDynamicLink(short: true,
                                                link: '/post?postId=' +
                                                    widget.post.postId
                                                        .toString());

                                            UtilsMethods.share(
                                                genterate, 'Werf');


                                            // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                            // UtilsMethods.share(
                                            //     genterate,
                                            //     'post');
                                            // print('post Id at share' + post.postId.toString());
                                            // print('linkgenerate:${genterate}');


                                            widget.controller.update();
                                          }
                                          else {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: Strings.shareWerf);
                                          }
                                        }
                                      },
                                      itemBuilder: (BuildContext context) =>
                                      [
                                        if(widget.post.saved == false ||
                                            widget.post.saved == null)
                                          PopupMenuItem(
                                            value: 1,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text('Bookmark',
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        if(widget.post.saved == true)
                                          PopupMenuItem(
                                            value: 2,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text(
                                                  Strings.removeWerfFromBookMark,
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        PopupMenuItem(
                                          value: 3,
                                          child: Row(
                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: Image.asset(
                                                      AppImages.copylink,
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5),
                                                Text(
                                                  Strings.copylinkToWerf,
                                                  style:
                                                  TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),),
                                              ]),),
                                        if(!kIsWeb)

                                          PopupMenuItem(
                                            value: 4,
                                            child: Row(
                                                children: [
                                                  Container(
                                                      width: 20,
                                                      height: 20,
                                                      child: Image.asset(
                                                        AppImages.share,
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                      )
                                                  ),
                                                  SizedBox(width: 5),
                                                  Text(
                                                    Strings.shareWerf,
                                                    style:
                                                    TextStyle(
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors
                                                            .black,
                                                        fontSize: 14
                                                    ),),
                                                ]),),
                                      ]
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                          : SizedBox()
                    ],
                  ),

                  // CarouselSlider(
                  //   options: CarouselOptions(
                  //     enableInfiniteScroll: false,
                  //   ),
                  //   items: imagesListForCarousel
                  //       .map(
                  //         (item) => Container(
                  //           child: Center(
                  //             child: Image.network(
                  //               item,
                  //               fit: BoxFit.fill,
                  //               width: Get.width * 0.4,
                  //             ),
                  //           ),
                  //         ),
                  //       )
                  //       .toList(),
                  // ),
                ),
              );
            })
                : SizedBox(),


            widget.chatCheck != 1
                ? Obx(() {
              return widget.post.reactionCheck.value == true
                  ? Positioned(
                bottom: 60,
                left: kIsWeb ? 180 : 20,
                child: Container(
                  height: 45,
                  width: 260,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(50),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(
                            0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          // print("raection print idhr ");


                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            // print("totalLikesxx: ${ widget.post.likeCount
                            //     .value}");
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          if (widget.post.reactionType.value ==
                              'like_simple_like') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "like_simple_like";
                          }

                          // post.reactionType.value = 'like_simple_like';

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }


                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.like,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            // print("totalLikesxx: ${ widget.post.likeCount
                            //     .value}");
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'love') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "love";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          // print("controller.counter ${controller.counter}");
                          // if(controller.counter == false)
                          // {
                          //   post.reactionType.value = null;
                          //
                          // }

                          // controller.update();

                          // controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.love,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            // print("totalLikesxx: ${ widget.post.likeCount
                            //     .value}");
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'lough') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "lough";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.lough,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            // print("totalLikesxx: ${ widget.post.likeCount
                            //     .value}");
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'excited') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "excited";
                          }


                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                            // print(
                            //     "totalLikes: ${ widget.post.likeCount.value}");
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.excited,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            // print("totalLikesxx: ${ widget.post.likeCount
                            //     .value}");
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'thanks') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "thanks";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                            // print(
                            //     "totalLikes: ${ widget.post.likeCount.value}");
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.thanks,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'cry') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "cry";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.cry,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'smile') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'cry' ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love") {
                            widget.post.reactionType.value =
                            "smile";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.smile,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                    ],
                  ),
                ),
              )
                  : SizedBox();
            })
                : SizedBox()
          ],
        )
            : Stack(
          children: [
            Container(
              color: Colors.black,
              width: Get.width,
              height: kIsWeb ? Get.height : Get.height,
              child: Stack(
                children: [
                  widget.imagesListForCarousel != null
                      ? widget.imagesListForCarousel.length >= 2
                      ? Swiper(
                    onIndexChanged: (index) => currentSwiperImgIndex = index,
                    loop: false,
                    index: widget.mediaIndex,
                    containerWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return widget.imagesListForCarousel !=
                          null
                          ? Center(
                        child: InteractiveViewer(
                          minScale: 0.0001,
                          maxScale: 0.0001,
                          child: Image.network(
                            widget.imagesListForCarousel[
                            index],
                            fit: BoxFit.contain,
                            height: kIsWeb
                                ? Get.height
                                : Get.height,
                            width: kIsWeb
                                ? Get.width * 0.4
                                : Get.width,
                          ),
                        ),
                      )
                          : SizedBox();
                      // : ChewieVideoPlayer(
                      // videoUrl: widget.videoListForCarousel[index]);
                    },
                    itemCount: widget.imagesListForCarousel !=
                        null
                        ? widget.imagesListForCarousel.length
                        : widget.videoListForCarousel.length,

                    pagination: SwiperPagination(
                      builder: FractionPaginationBuilder(
                        activeColor: Colors.amber,
                        fontSize: 18,
                        activeFontSize: 18,
                      ),
                      alignment: Alignment.topCenter,
                    ),
                    // control: SwiperControl(
                    //   padding: EdgeInsets.only(left: 28, right: 20),
                    //   size: 50,
                    //   color: Color(0xFFedab30),
                    // ),
                  )
                      : Swiper(
                    onIndexChanged: (index) => currentSwiperImgIndex = index,
                    loop: false,
                    index: widget.mediaIndex,
                    containerWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return widget.imagesListForCarousel !=
                          null
                          ? Center(
                        child: InteractiveViewer(
                          minScale: 0.0001,
                          maxScale: 0.0001,
                          child: Image.network(
                            widget.imagesListForCarousel[
                            index],
                            fit: BoxFit.contain,
                            height: kIsWeb
                                ? Get.height
                                : Get.height,
                            width: kIsWeb
                                ? Get.width * 0.4
                                : Get.width,
                          ),
                        ),
                      )
                          : SizedBox()
                      // ChewieVideoPlayer(
                      //     videoUrl: widget.videoListForCarousel[index])
                          ;
                    },
                    itemCount: widget.imagesListForCarousel !=
                        null
                        ? widget.imagesListForCarousel.length
                        : widget.videoListForCarousel.length,

                    // control: SwiperControl(
                    //   padding: EdgeInsets.only(left: 28, right: 20),
                    //   size: 50,
                    //   color: Color(0xFFedab30),
                    // ),
                  )
                      : SizedBox(),
                  widget.chatCheck != 1
                      ? Positioned.fill(
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        alignment: Alignment.center,
                        width: double.infinity,
                        height: 74,
                        color: Colors.black87,
                        // margin: EdgeInsets.symmetric(horizontal: 20),


                        ///Reaction Row
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: 20, right: 20, bottom: 20),
                          child: Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() {
                                return Row(
                                  children: [
                                    SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: Tooltip(
                                        message: 'React',
                                        child: InkWell(
                                          onLongPress: () {},
                                          onTap: () async {
                                            if (widget.post
                                                .reactionCheck ==
                                                false) {
                                              if (widget.check ==
                                                  1) {} else {
                                                widget.postList
                                                    .forEach(
                                                        (element) {
                                                      element
                                                          .reactionCheck
                                                          .value = false;
                                                    });
                                                widget
                                                    .post
                                                    .reactionCheck
                                                    .value = true;
                                              }


                                            } else if (widget.post
                                                .reactionCheck ==
                                                true) {
                                              widget
                                                  .post
                                                  .reactionCheck
                                                  .value = false;

                                            }

                                            // post.reactionCheck.value = false;
                                            // if(post.like.value == true)
                                            //   {
                                            //
                                            //
                                            //     post.reactionType.value = "like_simple_like";
                                            //   }
                                            // else if(post.like.value == false)
                                            //   {
                                            //     post.reactionType.value = "dislike_simple_dislike";
                                            //   }
                                            //
                                            // controller.likeUnlike(
                                            //   post.reactionType.value,
                                            //   post.postId,
                                            //   {
                                            //     'isLikedSocket': post.like.value,
                                            //     'totalLikes': post.likeCount.value
                                            //   },
                                            // );
                                            //
                                            // // ignore: unused_local_variable
                                            // 
                                            // if (post.like.value) {
                                            //   post.like.value = false;
                                            //
                                            //   if (post.likeCount.value > 0) {
                                            //     // post.likeCount.value--;
                                            //   } else {
                                            //     post.likeCount.value = 0;
                                            //   }
                                            //
                                            //   post.likeCount.refresh();
                                            //   // controller.update();
                                            //   print(
                                            //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                            // }
                                            // else {
                                            //   post.like.value = true;
                                            //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                            //   // post.simpleLikeCount++;
                                            //   // post.likeCount.value++;
                                            //   post.likeCount.refresh();
                                            //   // controller.update();
                                            // }
                                            // // ignore: unused_local_variable
                                            //
                                            //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                            //
                                            // // if (await UtilsMethods.checkInternet()) {
                                            // //
                                            // //   //   log('like response>>> $response'); //number of likes
                                            // //   //   var  postDetails= post;
                                            // //   //   postDetails.likeCount.value=response;
                                            // //   // var dbRes = await  DatabaseHelper.instance
                                            // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                            // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                            // // }
                                            // controller.postIndex = index;
                                            // controller.update();
                                          },
                                          child: widget
                                              .post
                                              .reactionType
                                              .value ==
                                              "love"
                                              ? Image.asset(
                                            'assets/reaction_gif/love-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget
                                              .post
                                              .reactionType
                                              .value ==
                                              "like_simple_like"
                                              ? Image.asset(
                                            'assets/reaction_gif/like-min.png',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget
                                              .post
                                              .reactionType
                                              .value ==
                                              null
                                              ? Image.asset(
                                            'assets/drawer_icons/not_like.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 25,
                                            height:
                                            25,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "lough"
                                              ? Image
                                              .asset(
                                            'assets/reaction_gif/laugh-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width:
                                            30,
                                            height:
                                            30,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "smile"
                                              ? Image
                                              .asset(
                                            'assets/reaction_gif/smile-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget.post.reactionType
                                              .value == "thanks"
                                              ? Image.asset(
                                            'assets/reaction_gif/thanks-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget.post.reactionType
                                              .value == "excited"
                                              ? Image.asset(
                                            'assets/reaction_gif/excited-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget.post.reactionType
                                              .value == "cry"
                                              ? Image.asset(
                                            'assets/reaction_gif/cry-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : Image.asset(
                                            'assets/drawer_icons/not_like.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 25,
                                            height: 25,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    GestureDetector(
                                      onTap: () async {
                                        // List<Reaction1> data =
                                        // await widget.controller.getWhoReacted(widget.post.postId);
                                        // // 
                                        // showDialog(
                                        //     context: context,
                                        //     builder: (context) {
                                        //       return ReactRetweetDialog(
                                        //         'People who reacted',
                                        //         // reactions: data,
                                        //       );
                                        //     });

                                        if (kIsWeb) {
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return ReactRetweetDialog(
                                                  'People who reacted',
                                                  post:
                                                  widget.post,

                                                  // reactions: data,
                                                );
                                              });

                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget.post
                                                  .postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        } else {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ReactRetweetDialog(
                                                      'People who reacted',
                                                      post: widget
                                                          .post,
                                                      // reactions: data,
                                                    )),
                                          );
                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget.post
                                                  .postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        }
                                      },
                                      child: Container(
                                        padding: const EdgeInsets
                                            .symmetric(
                                          horizontal: 5,
                                          vertical: 1,
                                        ),
                                        // decoration: BoxDecoration(
                                        //   color: Colors.grey[100],
                                        //   borderRadius: BorderRadius.circular(20),
                                        // ),
                                        child: Text(
                                          "${widget.post.likeCount.value}",
                                          style: Styles.baseTextTheme.headline2
                                              .copyWith(
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              }),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  Tooltip(
                                    message: 'Reply',
                                    child: InkWell(
                                      onTap: () {
                                        if (!kIsWeb) {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                      CommentsScreen(
                                                          postId: widget
                                                              .post
                                                              .postId)));
                                          widget.controller
                                              .postId =
                                              widget.post.postId;
                                          // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                          //   "postId": post.postId,
                                          //   "controller": controller
                                          // });
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (BuildContext context) => CommentsScreen(),
                                          //   ),
                                          // );
                                        } else {
                                          widget.postList
                                              .forEach((element) {
                                            element.isComment
                                                .value = false;
                                          });
                                          // controller.postIndex = ;
                                          widget.post.isComment
                                              .value = true;
                                          // controller.getNewsFeed(reload: false);
                                          // controller.update();
                                          // controller.isCommentClick = false;
                                          if (Get
                                              .find<
                                              BrowseController>()
                                              .browsePostList
                                              .isNotEmpty &&
                                              Get
                                                  .find<BrowseController>()
                                                  .browsePostList
                                                  .length >
                                                  0) {
                                            Get
                                                .find<
                                                BrowseController>()
                                                .browsePostList
                                                .forEach(
                                                    (element) {
                                                  element.isComment
                                                      .value = false;
                                                });
                                            // controller.postIndex = ;
                                            widget.post.isComment
                                                .value = true;
                                          }
                                        }
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: Icon(
                                          Icons.mode_comment_outlined, size: 20,
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.grey,),
                                        // Icon(Icons.comment_outlined,
                                        //     color: post.isRetweeted
                                        //         ? Theme.of(context).iconTheme.color
                                        //         : Colors.grey)
                                        // Text(
                                        //   Strings.comments,
                                        //   style: Theme.of(context).textTheme.bodyText2,
                                      ),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () async {
                                      // List<Retweet> data =
                                      //     await controller.getWhoRetweeted(post.postId);
                                      // 
                                      // showDialog(
                                      //     context: context,
                                      //     builder: (context) {
                                      //       return ReactRetweetDialog(
                                      //         Strings.peopleWhoRetweeted,
                                      //         retweets: data,
                                      //       );
                                      //     });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget.post.commentCount
                                            .value
                                            .toString(),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  widget.post.isRetweeted == null
                                      ? SizedBox()
                                      : Tooltip(
                                    message: Strings.rewerf,
                                    child: InkWell(
                                      onTap:
                                      widget.post.rebuzz
                                          .value
                                          ? () async {
                                        widget.controller.createDeleteBuzz(
                                            "undo_retweet",
                                            widget
                                                .post);

                                        // var response =
                                        //     await controller.undoRetweet(post.postId);
                                        // if (response == 'Undo retweeted Successfully')
                                        widget.post
                                            .isRetweeted =
                                        false;
                                        widget
                                            .post
                                            .rebuzz
                                            .value = false;
                                        // post.rebuzzCount.value--;
                                        widget
                                            .post
                                            .rebuzzCount
                                            .refresh();
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .undoRetweet(widget
                                            .post
                                            .postId);
                                        setState(
                                                () {});
                                        // controller.update();
                                      }
                                          : () async {
                                        widget.controller.createDeleteBuzz(
                                            "retweet",
                                            widget
                                                .post);
                                        // var response =
                                        //     await controller.addRetweet(post.postId);
                                        // if (response == 'Add retweet Successfully')
                                        widget.post
                                            .isRetweeted =
                                        true;
                                        // post.rebuzzCount.value++;
                                        widget
                                            .post
                                            .rebuzzCount
                                            .refresh();
                                        widget
                                            .post
                                            .rebuzz
                                            .value = true;
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .addRetweet(widget
                                            .post
                                            .postId);
                                        setState(
                                                () {});
                                        // controller.update();
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: Icon(
                                          Icons.repeat, size: 20, color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.grey,),
                                      ),
                                      // Icon(Icons.repeat,Ftext
                                      //     color: post.isRetweeted
                                      //         ? Theme.of(context).iconTheme.color
                                      //         : Colors.grey),
                                    ),
                                  ),
                                  // Text(
                                  //   Strings.reBuzz,
                                  //   style: Theme.of(context).textTheme.bodyText2,
                                  // ),
                                  GestureDetector(
                                    onTap: () async {
                                      List<Retweet> data =
                                      await widget.controller
                                          .getWhoRetweeted(
                                          widget.post
                                              .postId);
                                      
                                      showDialog(
                                          context: context,
                                          builder: (context) {
                                            return ReactRetweetDialog(
                                              Strings
                                                  .peopleWhoRetweeted,
                                              retweets: data,
                                            );
                                          });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget.post.rebuzzCount
                                            .value
                                            .toString(),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              ///
                              PopupMenuButton(
                                  tooltip: "Share",
                                  position: PopupMenuPosition.under,
                                  padding: EdgeInsets.zero,
                                  icon: Icon(
                                    Icons.share_outlined, size: 20, color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.grey,),

                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark ? Colors
                                      .black : Colors.white,
                                  // Callback that sets the selected popup menu item.
                                  onSelected: (value) async {
                                    if (value == 1) {
                                      // ignore: unused_local_variable
                                      bool isSuccess = await widget.controller
                                          .savePost(widget.post.postId);
                                      if (isSuccess) {
                                        widget.post.saved = true;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'Werf saved successfully!');
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in saving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in saving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme
                                        //           .of(context)
                                        //           .brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }

                                      // Get.showSnackbar(buildSnackBar(
                                      //     isSuccess
                                      //         ? 'Your Update is saved Successfull'
                                      //         : 'An Error Occured While Saving your update',
                                      //     context));
                                      // controller.update();
                                    }
                                    else if (value == 2) {
                                      bool isSuccess = await widget.controller
                                          .unSavePost(widget.post.postId);


                                      if (isSuccess) {
                                        widget.post.saved = false;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.werfUnsaved);
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in Unsaving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in Unsaving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme.of(context).brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }
                                    }

                                    else if (value == 3) {
                                      // kIsWeb ?
                                      // showReposrtUserDialog(
                                      //     context, post.authorId.toString(), controller) :

                                      // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                      String genterate = 'https://werfie.com/home/postDetail/' +
                                          widget.post.postId.toString();
                                      // toStringpost.postId.toString());

                                      // UtilsMethods.share(genterate, 'Werf');


                                      Clipboard.setData(
                                          ClipboardData(text: genterate)).then((
                                          _) {
                                        Fluttertoast.showToast(
                                            msg: 'Werf link copied successfully',
                                            toastLength:
                                            Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.TOP,
                                            timeInSecForIosWeb:
                                            1,
                                            backgroundColor: widget.controller
                                                .displayColor,

                                            textColor: Colors.white,
                                            webPosition: "center",
                                            webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                            fontSize: 16.0);
                                      });

                                      // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                      // UtilsMethods.share(
                                      //     genterate,
                                      //     'post');
                                      // print('post Id at share' + post.postId.toString());
                                      // print('linkgenerate:${genterate}');


                                      // UtilsMethods.toastMessageShow(
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     message: 'Werf link copied successfully');


                                      widget.controller.update();
                                    }
                                    else if (value == 4) {
                                      if (!kIsWeb) {
                                        // kIsWeb ?
                                        // showReposrtUserDialog(
                                        //     context, post.authorId.toString(), controller) :

                                        String genterate = await FirebaseDeepLink()
                                            .createDynamicLink(
                                            short: true, link: '/post?postId=' +
                                            widget.post.postId.toString());

                                        UtilsMethods.share(genterate, 'Werf');


                                        // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                        // UtilsMethods.share(
                                        //     genterate,
                                        //     'post');
                                        // print('post Id at share' + post.postId.toString());
                                        // print('linkgenerate:${genterate}');


                                        widget.controller.update();
                                      }
                                      else {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.shareWerf);
                                      }
                                    }
                                  },
                                  itemBuilder: (BuildContext context) =>
                                  [
                                    if(widget.post.saved == false ||
                                        widget.post.saved == null)
                                      PopupMenuItem(
                                        value: 1,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text('Bookmark',
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    if(widget.post.saved == true)
                                      PopupMenuItem(
                                        value: 2,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text(Strings.removeWerfFromBookMark,
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    PopupMenuItem(
                                      value: 3,
                                      child: Row(
                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: Image.asset(
                                                  AppImages.copylink,
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5),
                                            Text(
                                              Strings.copylinkToWerf,
                                              style:
                                              TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),),
                                          ]),),
                                    if(!kIsWeb)

                                      PopupMenuItem(
                                        value: 4,
                                        child: Row(
                                            children: [
                                              Container(
                                                  width: 20,
                                                  height: 20,
                                                  child: Image.asset(
                                                    AppImages.share,
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  )
                                              ),
                                              SizedBox(width: 5),
                                              Text(
                                                Strings.shareWerf,
                                                style:
                                                TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors
                                                        .black,
                                                    fontSize: 14
                                                ),),
                                            ]),),
                                  ]
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                      : SizedBox()
                ],
              ),

              // CarouselSlider(
              //   options: CarouselOptions(
              //     enableInfiniteScroll: false,
              //   ),
              //   items: imagesListForCarousel
              //       .map(
              //         (item) => Container(
              //           child: Center(
              //             child: Image.network(
              //               item,
              //               fit: BoxFit.fill,
              //               width: Get.width * 0.4,
              //             ),
              //           ),
              //         ),
              //       )
              //       .toList(),
              // ),
            ),

            widget.chatCheck != 1 ?
            Obx(() {
              return GestureDetector(
                onTap: () {
                  widget.post.reactionCheck.value = false;
                },
                child: Container(
                  color: Colors.black,
                  width: Get.width,
                  height: kIsWeb ? Get.height : Get.height,
                  child: Stack(
                    children: [
                      widget.imagesListForCarousel != null
                          ? widget.imagesListForCarousel.length >= 2
                          ? Swiper(
                        onIndexChanged: (index) => currentSwiperImgIndex = index,
                        loop: false,
                        index: widget.mediaIndex,
                        containerWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemBuilder:
                            (BuildContext context, int index) {
                          return widget.imagesListForCarousel !=
                              null
                              ? Center(
                            child: InteractiveViewer(
                              minScale: 0.0001,
                              maxScale: 0.0001,
                              child: Image.network(
                                widget.imagesListForCarousel[
                                index],
                                fit: BoxFit.contain,
                                height: kIsWeb
                                    ? Get.height
                                    : Get.height,
                                width: kIsWeb
                                    ? Get.width * 0.4
                                    : Get.width,
                              ),
                            ),
                          )
                              : SizedBox();
                          // : ChewieVideoPlayer(
                          // videoUrl: widget.videoListForCarousel[index]);
                        },
                        itemCount: widget.imagesListForCarousel !=
                            null
                            ? widget.imagesListForCarousel.length
                            : widget.videoListForCarousel.length,

                        pagination: SwiperPagination(
                          builder: FractionPaginationBuilder(
                            activeColor: Colors.amber,
                            fontSize: 18,
                            activeFontSize: 18,
                          ),
                          alignment: Alignment.topCenter,
                        ),
                        // control: SwiperControl(
                        //   padding: EdgeInsets.only(left: 28, right: 20),
                        //   size: 50,
                        //   color: Color(0xFFedab30),
                        // ),
                      )
                          : Swiper(
                        onIndexChanged: (index) => currentSwiperImgIndex = index,
                        loop: false,
                        index: widget.mediaIndex,
                        containerWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemBuilder:
                            (BuildContext context, int index) {
                          return widget.imagesListForCarousel !=
                              null
                              ? Center(
                            child: InteractiveViewer(
                              minScale: 0.0001,
                              maxScale: 0.0001,
                              child: Image.network(
                                widget.imagesListForCarousel[
                                index],
                                fit: BoxFit.contain,
                                height: kIsWeb
                                    ? Get.height
                                    : Get.height,
                                width: kIsWeb
                                    ? Get.width * 0.4
                                    : Get.width,
                              ),
                            ),
                          )
                              : SizedBox()
                          // ChewieVideoPlayer(
                          //     videoUrl: widget.videoListForCarousel[index])
                              ;
                        },
                        itemCount: widget.imagesListForCarousel !=
                            null
                            ? widget.imagesListForCarousel.length
                            : widget.videoListForCarousel.length,

                        // control: SwiperControl(
                        //   padding: EdgeInsets.only(left: 28, right: 20),
                        //   size: 50,
                        //   color: Color(0xFFedab30),
                        // ),
                      )
                          : SizedBox(),
                      widget.chatCheck != 1
                          ? Positioned.fill(
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            alignment: Alignment.center,
                            width: double.infinity,
                            height: 74,
                            color: Colors.black87,
                            // margin: EdgeInsets.symmetric(horizontal: 20),
                            ///reaction row
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: 20, right: 20, bottom: 20),
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Obx(() {
                                    return Row(
                                      children: [
                                        Tooltip(
                                          message: 'React',
                                          child: InkWell(
                                            onLongPress: () {},
                                            onTap: () async {
                                              if (widget.post.reactionCheck ==
                                                  false) {
                                                if (widget.check == 1) {

                                                }
                                                else {
                                                  widget.postList.forEach((
                                                      element) {
                                                    element.reactionCheck
                                                        .value = false;
                                                  });
                                                  widget.post.reactionCheck
                                                      .value = true;
                                                }

                                                
                                              } else if (widget.post
                                                  .reactionCheck ==
                                                  true) {
                                                widget
                                                    .post
                                                    .reactionCheck
                                                    .value = false;
                                                
                                              }

                                              // post.reactionCheck.value = false;
                                              // if(post.like.value == true)
                                              //   {
                                              //
                                              //
                                              //     post.reactionType.value = "like_simple_like";
                                              //   }
                                              // else if(post.like.value == false)
                                              //   {
                                              //     post.reactionType.value = "dislike_simple_dislike";
                                              //   }
                                              //
                                              // controller.likeUnlike(
                                              //   post.reactionType.value,
                                              //   post.postId,
                                              //   {
                                              //     'isLikedSocket': post.like.value,
                                              //     'totalLikes': post.likeCount.value
                                              //   },
                                              // );
                                              //
                                              // // ignore: unused_local_variable
                                              // 
                                              // if (post.like.value) {
                                              //   post.like.value = false;
                                              //
                                              //   if (post.likeCount.value > 0) {
                                              //     // post.likeCount.value--;
                                              //   } else {
                                              //     post.likeCount.value = 0;
                                              //   }
                                              //
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              //   print(
                                              //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                              // }
                                              // else {
                                              //   post.like.value = true;
                                              //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                              //   // post.simpleLikeCount++;
                                              //   // post.likeCount.value++;
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              // }
                                              // // ignore: unused_local_variable
                                              //
                                              //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                              //
                                              // // if (await UtilsMethods.checkInternet()) {
                                              // //
                                              // //   //   log('like response>>> $response'); //number of likes
                                              // //   //   var  postDetails= post;
                                              // //   //   postDetails.likeCount.value=response;
                                              // //   // var dbRes = await  DatabaseHelper.instance
                                              // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                              // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                              // // }
                                              // controller.postIndex = index;
                                              // controller.update();
                                            },
                                            child: widget
                                                .post
                                                .reactionType
                                                .value ==
                                                "love"
                                                ? Image.asset(
                                              'assets/reaction_gif/love-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget
                                                .post
                                                .reactionType
                                                .value ==
                                                "like_simple_like"
                                                ? Image.asset(
                                              'assets/reaction_gif/like-min.png',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget
                                                .post
                                                .reactionType
                                                .value ==
                                                null
                                                ? Image.asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 25,
                                              height:
                                              25,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "lough"
                                                ? Image
                                                .asset(
                                              'assets/reaction_gif/laugh-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width:
                                              30,
                                              height:
                                              30,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "smile"
                                                ? Image
                                                .asset(
                                              'assets/reaction_gif/smile-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "thanks"
                                                ? Image.asset(
                                              'assets/reaction_gif/thanks-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "excited"
                                                ? Image.asset(
                                              'assets/reaction_gif/excited-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "cry"
                                                ? Image.asset(
                                              'assets/reaction_gif/cry-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : Image.asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 25,
                                              height: 25,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 5),
                                        GestureDetector(
                                          onTap: () async {
                                            // List<Reaction1> data =
                                            // await widget.controller.getWhoReacted(widget.post.postId);
                                            // // 
                                            // showDialog(
                                            //     context: context,
                                            //     builder: (context) {
                                            //       return ReactRetweetDialog(
                                            //         'People who reacted',
                                            //         // reactions: data,
                                            //       );
                                            //     });

                                            if (kIsWeb) {
                                              showDialog(
                                                  context: context,
                                                  builder: (context) {
                                                    return ReactRetweetDialog(
                                                      'People who reacted',
                                                      post:
                                                      widget.post,

                                                      // reactions: data,
                                                    );
                                                  });

                                              // List<Reaction1> data =
                                              await widget.controller
                                                  .getWhoReacted(
                                                  widget.post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes: 0);
                                            } else {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReactRetweetDialog(
                                                          'People who reacted',
                                                          post: widget
                                                              .post,
                                                          // reactions: data,
                                                        )),
                                              );
                                              // List<Reaction1> data =
                                              await widget.controller
                                                  .getWhoReacted(
                                                  widget.post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes: 0);
                                            }
                                          },
                                          child: Container(
                                            padding: const EdgeInsets
                                                .symmetric(
                                              horizontal: 5,
                                              vertical: 1,
                                            ),
                                            // decoration: BoxDecoration(
                                            //   color: Colors.grey[100],
                                            //   borderRadius: BorderRadius.circular(20),
                                            // ),
                                            child: Text(
                                              "${widget.post.likeCount.value}",
                                              style: Styles.baseTextTheme
                                                  .headline2.copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  }),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      Tooltip(
                                        message: 'Comment',
                                        child: InkWell(
                                          onTap: () {
                                            if (!kIsWeb) {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (BuildContext
                                                      context) =>
                                                          CommentsScreen(
                                                              postId: widget
                                                                  .post
                                                                  .postId)));
                                              widget.controller
                                                  .postId =
                                                  widget.post.postId;
                                              // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                              //   "postId": post.postId,
                                              //   "controller": controller
                                              // });
                                              // Navigator.push(
                                              //   context,
                                              //   MaterialPageRoute(
                                              //     builder: (BuildContext context) => CommentsScreen(),
                                              //   ),
                                              // );
                                            } else {
                                              widget.postList.forEach((
                                                  element) {
                                                element.isComment.value = false;
                                              });
                                              // controller.postIndex = ;
                                              widget.post.isComment
                                                  .value = true;
                                              // controller.getNewsFeed(reload: false);
                                              // controller.update();
                                              // controller.isCommentClick = false;
                                              if (Get
                                                  .find<
                                                  BrowseController>()
                                                  .browsePostList
                                                  .isNotEmpty &&
                                                  Get
                                                      .find<BrowseController>()
                                                      .browsePostList
                                                      .length >
                                                      0) {
                                                Get
                                                    .find<
                                                    BrowseController>()
                                                    .browsePostList
                                                    .forEach(
                                                        (element) {
                                                      element.isComment
                                                          .value = false;
                                                    });
                                                // controller.postIndex = ;
                                                widget.post.isComment
                                                    .value = true;
                                              }
                                            }
                                          },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            child: new Image.asset(
                                              'assets/drawer_icons/comments.png',

                                              // post.isRetweeted
                                              //     ? Theme.of(context).iconTheme.color
                                              //     :

                                              color: Colors.white,
                                            ),
                                            // Icon(Icons.comment_outlined,
                                            //     color: post.isRetweeted
                                            //         ? Theme.of(context).iconTheme.color
                                            //         : Colors.grey)
                                            // Text(
                                            //   Strings.comments,
                                            //   style: Theme.of(context).textTheme.bodyText2,
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          // List<Retweet> data =
                                          //     await controller.getWhoRetweeted(post.postId);
                                          // 
                                          // showDialog(
                                          //     context: context,
                                          //     builder: (context) {
                                          //       return ReactRetweetDialog(
                                          //         Strings.peopleWhoRetweeted,
                                          //         retweets: data,
                                          //       );
                                          //     });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget.post.commentCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      widget.post.isRetweeted == null
                                          ? SizedBox()
                                          : Tooltip(
                                        message: Strings.rewerf,
                                        child: InkWell(
                                          onTap:
                                          widget.post.rebuzz
                                              .value
                                              ? () async {
                                            widget.controller.createDeleteBuzz(
                                                "undo_retweet",
                                                widget
                                                    .post);

                                            // var response =
                                            //     await controller.undoRetweet(post.postId);
                                            // if (response == 'Undo retweeted Successfully')
                                            widget.post
                                                .isRetweeted =
                                            false;
                                            widget
                                                .post
                                                .rebuzz
                                                .value = false;
                                            // post.rebuzzCount.value--;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .undoRetweet(widget
                                                .post
                                                .postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          }
                                              : () async {
                                            widget.controller.createDeleteBuzz(
                                                "retweet",
                                                widget
                                                    .post);
                                            // var response =
                                            //     await controller.addRetweet(post.postId);
                                            // if (response == 'Add retweet Successfully')
                                            widget.post
                                                .isRetweeted =
                                            true;
                                            // post.rebuzzCount.value++;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            widget
                                                .post
                                                .rebuzz
                                                .value = true;
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .addRetweet(widget
                                                .post
                                                .postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              'assets/drawer_icons/rebuzz.png',
                                              color: widget
                                                  .post
                                                  .rebuzz
                                                  .value
                                                  ? Colors
                                                  .white
                                                  : Colors
                                                  .white,
                                            ),
                                          ),
                                          // Icon(Icons.repeat,Ftext
                                          //     color: post.isRetweeted
                                          //         ? Theme.of(context).iconTheme.color
                                          //         : Colors.grey),
                                        ),
                                      ),
                                      // Text(
                                      //   Strings.reBuzz,
                                      //   style: Theme.of(context).textTheme.bodyText2,
                                      // ),
                                      GestureDetector(
                                        onTap: () async {
                                          List<Retweet> data =
                                          await widget.controller
                                              .getWhoRetweeted(
                                              widget.post
                                                  .postId);
                                          
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return ReactRetweetDialog(
                                                  Strings
                                                      .peopleWhoRetweeted,
                                                  retweets: data,
                                                );
                                              });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget.post.rebuzzCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  PopupMenuButton(
                                      tooltip: "Share",
                                      position: PopupMenuPosition.under,
                                      padding: EdgeInsets.zero,
                                      icon: Image.asset(
                                        AppImages.share,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.white,
                                        height: 25,
                                        width: 25,
                                      ),

                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.black
                                          : Colors.white,
                                      // Callback that sets the selected popup menu item.
                                      onSelected: (value) async {
                                        if (value == 1) {
                                          // ignore: unused_local_variable
                                          bool isSuccess = await widget
                                              .controller.savePost(
                                              widget.post.postId);
                                          if (isSuccess) {
                                            widget.post.saved = true;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'Werf saved successfully!');
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in saving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in saving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme
                                            //           .of(context)
                                            //           .brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }

                                          // Get.showSnackbar(buildSnackBar(
                                          //     isSuccess
                                          //         ? 'Your Update is saved Successfull'
                                          //         : 'An Error Occured While Saving your update',
                                          //     context));
                                          // controller.update();
                                        }
                                        else if (value == 2) {
                                          bool isSuccess = await widget
                                              .controller.unSavePost(
                                              widget.post.postId);


                                          if (isSuccess) {
                                            widget.post.saved = false;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: Strings.werfUnsaved);
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in Unsaving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in Unsaving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme.of(context).brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }
                                        }
                                        else if (value == 3) {
                                          // kIsWeb ?
                                          // showReposrtUserDialog(
                                          //     context, post.authorId.toString(), controller) :

                                          // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                          String genterate = 'https://werfie.com/home/postDetail/' +
                                              widget.post.postId.toString();
                                          // toStringpost.postId.toString());

                                          // UtilsMethods.share(genterate, 'Werf');


                                          Clipboard.setData(
                                              ClipboardData(text: genterate))
                                              .then((_) {
                                            Fluttertoast.showToast(
                                                msg: 'Werf link copied successfully',
                                                toastLength:
                                                Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.TOP,
                                                timeInSecForIosWeb:
                                                1,
                                                backgroundColor: widget
                                                    .controller.displayColor,

                                                textColor: Colors.white,
                                                webPosition: "center",
                                                webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                                fontSize: 16.0);
                                          });

                                          // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                          // UtilsMethods.share(
                                          //     genterate,
                                          //     'post');
                                          // print('post Id at share' + post.postId.toString());
                                          // print('linkgenerate:${genterate}');


                                          // UtilsMethods.toastMessageShow(
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     message: 'Werf link copied successfully');


                                          widget.controller.update();
                                        }
                                      },
                                      itemBuilder: (BuildContext context) =>
                                      [
                                        if(widget.post.saved == false ||
                                            widget.post.saved == null)
                                          PopupMenuItem(
                                            value: 1,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text(Strings.bookmark,
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        if(widget.post.saved == true)
                                          PopupMenuItem(
                                            value: 2,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text(
                                                  Strings.removeWerfFromBookMark,
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        PopupMenuItem(
                                          value: 3,
                                          child: Row(
                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: Image.asset(
                                                      AppImages.copylink,
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5),
                                                Text(
                                                  Strings.copylinkToWerf,
                                                  style:
                                                  TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),),
                                              ]),),
                                      ]
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                          : SizedBox()
                    ],
                  ),

                  // CarouselSlider(
                  //   options: CarouselOptions(
                  //     enableInfiniteScroll: false,
                  //   ),
                  //   items: imagesListForCarousel
                  //       .map(
                  //         (item) => Container(
                  //           child: Center(
                  //             child: Image.network(
                  //               item,
                  //               fit: BoxFit.fill,
                  //               width: Get.width * 0.4,
                  //             ),
                  //           ),
                  //         ),
                  //       )
                  //       .toList(),
                  // ),
                ),
              );
            }) : SizedBox(),

            widget.chatCheck != 1
                ? Obx(() {
              return widget.post.reactionCheck.value == true
                  ? Positioned(
                bottom: 60,
                left: kIsWeb ? 180 : 20,
                child: Container(
                  height: 45,
                  width: 260,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(50),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(
                            0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          // print("raection print idhr ");


                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          if (widget.post.reactionType.value ==
                              'like_simple_like') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "like_simple_like";
                          }

                          // post.reactionType.value = 'like_simple_like';

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }


                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.like,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'love') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "love";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          // print("controller.counter ${controller.counter}");
                          // if(controller.counter == false)
                          // {
                          //   post.reactionType.value = null;
                          //
                          // }

                          // controller.update();

                          // controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.love,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'lough') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "lough";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.lough,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'excited') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "excited";
                          }


                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.excited,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'thanks') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "thanks";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.thanks,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'cry') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "cry";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.cry,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'smile') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'cry' ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love") {
                            widget.post.reactionType.value =
                            "smile";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.smile,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                    ],
                  ),
                ),
              )
                  : SizedBox();
            })
                : SizedBox()
          ],
        ),
      );
    }
    else {
      print("=====> ELSE CALLED");
      return AlertDialog(
        insetPadding: kIsWeb
            ? EdgeInsets.symmetric(horizontal: 40.0, vertical: 24.0)
            : EdgeInsets.symmetric(horizontal: 0.0, vertical: 0.0),
        titlePadding: EdgeInsets.zero,
        title: Row(
          children: [
            IconButton(
              onPressed: () {
                Navigator.of(context).pop();
                widget.post.reactionCheck.value = false;
              },
              icon: Actions(
                actions: {
                  EscIntent: CallbackAction<EscIntent>(
                      onInvoke: (Intent) => Navigator.of(context).pop()),
                },
                child: Focus(
                  // focusNode: focus,
                  autofocus: true,
                  child: Icon(Icons.close, color: Colors.white),
                ),
              ),
            ),
            const Spacer(),
            !kIsWeb ? IconButton(
              onPressed: () async{
                saveAsImageAndShare(widget.imagesListForCarousel[currentSwiperImgIndex]);
              },
              icon:Icon(
                Icons.share_outlined, size: 20, color: Theme
                  .of(context)
                  .brightness == Brightness.dark
                  ? Colors.white
                  : Colors.grey,),
            ) : SizedBox(),
          ],
        ),
        backgroundColor: Colors.black,
        contentPadding: EdgeInsets.zero,
        content: kIsWeb
            ? Stack(
          children: [
            Container(
              color: Colors.black,
              width: Get.width,
              height: kIsWeb ? Get.height : Get.height,
              child: Stack(
                children: [
                  Swiper(
                    onIndexChanged: (index) => currentSwiperImgIndex = index,
                    loop: false,
// layout: SwiperLayout.TINDER,
                    index: widget.mediaIndex,
                    containerWidth: kIsWeb ? Get.width * 0.4 : Get.width,
                    itemWidth: kIsWeb ? Get.width * 0.4 : Get.width,
                    itemBuilder: (BuildContext context, int index) {
                      return widget.imagesListForCarousel != null
                          ? Center(
                        child: InteractiveViewer(
                          minScale: 0.0001,
                          maxScale: 0.0001,
                          child: Image.network(
                            widget.imagesListForCarousel[index],
                            fit: BoxFit.contain,
                            height:
                            kIsWeb ? Get.height : Get.height,
                            width: kIsWeb
                                ? Get.width * 0.4
                                : Get.width,
                          ),
                        ),
                      )
                          : SizedBox();
                      // : ChewieVideoPlayer(
                      // videoUrl: widget.videoListForCarousel[index]);
                    },
                    itemCount: widget.imagesListForCarousel != null
                        ? widget.imagesListForCarousel.length
                        : widget.videoListForCarousel.length,
                    control: SwiperControl(
                      padding: EdgeInsets.only(left: 28, right: 20),
                      size: 50,
                      color: Color(0xFFedab30),
                    ),
                  ),

                  ///

                  widget.chatCheck != 1 ?
                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        alignment: Alignment.center,
                        width: Get.width * 0.4,
                        height: 74,
                        color: Colors.black87,
                        // margin: EdgeInsets.symmetric(horizontal: 20),
                        ///reaction row
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: 20, right: 20, bottom: 20),
                          child: Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() {
                                return Row(
                                  children: [
                                    SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: Tooltip(
                                        message: 'React',
                                        child: InkWell(
                                          onLongPress: () {},
                                          onTap: () async {
                                            if (widget.post
                                                .reactionCheck ==
                                                false) {
                                              if (widget.check == 1) {} else {
                                                widget.controller
                                                    .postList
                                                    .forEach(
                                                        (element) {
                                                      element
                                                          .reactionCheck
                                                          .value = false;
                                                    });
                                                widget
                                                    .post
                                                    .reactionCheck
                                                    .value = true;

                                                
                                              }
                                            } else if (widget.post
                                                .reactionCheck ==
                                                true) {
                                              widget
                                                  .post
                                                  .reactionCheck
                                                  .value = false;

                                            }

                                            // post.reactionCheck.value = false;
                                            // if(post.like.value == true)
                                            //   {
                                            //
                                            //
                                            //     post.reactionType.value = "like_simple_like";
                                            //   }
                                            // else if(post.like.value == false)
                                            //   {
                                            //     post.reactionType.value = "dislike_simple_dislike";
                                            //   }
                                            //
                                            // controller.likeUnlike(
                                            //   post.reactionType.value,
                                            //   post.postId,
                                            //   {
                                            //     'isLikedSocket': post.like.value,
                                            //     'totalLikes': post.likeCount.value
                                            //   },
                                            // );
                                            //
                                            // // ignore: unused_local_variable
                                            // 
                                            // if (post.like.value) {
                                            //   post.like.value = false;
                                            //
                                            //   if (post.likeCount.value > 0) {
                                            //     // post.likeCount.value--;
                                            //   } else {
                                            //     post.likeCount.value = 0;
                                            //   }
                                            //
                                            //   post.likeCount.refresh();
                                            //   // controller.update();
                                            //   print(
                                            //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                            // }
                                            // else {
                                            //   post.like.value = true;
                                            //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                            //   // post.simpleLikeCount++;
                                            //   // post.likeCount.value++;
                                            //   post.likeCount.refresh();
                                            //   // controller.update();
                                            // }
                                            // // ignore: unused_local_variable
                                            //
                                            //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                            //
                                            // // if (await UtilsMethods.checkInternet()) {
                                            // //
                                            // //   //   log('like response>>> $response'); //number of likes
                                            // //   //   var  postDetails= post;
                                            // //   //   postDetails.likeCount.value=response;
                                            // //   // var dbRes = await  DatabaseHelper.instance
                                            // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                            // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                            // // }
                                            // controller.postIndex = index;
                                            // controller.update();
                                          },
                                          child: widget
                                              .post
                                              .reactionType
                                              .value ==
                                              "love"
                                              ? Image.asset(
                                            'assets/reaction_gif/love-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget
                                              .post
                                              .reactionType
                                              .value ==
                                              "like_simple_like"
                                              ? Image.asset(
                                            'assets/reaction_gif/like-min.png',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget
                                              .post
                                              .reactionType
                                              .value ==
                                              null
                                              ? Image.asset(
                                            'assets/drawer_icons/not_like.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 25,
                                            height: 25,
                                            color: Colors
                                                .white,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "lough"
                                              ? Image
                                              .asset(
                                            'assets/reaction_gif/laugh-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width:
                                            30,
                                            height:
                                            30,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "smile"
                                              ? Image
                                              .asset(
                                            'assets/reaction_gif/smile-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width:
                                            30,
                                            height:
                                            30,
                                          )
                                              : widget.post.reactionType
                                              .value ==
                                              "thanks"
                                              ? Image.asset(
                                            'assets/reaction_gif/thanks-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget.post.reactionType
                                              .value == "excited"
                                              ? Image.asset(
                                            'assets/reaction_gif/excited-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : widget.post.reactionType
                                              .value == "cry"
                                              ? Image.asset(
                                            'assets/reaction_gif/cry-min.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 30,
                                            height: 30,
                                          )
                                              : Image.asset(
                                            'assets/drawer_icons/not_like.png',
                                            // : 'assets/reaction_gif/like_gif.gif',
                                            width: 25,
                                            height: 25,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    GestureDetector(
                                      onTap: () async {
                                        // List<Reaction1> data =
                                        // await widget
                                        //     .controller
                                        //     .getWhoReacted(widget.post.postId);
                                        // // 
                                        // showDialog(
                                        //     context: context,
                                        //     builder: (context) {
                                        //       return ReactRetweetDialog(
                                        //         'People who reacted',
                                        //         // reactions: data,
                                        //       );
                                        //     });

                                        if (kIsWeb) {
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return ReactRetweetDialog(
                                                  'People who reacted',
                                                  post: widget.post,

                                                  // reactions: data,
                                                );
                                              });

                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget
                                                  .post.postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        } else {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ReactRetweetDialog(
                                                      'People who reacted',
                                                      post: widget
                                                          .post,
                                                      // reactions: data,
                                                    )),
                                          );
                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget
                                                  .post.postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        }
                                      },
                                      child: Container(
                                        padding: const EdgeInsets
                                            .symmetric(
                                          horizontal: 5,
                                          vertical: 1,
                                        ),
                                        // decoration: BoxDecoration(
                                        //   color: Colors.grey[100],
                                        //   borderRadius: BorderRadius.circular(20),
                                        // ),
                                        child: Text(
                                          "${widget.post.likeCount.value}",
                                          // style: TextStyle(
                                          //   color: Colors.grey[600],
                                          //   fontSize: 14,
                                          // ),
                                          style: Theme
                                              .of(context)
                                              .brightness ==
                                              Brightness.dark
                                              ? TextStyle(
                                            color:
                                            Colors.white,
                                            fontSize: 14,
                                          )
                                              : TextStyle(
                                            color:
                                            Colors.white,
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              }),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  Tooltip(
                                    message: 'Reply',
                                    child: InkWell(
                                      onTap: () {
                                        if (!kIsWeb) {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                      CommentsScreen(
                                                          postId: widget
                                                              .post
                                                              .postId)));
                                          widget.controller.postId =
                                              widget.post.postId;
                                          // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                          //   "postId": post.postId,
                                          //   "controller": controller
                                          // });
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (BuildContext context) => CommentsScreen(),
                                          //   ),
                                          // );
                                        } else {
                                          widget.controller.postList
                                              .forEach((element) {
                                            element.isComment
                                                .value = false;
                                          });
                                          // controller.postIndex = ;
                                          widget.post.isComment
                                              .value = true;
                                          Navigator.of(context)
                                              .pop();
                                          // controller.getNewsFeed(reload: false);
                                          // controller.update();
                                          // controller.isCommentClick = false;
                                          if (Get.isRegistered<
                                              BrowseController>()) {
                                            if (Get
                                                .find<
                                                BrowseController>()
                                                .browsePostList
                                                .isNotEmpty &&
                                                Get
                                                    .find<BrowseController>()
                                                    .browsePostList
                                                    .length >
                                                    0) {
                                              Get
                                                  .find<
                                                  BrowseController>()
                                                  .browsePostList
                                                  .forEach(
                                                      (element) {
                                                    element.isComment
                                                        .value = false;
                                                  });
                                              // controller.postIndex = ;
                                              widget.post.isComment
                                                  .value = true;
                                            }
                                          }
                                        }
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: Icon(
                                          Icons.mode_comment_outlined, size: 20,
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.grey,),
                                        // Icon(Icons.comment_outlined,
                                        //     color: post.isRetweeted
                                        //         ? Theme.of(context).iconTheme.color
                                        //         : Colors.grey)
                                        // Text(
                                        //   Strings.comments,
                                        //   style: Theme.of(context).textTheme.bodyText2,
                                      ),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () async {
                                      // List<Retweet> data =
                                      //     await controller.getWhoRetweeted(post.postId);
                                      // 
                                      // showDialog(
                                      //     context: context,
                                      //     builder: (context) {
                                      //       return ReactRetweetDialog(
                                      //         Strings.peopleWhoRetweeted,
                                      //         retweets: data,
                                      //       );
                                      //     });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget
                                            .post.commentCount.value
                                            .toString(),
                                        style: Theme
                                            .of(context)
                                            .brightness ==
                                            Brightness.dark
                                            ? TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                        )
                                            : TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  widget.post.isRetweeted == null
                                      ? SizedBox()
                                      : Tooltip(
                                    message: Strings.rewerf,
                                    child: InkWell(
                                      onTap: widget.post
                                          .rebuzz.value
                                          ? () async {
                                        widget
                                            .controller
                                            .createDeleteBuzz(
                                            "undo_retweet",
                                            widget
                                                .post);

                                        // var response =
                                        //     await controller.undoRetweet(post.postId);
                                        // if (response == 'Undo retweeted Successfully')
                                        widget.post
                                            .isRetweeted =
                                        false;
                                        widget
                                            .post
                                            .rebuzz
                                            .value =
                                        false;
                                        // post.rebuzzCount.value--;
                                        widget.post
                                            .rebuzzCount
                                            .refresh();
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .undoRetweet(
                                            widget
                                                .post
                                                .postId);
                                        setState(() {});
                                        // controller.update();
                                      }
                                          : () async {
                                        widget.controller.createDeleteBuzz(
                                            "retweet",
                                            widget
                                                .post);
                                        // var response =
                                        //     await controller.addRetweet(post.postId);
                                        // if (response == 'Add retweet Successfully')
                                        widget.post
                                            .isRetweeted =
                                        true;
                                        // post.rebuzzCount.value++;
                                        widget.post
                                            .rebuzzCount
                                            .refresh();
                                        widget
                                            .post
                                            .rebuzz
                                            .value =
                                        true;
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .addRetweet(
                                            widget
                                                .post
                                                .postId);
                                        setState(() {});
                                        // controller.update();
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: Icon(
                                          Icons.repeat, size: 20, color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.grey,),
                                      ),
                                      // Icon(Icons.repeat,Ftext
                                      //     color: post.isRetweeted
                                      //         ? Theme.of(context).iconTheme.color
                                      //         : Colors.grey),
                                    ),
                                  ),
                                  // Text(
                                  //   Strings.reBuzz,
                                  //   style: Theme.of(context).textTheme.bodyText2,
                                  // ),
                                  GestureDetector(
                                    onTap: () async {
                                      List<Retweet> data =
                                      await widget.controller
                                          .getWhoRetweeted(
                                          widget
                                              .post.postId);
                                      // 
                                      showDialog(
                                          context: context,
                                          builder: (context) {
                                            return ReactRetweetDialog(
                                              Strings
                                                  .peopleWhoRetweeted,
                                              retweets: data,
                                            );
                                          });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget.post.rebuzzCount.value
                                            .toString(),
                                        style: Theme
                                            .of(context)
                                            .brightness ==
                                            Brightness.dark
                                            ? TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                        )
                                            : TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              ///
                              PopupMenuButton(
                                  tooltip: "Share",
                                  position: PopupMenuPosition.under,
                                  padding: EdgeInsets.zero,
                                  icon: Icon(
                                    Icons.share_outlined, size: 20, color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.grey,),

                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark ? Colors
                                      .black : Colors.white,
                                  // Callback that sets the selected popup menu item.
                                  onSelected: (value) async {
                                    if (value == 1) {
                                      // ignore: unused_local_variable
                                      bool isSuccess = await widget.controller
                                          .savePost(widget.post.postId);
                                      if (isSuccess) {
                                        widget.post.saved = true;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'Werf saved successfully!');
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in saving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in saving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme
                                        //           .of(context)
                                        //           .brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }

                                      // Get.showSnackbar(buildSnackBar(
                                      //     isSuccess
                                      //         ? 'Your Update is saved Successfull'
                                      //         : 'An Error Occured While Saving your update',
                                      //     context));
                                      // controller.update();
                                    }
                                    else if (value == 2) {
                                      bool isSuccess = await widget.controller
                                          .unSavePost(widget.post.postId);


                                      if (isSuccess) {
                                        widget.post.saved = false;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.werfUnsaved);
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in Unsaving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in Unsaving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme.of(context).brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }
                                    }

                                    else if (value == 3) {
                                      // kIsWeb ?
                                      // showReposrtUserDialog(
                                      //     context, post.authorId.toString(), controller) :

                                      // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                      String genterate = 'https://werfie.com/home/postDetail/' +
                                          widget.post.postId.toString();
                                      // toStringpost.postId.toString());

                                      // UtilsMethods.share(genterate, 'Werf');


                                      Clipboard.setData(
                                          ClipboardData(text: genterate)).then((
                                          _) {
                                        Fluttertoast.showToast(
                                            msg: 'Werf link copied successfully',
                                            toastLength:
                                            Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.TOP,
                                            timeInSecForIosWeb:
                                            1,
                                            backgroundColor: widget.controller
                                                .displayColor,

                                            textColor: Colors.white,
                                            webPosition: "center",
                                            webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                            fontSize: 16.0);
                                      });

                                      // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                      // UtilsMethods.share(
                                      //     genterate,
                                      //     'post');
                                      // print('post Id at share' + post.postId.toString());
                                      // print('linkgenerate:${genterate}');


                                      // UtilsMethods.toastMessageShow(
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     message: 'Werf link copied successfully');


                                      widget.controller.update();
                                    }
                                    else if (value == 4) {
                                      if (!kIsWeb) {
                                        // kIsWeb ?
                                        // showReposrtUserDialog(
                                        //     context, post.authorId.toString(), controller) :

                                        String genterate = await FirebaseDeepLink()
                                            .createDynamicLink(
                                            short: true, link: '/post?postId=' +
                                            widget.post.postId.toString());

                                        UtilsMethods.share(genterate, 'Werf');


                                        // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                        // UtilsMethods.share(
                                        //     genterate,
                                        //     'post');
                                        // print('post Id at share' + post.postId.toString());
                                        // print('linkgenerate:${genterate}');


                                        widget.controller.update();
                                      }
                                      else {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.shareWerf);
                                      }
                                    }
                                  },
                                  itemBuilder: (BuildContext context) =>
                                  [
                                    if(widget.post.saved == false ||
                                        widget.post.saved == null)
                                      PopupMenuItem(
                                        value: 1,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text(Strings.bookmark,
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    if(widget.post.saved == true)
                                      PopupMenuItem(
                                        value: 2,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text(Strings.removeWerfFromBookMark,
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    PopupMenuItem(
                                      value: 3,
                                      child: Row(
                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: Image.asset(
                                                  AppImages.copylink,
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5),
                                            Text(
                                              Strings.copylinkToWerf,
                                              style:
                                              TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),),
                                          ]),),
                                    if(!kIsWeb)

                                      PopupMenuItem(
                                        value: 4,
                                        child: Row(
                                            children: [
                                              Container(
                                                  width: 20,
                                                  height: 20,
                                                  child: Image.asset(
                                                    AppImages.share,
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  )
                                              ),
                                              SizedBox(width: 5),
                                              Text(
                                                Strings.shareWerf,
                                                style:
                                                TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors
                                                        .black,
                                                    fontSize: 14
                                                ),),
                                            ]),),
                                  ]
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                      : SizedBox()
                ],
              ),
            ),


            widget.chatCheck != 1
                ? Obx(() {
              return GestureDetector(
                onTap: () {
                  widget.post.reactionCheck.value = false;
                },
                child: Container(
                  color: Colors.black,
                  width: Get.width,
                  height: kIsWeb ? Get.height : Get.height,
                  child: Stack(
                    children: [
                      Swiper(
                        onIndexChanged: (index) => currentSwiperImgIndex = index,
                        loop: false,
// layout: SwiperLayout.TINDER,
                        index: widget.mediaIndex,
                        containerWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemBuilder:
                            (BuildContext context, int index) {
                          return widget.imagesListForCarousel != null
                              ? Center(
                            child: InteractiveViewer(
                              minScale: 0.0001,
                              maxScale: 0.0001,
                              child: Image.network(
                                widget.imagesListForCarousel[
                                index],
                                fit: BoxFit.contain,
                                height: kIsWeb
                                    ? Get.height
                                    : Get.height,
                                width: kIsWeb
                                    ? Get.width * 0.4
                                    : Get.width,
                              ),
                            ),
                          )
                              : SizedBox();
                          // : ChewieVideoPlayer(
                          // videoUrl: widget.videoListForCarousel[index]);
                        },
                        itemCount:
                        widget.imagesListForCarousel != null
                            ? widget.imagesListForCarousel.length
                            : widget.videoListForCarousel.length,
                        control: SwiperControl(
                          padding:
                          EdgeInsets.only(left: 28, right: 20),
                          size: 50,
                          color: Color(0xFFedab30),
                        ),
                      ),
                      widget.chatCheck != 1
                          ? Positioned.fill(
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            alignment: Alignment.center,
                            width: Get.width * 0.4,
                            height: 74,
                            color: Colors.black87,
                            // margin: EdgeInsets.symmetric(horizontal: 20),
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: 20,
                                  right: 20,
                                  bottom: 20),

                              ///reaction row for web
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .spaceBetween,
                                children: [
                                  Obx(() {
                                    return Row(
                                      children: [
                                        Tooltip(
                                          message: 'React',
                                          child: InkWell(
                                            onLongPress: () {},
                                            onTap: () async {
                                              if (widget.post
                                                  .reactionCheck ==
                                                  false) {
                                                if (widget
                                                    .check ==
                                                    1) {} else {
                                                  widget
                                                      .controller
                                                      .postList
                                                      .forEach(
                                                          (element) {
                                                        element
                                                            .reactionCheck
                                                            .value = false;
                                                      });
                                                  widget
                                                      .post
                                                      .reactionCheck
                                                      .value = true;


                                                }
                                              } else if (widget
                                                  .post
                                                  .reactionCheck ==
                                                  true) {
                                                widget
                                                    .post
                                                    .reactionCheck
                                                    .value = false;
                                                
                                              }

                                              // post.reactionCheck.value = false;
                                              // if(post.like.value == true)
                                              //   {
                                              //
                                              //
                                              //     post.reactionType.value = "like_simple_like";
                                              //   }
                                              // else if(post.like.value == false)
                                              //   {
                                              //     post.reactionType.value = "dislike_simple_dislike";
                                              //   }
                                              //
                                              // controller.likeUnlike(
                                              //   post.reactionType.value,
                                              //   post.postId,
                                              //   {
                                              //     'isLikedSocket': post.like.value,
                                              //     'totalLikes': post.likeCount.value
                                              //   },
                                              // );
                                              //
                                              // // ignore: unused_local_variable
                                              // 
                                              // if (post.like.value) {
                                              //   post.like.value = false;
                                              //
                                              //   if (post.likeCount.value > 0) {
                                              //     // post.likeCount.value--;
                                              //   } else {
                                              //     post.likeCount.value = 0;
                                              //   }
                                              //
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              //   print(
                                              //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                              // }
                                              // else {
                                              //   post.like.value = true;
                                              //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                              //   // post.simpleLikeCount++;
                                              //   // post.likeCount.value++;
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              // }
                                              // // ignore: unused_local_variable
                                              //
                                              //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                              //
                                              // // if (await UtilsMethods.checkInternet()) {
                                              // //
                                              // //   //   log('like response>>> $response'); //number of likes
                                              // //   //   var  postDetails= post;
                                              // //   //   postDetails.likeCount.value=response;
                                              // //   // var dbRes = await  DatabaseHelper.instance
                                              // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                              // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                              // // }
                                              // controller.postIndex = index;
                                              // controller.update();
                                            },
                                            child: widget
                                                .post
                                                .reactionType
                                                .value ==
                                                "love"
                                                ? Image.asset(
                                              'assets/reaction_gif/love-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "like_simple_like"
                                                ? Image
                                                .asset(
                                              'assets/reaction_gif/like-min.png',
                                              width:
                                              30,
                                              height:
                                              30,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                null
                                                ? Image
                                                .asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width:
                                              25,
                                              height:
                                              25,
                                              color:
                                              Colors.white,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "lough"
                                                ? Image.asset(
                                              'assets/reaction_gif/laugh-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "smile"
                                                ? Image.asset(
                                              'assets/reaction_gif/smile-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "thanks"
                                                ? Image.asset(
                                              'assets/reaction_gif/thanks-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "excited"
                                                ? Image.asset(
                                              'assets/reaction_gif/excited-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "cry"
                                                ? Image.asset(
                                              'assets/reaction_gif/cry-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : Image.asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 25,
                                              height: 25,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 5),
                                        GestureDetector(
                                          onTap: () async {
                                            // List<Reaction1> data =
                                            // await widget
                                            //     .controller
                                            //     .getWhoReacted(widget.post.postId);
                                            // // 
                                            // showDialog(
                                            //     context: context,
                                            //     builder: (context) {
                                            //       return ReactRetweetDialog(
                                            //         'People who reacted',
                                            //         // reactions: data,
                                            //       );
                                            //     });

                                            if (kIsWeb) {
                                              showDialog(
                                                  context:
                                                  context,
                                                  builder:
                                                      (context) {
                                                    return ReactRetweetDialog(
                                                      'People who reacted',
                                                      post: widget
                                                          .post,

                                                      // reactions: data,
                                                    );
                                                  });

                                              // List<Reaction1> data =
                                              await widget
                                                  .controller
                                                  .getWhoReacted(
                                                  widget
                                                      .post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes:
                                                  0);
                                            } else {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder:
                                                        (context) =>
                                                        ReactRetweetDialog(
                                                          'People who reacted',
                                                          post: widget.post,
                                                          // reactions: data,
                                                        )),
                                              );
                                              // List<Reaction1> data =
                                              await widget
                                                  .controller
                                                  .getWhoReacted(
                                                  widget
                                                      .post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes:
                                                  0);
                                            }
                                          },
                                          child: Container(
                                            padding:
                                            const EdgeInsets
                                                .symmetric(
                                              horizontal: 5,
                                              vertical: 1,
                                            ),
                                            // decoration: BoxDecoration(
                                            //   color: Colors.grey[100],
                                            //   borderRadius: BorderRadius.circular(20),
                                            // ),
                                            child: Text(
                                              "${widget.post.likeCount.value}",
                                              // style: TextStyle(
                                              //   color: Colors.grey[600],
                                              //   fontSize: 14,
                                              // ),
                                              style: Styles.baseTextTheme
                                                  .headline2.copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  }),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      Tooltip(
                                        message: 'Reply',
                                        child: InkWell(
                                          onTap: () {
                                            processReplyDialog(context);
                                            return;
                                            if (!kIsWeb) {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (BuildContext
                                                      context) =>
                                                          CommentsScreen(
                                                              postId: widget
                                                                  .post
                                                                  .postId)));
                                              widget.controller
                                                  .postId =
                                                  widget.post
                                                      .postId;
                                              // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                              //   "postId": post.postId,
                                              //   "controller": controller
                                              // });
                                              // Navigator.push(
                                              //   context,
                                              //   MaterialPageRoute(
                                              //     builder: (BuildContext context) => CommentsScreen(),
                                              //   ),
                                              // );
                                            } else {
                                              widget.controller
                                                  .postList
                                                  .forEach(
                                                      (element) {
                                                    element.isComment
                                                        .value =
                                                    false;
                                                  });
                                              // controller.postIndex = ;
                                              widget
                                                  .post
                                                  .isComment
                                                  .value = true;
                                              Navigator.of(
                                                  context)
                                                  .pop();
                                              // controller.getNewsFeed(reload: false);
                                              // controller.update();
                                              // controller.isCommentClick = false;
                                              if (Get.isRegistered<
                                                  BrowseController>()) {
                                                if (Get
                                                    .find<
                                                    BrowseController>()
                                                    .browsePostList
                                                    .isNotEmpty &&
                                                    Get
                                                        .find<
                                                        BrowseController>()
                                                        .browsePostList
                                                        .length >
                                                        0) {
                                                  Get
                                                      .find<
                                                      BrowseController>()
                                                      .browsePostList
                                                      .forEach(
                                                          (element) {
                                                        element
                                                            .isComment
                                                            .value = false;
                                                      });
                                                  // controller.postIndex = ;
                                                  widget
                                                      .post
                                                      .isComment
                                                      .value = true;
                                                }
                                              }
                                            }
                                          },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            child:
                                            new Image.asset(
                                              'assets/drawer_icons/comments.png',

                                              // post.isRetweeted
                                              //     ? Theme.of(context).iconTheme.color
                                              //     :

                                              color:
                                              Colors.white,
                                            ),
                                            // Icon(Icons.comment_outlined,
                                            //     color: post.isRetweeted
                                            //         ? Theme.of(context).iconTheme.color
                                            //         : Colors.grey)
                                            // Text(
                                            //   Strings.comments,
                                            //   style: Theme.of(context).textTheme.bodyText2,
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          // List<Retweet> data =
                                          //     await controller.getWhoRetweeted(post.postId);
                                          // 
                                          // showDialog(
                                          //     context: context,
                                          //     builder: (context) {
                                          //       return ReactRetweetDialog(
                                          //         Strings.peopleWhoRetweeted,
                                          //         retweets: data,
                                          //       );
                                          //     });
                                        },
                                        child: Container(
                                          padding:
                                          const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget
                                                .post
                                                .commentCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      widget.post.isRetweeted ==
                                          null
                                          ? SizedBox()
                                          : Tooltip(
                                        message: Strings.rewerf,
                                        child: InkWell(
                                          onTap: widget.post.rebuzz.value
                                              ? () async {
                                            widget.controller.createDeleteBuzz(
                                                "undo_retweet",
                                                widget.post);

                                            // var response =
                                            //     await controller.undoRetweet(post.postId);
                                            // if (response == 'Undo retweeted Successfully')
                                            widget
                                                .post
                                                .isRetweeted = false;
                                            widget
                                                .post
                                                .rebuzz
                                                .value = false;
                                            // post.rebuzzCount.value--;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .undoRetweet(
                                                widget.post.postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          }
                                              : () async {
                                            widget.controller.createDeleteBuzz(
                                                "retweet",
                                                widget.post);
                                            // var response =
                                            //     await controller.addRetweet(post.postId);
                                            // if (response == 'Add retweet Successfully')
                                            widget
                                                .post
                                                .isRetweeted = true;
                                            // post.rebuzzCount.value++;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            widget
                                                .post
                                                .rebuzz
                                                .value = true;
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .addRetweet(widget.post.postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          },
                                          child:
                                          Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              'assets/drawer_icons/rebuzz.png',
                                              color: widget.post.rebuzz.value
                                                  ? Colors.white
                                                  : Colors
                                                  .white,
                                            ),
                                          ),
                                          // Icon(Icons.repeat,Ftext
                                          //     color: post.isRetweeted
                                          //         ? Theme.of(context).iconTheme.color
                                          //         : Colors.grey),
                                        ),
                                      ),
                                      // Text(
                                      //   Strings.reBuzz,
                                      //   style: Theme.of(context).textTheme.bodyText2,
                                      // ),
                                      GestureDetector(
                                        onTap: () async {
                                          List<Retweet> data =
                                          await widget
                                              .controller
                                              .getWhoRetweeted(
                                              widget
                                                  .post
                                                  .postId);
                                          
                                          showDialog(
                                              context: context,
                                              builder:
                                                  (context) {
                                                return ReactRetweetDialog(
                                                  Strings
                                                      .peopleWhoRetweeted,
                                                  retweets:
                                                  data,
                                                );
                                              });
                                        },
                                        child: Container(
                                          padding:
                                          const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget
                                                .post
                                                .rebuzzCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  ///
                                  PopupMenuButton(
                                      tooltip: "Share",
                                      position: PopupMenuPosition.under,
                                      padding: EdgeInsets.zero,
                                      icon: Image.asset(
                                        AppImages.share,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.white,
                                        height: 25,
                                        width: 25,
                                      ),

                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.black
                                          : Colors.white,
                                      // Callback that sets the selected popup menu item.
                                      onSelected: (value) async {
                                        if (value == 1) {
                                          // ignore: unused_local_variable
                                          bool isSuccess = await widget
                                              .controller.savePost(
                                              widget.post.postId);
                                          if (isSuccess) {
                                            widget.post.saved = true;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'Werf saved successfully!');
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in saving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in saving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme
                                            //           .of(context)
                                            //           .brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }

                                          // Get.showSnackbar(buildSnackBar(
                                          //     isSuccess
                                          //         ? 'Your Update is saved Successfull'
                                          //         : 'An Error Occured While Saving your update',
                                          //     context));
                                          // controller.update();
                                        }
                                        else if (value == 2) {
                                          bool isSuccess = await widget
                                              .controller.unSavePost(
                                              widget.post.postId);


                                          if (isSuccess) {
                                            widget.post.saved = false;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: Strings.werfUnsaved);
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in Unsaving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in Unsaving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme.of(context).brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }
                                        }

                                        else if (value == 3) {
                                          // kIsWeb ?
                                          // showReposrtUserDialog(
                                          //     context, post.authorId.toString(), controller) :

                                          // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                          String genterate = 'https://werfie.com/home/postDetail/' +
                                              widget.post.postId.toString();
                                          // toStringpost.postId.toString());

                                          // UtilsMethods.share(genterate, 'Werf');


                                          Clipboard.setData(
                                              ClipboardData(text: genterate))
                                              .then((_) {
                                            Fluttertoast.showToast(
                                                msg: 'Werf link copied successfully',
                                                toastLength:
                                                Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.TOP,
                                                timeInSecForIosWeb:
                                                1,
                                                backgroundColor: widget
                                                    .controller.displayColor,

                                                textColor: Colors.white,
                                                webPosition: "center",
                                                webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                                fontSize: 16.0);
                                          });

                                          // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                          // UtilsMethods.share(
                                          //     genterate,
                                          //     'post');
                                          // print('post Id at share' + post.postId.toString());
                                          // print('linkgenerate:${genterate}');


                                          // UtilsMethods.toastMessageShow(
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     message: 'Werf link copied successfully');


                                          widget.controller.update();
                                        }
                                        else if (value == 4) {
                                          if (!kIsWeb) {
                                            // kIsWeb ?
                                            // showReposrtUserDialog(
                                            //     context, post.authorId.toString(), controller) :

                                            String genterate = await FirebaseDeepLink()
                                                .createDynamicLink(short: true,
                                                link: '/post?postId=' +
                                                    widget.post.postId
                                                        .toString());

                                            UtilsMethods.share(
                                                genterate, 'Werf');


                                            // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                            // UtilsMethods.share(
                                            //     genterate,
                                            //     'post');
                                            // print('post Id at share' + post.postId.toString());
                                            // print('linkgenerate:${genterate}');


                                            widget.controller.update();
                                          }
                                          else {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: Strings.shareWerf);
                                          }
                                        }
                                      },
                                      itemBuilder: (BuildContext context) =>
                                      [
                                        if(widget.post.saved == false ||
                                            widget.post.saved == null)
                                          PopupMenuItem(
                                            value: 1,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text(Strings.bookmark,
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        if(widget.post.saved == true)
                                          PopupMenuItem(
                                            value: 2,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text(
                                                  Strings.removeWerfFromBookMark,
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        PopupMenuItem(
                                          value: 3,
                                          child: Row(
                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: Image.asset(
                                                      AppImages.copylink,
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5),
                                                Text(
                                                  Strings.copylinkToWerf,
                                                  style:
                                                  TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),),
                                              ]),),
                                        if(!kIsWeb)

                                          PopupMenuItem(
                                            value: 4,
                                            child: Row(
                                                children: [
                                                  Container(
                                                      width: 20,
                                                      height: 20,
                                                      child: Image.asset(
                                                        AppImages.share,
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                      )
                                                  ),
                                                  SizedBox(width: 5),
                                                  Text(
                                                    Strings.shareWerf,
                                                    style:
                                                    TextStyle(
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors
                                                            .black,
                                                        fontSize: 14
                                                    ),),
                                                ]),),
                                      ]
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                          : SizedBox()
                    ],
                  ),

                  // CarouselSlider(
                  //   options: CarouselOptions(
                  //     enableInfiniteScroll: false,
                  //   ),
                  //   items: imagesListForCarousel
                  //       .map(
                  //         (item) => Container(
                  //           child: Center(
                  //             child: Image.network(
                  //               item,
                  //               fit: BoxFit.fill,
                  //               width: Get.width * 0.4,
                  //             ),
                  //           ),
                  //         ),
                  //       )
                  //       .toList(),
                  // ),
                ),
              );
            })
                : SizedBox(),
            widget.chatCheck != 1
                ? Obx(() {
              return widget.post.reactionCheck.value == true
                  ? Positioned(
                bottom: 60,
                left: kIsWeb ? 180 : 20,
                child: Container(
                  height: 45,
                  width: 260,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(50),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(
                            0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          // print("raection print idhr ");


                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          if (widget.post.reactionType.value ==
                              'like_simple_like') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "like_simple_like";
                          }

                          // post.reactionType.value = 'like_simple_like';

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }


                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.like,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'love') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "love";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          // print("controller.counter ${controller.counter}");
                          // if(controller.counter == false)
                          // {
                          //   post.reactionType.value = null;
                          //
                          // }

                          // controller.update();

                          // controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.love,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'lough') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "lough";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.lough,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'excited') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "excited";
                          }


                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.excited,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'thanks') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "thanks";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.thanks,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'cry') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "cry";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.cry,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'smile') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'cry' ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love") {
                            widget.post.reactionType.value =
                            "smile";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.smile,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                    ],
                  ),
                ),
              )
                  : SizedBox();
            })
                : SizedBox()
          ],
        )
            : Stack(
          children: [
            Container(
              color: Colors.black,
              width: Get.width,
              height: kIsWeb ? Get.height : Get.height,
              child: Stack(
                children: [
                  widget.imagesListForCarousel != null
                      ? widget.imagesListForCarousel.length >= 2
                      ? Swiper(
                    onIndexChanged: (index) => currentSwiperImgIndex = index,
                    loop: false,
                    index: widget.mediaIndex,
                    containerWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return widget.imagesListForCarousel !=
                          null
                          ? Center(
                        child: InteractiveViewer(

                          minScale: 0.0001,
                          maxScale: 0.0001,
                          child: Image.network(
                            widget.imagesListForCarousel[
                            index],
                            fit: BoxFit.contain,
                            height: kIsWeb
                                ? Get.height
                                : Get.height,
                            width: kIsWeb
                                ? Get.width * 0.4
                                : Get.width,
                          ),
                        ),
                      )
                          : SizedBox();
                      // : ChewieVideoPlayer(
                      // videoUrl: widget.videoListForCarousel[index]);
                    },
                    itemCount: widget.imagesListForCarousel !=
                        null
                        ? widget.imagesListForCarousel.length
                        : widget.videoListForCarousel.length,

                    pagination: SwiperPagination(
                      builder: FractionPaginationBuilder(
                        activeColor: Colors.amber,
                        fontSize: 18,
                        activeFontSize: 18,
                      ),
                      alignment: Alignment.topCenter,
                    ),
                    // control: SwiperControl(
                    //   padding: EdgeInsets.only(left: 28, right: 20),
                    //   size: 50,
                    //   color: Color(0xFFedab30),
                    // ),
                  )
                      : Swiper(
                    onIndexChanged: (index) => currentSwiperImgIndex = index,
                    loop: false,
                    index: widget.mediaIndex,
                    containerWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemWidth:
                    kIsWeb ? Get.width * 0.4 : Get.width,
                    itemBuilder:
                        (BuildContext context, int index) {
                      return widget.imagesListForCarousel !=
                          null
                          ? Center(
                        child: InteractiveViewer(
                          minScale: 0.0001,
                          maxScale: 0.0001,
                          child: Image.network(
                            widget.imagesListForCarousel[
                            index],
                            fit: BoxFit.contain,
                            height: kIsWeb
                                ? Get.height
                                : Get.height,
                            width: kIsWeb
                                ? Get.width * 0.4
                                : Get.width,
                          ),
                        ),
                      )
                          : SizedBox()
                      // ChewieVideoPlayer(
                      //     videoUrl: widget.videoListForCarousel[index])
                          ;
                    },
                    itemCount: widget.imagesListForCarousel !=
                        null
                        ? widget.imagesListForCarousel.length
                        : widget.videoListForCarousel.length,

                    // control: SwiperControl(
                    //   padding: EdgeInsets.only(left: 28, right: 20),
                    //   size: 50,
                    //   color: Color(0xFFedab30),
                    // ),
                  )
                      : SizedBox(),
                  widget.chatCheck != 1
                      ? Positioned.fill(
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        alignment: Alignment.center,
                        width: double.infinity,
                        height: 74,
                        color: Colors.black87,
                        // margin: EdgeInsets.symmetric(horizontal: 20),


                        ///Reaction Row
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: 20, right: 20, bottom: 20),
                          child: Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() {
                                return Row(
                                  children: [
                                    Tooltip(
                                      message: 'React',
                                      child: InkWell(
                                        onLongPress: () {},
                                        onTap: () async {
                                          if (widget.post
                                              .reactionCheck ==
                                              false) {
                                            if (widget.check ==
                                                1) {} else {
                                              widget.controller
                                                  .postList
                                                  .forEach(
                                                      (element) {
                                                    element
                                                        .reactionCheck
                                                        .value = false;
                                                  });
                                              widget
                                                  .post
                                                  .reactionCheck
                                                  .value = true;
                                            }


                                          } else if (widget.post
                                              .reactionCheck ==
                                              true) {
                                            widget
                                                .post
                                                .reactionCheck
                                                .value = false;

                                          }

                                          // post.reactionCheck.value = false;
                                          // if(post.like.value == true)
                                          //   {
                                          //
                                          //
                                          //     post.reactionType.value = "like_simple_like";
                                          //   }
                                          // else if(post.like.value == false)
                                          //   {
                                          //     post.reactionType.value = "dislike_simple_dislike";
                                          //   }
                                          //
                                          // controller.likeUnlike(
                                          //   post.reactionType.value,
                                          //   post.postId,
                                          //   {
                                          //     'isLikedSocket': post.like.value,
                                          //     'totalLikes': post.likeCount.value
                                          //   },
                                          // );
                                          //
                                          // // ignore: unused_local_variable
                                          // 
                                          // if (post.like.value) {
                                          //   post.like.value = false;
                                          //
                                          //   if (post.likeCount.value > 0) {
                                          //     // post.likeCount.value--;
                                          //   } else {
                                          //     post.likeCount.value = 0;
                                          //   }
                                          //
                                          //   post.likeCount.refresh();
                                          //   // controller.update();
                                          //   print(
                                          //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                          // }
                                          // else {
                                          //   post.like.value = true;
                                          //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                          //   // post.simpleLikeCount++;
                                          //   // post.likeCount.value++;
                                          //   post.likeCount.refresh();
                                          //   // controller.update();
                                          // }
                                          // // ignore: unused_local_variable
                                          //
                                          //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                          //
                                          // // if (await UtilsMethods.checkInternet()) {
                                          // //
                                          // //   //   log('like response>>> $response'); //number of likes
                                          // //   //   var  postDetails= post;
                                          // //   //   postDetails.likeCount.value=response;
                                          // //   // var dbRes = await  DatabaseHelper.instance
                                          // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                          // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                          // // }
                                          // controller.postIndex = index;
                                          // controller.update();
                                        },
                                        child: widget
                                            .post
                                            .reactionType
                                            .value ==
                                            "love"
                                            ? Image.asset(
                                          'assets/reaction_gif/love-min.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width: 30,
                                          height: 30,
                                        )
                                            : widget
                                            .post
                                            .reactionType
                                            .value ==
                                            "like_simple_like"
                                            ? Image.asset(
                                          'assets/reaction_gif/like-min.png',
                                          width: 30,
                                          height: 30,
                                        )
                                            : widget
                                            .post
                                            .reactionType
                                            .value ==
                                            null
                                            ? Image.asset(
                                          'assets/drawer_icons/not_like.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width: 25,
                                          height:
                                          25,
                                        )
                                            : widget.post.reactionType
                                            .value ==
                                            "lough"
                                            ? Image
                                            .asset(
                                          'assets/reaction_gif/laugh-min.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width:
                                          30,
                                          height:
                                          30,
                                        )
                                            : widget.post.reactionType.value ==
                                            "smile"
                                            ? Image
                                            .asset(
                                          'assets/reaction_gif/smile-min.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width: 30,
                                          height: 30,
                                        )
                                            : widget.post.reactionType.value ==
                                            "thanks"
                                            ? Image.asset(
                                          'assets/reaction_gif/thanks-min.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width: 30,
                                          height: 30,
                                        )
                                            : widget.post.reactionType.value ==
                                            "excited"
                                            ? Image.asset(
                                          'assets/reaction_gif/excited-min.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width: 30,
                                          height: 30,
                                        )
                                            : widget.post.reactionType.value ==
                                            "cry"
                                            ? Image.asset(
                                          'assets/reaction_gif/cry-min.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width: 30,
                                          height: 30,
                                        )
                                            : Image.asset(
                                          'assets/drawer_icons/not_like.png',
                                          // : 'assets/reaction_gif/like_gif.gif',
                                          width: 25,
                                          height: 25,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 5),
                                    GestureDetector(
                                      onTap: () async {
                                        // List<Reaction1> data =
                                        // await widget.controller.getWhoReacted(widget.post.postId);
                                        // // 
                                        // showDialog(
                                        //     context: context,
                                        //     builder: (context) {
                                        //       return ReactRetweetDialog(
                                        //         'People who reacted',
                                        //         // reactions: data,
                                        //       );
                                        //     });

                                        if (kIsWeb) {
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return ReactRetweetDialog(
                                                  'People who reacted',
                                                  post:
                                                  widget.post,

                                                  // reactions: data,
                                                );
                                              });

                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget.post
                                                  .postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        } else {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ReactRetweetDialog(
                                                      'People who reacted',
                                                      post: widget
                                                          .post,
                                                      // reactions: data,
                                                    )),
                                          );
                                          // List<Reaction1> data =
                                          await widget.controller
                                              .getWhoReacted(
                                              widget.post
                                                  .postId,
                                              reactionType:
                                              "all",
                                              allLikes: 0);
                                        }
                                      },
                                      child: Container(
                                        padding: const EdgeInsets
                                            .symmetric(
                                          horizontal: 5,
                                          vertical: 1,
                                        ),
                                        // decoration: BoxDecoration(
                                        //   color: Colors.grey[100],
                                        //   borderRadius: BorderRadius.circular(20),
                                        // ),
                                        child: Text(
                                          "${widget.post.likeCount.value}",
                                          style: Styles.baseTextTheme.headline2
                                              .copyWith(
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              }),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  Tooltip(
                                    message: 'Reply',
                                    child: InkWell(
                                      onTap: () {
                                        if (!kIsWeb) {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                      CommentsScreen(
                                                          postId: widget
                                                              .post
                                                              .postId)));
                                          widget.controller
                                              .postId =
                                              widget.post.postId;
                                          // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                          //   "postId": post.postId,
                                          //   "controller": controller
                                          // });
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (BuildContext context) => CommentsScreen(),
                                          //   ),
                                          // );
                                        } else {
                                          widget
                                              .controller.postList
                                              .forEach((element) {
                                            element.isComment
                                                .value = false;
                                          });
                                          // controller.postIndex = ;
                                          widget.post.isComment
                                              .value = true;
                                          // controller.getNewsFeed(reload: false);
                                          // controller.update();
                                          // controller.isCommentClick = false;
                                          if (Get
                                              .find<
                                              BrowseController>()
                                              .browsePostList
                                              .isNotEmpty &&
                                              Get
                                                  .find<BrowseController>()
                                                  .browsePostList
                                                  .length >
                                                  0) {
                                            Get
                                                .find<
                                                BrowseController>()
                                                .browsePostList
                                                .forEach(
                                                    (element) {
                                                  element.isComment
                                                      .value = false;
                                                });
                                            // controller.postIndex = ;
                                            widget.post.isComment
                                                .value = true;
                                          }
                                        }
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: new Image.asset(
                                          'assets/drawer_icons/comments.png',

                                          // post.isRetweeted
                                          //     ? Theme.of(context).iconTheme.color
                                          //     :

                                          color: Colors.white,
                                        ),
                                        // Icon(Icons.comment_outlined,
                                        //     color: post.isRetweeted
                                        //         ? Theme.of(context).iconTheme.color
                                        //         : Colors.grey)
                                        // Text(
                                        //   Strings.comments,
                                        //   style: Theme.of(context).textTheme.bodyText2,
                                      ),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () async {
                                      // List<Retweet> data =
                                      //     await controller.getWhoRetweeted(post.postId);
                                      // 
                                      // showDialog(
                                      //     context: context,
                                      //     builder: (context) {
                                      //       return ReactRetweetDialog(
                                      //         Strings.peopleWhoRetweeted,
                                      //         retweets: data,
                                      //       );
                                      //     });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget.post.commentCount
                                            .value
                                            .toString(),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  widget.post.isRetweeted == null
                                      ? SizedBox()
                                      : Tooltip(
                                    message: Strings.rewerf,
                                    child: InkWell(
                                      onTap:
                                      widget.post.rebuzz
                                          .value
                                          ? () async {
                                        widget.controller.createDeleteBuzz(
                                            "undo_retweet",
                                            widget
                                                .post);

                                        // var response =
                                        //     await controller.undoRetweet(post.postId);
                                        // if (response == 'Undo retweeted Successfully')
                                        widget.post
                                            .isRetweeted =
                                        false;
                                        widget
                                            .post
                                            .rebuzz
                                            .value = false;
                                        // post.rebuzzCount.value--;
                                        widget
                                            .post
                                            .rebuzzCount
                                            .refresh();
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .undoRetweet(widget
                                            .post
                                            .postId);
                                        setState(
                                                () {});
                                        // controller.update();
                                      }
                                          : () async {
                                        widget.controller.createDeleteBuzz(
                                            "retweet",
                                            widget
                                                .post);
                                        // var response =
                                        //     await controller.addRetweet(post.postId);
                                        // if (response == 'Add retweet Successfully')
                                        widget.post
                                            .isRetweeted =
                                        true;
                                        // post.rebuzzCount.value++;
                                        widget
                                            .post
                                            .rebuzzCount
                                            .refresh();
                                        widget
                                            .post
                                            .rebuzz
                                            .value = true;
                                        // ignore: unused_local_variable
                                        var response = await widget
                                            .controller
                                            .addRetweet(widget
                                            .post
                                            .postId);
                                        setState(
                                                () {});
                                        // controller.update();
                                      },
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                        child: Image.asset(
                                          'assets/drawer_icons/rebuzz.png',
                                          color: widget
                                              .post
                                              .rebuzz
                                              .value
                                              ? Colors
                                              .white
                                              : Colors
                                              .white,
                                        ),
                                      ),
                                      // Icon(Icons.repeat,Ftext
                                      //     color: post.isRetweeted
                                      //         ? Theme.of(context).iconTheme.color
                                      //         : Colors.grey),
                                    ),
                                  ),
                                  // Text(
                                  //   Strings.reBuzz,
                                  //   style: Theme.of(context).textTheme.bodyText2,
                                  // ),
                                  GestureDetector(
                                    onTap: () async {
                                      List<Retweet> data =
                                      await widget.controller
                                          .getWhoRetweeted(
                                          widget.post
                                              .postId);
                                      
                                      showDialog(
                                          context: context,
                                          builder: (context) {
                                            return ReactRetweetDialog(
                                              Strings
                                                  .peopleWhoRetweeted,
                                              retweets: data,
                                            );
                                          });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                        horizontal: 8,
                                        vertical: 1,
                                      ),
                                      // decoration: BoxDecoration(
                                      //   color: Colors.grey[100],
                                      //   borderRadius: BorderRadius.circular(20),
                                      // ),
                                      child: Text(
                                        widget.post.rebuzzCount
                                            .value
                                            .toString(),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              ///
                              PopupMenuButton(
                                  tooltip: "Share",
                                  position: PopupMenuPosition.under,
                                  padding: EdgeInsets.zero,
                                  icon: Image.asset(
                                    AppImages.share,
                                    color: Theme
                                        .of(context)
                                        .brightness == Brightness.dark
                                        ? Colors.white
                                        : Colors.white,
                                    height: 25,
                                    width: 25,
                                  ),

                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark ? Colors
                                      .black : Colors.white,
                                  // Callback that sets the selected popup menu item.
                                  onSelected: (value) async {
                                    if (value == 1) {
                                      // ignore: unused_local_variable
                                      bool isSuccess = await widget.controller
                                          .savePost(widget.post.postId);
                                      if (isSuccess) {
                                        widget.post.saved = true;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'Werf saved successfully!');
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in saving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in saving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme
                                        //           .of(context)
                                        //           .brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }

                                      // Get.showSnackbar(buildSnackBar(
                                      //     isSuccess
                                      //         ? 'Your Update is saved Successfull'
                                      //         : 'An Error Occured While Saving your update',
                                      //     context));
                                      // controller.update();
                                    }
                                    else if (value == 2) {
                                      bool isSuccess = await widget.controller
                                          .unSavePost(widget.post.postId);


                                      if (isSuccess) {
                                        widget.post.saved = false;
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.werfUnsaved);
                                      }
                                      if (!isSuccess) {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: 'There was an error in Unsaving this werf!');
                                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                        //   content: Text('There was an error in Unsaving this werf!',
                                        //     style: TextStyle(
                                        //       color: Theme.of(context).brightness == Brightness.dark
                                        //           ? Colors.white
                                        //           : Colors.black,
                                        //     ),
                                        //   ),
                                        // ),
                                        // );
                                      }
                                    }

                                    else if (value == 3) {
                                      // kIsWeb ?
                                      // showReposrtUserDialog(
                                      //     context, post.authorId.toString(), controller) :

                                      // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                      String genterate = 'https://werfie.com/home/postDetail/' +
                                          widget.post.postId.toString();
                                      // toStringpost.postId.toString());

                                      // UtilsMethods.share(genterate, 'Werf');


                                      Clipboard.setData(
                                          ClipboardData(text: genterate)).then((
                                          _) {
                                        Fluttertoast.showToast(
                                            msg: 'Werf link copied successfully',
                                            toastLength:
                                            Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.TOP,
                                            timeInSecForIosWeb:
                                            1,
                                            backgroundColor: widget.controller
                                                .displayColor,

                                            textColor: Colors.white,
                                            webPosition: "center",
                                            webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                            fontSize: 16.0);
                                      });

                                      // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                      // UtilsMethods.share(
                                      //     genterate,
                                      //     'post');
                                      // print('post Id at share' + post.postId.toString());
                                      // print('linkgenerate:${genterate}');


                                      // UtilsMethods.toastMessageShow(
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     controller.displayColor,
                                      //     message: 'Werf link copied successfully');


                                      widget.controller.update();
                                    }
                                    else if (value == 4) {
                                      if (!kIsWeb) {
                                        // kIsWeb ?
                                        // showReposrtUserDialog(
                                        //     context, post.authorId.toString(), controller) :

                                        String genterate = await FirebaseDeepLink()
                                            .createDynamicLink(
                                            short: true, link: '/post?postId=' +
                                            widget.post.postId.toString());

                                        UtilsMethods.share(genterate, 'Werf');


                                        // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                        // UtilsMethods.share(
                                        //     genterate,
                                        //     'post');
                                        // print('post Id at share' + post.postId.toString());
                                        // print('linkgenerate:${genterate}');


                                        widget.controller.update();
                                      }
                                      else {
                                        UtilsMethods.toastMessageShow(
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            widget.controller.displayColor,
                                            message: Strings.shareWerf);
                                      }
                                    }
                                  },
                                  itemBuilder: (BuildContext context) =>
                                  [
                                    if(widget.post.saved == false ||
                                        widget.post.saved == null)
                                      PopupMenuItem(
                                        value: 1,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text(Strings.bookmark,
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    if(widget.post.saved == true)
                                      PopupMenuItem(
                                        value: 2,
                                        child: Row(

                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/svg_drawer_icons/saved.svg',
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5,),
                                            Text(Strings.removeWerfFromBookMark,
                                              style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),
                                            ),
                                          ],
                                        ),),

                                    PopupMenuItem(
                                      value: 3,
                                      child: Row(
                                          children: [
                                            Container(
                                                width: 20,
                                                height: 20,
                                                child: Image.asset(
                                                  AppImages.copylink,
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                )
                                            ),
                                            SizedBox(width: 5),
                                            Text(
                                              Strings.copylinkToWerf,
                                              style:
                                              TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors
                                                      .black,
                                                  fontSize: 14
                                              ),),
                                          ]),),
                                    if(!kIsWeb)

                                      PopupMenuItem(
                                        value: 4,
                                        child: Row(
                                            children: [
                                              Container(
                                                  width: 20,
                                                  height: 20,
                                                  child: Image.asset(
                                                    AppImages.share,
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  )
                                              ),
                                              SizedBox(width: 5),
                                              Text(
                                                Strings.shareWerf,
                                                style:
                                                TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors
                                                        .black,
                                                    fontSize: 14
                                                ),),
                                            ]),),
                                  ]
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                      : SizedBox()
                ],
              ),

              // CarouselSlider(
              //   options: CarouselOptions(
              //     enableInfiniteScroll: false,
              //   ),
              //   items: imagesListForCarousel
              //       .map(
              //         (item) => Container(
              //           child: Center(
              //             child: Image.network(
              //               item,
              //               fit: BoxFit.fill,
              //               width: Get.width * 0.4,
              //             ),
              //           ),
              //         ),
              //       )
              //       .toList(),
              // ),
            ),

            widget.chatCheck != 1 ?
            Obx(() {
              return GestureDetector(
                onTap: () {
                  widget.post.reactionCheck.value = false;
                },
                child: Container(
                  color: Colors.black,
                  width: Get.width,
                  height: kIsWeb ? Get.height : Get.height,
                  child: Stack(
                    children: [
                      widget.imagesListForCarousel != null
                          ? widget.imagesListForCarousel.length >= 2
                          ? Swiper(
                        onIndexChanged: (index) => currentSwiperImgIndex = index,
                        loop: false,
                        index: widget.mediaIndex,
                        containerWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemBuilder:
                            (BuildContext context, int index) {
                          return widget.imagesListForCarousel !=
                              null
                              ? Center(
                            child: InteractiveViewer(
                              minScale: 0.0001,
                              maxScale: 0.0001,
                              child: Image.network(
                                widget.imagesListForCarousel[
                                index],
                                fit: BoxFit.contain,
                                height: kIsWeb
                                    ? Get.height
                                    : Get.height,
                                width: kIsWeb
                                    ? Get.width * 0.4
                                    : Get.width,
                              ),
                            ),
                          )
                              : SizedBox();
                          // : ChewieVideoPlayer(
                          // videoUrl: widget.videoListForCarousel[index]);
                        },
                        itemCount: widget.imagesListForCarousel !=
                            null
                            ? widget.imagesListForCarousel.length
                            : widget.videoListForCarousel.length,

                        pagination: SwiperPagination(
                          builder: FractionPaginationBuilder(
                            activeColor: Colors.amber,
                            fontSize: 18,
                            activeFontSize: 18,
                          ),
                          alignment: Alignment.topCenter,
                        ),
                        // control: SwiperControl(
                        //   padding: EdgeInsets.only(left: 28, right: 20),
                        //   size: 50,
                        //   color: Color(0xFFedab30),
                        // ),
                      )
                          : Swiper(
                        onIndexChanged: (index) => currentSwiperImgIndex = index,
                        loop: false,
                        index: widget.mediaIndex,
                        containerWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemWidth:
                        kIsWeb ? Get.width * 0.4 : Get.width,
                        itemBuilder:
                            (BuildContext context, int index) {
                          return widget.imagesListForCarousel !=
                              null
                              ? Center(
                            child: InteractiveViewer(
                              minScale: 0.0001,
                              maxScale: 0.0001,
                              child: Image.network(
                                widget.imagesListForCarousel[
                                index],
                                fit: BoxFit.contain,
                                height: kIsWeb
                                    ? Get.height
                                    : Get.height,
                                width: kIsWeb
                                    ? Get.width * 0.4
                                    : Get.width,
                              ),
                            ),
                          )
                              : SizedBox()
                          // ChewieVideoPlayer(
                          //     videoUrl: widget.videoListForCarousel[index])
                              ;
                        },
                        itemCount: widget.imagesListForCarousel !=
                            null
                            ? widget.imagesListForCarousel.length
                            : widget.videoListForCarousel.length,

                        // control: SwiperControl(
                        //   padding: EdgeInsets.only(left: 28, right: 20),
                        //   size: 50,
                        //   color: Color(0xFFedab30),
                        // ),
                      )
                          : SizedBox(),
                      widget.chatCheck != 1
                          ? Positioned.fill(
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            alignment: Alignment.center,
                            width: double.infinity,
                            height: 74,
                            color: Colors.black87,
                            // margin: EdgeInsets.symmetric(horizontal: 20),

                            ///reaction row
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: 20, right: 20, bottom: 20),
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Obx(() {
                                    return Row(
                                      children: [
                                        Tooltip(
                                          message: 'React',
                                          child: InkWell(
                                            onLongPress: () {},
                                            onTap: () async {
                                              if (widget.post
                                                  .reactionCheck ==
                                                  false) {
                                                if (widget.check ==
                                                    1) {} else {
                                                  widget.controller.postList
                                                      .forEach((element) {
                                                    element.reactionCheck
                                                        .value = false;
                                                  });
                                                  widget.post.reactionCheck
                                                      .value = true;
                                                }

                                                
                                              } else if (widget.post
                                                  .reactionCheck ==
                                                  true) {
                                                widget
                                                    .post
                                                    .reactionCheck
                                                    .value = false;
                                                
                                              }

                                              // post.reactionCheck.value = false;
                                              // if(post.like.value == true)
                                              //   {
                                              //
                                              //
                                              //     post.reactionType.value = "like_simple_like";
                                              //   }
                                              // else if(post.like.value == false)
                                              //   {
                                              //     post.reactionType.value = "dislike_simple_dislike";
                                              //   }
                                              //
                                              // controller.likeUnlike(
                                              //   post.reactionType.value,
                                              //   post.postId,
                                              //   {
                                              //     'isLikedSocket': post.like.value,
                                              //     'totalLikes': post.likeCount.value
                                              //   },
                                              // );
                                              //
                                              // // ignore: unused_local_variable
                                              // 
                                              // if (post.like.value) {
                                              //   post.like.value = false;
                                              //
                                              //   if (post.likeCount.value > 0) {
                                              //     // post.likeCount.value--;
                                              //   } else {
                                              //     post.likeCount.value = 0;
                                              //   }
                                              //
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              //   print(
                                              //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                              // }
                                              // else {
                                              //   post.like.value = true;
                                              //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                              //   // post.simpleLikeCount++;
                                              //   // post.likeCount.value++;
                                              //   post.likeCount.refresh();
                                              //   // controller.update();
                                              // }
                                              // // ignore: unused_local_variable
                                              //
                                              //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                              //
                                              // // if (await UtilsMethods.checkInternet()) {
                                              // //
                                              // //   //   log('like response>>> $response'); //number of likes
                                              // //   //   var  postDetails= post;
                                              // //   //   postDetails.likeCount.value=response;
                                              // //   // var dbRes = await  DatabaseHelper.instance
                                              // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                              // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                              // // }
                                              // controller.postIndex = index;
                                              // controller.update();
                                            },
                                            child: widget
                                                .post
                                                .reactionType
                                                .value ==
                                                "love"
                                                ? Image.asset(
                                              'assets/reaction_gif/love-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget
                                                .post
                                                .reactionType
                                                .value ==
                                                "like_simple_like"
                                                ? Image.asset(
                                              'assets/reaction_gif/like-min.png',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget
                                                .post
                                                .reactionType
                                                .value ==
                                                null
                                                ? Image.asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 25,
                                              height:
                                              25,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "lough"
                                                ? Image
                                                .asset(
                                              'assets/reaction_gif/laugh-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width:
                                              30,
                                              height:
                                              30,
                                            )
                                                : widget.post.reactionType
                                                .value ==
                                                "smile"
                                                ? Image
                                                .asset(
                                              'assets/reaction_gif/smile-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "thanks"
                                                ? Image.asset(
                                              'assets/reaction_gif/thanks-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "excited"
                                                ? Image.asset(
                                              'assets/reaction_gif/excited-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : widget.post.reactionType
                                                .value == "cry"
                                                ? Image.asset(
                                              'assets/reaction_gif/cry-min.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 30,
                                              height: 30,
                                            )
                                                : Image.asset(
                                              'assets/drawer_icons/not_like.png',
                                              // : 'assets/reaction_gif/like_gif.gif',
                                              width: 25,
                                              height: 25,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 5),
                                        GestureDetector(
                                          onTap: () async {
                                            // List<Reaction1> data =
                                            // await widget.controller.getWhoReacted(widget.post.postId);
                                            // // 
                                            // showDialog(
                                            //     context: context,
                                            //     builder: (context) {
                                            //       return ReactRetweetDialog(
                                            //         'People who reacted',
                                            //         // reactions: data,
                                            //       );
                                            //     });

                                            if (kIsWeb) {
                                              showDialog(
                                                  context: context,
                                                  builder: (context) {
                                                    return ReactRetweetDialog(
                                                      'People who reacted',
                                                      post:
                                                      widget.post,

                                                      // reactions: data,
                                                    );
                                                  });

                                              // List<Reaction1> data =
                                              await widget.controller
                                                  .getWhoReacted(
                                                  widget.post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes: 0);
                                            } else {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReactRetweetDialog(
                                                          'People who reacted',
                                                          post: widget
                                                              .post,
                                                          // reactions: data,
                                                        )),
                                              );
                                              // List<Reaction1> data =
                                              await widget.controller
                                                  .getWhoReacted(
                                                  widget.post
                                                      .postId,
                                                  reactionType:
                                                  "all",
                                                  allLikes: 0);
                                            }
                                          },
                                          child: Container(
                                            padding: const EdgeInsets
                                                .symmetric(
                                              horizontal: 5,
                                              vertical: 1,
                                            ),
                                            // decoration: BoxDecoration(
                                            //   color: Colors.grey[100],
                                            //   borderRadius: BorderRadius.circular(20),
                                            // ),
                                            child: Text(
                                              "${widget.post.likeCount.value}",
                                              style: Styles.baseTextTheme
                                                  .headline2.copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  }),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      Tooltip(
                                        message: 'Comment',
                                        child: InkWell(
                                          onTap: () {
                                            processReplyDialog(context);
                                            return;
                                            if (!kIsWeb) {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (BuildContext
                                                      context) =>
                                                          CommentsScreen(
                                                              postId: widget
                                                                  .post
                                                                  .postId)));
                                              widget.controller
                                                  .postId =
                                                  widget.post.postId;
                                              // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
                                              //   "postId": post.postId,
                                              //   "controller": controller
                                              // });
                                              // Navigator.push(
                                              //   context,
                                              //   MaterialPageRoute(
                                              //     builder: (BuildContext context) => CommentsScreen(),
                                              //   ),
                                              // );
                                            } else {
                                              widget.controller.postList
                                                  .forEach((element) {
                                                element.isComment.value = false;
                                              });
                                              // controller.postIndex = ;
                                              widget.post.isComment
                                                  .value = true;
                                              // controller.getNewsFeed(reload: false);
                                              // controller.update();
                                              // controller.isCommentClick = false;
                                              if (Get
                                                  .find<
                                                  BrowseController>()
                                                  .browsePostList
                                                  .isNotEmpty &&
                                                  Get
                                                      .find<BrowseController>()
                                                      .browsePostList
                                                      .length >
                                                      0) {
                                                Get
                                                    .find<
                                                    BrowseController>()
                                                    .browsePostList
                                                    .forEach(
                                                        (element) {
                                                      element.isComment
                                                          .value = false;
                                                    });
                                                // controller.postIndex = ;
                                                widget.post.isComment
                                                    .value = true;
                                              }
                                            }
                                          },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            child: new Image.asset(
                                              'assets/drawer_icons/comments.png',

                                              // post.isRetweeted
                                              //     ? Theme.of(context).iconTheme.color
                                              //     :

                                              color: Colors.white,
                                            ),
                                            // Icon(Icons.comment_outlined,
                                            //     color: post.isRetweeted
                                            //         ? Theme.of(context).iconTheme.color
                                            //         : Colors.grey)
                                            // Text(
                                            //   Strings.comments,
                                            //   style: Theme.of(context).textTheme.bodyText2,
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () async {
                                          // List<Retweet> data =
                                          //     await controller.getWhoRetweeted(post.postId);
                                          // 
                                          // showDialog(
                                          //     context: context,
                                          //     builder: (context) {
                                          //       return ReactRetweetDialog(
                                          //         Strings.peopleWhoRetweeted,
                                          //         retweets: data,
                                          //       );
                                          //     });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget.post.commentCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: [
                                      widget.post.isRetweeted == null
                                          ? SizedBox()
                                          : Tooltip(
                                        message: Strings.rewerf,
                                        child: InkWell(
                                          onTap:
                                          widget.post.rebuzz
                                              .value
                                              ? () async {
                                            widget.controller.createDeleteBuzz(
                                                "undo_retweet",
                                                widget
                                                    .post);

                                            // var response =
                                            //     await controller.undoRetweet(post.postId);
                                            // if (response == 'Undo retweeted Successfully')
                                            widget.post
                                                .isRetweeted =
                                            false;
                                            widget
                                                .post
                                                .rebuzz
                                                .value = false;
                                            // post.rebuzzCount.value--;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .undoRetweet(widget
                                                .post
                                                .postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          }
                                              : () async {
                                            widget.controller.createDeleteBuzz(
                                                "retweet",
                                                widget
                                                    .post);
                                            // var response =
                                            //     await controller.addRetweet(post.postId);
                                            // if (response == 'Add retweet Successfully')
                                            widget.post
                                                .isRetweeted =
                                            true;
                                            // post.rebuzzCount.value++;
                                            widget
                                                .post
                                                .rebuzzCount
                                                .refresh();
                                            widget
                                                .post
                                                .rebuzz
                                                .value = true;
                                            // ignore: unused_local_variable
                                            var response = await widget
                                                .controller
                                                .addRetweet(widget
                                                .post
                                                .postId);
                                            setState(
                                                    () {});
                                            // controller.update();
                                          },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              'assets/drawer_icons/rebuzz.png',
                                              color: widget
                                                  .post
                                                  .rebuzz
                                                  .value
                                                  ? Colors
                                                  .white
                                                  : Colors
                                                  .white,
                                            ),
                                          ),
                                          // Icon(Icons.repeat,Ftext
                                          //     color: post.isRetweeted
                                          //         ? Theme.of(context).iconTheme.color
                                          //         : Colors.grey),
                                        ),
                                      ),
                                      // Text(
                                      //   Strings.reBuzz,
                                      //   style: Theme.of(context).textTheme.bodyText2,
                                      // ),
                                      GestureDetector(
                                        onTap: () async {
                                          List<Retweet> data =
                                          await widget.controller
                                              .getWhoRetweeted(
                                              widget.post
                                                  .postId);
                                          // 
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return ReactRetweetDialog(
                                                  Strings
                                                      .peopleWhoRetweeted,
                                                  retweets: data,
                                                );
                                              });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets
                                              .symmetric(
                                            horizontal: 8,
                                            vertical: 1,
                                          ),
                                          // decoration: BoxDecoration(
                                          //   color: Colors.grey[100],
                                          //   borderRadius: BorderRadius.circular(20),
                                          // ),
                                          child: Text(
                                            widget.post.rebuzzCount
                                                .value
                                                .toString(),
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  ///
                                  PopupMenuButton(
                                      tooltip: "Share",
                                      position: PopupMenuPosition.under,
                                      padding: EdgeInsets.zero,
                                      icon: Image.asset(
                                        AppImages.share,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.white,
                                        height: 25,
                                        width: 25,
                                      ),

                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.black
                                          : Colors.white,
                                      // Callback that sets the selected popup menu item.
                                      onSelected: (value) async {
                                        if (value == 1) {
                                          // ignore: unused_local_variable
                                          bool isSuccess = await widget
                                              .controller.savePost(
                                              widget.post.postId);
                                          if (isSuccess) {
                                            widget.post.saved = true;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'Werf saved successfully!');
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in saving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in saving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme
                                            //           .of(context)
                                            //           .brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }

                                          // Get.showSnackbar(buildSnackBar(
                                          //     isSuccess
                                          //         ? 'Your Update is saved Successfull'
                                          //         : 'An Error Occured While Saving your update',
                                          //     context));
                                          // controller.update();
                                        }
                                        else if (value == 2) {
                                          bool isSuccess = await widget
                                              .controller.unSavePost(
                                              widget.post.postId);


                                          if (isSuccess) {
                                            widget.post.saved = false;
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: Strings.werfUnsaved);
                                          }
                                          if (!isSuccess) {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: 'There was an error in Unsaving this werf!');
                                            // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                            //   content: Text('There was an error in Unsaving this werf!',
                                            //     style: TextStyle(
                                            //       color: Theme.of(context).brightness == Brightness.dark
                                            //           ? Colors.white
                                            //           : Colors.black,
                                            //     ),
                                            //   ),
                                            // ),
                                            // );
                                          }
                                        }

                                        else if (value == 3) {
                                          // kIsWeb ?
                                          // showReposrtUserDialog(
                                          //     context, post.authorId.toString(), controller) :

                                          // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                                          String genterate = 'https://werfie.com/home/postDetail/' +
                                              widget.post.postId.toString();
                                          // toStringpost.postId.toString());

                                          // UtilsMethods.share(genterate, 'Werf');


                                          Clipboard.setData(
                                              ClipboardData(text: genterate))
                                              .then((_) {
                                            Fluttertoast.showToast(
                                                msg: 'Werf link copied successfully',
                                                toastLength:
                                                Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.TOP,
                                                timeInSecForIosWeb:
                                                1,
                                                backgroundColor: widget
                                                    .controller.displayColor,

                                                textColor: Colors.white,
                                                webPosition: "center",
                                                webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                                fontSize: 16.0);
                                          });

                                          // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                          // UtilsMethods.share(
                                          //     genterate,
                                          //     'post');
                                          // print('post Id at share' + post.postId.toString());
                                          // print('linkgenerate:${genterate}');


                                          // UtilsMethods.toastMessageShow(
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     controller.displayColor,
                                          //     message: 'Werf link copied successfully');


                                          widget.controller.update();
                                        }
                                        else if (value == 4) {
                                          if (!kIsWeb) {
                                            // kIsWeb ?
                                            // showReposrtUserDialog(
                                            //     context, post.authorId.toString(), controller) :

                                            String genterate = await FirebaseDeepLink()
                                                .createDynamicLink(short: true,
                                                link: '/post?postId=' +
                                                    widget.post.postId
                                                        .toString());

                                            UtilsMethods.share(
                                                genterate, 'Werf');


                                            // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                                            // UtilsMethods.share(
                                            //     genterate,
                                            //     'post');
                                            // print('post Id at share' + post.postId.toString());
                                            // print('linkgenerate:${genterate}');


                                            widget.controller.update();
                                          }
                                          else {
                                            UtilsMethods.toastMessageShow(
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                widget.controller.displayColor,
                                                message: Strings.shareWerf);
                                          }
                                        }
                                      },
                                      itemBuilder: (BuildContext context) =>
                                      [
                                        if(widget.post.saved == false ||
                                            widget.post.saved == null)
                                          PopupMenuItem(
                                            value: 1,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text(Strings.bookmark,
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        if(widget.post.saved == true)
                                          PopupMenuItem(
                                            value: 2,
                                            child: Row(

                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/svg_drawer_icons/saved.svg',
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5,),
                                                Text(
                                                  Strings.removeWerfFromBookMark,
                                                  style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),
                                                ),
                                              ],
                                            ),),

                                        PopupMenuItem(
                                          value: 3,
                                          child: Row(
                                              children: [
                                                Container(
                                                    width: 20,
                                                    height: 20,
                                                    child: Image.asset(
                                                      AppImages.copylink,
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    )
                                                ),
                                                SizedBox(width: 5),
                                                Text(
                                                  Strings.copylinkToWerf,
                                                  style:
                                                  TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      fontSize: 14
                                                  ),),
                                              ]),),
                                        if(!kIsWeb)

                                          PopupMenuItem(
                                            value: 4,
                                            child: Row(
                                                children: [
                                                  Container(
                                                      width: 20,
                                                      height: 20,
                                                      child: Image.asset(
                                                        AppImages.share,
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                      )
                                                  ),
                                                  SizedBox(width: 5),
                                                  Text(
                                                    Strings.shareWerf,
                                                    style:
                                                    TextStyle(
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors
                                                            .black,
                                                        fontSize: 14
                                                    ),),
                                                ]),),
                                      ]
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                          : SizedBox()
                    ],
                  ),

                  // CarouselSlider(
                  //   options: CarouselOptions(
                  //     enableInfiniteScroll: false,
                  //   ),
                  //   items: imagesListForCarousel
                  //       .map(
                  //         (item) => Container(
                  //           child: Center(
                  //             child: Image.network(
                  //               item,
                  //               fit: BoxFit.fill,
                  //               width: Get.width * 0.4,
                  //             ),
                  //           ),
                  //         ),
                  //       )
                  //       .toList(),
                  // ),
                ),
              );
            }) : SizedBox(),

            widget.chatCheck != 1
                ? Obx(() {
              return widget.post.reactionCheck.value == true
                  ? Positioned(
                bottom: 60,
                left: kIsWeb ? 180 : 20,
                child: Container(
                  height: 45,
                  width: 260,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(50),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(
                            0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          // print("raection print idhr ");


                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          if (widget.post.reactionType.value ==
                              'like_simple_like') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "like_simple_like";
                          }

                          // post.reactionType.value = 'like_simple_like';

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }


                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.like,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'love') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "lough" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "love";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          // print("controller.counter ${controller.counter}");
                          // if(controller.counter == false)
                          // {
                          //   post.reactionType.value = null;
                          //
                          // }

                          // controller.update();

                          // controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.love,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'lough') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "excited" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "lough";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.lough,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'excited') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile" ||
                              widget.post.reactionType.value ==
                                  "thanks") {
                            widget.post.reactionType.value =
                            "excited";
                          }


                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          // ignore: unused_local_variable
                          

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;

                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // controller.update();

                          // widget.controller.postIndex = index;

                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.excited,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'thanks') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "cry" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "thanks";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }


                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }

                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.thanks,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'cry') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love" ||
                              widget.post.reactionType.value ==
                                  "smile") {
                            widget.post.reactionType.value =
                            "cry";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);
                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.cry,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          if (widget.post.reactionType.value == null ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            widget.post.likeCount.value =
                                widget.post.likeCount.value + 1;


                            
                            widget.controller.likeUnlike(
                              widget.post.reactionType.value,
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          if (widget.post.reactionType.value ==
                              'smile') {
                            widget.post.reactionType.value =
                            "dislike_simple_dislike";
                          } else if (widget.post.reactionType
                              .value ==
                              null ||
                              widget.post.reactionType.value ==
                                  'cry' ||
                              widget.post.reactionType.value ==
                                  'thanks' ||
                              widget.post.reactionType.value ==
                                  'excited' ||
                              widget.post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              widget.post.reactionType.value ==
                                  'lough' ||
                              widget.post.reactionType.value ==
                                  "like_simple_like" ||
                              widget.post.reactionType.value ==
                                  "love") {
                            widget.post.reactionType.value =
                            "smile";
                          }

                          if (widget.post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (widget.post.likeCount.value != 0) {
                              widget.post.likeCount.value--;
                            } else {
                              widget.post.likeCount.value = 0;
                            }
                           
                            widget.controller.likeUnlike(
                              "unlike",
                              widget.post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': widget.post.likeCount.value
                              },
                            );
                          }
                          
                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          widget.post.like.value = false;
                          widget.post.reactionCheck.value =
                          false;
                          await widget.controller.likePost(
                              widget.post.postId,
                              widget.post.reactionType.value,
                              post: widget.post);

                          if (widget.controller.counter == 0) {
                            widget.post.reactionType.value =
                            null;
                          }
                          // widget.controller.postIndex = index;
                          widget.controller.update();
                        },
                        child: Image.asset(
                          AppImages.smile,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),
                    ],
                  ),
                ),
              )
                  : SizedBox();
            })
                : SizedBox()
          ],
        ),
      );
    }
  }
  Future<void> saveAsImageAndShare(String imgUrl) async {

    final url = Uri.parse(imgUrl);
    final response = await http.get(url);

    final path = (await getTemporaryDirectory()).path;
    final file = File('$path/Share_image.png');
    await file.writeAsBytes(response.bodyBytes);

    Share.shareXFiles([XFile('$path/Share_image.png')]);

  }


  processReplyDialog(context){
    if (kIsWeb) {
      //gotoWerfDetailPage(context);
      showReplyDialog(context);

    }
    else {
      debugPrint("Comments Clicked");
      if (widget.commentId == 1) {
        if (Get.isRegistered<
            MobileCommentsController>()) {
          Get.delete<
              MobileCommentsController>();
        }
      } else {
        widget.controller.selectedPost = widget.post;
        widget.controller.commentController.clear();
        widget.controller.selectedPost = widget.post;
      }

      gotoReplyDialog(context);
      return;
    }
  }

  showReplyDialog(BuildContext context) async{
    SingleTone.instance.commentId = widget.commentId;
    if (widget.commentId == 1) {
      MobileCommentsController mobileController;
      if (Get.isRegistered<MobileCommentsController>()) {
        mobileController = await Get.find<MobileCommentsController>();
        //controller.selectedPost2 = await mobileController.getSingleNewsFeedItem(post.postId, isReload: true);
        //controller.getCommentsList = await mobileController.getCommentsPostLists(postId: post.postId);
      } else {
        mobileController = await Get.put(MobileCommentsController());
      }
    }
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                      Radius.circular(10.0))),
              insetPadding: EdgeInsets.symmetric(
                  horizontal: 0, vertical: 0),
              contentPadding: EdgeInsets.symmetric(
                  horizontal: 12),
              content: WebReplayModule(
                post: widget.post,
                newsfeedController: widget.controller,
                replyPageId: 2,
                getClickId: 1,

              ));
        });

  }

  gotoReplyDialog(var context){

    showModalBottomSheet(
        isDismissible: true,
        isScrollControlled: true,
        backgroundColor: Theme
            .of(context)
            .brightness == Brightness.dark ? Colors.black : Colors
            .white,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20))),
        context: context,
        builder: (context) {
          return SizedBox(
            height: Get.height - 60,
            child: ReplayMobile(
              post: widget.post, newsfeedController: widget.controller,
              replyPageId: widget.replyPageId,
              getClickId: 2,
            ),
          );
        });

  }
}
