import 'package:chewie/chewie.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:werfieapp/models/post.dart';

class ChewieAudioPlayer extends StatefulWidget {
  const ChewieAudioPlayer({
    Key key,
    // this.post,
    // this.index,
    this.audioUrl,
    // this.isAudio = false,
    // this.aspectRatio,
    // this.borderRadius = 12,
    // this.allowFullScreen = true,
    // this.isFullScreenOnMobile = false,
    // this.thumbnailUrl,
  }) : super(key: key);

  final String audioUrl;

  // final bool isAudio;
  // final double aspectRatio;
  // final double borderRadius;
  // final bool isFullScreenOnMobile;
  // final allowFullScreen;
  // final thumbnailUrl;

  @override
  State<ChewieAudioPlayer> createState() => _ChewieAudioPlayerState();
}

class _ChewieAudioPlayerState extends State<ChewieAudioPlayer> {
  VideoPlayerController videoPlayerController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    videoPlayerController = VideoPlayerController.network(widget.audioUrl);
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: AspectRatio(
          aspectRatio: 16 / 9,
          child: Chewie(
            controller: ChewieController(
              autoInitialize: false,
              allowFullScreen: false,
              placeholder: Align(
                alignment: Alignment.center,
                child: Container(
                  height: 200,
                  width: 200,
                  alignment: Alignment.center,
                  child: Image.asset(
                    'assets/images/audio_placeholder.png',
                    alignment: Alignment.center,
                  ),
                ),
              ),
              aspectRatio: 16 / 9,
              allowMuting: true,
              videoPlayerController: videoPlayerController,
              autoPlay: false,
              looping: true,
            ),
          )),
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose

    videoPlayerController.dispose();
  }
}
