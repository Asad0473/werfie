import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../network/controller/signup_controller.dart';
import '../utils/asset_string.dart';


class SignUpAppBarWidget extends StatefulWidget implements PreferredSizeWidget {
  final String title;
  final String bottomText;
  final VoidCallback onPress;

  SignUpAppBarWidget({
    Key key,
    this.title,
    this.onPress,
     this.bottomText=""
  }) : super(key: key);

  @override
  State<SignUpAppBarWidget> createState() => _SignUpAppBarWidgetState();

  @override
  Size get preferredSize => const Size.fromHeight(100);
}

class _SignUpAppBarWidgetState extends State<SignUpAppBarWidget> {
  final signupController = Get.find<SignupController>();

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.grey.shade100,
      elevation: 0,
      centerTitle: true,
      title:Image.asset(
        AppImages.newWerfieLogoPng,
        width: 100,
      ),
      leading:IconButton(
        icon: kIsWeb && signupController.currentStep == 1 ? Icon(Icons.close,color: Colors.black,) : Icon(Icons.arrow_back,color: Colors.black,),
        onPressed:widget.onPress,
      ),
      bottom: SignUpBottomAppbarWidget(title: widget.bottomText,),


    );
  }
}




class SignUpBottomAppbarWidget extends StatefulWidget implements PreferredSizeWidget {
  final String title;


  SignUpBottomAppbarWidget({
    Key key,
    this.title,

  }) : super(key: key);

  @override
  State<SignUpBottomAppbarWidget> createState() => _SignUpBottomAppbarWidgetState();

  @override
  Size get preferredSize => const Size.fromHeight(56);
}

class _SignUpBottomAppbarWidgetState extends State<SignUpBottomAppbarWidget> {
  @override
  Widget build(BuildContext context) {
    return   Container(
      padding: EdgeInsets.only(left: 30),
      child: Row(
        children: [
          Text(widget.title,
            textAlign: TextAlign.left,
            style:
            TextStyle(
              fontSize: 18.0,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

