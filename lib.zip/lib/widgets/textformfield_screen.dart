import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/font.dart';

class CustomFormField extends StatefulWidget {
  CustomFormField(
      {Key key,
      this.label,
      this.textInputType,
      this.onTextChange,
      this.inputFormator = const [],
      this.onChange,
      this.obscureText = false,
      this.hintColor,
      this.fieldType = 2,
      this.textAlign = TextAlign.start,
      this.controller,
      this.icon,
      this.isRounded = true,
      this.hasIcon = true,
      this.iswitf,
      this.labelStyle,
      this.focusBorderColor,
      this.hintText,
      this.maxLength,
      this.minLine,
      this.maxline})
      : super(key: key);
  final String label;
  final TextAlign textAlign;
  final TextInputType textInputType;
  final onTextChange;
  bool obscureText;
  final int fieldType;
  final IconData icon;
  final List<TextInputFormatter> inputFormator;
  final bool hasIcon;
  final bool isRounded;
  final Function(String) onChange;
  final hintColor;
  final iswitf;
  final Color focusBorderColor;
  final TextStyle labelStyle;
  final String hintText;
  final int maxLength;
  final int maxline;
  final int minLine;

  final TextEditingController controller;

  @override
  State<CustomFormField> createState() => _CustomFormFieldState();
}

class _CustomFormFieldState extends State<CustomFormField> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, right: 15),
      child: TextFormField(
        controller: widget.controller,
        maxLength: widget.maxLength,
        inputFormatters: widget.inputFormator,
        style: Styles.baseTextTheme.headline2.copyWith(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Colors.black,
          fontWeight: FontWeight.w500,
          fontSize: kIsWeb ? 16 : 14,
        ),

        decoration: InputDecoration(
          contentPadding: const EdgeInsets.all(10.0),
          //border:  _inputBorder(widget.isRounded),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey, width: 1),
          ),
          // disabledBorder: _inputBorder(widget.isRounded),
          disabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey, width: 1),
          ),
          // enabledBorder:widget.isRounded?  _inputBorder(widget.isRounded):null,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.grey, width: 1),
          ),
          enabled: true,
          errorBorder: _inputBorder(widget.isRounded),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(
                width: 1,
                color: widget.focusBorderColor,
              )),
          focusedErrorBorder: _inputBorder(widget.isRounded),
          filled: true,
          //  labelText: widget.label,
          //  labelStyle: widget.labelStyle,
          hintText: widget.hintText,
          hintStyle: Styles.baseTextTheme.headline2.copyWith(
            //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
            fontWeight: FontWeight.w400,
            fontSize: kIsWeb ? 16 : 14,
          ),
          // TextStyle(
          //     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
          //     fontWeight: FontWeight.bold,
          // ),
          fillColor: Colors.grey[250],
        ),
        keyboardType: widget.textInputType,
        obscureText: widget.obscureText,
        textAlign: TextAlign.start,
        cursorColor: Colors.blue,
        maxLines: widget.maxline,
        minLines: widget.minLine,

        onChanged: widget.onChange,

        //     (text) {
        //
        //   widget.onTextChange(text);
        //
        //
        // },
        onSaved: (val) {},
      ),
    );
  }

  InputBorder _inputBorder(isRounded) {
    return OutlineInputBorder(
      borderSide: BorderSide(),
      // borderRadius: BorderRadius.circular(isRounded?10:10,),
    );
  }
}

List<ItemVO> mainList = List();
List<ItemVO> sampleMenList = [
  ItemVO("1", "Mens 1"),
  ItemVO("2", "Mens 2"),
  ItemVO("3", "Mens 3")
];
List<ItemVO> sampleWomenList = [
  ItemVO("1", "Women 1"),
  ItemVO("2", "Women 2"),
  ItemVO("3", "Women 3")
];
List<ItemVO> sampleKidsList = [
  ItemVO("1", "kids 1"),
  ItemVO("2", "kids 2"),
  ItemVO("3", "kids 3")
];

class TestScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _TestScreen();
  }
}

class _TestScreen extends State<TestScreen> {
  @override
  void initState() {
    super.initState();
    mainList.addAll(sampleMenList);
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Stack(
        children: <Widget>[
          ListView.builder(
            itemBuilder: (BuildContext context, index) {
              return getCard(index);
            },
            itemCount: mainList.length,
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20),
            alignment: Alignment.bottomCenter,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                FloatingActionButton(
                  heroTag: UniqueKey(),

                  onPressed: () {
                    mainList.clear();
                    setState(() {
                      mainList.addAll(sampleMenList);
                    });
                  },
                  // heroTag: "btn1",
                  child: Text("Mens"),
                ),
                FloatingActionButton(
                  heroTag: UniqueKey(),

                  onPressed: () {
                    mainList.clear();
                    setState(() {
                      mainList.addAll(sampleWomenList);
                    });
                  },
                  // heroTag: "btn2",
                  child: Text("Women"),
                ),
                FloatingActionButton(
                  heroTag: UniqueKey(),

                  onPressed: () {
                    mainList.clear();
                    setState(() {
                      mainList.addAll(sampleKidsList);
                    });
                  },
                  // heroTag: "btn3",
                  child: Text("Kids"),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  /*
    Get the card item for a list
   */
  getCard(int position) {
    ItemVO model = mainList[position];
    return Card(
      child: Container(
        height: 50,
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "ID:: " + model._id,
              style: TextStyle(fontSize: 18, color: Colors.black),
            ),
            Padding(padding: EdgeInsets.only(left: 5, right: 5)),
            Text(
              "Name:: " + model._name,
              style: TextStyle(fontSize: 18, color: Colors.black),
            )
          ],
        ),
      ),
      margin: EdgeInsets.all(10),
    );
  }
}

/*
Custom model
i.e. for itemList
 */
class ItemVO {
  String _id, _name;

  String get id => _id;

  set id(String value) {
    _id = value;
  }

  get name => _name;

  set name(value) {
    _name = value;
  }

  ItemVO(this._id, this._name);
}
