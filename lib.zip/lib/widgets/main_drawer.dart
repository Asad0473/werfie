import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:routemaster/routemaster.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/controller/List_controller.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/screens/list_screen.dart';
import 'package:werfieapp/screens/login_screen.dart';
import 'package:werfieapp/screens/saved_post_screen.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/screens/settings_screen.dart';
import 'package:werfieapp/screens/topic_screens/topic_tab_screen.dart';
import 'package:werfieapp/screens/trends_screen.dart';
import 'package:werfieapp/screens/user_profile.dart';
import 'package:werfieapp/screens/who_to_follow_screen.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/constants.dart';
import 'package:werfieapp/utils/fluro_router.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/routes.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';

import '../network/apis/logout/logout.dart';
import '../network/controller/profile_controller.dart';
import '../network/singleTone.dart';
import '../screens/moments_screen/moments_create_screen.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import '../video_call/controller/video_call_controller.dart';
import '../video_call/video_call_home.dart';
import '../web_views/web_guest_user/web_guest_user_main.dart';
import 'blue_tick.dart';

class MainDrawer extends StatelessWidget {
  final NewsfeedController controller;

  MainDrawer(
    this.controller,
  );

  // final controller = Get.isRegistered<NewsfeedController>()? Get.find<NewsfeedController>():Get.put(NewsfeedController());
  @override
  Widget build(BuildContext context) {
    GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
    return Drawer(
      child: Column(
        children: [
          topProfilePicSection(context),
          Expanded(child: Obx(() {
            return ListView(
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              children: [
                videoCallWidget(context),
                buildListTile(
                  title: Strings.home,
                  iconImage: "assets/drawer_icons_new/home.png",
                  context: context,
                  index: Constants.homeScreenId,
                  selectedIndex: controller.index.value,
                  tapHandler: () async {
                    controller.index.value = Constants.homeScreenId;
                    controller.bottomNavIndex.value = Constants.homeScreenId;
                    Navigator.pop(context);
                    controller.postList = await controller.getNewsFeed(
                      shouldUpdate: false,
                      reload: true,
                      newsFeedMobile: true,
                    );
                  },
                ),
                buildListTile(
                  title: Strings.explore,
                  iconImage: "assets/drawer_icons_new/explore.png",
                  context: context,
                  index: Constants.browseScreenId,
                  selectedIndex: controller.index.value,
                  tapHandler: () {
                    controller.index.value = Constants.browseScreenId;
                    controller.bottomNavIndex.value = Constants.browseScreenId;
                    Navigator.pop(context);
                  },
                ),

                   buildListTile(
                  title: Strings.hotTrends,
                  iconImage: "assets/drawer_icons_new/hashtag.png",
                  context: context,
                  index: Constants.hotTrendsScreenId,
                  selectedIndex: controller.index.value,
                  tapHandler: () async {
                    controller.index.value = Constants.hotTrendsScreenId;
                    Navigator.pop(context);
                    controller.isSavedPostScreenExists
                        ? pushReplacement(
                            context, TrendsScreen(controller: controller))
                        : pushRoute(
                            context, TrendsScreen(controller: controller));
                  },
                ),
                buildListTile(
                  title: Strings.whoToFollow,
                  iconImage: "assets/drawer_icons_new/who_to_follow.png",
                  context: context,
                  index: Constants.whoToFollowScreenId,
                  selectedIndex: controller.index.value,
                  tapHandler: () {
                    controller.index.value = Constants.whoToFollowScreenId;
                    Navigator.pop(context);
                    controller.isSavedPostScreenExists
                        ? pushReplacement(
                            context, WhoToFollow(controller: controller))
                        : pushRoute(
                            context, WhoToFollow(controller: controller));
                  },
                ),
                buildListTile(
                  title: Strings.notifications,
                  iconImage: "assets/drawer_icons_new/notifications.png",
                  tapHandler: () async {
                    controller.index.value = Constants.notificationsScreenId;
                    controller.bottomNavIndex.value =
                        Constants.notificationsScreenId;
                    Navigator.pop(context);
                    Get.find<NotificationController>().getNotifications();
                    // Navigator.pop(context);
                    // controller.index.value = Constants.notificationsScreenId;
                    // controller.bottomNavIndex.value =
                    //     Constants.notificationsScreenId;
                    // if (Get.isRegistered<NotificationController>()) {
                    //   Get.find<NotificationController>().getNotifications();
                    // }
                    // Navigator.pop(context);
                  },
                  context: context,
                  selectedIndex: controller.index.value,
                  index: Constants.notificationsScreenId,
                ),
                buildListTile(
                  title: Strings.chats,
                  iconImage: "assets/drawer_icons_new/chat.png",
                  tapHandler: () async {
                    controller.newMessageCount = 0;
                    controller.index.value = Constants.chatsScreenId;
                    controller.bottomNavIndex.value = Constants.chatsScreenId;
                    Navigator.pop(context);
                    controller.chatRequestUserList = await controller.getMessageRequest();
                    LoggingUtils.printValue("message req count", controller.chatRequestUserList.length);
                    controller.chatUserList = await controller.getChat();

                  },
                  context: context,
                  index: Constants.chatsScreenId,
                  selectedIndex: controller.index.value,
                ),
                buildListTile(
                  title: Strings.lists,
                  iconImage: "assets/drawer_icons_new/list.png",
                  context: context,
                  index: Constants.listScreenId,
                  selectedIndex: controller.index.value,
                  tapHandler: () {
                    controller.index.value = Constants.listScreenId;
                    Navigator.pop(context);
                    controller.isSavedPostScreenExists
                        ? pushReplacement(
                            context, ListScreen(controller: controller))
                        : pushRoute(
                            context, ListScreen(controller: controller));
                  },
                ),

                ///topic
                buildListTile(
                  title: Strings.topic,
                  iconImage: "assets/drawer_icons_new/topics.png",
                  context: context,
                  index: Constants.topicScreenId,
                  selectedIndex: controller.index.value,
                  tapHandler: () {
                    controller.index.value = Constants.topicScreenId;
                    Navigator.pop(context);
                    controller.isSavedPostScreenExists
                        ? pushReplacement(context, Topic_Tab_Screen())
                        : pushRoute(context, Topic_Tab_Screen());
                  },
                ),

                buildListTile(
                  title: Strings.bookmarks,
                  iconImage: "assets/drawer_icons_new/bookmark.png",
                  tapHandler: () {
                    Navigator.pop(context);
                    controller.index.value = Constants.bookMarkScreenId;
                    // Get.find<SavedPostController>().update();
                    pushRoute(context,
                        SavedPostScreen(newsFeedController: controller));
                  },
                  context: context,
                  index: Constants.bookMarkScreenId,
                  selectedIndex: controller.index.value,
                ),

                // buildListTile(
                //   title: Strings.communities,
                //   iconImage: AppImages.saved,
                //   tapHandler: () {
                //     controller.index.value = Constants.communitiesScreenId;
                //     // Get.find<SavedPostController>().update();
                //     pushRoute(context, MainCommunitiesScreen());
                //   },
                //   context: context,
                //   index: Constants.communitiesScreenId,
                //   selectedIndex: controller.index.value,
                // ),

                buildListTile(
                  title: Strings.profile,
                  iconImage: "assets/drawer_icons_new/profile.png",
                  tapHandler: () async {
                    controller.index.value = Constants.profileScreenId;
                    Navigator.pop(context);
                    controller.isSavedPostScreenExists
                        ? pushReplacement(
                            context, ProfileScreen(controller: controller))
                        : pushRoute(
                            context, ProfileScreen(controller: controller));

                    if (Get.isRegistered<ProfileController>()) {
                      ///
                      Get.find<ProfileController>().isHiddenPost = false;
                      Get.find<ProfileController>().isTweets = true;
                      Get.find<ProfileController>().isTweetsReply = false;
                      Get.find<ProfileController>().isMedia = false;
                      Get.find<ProfileController>().isLikes = false;
                      Get.find<ProfileController>().userProfile =
                          await controller.getUserProfile();
                      await Get.find<ProfileController>()
                          .filterUsersPost("posts");
                      Get.find<ProfileController>()
                          .userPosts
                          .forEach((element) {
                        element.likeCount.value = element.simpleLikeCount;
                        element.rebuzzCount.value = element.retweetCount;
                        element.commentCount.value = element.commentsCount;
                        element.reactionType.value = element.isLiked;
                        // element.comments.forEach((element) {
                        //   element.reactionType.value = element.isLiked;
                        //   element.commentCount.value  = element.simpleLikeCount;
                        // });
                        element.reactionType.refresh();
                      });
                      Get.find<ProfileController>().update();
                    }
                  },
                  context: context,
                  index: Constants.profileScreenId,
                  selectedIndex: controller.index.value,
                ),
                buildListTile(
                  title: Strings.settings,
                  iconImage: "assets/drawer_icons_new/settings.png",
                  tapHandler: () {
                    Navigator.pop(context);

                    controller
                        .getOtherUserProfile(GetStorage().read('id'))
                        .whenComplete(() {
                      controller.verification =
                          controller.otherUserProfile.accountVerified;
                    });

                    controller.index.value = Constants.settingScreenId;

                    controller.isSavedPostScreenExists
                        ? pushReplacement(context, SettingsScreen())
                        : pushRoute(context, SettingsScreen());
                  },
                  context: context,
                  index: Constants.settingScreenId,
                  selectedIndex: controller.index.value,
                ),
                ExpansionTile(
                  title: Text(
                    Strings.more,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  leading: Container(
                      width: 22,
                      height: 22,
                      child: new Image.asset(
                        "assets/drawer_icons_new/more.png",
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )),
                  children: [
                    // ListTile(
                    //   onTap: () {
                    //     Navigator.of(context).pop();
                    //     Get.to(MobileAboutScreen());
                    //   },
                    //   leading: Container(
                    //       width: 24,
                    //       height: 24,
                    //       child:
                    //           new Image.asset('assets/drawer_icons/about.png')),
                    //   title: Text(
                    //     Strings.about,
                    //     style: Theme.of(context).textTheme.bodyText1,
                    //   ),
                    // ),
                    // ListTile(
                    //   leading: Container(
                    //       width: 24,
                    //       height: 24,
                    //       child:
                    //           new Image.asset('assets/drawer_icons/help.png')),
                    //   title: Text(
                    //     Strings.help,
                    //     style: Theme.of(context).textTheme.bodyText1,
                    //   ),
                    // ),

                    /// momemnts screen
                    buildListTile(
                      title: Strings.moments,
                      iconImage: "assets/drawer_icons_new/moments.png",
                      context: context,
                      index: Constants.momentsScreenId,
                      selectedIndex: controller.index.value,
                      tapHandler: () {
                        controller.index.value = Constants.momentsScreenId;
                        Navigator.pop(context);
                        controller.isSavedPostScreenExists
                            ? pushReplacement(context, MomentsCreateScreen())
                            : pushRoute(context, MomentsCreateScreen());
                      },
                    ),
                    buildListTile(
                      title: Strings.displaySettings,
                      iconImage: "assets/drawer_icons_new/display_settings.png",
                      context: context,
                      index: Constants.displayScreenId,
                      selectedIndex: controller.index.value,
                      tapHandler: () {
                        Navigator.pop(context);

                        // showDialog<String>(
                        //     context: context,
                        //     builder: (BuildContext context) => AlertDialog(
                        //         title:
                        //         Container(  height:
                        //         Get.height * 0.55,
                        //             width:
                        //             Get.width * 0.30,
                        //           child: Column(
                        //                 children: [
                        //               Text("Customize your view",
                        //                 style: Theme.of(context).brightness == Brightness.dark ?
                        //                 TextStyle(color: Colors.white,fontSize: 18,fontWeight: FontWeight.w900
                        //                 )
                        //                     : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w900
                        //                 ),),SizedBox(height: 15,),
                        //               Text("These settings affect all the Werfie accounts on this browser.",
                        //                 style: Theme.of(context).brightness == Brightness.dark ?
                        //                 TextStyle(color: Colors.white,fontSize: 12,fontWeight: FontWeight.w600
                        //                 )
                        //                     : TextStyle(color: Colors.black,fontSize: 12,fontWeight: FontWeight.w600
                        //                 ),
                        //               ),
                        //               SizedBox(height: 20,),
                        //               Padding(
                        //                 padding: const EdgeInsets.only(left: 20,right: 20),
                        //                 child: Column(crossAxisAlignment: CrossAxisAlignment.start,children: [
                        //                   Text("Colors",
                        //                     style: Theme.of(context).brightness == Brightness.dark ?
                        //                     TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.w900
                        //                     )
                        //                         : TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w900
                        //                     ),
                        //                   ),
                        //                   Container(width: Get.width,height: 60,decoration: BoxDecoration(border: Border.all(color: Colors.grey,width: 1)) ,child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,crossAxisAlignment: CrossAxisAlignment.center,children: [
                        //                     InkWell(onTap: (){
                        //                       print("tap this color..................");
                        //                       controller.displayColor = MyColors.yellow;
                        //                       controller.storage.write("color",0xFFedab30 );
                        //
                        //                       NewsfeedController();
                        //                       ListController();
                        //                       DummyData();
                        //                       controller.update();
                        //
                        //
                        //                     },child: CircleAvatar(backgroundColor: MyColors.yellow,radius: 20,)),
                        //                     InkWell(onTap: (){
                        //                       print("tap this color..................222222");
                        //                       controller.displayColor = MyColors.teal;
                        //                       controller.storage.write("color",0xFF008080 );
                        //
                        //                       NewsfeedController();
                        //                       ListController();
                        //                       controller.update();
                        //
                        //                     },child: CircleAvatar(backgroundColor: MyColors.teal,radius: 20,)),
                        //
                        //                     InkWell(onTap: (){
                        //                       print("tap this color..................4444444444");
                        //                       controller.displayColor = MyColors.pink;
                        //                       controller.storage.write("color",0xFFFFC0CB );
                        //
                        //                       NewsfeedController();
                        //
                        //                       ListController();
                        //                       controller.update();
                        //
                        //                     },child: CircleAvatar(backgroundColor: MyColors.pink,radius: 20,)),
                        //
                        //                   ],),),
                        //                   SizedBox(height: 10,),
                        //                   //         Column(crossAxisAlignment: CrossAxisAlignment.start,children: [
                        //                   //           Text("Background Color",
                        //                   //               style:
                        //                   //               TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w900
                        //                   //               )),
                        //                   //           Container(width: Get.width,height: 100,decoration: BoxDecoration(color: Colors.grey[200],border: Border.all(width: 1,color: Colors.black
                        //                   //           )),child:
                        //                   //             Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,crossAxisAlignment: CrossAxisAlignment.center,children: [
                        //                   //               Container(height: 80,width: 80,decoration: BoxDecoration(color: Colors.white,border: Border.all(width: 2,color: Colors.black))),
                        //                   //               Container(height: 80,width: 80,decoration: BoxDecoration(color: Colors.black,border: Border.all(width: 2,color: Colors.white)),)
                        //                   //             ],),),
                        //                   //
                        //                   // ]),
                        //
                        //                   Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey,width: 1)) , padding: EdgeInsets.all(10.0), child:InkWell(
                        //                       onTap: (){
                        //                         controller.storage.write("mode", true);
                        //                         controller.update();
                        //                         Get.delete<
                        //                             NewsfeedController>();
                        //                         if (kIsWeb) {
                        //                           Routemaster.of(context)
                        //                               .replace(
                        //                               AppRoute.postScreen,
                        //                               queryParameters: {
                        //                                 "postId": null,
                        //                                 "profileId": null
                        //                               });
                        //                         } else {
                        //                           Get.offUntil(
                        //                               MaterialPageRoute(
                        //                                 builder: (context) =>
                        //                                     Session(),
                        //                               ),
                        //                                   (route) => false);
                        //                         }
                        //                       },
                        //                       child:
                        //                       Row(
                        //                         children: [
                        //                           Text("Dark",
                        //                             style: Theme.of(context).brightness == Brightness.dark ?
                        //                             TextStyle(color: Colors.white,
                        //                             )
                        //                                 : TextStyle(color: Colors.black,
                        //                             ),),
                        //                           Icon(controller.storage.read("mode")==null?Icons.radio_button_off:controller.storage.read("mode") ?Icons.check_circle:Icons.radio_button_off),
                        //                         ],
                        //                       )
                        //                   ) ),
                        //                  SizedBox(height: 6,),
                        //                   Container(decoration: BoxDecoration(border: Border.all(color: Colors.grey,width: 1)) , padding: EdgeInsets.all(10.0), child:InkWell(
                        //                       onTap: (){
                        //                         controller.storage.write("mode", false);
                        //                         controller.update();
                        //                         Get.delete<
                        //                             NewsfeedController>();
                        //                         if (kIsWeb) {
                        //                           Routemaster.of(context)
                        //                               .replace(
                        //                               AppRoute.postScreen,
                        //                               queryParameters: {
                        //                                 "postId": null,
                        //                                 "profileId": null
                        //                               });
                        //                         } else {
                        //                           Get.offUntil(
                        //                               MaterialPageRoute(
                        //                                 builder: (context) =>
                        //                                     Session(),
                        //                               ),
                        //                                   (route) => false);
                        //                         }
                        //                       },
                        //                       child:
                        //                       Row(
                        //                         children: [
                        //                           Text("Light",
                        //                             style: Theme.of(context).brightness == Brightness.dark ?
                        //                             TextStyle(color: Colors.white,
                        //                             )
                        //                                 : TextStyle(color: Colors.black,
                        //                             ),),
                        //                           Icon(controller.storage.read("mode")==null?Icons.check_circle:!controller.storage.read("mode") ?Icons.check_circle:Icons.radio_button_off),
                        //                         ],
                        //                       )
                        //
                        //                   ) )
                        //                  , SizedBox(height: 10,),
                        //                   Center(
                        //                     child: ElevatedButton(onPressed: (){
                        //                       Navigator.pop(context);
                        //                     }, child: Text("Done",style: TextStyle(color: Colors.white),),
                        //                       style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), primary: controller.displayColor),
                        //
                        //
                        //                     ),
                        //                   )
                        //
                        //
                        //
                        //
                        //                 ],
                        //
                        //
                        //
                        //
                        //                 ),
                        //               ),
                        //
                        //             ]
                        //             ),
                        //         ),
                        //     ),
                        // );
                        showModalBottomSheet(
                            isDismissible: true,
                            isScrollControlled: true,
                            // backgroundColor: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20))),
                            context: context,
                            builder: (context) {
                              return StatefulBuilder(
                                  builder: (context, setState) {
                                Scaffold(
                                  key: _scaffoldKey,
                                );
                                return Container(
                                  height: Get.height / 1.5,
                                  child: SingleChildScrollView(
                                    child: Column(children: [
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Text(
                                        Strings.customizeView,
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        Strings.theseSettingsAffect,
                                        style: Styles.baseTextTheme.headline4
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 12,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 20, right: 20),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              Strings.colors,
                                              style: Styles
                                                  .baseTextTheme.headline2
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Container(
                                              width: Get.width,
                                              height: 60,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                color: controller.displayColor,
                                                width: 2,
                                              )),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  InkWell(
                                                      onTap: () {
                                                        // print(
                                                        //     "tap this color..................");
                                                        controller
                                                                .displayColor =
                                                            MyColors.werfieNewColor;
                                                        controller.storage
                                                            .write("color",
                                                            0xFF1D9BF0);
                                                        NewsfeedController();
                                                        ListController();
                                                        // if (kIsWeb) {
                                                        //   Get.offNamed(FluroRouters.mainScreen);
                                                        // } else {
                                                        //   Get.offUntil(
                                                        //       MaterialPageRoute(
                                                        //         builder: (context) =>
                                                        //             Session(),
                                                        //       ),
                                                        //           (route) => false);
                                                        // }
                                                        controller.update();
                                                        setState(() {});
                                                      },
                                                      child: CircleAvatar(
                                                        backgroundColor:
                                                            MyColors.werfieNewColor,
                                                        radius: 20,
                                                        child: Visibility(
                                                            visible: controller
                                                                        .storage
                                                                        .read(
                                                                            "color") ==
                                                                0xFF1D9BF0
                                                                ? true
                                                                : false,
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                            )),
                                                      )),
                                                  InkWell(
                                                      onTap: () {
                                                        // print(
                                                        //     "tap this color..................222222");
                                                        controller
                                                                .displayColor =
                                                            MyColors
                                                                .yellowColor;
                                                        controller.storage
                                                            .write("color",
                                                                0xFFffd400);

                                                        NewsfeedController();
                                                        ListController();

                                                        controller.update();
                                                        setState(() {});
                                                      },
                                                      child: CircleAvatar(
                                                        backgroundColor:
                                                            MyColors
                                                                .yellowColor,
                                                        radius: 20,
                                                        child: Visibility(
                                                            visible: controller
                                                                        .storage
                                                                        .read(
                                                                            "color") ==
                                                                    0xFFffd400
                                                                ? true
                                                                : false,
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                            )),
                                                      )),
                                                  InkWell(
                                                      onTap: () {
                                                        // print(
                                                        //     "tap this color..................4444444444");
                                                        controller
                                                                .displayColor =
                                                            MyColors.pinkColor;
                                                        controller.storage
                                                            .write("color",
                                                                0xFFf91880);

                                                        NewsfeedController();

                                                        ListController();

                                                        controller.update();
                                                        setState(() {});
                                                      },
                                                      child: CircleAvatar(
                                                        backgroundColor:
                                                            MyColors.pinkColor,
                                                        radius: 20,
                                                        child: Visibility(
                                                            visible: controller
                                                                        .storage
                                                                        .read(
                                                                            "color") ==
                                                                    0xFFf91880
                                                                ? true
                                                                : false,
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                            )),
                                                      )),
                                                  InkWell(
                                                      onTap: () {
                                                        // print(
                                                        //     "tap this color..................4444444444");
                                                        controller
                                                                .displayColor =
                                                            MyColors
                                                                .purpleColor;
                                                        controller.storage
                                                            .write("color",
                                                                0xFF7856ff);

                                                        NewsfeedController();

                                                        ListController();

                                                        controller.update();
                                                        setState(() {});
                                                      },
                                                      child: CircleAvatar(
                                                        backgroundColor:
                                                            MyColors
                                                                .purpleColor,
                                                        radius: 20,
                                                        child: Visibility(
                                                            visible: controller
                                                                        .storage
                                                                        .read(
                                                                            "color") ==
                                                                    0xFF7856ff
                                                                ? true
                                                                : false,
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                            )),
                                                      )),
                                                  InkWell(
                                                      onTap: () {
                                                        // print(
                                                        //     "tap this color..................4444444444");
                                                        controller
                                                                .displayColor =
                                                            MyColors
                                                                .orangeColor;
                                                        controller.storage
                                                            .write("color",
                                                                0xFFff7a00);

                                                        NewsfeedController();

                                                        ListController();

                                                        controller.update();
                                                        setState(() {});
                                                      },
                                                      child: CircleAvatar(
                                                        backgroundColor:
                                                            MyColors
                                                                .orangeColor,
                                                        radius: 20,
                                                        child: Visibility(
                                                            visible: controller
                                                                        .storage
                                                                        .read(
                                                                            "color") ==
                                                                    0xFFff7a00
                                                                ? true
                                                                : false,
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                            )),
                                                      )),
                                                  InkWell(
                                                      onTap: () {
                                                        // print(
                                                        //     "tap this color..................4444444444");
                                                        controller
                                                                .displayColor =
                                                            MyColors.greenColor;
                                                        controller.storage
                                                            .write("color",
                                                                0xFF00ba7c);

                                                        NewsfeedController();

                                                        ListController();

                                                        controller.update();
                                                        setState(() {});
                                                      },
                                                      child: CircleAvatar(
                                                        backgroundColor:
                                                            MyColors.greenColor,
                                                        radius: 20,
                                                        child: Visibility(
                                                            visible: controller
                                                                        .storage
                                                                        .read(
                                                                            "color") ==
                                                                    0xFF00ba7c
                                                                ? true
                                                                : false,
                                                            child: Icon(
                                                              Icons.check,
                                                              color:
                                                                  Colors.white,
                                                            )),
                                                      )),
                                                ],
                                              ),
                                            ),

                                            SizedBox(
                                              height: 10,
                                            ),
                                            //         Column(crossAxisAlignment: CrossAxisAlignment.start,children: [
                                            //           Text("Background Color",
                                            //               style:
                                            //               TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w900
                                            //               )),
                                            //           Container(width: Get.width,height: 100,decoration: BoxDecoration(color: Colors.grey[200],border: Border.all(width: 1,color: Colors.black
                                            //           )),child:
                                            //             Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,crossAxisAlignment: CrossAxisAlignment.center,children: [
                                            //               Container(height: 80,width: 80,decoration: BoxDecoration(color: Colors.white,border: Border.all(width: 2,color: Colors.black))),
                                            //               Container(height: 80,width: 80,decoration: BoxDecoration(color: Colors.black,border: Border.all(width: 2,color: Colors.white)),)
                                            //             ],),),
                                            //
                                            // ]),
                                            Container(
                                              decoration: const BoxDecoration(
                                                  // border: Border.all(
                                                  //     color: Colors.white,
                                                  //     width: 1,
                                                  // ),
                                                  ),
                                              padding: const EdgeInsets.all(10.0),
                                              child: InkWell(
                                                  onTap: () {
                                                    Get.changeThemeMode(
                                                      ThemeMode.dark,
                                                    );
                                                    controller.storage
                                                        .write("mode", true);
                                                    controller.update();

                                                    // controller.storage.write("mode", true);
                                                    // controller.update();
                                                    // Get.delete<
                                                    //     NewsfeedController>();
                                                    // if (kIsWeb) {
                                                    // // Get.off(Session());
                                                    // Get.offNamed(FluroRouters.mainScreen);
                                                    // // context.pushReplacement(AppRoute.routeMain);
                                                    //
                                                    // } else {
                                                    //   Get.offUntil(
                                                    //       MaterialPageRoute(
                                                    //         builder: (context) =>
                                                    //             Session(),
                                                    //       ),
                                                    //           (route) => false);
                                                    // }
                                                  },
                                                  child: Row(
                                                    children: [
                                                      Text(
                                                        Strings.dark,
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                      const Spacer(),
                                                      // Icon(
                                                      //     controller.storage.read("mode")==null ?Icons.radio_button_off :controller.storage.read("mode")
                                                      //         ?Icons.check_circle
                                                      //         :Icons.radio_button_off,
                                                      //   color: controller.displayColor,
                                                      // ),

                                                      controller.storage.read(
                                                                  "mode") ==
                                                              null
                                                          ? Container(
                                                              height: 25,
                                                              width: 25,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .black
                                                                    : Colors
                                                                        .white,
                                                                shape: BoxShape
                                                                    .circle,
                                                                border: Border.all(
                                                                    color: Colors
                                                                        .grey,
                                                                    width: 1),
                                                              ),
                                                            )
                                                          : controller.storage
                                                                  .read("mode")
                                                              ? Container(
                                                                  height: 25,
                                                                  width: 25,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: controller
                                                                        .displayColor,
                                                                    shape: BoxShape
                                                                        .circle,
                                                                  ),
                                                                  child: const Icon(
                                                                    Icons.check,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                )
                                                              : Container(
                                                                  height: 25,
                                                                  width: 25,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .black
                                                                        : Colors
                                                                            .white,
                                                                    shape: BoxShape
                                                                        .circle,
                                                                    border: Border.all(
                                                                        color: Colors
                                                                            .grey,
                                                                        width:
                                                                            1),
                                                                  ),
                                                                )
                                                    ],
                                                  )),
                                            ),
                                            const Divider(
                                              color: Colors.grey,
                                              thickness: 0.5,
                                            ),
                                            const SizedBox(
                                              height: 20,
                                            ),
                                            Container(
                                              decoration: const BoxDecoration(
                                                  // border: Border.all(
                                                  //     color: Colors.white,
                                                  //     width: 1,
                                                  // ),
                                                  ),
                                              padding: const EdgeInsets.all(10.0),
                                              child: InkWell(
                                                  onTap: () {
                                                    Get.changeThemeMode(
                                                      ThemeMode.light,
                                                    );
                                                    controller.storage
                                                        .write("mode", false);
                                                    controller.update();

                                                    // controller.storage.write("mode", false);
                                                    // controller.update();
                                                    // Get.delete<
                                                    //     NewsfeedController>();
                                                    // if (kIsWeb) {
                                                    //   Get.offNamed(FluroRouters.mainScreen);
                                                    //   // context.pushReplacement(AppRoute.routeMain);
                                                    //
                                                    // } else {
                                                    //   Get.offUntil(
                                                    //       MaterialPageRoute(
                                                    //         builder: (context) =>
                                                    //             Session(),
                                                    //       ),
                                                    //           (route) => false);
                                                    // }
                                                  },
                                                  child: Row(
                                                    children: [
                                                      Text(
                                                        Strings.light,
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      // Icon(
                                                      //     controller.storage.read("mode")==null
                                                      //     ?Icons.check_circle
                                                      //         :!controller.storage.read("mode")
                                                      //         ?Icons.check_circle
                                                      //         :Icons.radio_button_off,
                                                      //   color:  controller.displayColor,
                                                      // ),

                                                      controller.storage.read(
                                                                  "mode") ==
                                                              null
                                                          ? Container(
                                                              height: 25,
                                                              width: 25,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: controller
                                                                    .displayColor,
                                                                shape: BoxShape
                                                                    .circle,
                                                              ),
                                                              child: Icon(
                                                                Icons.check,
                                                                color: Colors
                                                                    .white,
                                                              ),
                                                            )
                                                          : !controller.storage
                                                                  .read("mode")
                                                              ? Container(
                                                                  height: 25,
                                                                  width: 25,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: controller
                                                                        .displayColor,
                                                                    shape: BoxShape
                                                                        .circle,
                                                                  ),
                                                                  child: Icon(
                                                                    Icons.check,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                )
                                                              : Container(
                                                                  height: 25,
                                                                  width: 25,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .black
                                                                        : Colors
                                                                            .white,
                                                                    shape: BoxShape
                                                                        .circle,
                                                                    border: Border.all(
                                                                        color: Colors
                                                                            .grey,
                                                                        width:
                                                                            1),
                                                                  ),
                                                                ),
                                                    ],
                                                  )),
                                            ),
                                            Divider(
                                              color: Colors.grey,
                                              thickness: 0.5,
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Center(
                                              child: ElevatedButton(
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                },
                                                child: Text(
                                                  Strings.done,
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                                style: ElevatedButton.styleFrom(
                                                  padding: EdgeInsets.only(
                                                      left: 20,
                                                      right: 20,
                                                      top: 5,
                                                      bottom: 5),
                                                  backgroundColor:
                                                      controller.displayColor,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            30),
                                                  ),
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ]),
                                  ),
                                );
                              });
                            });
                        controller.update();
                      },
                    ),
                    expansionTileChild(
                      context,
                      Url.werfieTermsUrl,
                      "assets/drawer_icons_new/terms_of_service.png",
                      Strings.termsOfService,
                    ),
                    expansionTileChild(
                      context,
                      Url.werfiePrivacyUrl,
                      "assets/drawer_icons_new/privacy_policy.png",
                      Strings.privacyPolicy,
                    ),
                    // ListTile(
                    //   leading: Container(
                    //       width: 24,
                    //       height: 24,
                    //       child:
                    //           new Image.asset('assets/drawer_icons/blogs.png')),
                    //   title: Text(
                    //     Strings.blog,
                    //     style: Theme.of(context).textTheme.bodyText1,
                    //   ),
                    // ),
                  ],
                ),
                buildListTile(
                  title: Strings.logout,
                  iconImage: "assets/drawer_icons_new/logout.png",
                  tapHandler: () async {
                    SharedPreferences preferences =
                        await SharedPreferences.getInstance();
                    //print('SingleTone:${SingleTone.instance.socialLogin}');

                    final storage = GetStorage();
                    String token = storage.read("token");
                    String fcmToken = storage.read("fcm_token");
                    LogoutAPI().logout(token,fcmToken);

                    if (preferences.getBool('socialLogin') == true) {
                      print('social logout');
                      UtilsMethods utils = UtilsMethods();
                      utils.signOutGoogle();

                      await preferences.clear();
                      await preferences.remove("userName");
                      await preferences.remove("id");
                      await controller.storage.erase();

                      Get.delete<SessionController>();
                      Get.delete<NewsfeedController>();
                      Get.delete<ProfileController>();
                      Get.delete<BrowseController>();
                      Get.delete<NotificationController>();
                      preferences.setBool('guestUser', true);
                      SingleTone.instance.socialLogin = false;
                      if (kIsWeb) {
                        // Get.offNamed(FluroRouters.guestUserMainScreen);
                        Get.offAll(GuestUserMainScreen(isFromPosh: false,),routeName: FluroRouters.guestUserMainScreen);

                        // context.pushReplacement(AppRoute.loginScreen);

                        // Routemaster.of(context).replace(AppRoute.guestUserMainScreen,);
                      } else {
                        Get.offUntil(
                            MaterialPageRoute(
                                builder: (context) => LoginScreen(isFromWorldNoorApp: 2,)),
                            (route) => false);
                      }
                    } else {
                      //print('else logout');

                      await preferences.clear();
                      await preferences.remove("userName");
                      await preferences.remove("id");
                      await controller.storage.erase();

                      Get.delete<SessionController>();
                      Get.delete<NewsfeedController>();
                      Get.delete<ProfileController>();
                      Get.delete<BrowseController>();
                      Get.delete<NotificationController>();

                      preferences.setBool('guestUser', true);
                      SingleTone.instance.socialLogin = false;
                      if (kIsWeb) {
                        Routemaster.of(context).replace(
                          AppRoute.guestUserMainScreen,
                        );
                      } else {
                        Get.offUntil(
                            MaterialPageRoute(
                                builder: (context) => LoginScreen(isFromWorldNoorApp: 2,)),
                            (route) => false);
                      }
                    }
                  },
                  context: context,
                  index: 9,
                  selectedIndex: controller.index.value,
                ),
              ],
            );
          })),
        ],
      ),
    );
  }

  ListTile buildListTile(
      {String title,
      String iconImage,
      Function tapHandler,
      BuildContext context,
      bool check,
      int index,
      int selectedIndex}) {


    return ListTile(
      leading: Stack(
        children: [
          Container(
              width: 22,
              height: 22,
              child: Image.asset(
                iconImage,
                width: 22,
                height: 22,
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
              )

          ),
          title == Strings.chats && controller.newMessageCount > 0 ?
          Positioned(
              right: 0,
              child: CircleAvatar(
                radius: 8,
                backgroundColor: MyColors.blue,
                child: Text(
                    controller.newMessageCount > 99 ? "+99" :  controller.newMessageCount.toString(), //badgeCount > 99 ? '+99' : '$badgeCount',
                    // style: TextStyle(fontSize: 8, color: Colors.white),
                    style: TextStyle(color: Colors.white, fontSize: 8)
                ),
              ))
              : SizedBox(),
        ],
      ),
      // Icon(
      //   icon,
      //   color: Color(0xFFedab30),
      // ),
      title: Text(
        title,
        // style: Theme.of(context).textTheme.bodyText1,
        style: Styles.baseTextTheme.headline2.copyWith(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Colors.black,
          fontWeight: FontWeight.bold,
        ),

        //
        // TextStyle(
        //   // fontWeight: controller.isNewsFeedScreen,
        //   // ? FontWeight.bold
        //   // : FontWeight.normal,
        //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white:Colors.black,
        //   fontWeight: FontWeight.w400,
        // ),
      ),
      onTap: tapHandler,
    );
  }

  Widget videoCallWidget(context) {
    VideoCallController videoCallController;
    if (Get.isRegistered<VideoCallController>()) {
      videoCallController = Get.find<VideoCallController>();
    } else {
      videoCallController = Get.put(VideoCallController());
    }
    return GetBuilder<VideoCallController>(builder: (videoController) {
      return videoController.conversationID != null && videoController.conversationID.isNotEmpty
          ? InkWell(
        onTap: () {
          if (kIsWeb) {
            // onVideoCallChange = true;
            controller.navRoute = "isVideoCallScreen";

            Get.toNamed(FluroRouters.mainScreen + '/videocall', arguments: null);
          } else {
            Navigator.pop(context);
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => VideoCallHome()));
          }
        },
        child: Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(right: 70, left: 20.0, bottom: 20, top: 20),
          padding: EdgeInsets.symmetric(vertical: 5.0),
          decoration: BoxDecoration(
              border: Border.all(color: Colors.blueAccent),
              // color: controller.displayColor,
              borderRadius: BorderRadius.circular(20.0)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: Container(
                  width: 15,
                  height: 15,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.red,
                      width: 1,
                    ),
                    color: Colors.transparent, // Set inner color as transparent
                  ),
                  padding: EdgeInsets.all(2),
                  // Adjust padding for the gap
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red, // Inner circle color
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10.0),
              Text(
                "Ongoing Call",
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Colors.blueAccent,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
              // SizedBox(width:10.0),
            ],
          ),
        ),
      )
          : SizedBox();
    });
  }

  void pushReplacement(context, Widget route) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => route,
      ),
    );
  }

  void pushRoute(context, Widget route) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => route,
      ),
    );
  }

  Widget expansionTileChild(context, url, imageAssets, String title) {
    return ListTile(
      onTap: () async {
        try {
          await launch(url);
        } catch (e) {
          print(e.toString());
        }
      },
      leading: Container(
          width: 22,
          height: 22,
          child: Image.asset(
            imageAssets,
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
          )),
      title: Text(
        title,
        style: Styles.baseTextTheme.headline2.copyWith(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Colors.black,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget topProfilePicSection(context) {
    return Container(
      padding: EdgeInsets.only(
        top: 40,
        left: 20,
        right: 12,

      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () async {

              controller.isSavedPostScreenExists
                  ? pushReplacement(
                      context, ProfileScreen(controller: controller))
                  : pushRoute(context, ProfileScreen(controller: controller));

              if (Get.isRegistered<ProfileController>()) {
                ///
                Get.find<ProfileController>().isHiddenPost = false;
                Get.find<ProfileController>().isTweets = true;
                Get.find<ProfileController>().isTweetsReply = false;
                Get.find<ProfileController>().isMedia = false;
                Get.find<ProfileController>().isLikes = false;
                Get.find<ProfileController>().userProfile =
                    await controller.getUserProfile();
                await Get.find<ProfileController>().filterUsersPost("posts");
                Get.find<ProfileController>().userPosts.forEach((element) {
                  element.likeCount.value = element.simpleLikeCount;
                  element.rebuzzCount.value = element.retweetCount;
                  element.commentCount.value = element.commentsCount;
                  element.reactionType.value = element.isLiked;
                  // element.comments.forEach((element) {
                  //   element.reactionType.value = element.isLiked;
                  //   element.commentCount.value  = element.simpleLikeCount;
                  // });
                  element.reactionType.refresh();

                  // if (element.isLiked == true) {
                  //   element.like.value = true;
                  //   element.like.refresh();
                  // }
                });
                Get.find<ProfileController>().update();
              }

              controller.isNewsFeedScreen = false;
              controller.isSavedPostScreenExists = false;
              controller.isProfileScreen = true;

              controller.navRoute = "isProfileScreen";
              controller.update();
            },
            child: controller.userProfile == null
                ? Container(
                    width: 24,
                    child: Center(
                      child: SpinKitCircle(
                        color: Colors.grey,
                        size: 20,
                      ),
                    ))
                : controller.userProfile.profileImage == null
                    ? CircleAvatar(
                        radius: 20,
                        backgroundImage:
                            AssetImage(AppImages.personPlaceHolder),
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(40),
                        child: FadeInImage(
                            fit: BoxFit.cover,
                            width: 50,
                            height: 50,
                            placeholder:
                                AssetImage(AppImages.personPlaceHolder),
                            image: NetworkImage(controller
                                        .userProfile.profileImage !=
                                    null
                                ? controller.userProfile.profileImage
                                : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                      ),
          ),
          SizedBox(
            height: 14,
          ),
          Row(
            children: [
              Expanded(
                child: Text(
                  controller.userProfile != null
                      ? controller.userProfile.firstname != null
                      ? '${controller.userProfile.firstname} ${controller.userProfile.lastname!=null?controller.userProfile.lastname:""}'
                      : ''
                      : '',
                  textAlign: TextAlign.start,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
            width: 5,
          ),
          InkWell(
            onTap: () async {
              controller.isSavedPostScreenExists
                  ? pushReplacement(
                      context, ProfileScreen(controller: controller))
                  : pushRoute(context, ProfileScreen(controller: controller));

              controller.isNewsFeedScreen = false;
              controller.isSavedPostScreenExists = false;
              controller.isProfileScreen = true;
              controller.navRoute = "isProfileScreen";
              controller.update();
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Expanded(
                  child: Text(
                    controller.userProfile != null
                        ? controller.userProfile.username != null
                            ? '@${controller.userProfile.username}'
                            : ''
                        : '',
                    textAlign: TextAlign.start,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black54,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                SizedBox(
                  width: 5,
                ),
                controller.userProfile != null && controller.userProfile.accountVerified == "verified"
                    ? BlueTick(
                        height: 16,
                        width: 16,
                        iconSize: 10,
                      )
                    : SizedBox(),
              ],
            ),
          ),
          SizedBox(
            height: 14,
          ),
          Row(
            children: [
              Row(
                children: [
                  Text(
                    controller.userProfile ==
                        null
                        ? ""
                        : "${controller.userProfile.followings} ",
                    style: Styles
                        .baseTextTheme
                        .headline1
                        .copyWith(
                      color: Theme.of(context)
                          .brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb
                          ? 16.0
                          : 14.0,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark
                    //       ? Colors.white
                    //       : Colors.black,
                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                    //   fontWeight: FontWeight.bold,
                    //
                    // ),
                  ),
                  Text(
                    controller.userProfile ==
                        null
                        ? ""
                        : Strings.followings,
                    style: Styles
                        .baseTextTheme
                        .headline2
                        .copyWith(
                      fontSize: kIsWeb
                          ? 16.0
                          : 14.0,
                      fontWeight:
                      FontWeight.w500,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark
                    //       ? Color(0xFF586976)
                    //       : Color(0xFF586976),
                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                    //   fontWeight: FontWeight.bold,
                    //
                    // ),
                  ),
                ],
              ),
              SizedBox(
                width: 10,
              ),
              Row(
                children: [
                  Text(
                    controller.userProfile ==
                        null
                        ? ""
                        : "${controller.userProfile.followers} ",
                    style: Styles
                        .baseTextTheme
                        .headline1
                        .copyWith(
                      color: Theme.of(context)
                          .brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb
                          ? 16.0
                          : 14.0,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark
                    //       ? Colors.white
                    //       : Colors.black,
                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                    //   fontWeight: FontWeight.bold,
                    //
                    // ),
                  ),
                  Text(
                    controller.userProfile ==
                        null
                        ? ""
                        : Strings.followers,
                    // style: Theme.of(context).brightness == Brightness.dark ?
                    // TextStyle(color: Colors.white,fontSize: kIsWeb ? 18.0 : 14.0,
                    //
                    // )
                    //     : TextStyle(  color: Colors.black,fontSize: kIsWeb ? 18.0 : 14.0,
                    // ),
                    style: Styles
                        .baseTextTheme
                        .headline2
                        .copyWith(
                      fontSize: kIsWeb
                          ? 16.0
                          : 14.0,
                      fontWeight:
                      FontWeight.w500,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark
                    //       ? Color(0xFF586976)
                    //       : Color(0xFF586976),
                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                    //  fontWeight: FontWeight.bold,
                    //
                    //
                    // ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Divider(
            thickness: 1,
            color: Colors.blue,
          ),
        ],
      ),
    );
  }
}
