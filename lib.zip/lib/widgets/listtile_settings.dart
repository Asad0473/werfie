import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:werfieapp/utils/colors.dart';

// ignore: must_be_immutable
class ListTileSettings extends StatelessWidget {
  final title;
  final IconData iconData;

  ListTileSettings(this.title, this.iconData, this.onTapHandler,
      this.isSelected, this.fontWeight);

  Function onTapHandler;
  final isSelected;
  final FontWeight fontWeight;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      selected: isSelected,
      onTap: onTapHandler,
      // selectedTileColor: Colors.grey[300],
      // hoverColor: Colors.grey[200],
      title: Text(
        title,
        style: TextStyle(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Colors.black,
          fontSize: kIsWeb ? 16 : 14,
          fontWeight: fontWeight,
        ),
        // Styles.baseTextTheme.headline1.copyWith(
        //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
        //    fontSize: kIsWeb ? 16 : 14,
        //   fontWeight:FontWeight.w600,
        // ),
        // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
        //     fontWeight: FontWeight.w500
        // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
        //
        //
        // ),
      ),
      trailing: iconData == null
          ? SizedBox()
          : Icon(
              iconData,
              size: 20,
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : MyColors.black,
            ),
    );
  }
}
