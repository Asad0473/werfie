import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:werfieapp/network/controller/communities_controller.dart';

class CommunityRequests extends StatelessWidget {
  CommunityRequests({Key key}) : super(key: key);
  final CommunitiesController communitiesController =
      Get.put(CommunitiesController());

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CommunitiesController>(
      assignId: true,
      builder: (controller) {
        return kIsWeb
            ? Container(
                height: 590,
                width: 500,
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Pending Members' Requests",
                            style:
                                Theme.of(context).brightness == Brightness.dark
                                    ? TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white)
                                    : TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Icon(
                              Icons.cancel,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 25,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Expanded(
                        child: ListView.builder(
                            itemCount: 10,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding: const EdgeInsets.only(top: 10),
                                child: Container(
                                  width: Get.width,
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white.withOpacity(0.5)
                                        : Colors.grey.withOpacity(0.5),
                                    width: 1,
                                  )),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          CircleAvatar(
                                              radius: 20,
                                              backgroundImage: AssetImage(
                                                  "assets/images/person_placeholder.png")),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "Asad Iqbal",
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          fontSize: 12,
                                                          color: Colors.blue)
                                                      : TextStyle(
                                                          fontSize: 12,
                                                          color: Colors.blue),
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  "21 October, 2022",
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          fontSize: 12,
                                                          color: Colors.white
                                                              .withOpacity(0.5),
                                                        )
                                                      : TextStyle(
                                                          fontSize: 12,
                                                          color: Colors.grey
                                                              .withOpacity(0.5),
                                                        ),
                                                ),
                                              ]),
                                          Spacer(),
                                          Row(
                                            children: [
                                              MaterialButton(
                                                color: Color(0xFF0157d3),
                                                elevation: 0.0,

                                                onHighlightChanged:
                                                    (bool value) {},
                                                // hoverColor: Color(0xFF0157d3),
                                                // borderSide: const BorderSide(
                                                //   color: Colors.white,
                                                //   style: BorderStyle.solid,
                                                //   width: 1,
                                                // ),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0),
                                                ),

                                                onPressed: () {},
                                                child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5, bottom: 5),
                                                    child: Text(
                                                      "Approve",
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                      ),
                                                    )),
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              MaterialButton(
                                                color: Color(0xFF0157d3),
                                                elevation: 0.0,

                                                onHighlightChanged:
                                                    (bool value) {},
                                                // hoverColor: Color(0xFF0157d3),
                                                // borderSide: const BorderSide(
                                                //   color: Colors.white,
                                                //   style: BorderStyle.solid,
                                                //   width: 1,
                                                // ),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0),
                                                ),

                                                onPressed: () {},
                                                child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5, bottom: 5),
                                                    child: Text(
                                                      "Reject",
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                      ),
                                                    )),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }),
                      ),
                    ],
                  ),
                ),
              )
            : Scaffold(
                appBar: AppBar(
                  automaticallyImplyLeading: false,
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  title: Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          size: 25,
                        ),
                      ),
                      Spacer(),
                      Text(
                        "Pending Members' Requests",
                        style: Theme.of(context).brightness == Brightness.dark
                            ? TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white)
                            : TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.black),
                      ),
                      Spacer(),
                    ],
                  ),
                ),
                body: Container(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.black
                      : Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: ListView.builder(
                              itemCount: 10,
                              itemBuilder: (BuildContext context, int index) {
                                return Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Container(
                                    width: Get.width,
                                    padding: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white.withOpacity(0.5)
                                          : Colors.grey.withOpacity(0.5),
                                      width: 1,
                                    )),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            CircleAvatar(
                                                radius: 20,
                                                backgroundImage: AssetImage(
                                                    "assets/images/person_placeholder.png")),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "Asad Iqbal",
                                                    style: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? TextStyle(
                                                            fontSize: 12,
                                                            color: Colors.blue)
                                                        : TextStyle(
                                                            fontSize: 12,
                                                            color: Colors.blue),
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    "21 October, 2022",
                                                    style: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? TextStyle(
                                                            fontSize: 12,
                                                            color: Colors.white
                                                                .withOpacity(
                                                                    0.5),
                                                          )
                                                        : TextStyle(
                                                            fontSize: 12,
                                                            color: Colors.grey
                                                                .withOpacity(
                                                                    0.5),
                                                          ),
                                                  ),
                                                ]),
                                            Spacer(),
                                            Row(
                                              children: [
                                                MaterialButton(
                                                  color: Color(0xFF0157d3),
                                                  elevation: 0.0,

                                                  onHighlightChanged:
                                                      (bool value) {},
                                                  // hoverColor: Color(0xFF0157d3),
                                                  // borderSide: const BorderSide(
                                                  //   color: Colors.white,
                                                  //   style: BorderStyle.solid,
                                                  //   width: 1,
                                                  // ),
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                  ),

                                                  onPressed: () {},
                                                  child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 5,
                                                              bottom: 5),
                                                      child: Text(
                                                        "Approve",
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                        ),
                                                      )),
                                                ),
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                MaterialButton(
                                                  color: Color(0xFF0157d3),
                                                  elevation: 0.0,

                                                  onHighlightChanged:
                                                      (bool value) {},
                                                  // hoverColor: Color(0xFF0157d3),
                                                  // borderSide: const BorderSide(
                                                  //   color: Colors.white,
                                                  //   style: BorderStyle.solid,
                                                  //   width: 1,
                                                  // ),
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5.0),
                                                  ),

                                                  onPressed: () {},
                                                  child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 5,
                                                              bottom: 5),
                                                      child: Text(
                                                        "Reject",
                                                        style: TextStyle(
                                                          color: Colors.white,
                                                        ),
                                                      )),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }),
                        ),
                      ],
                    ),
                  ),
                ));
      },
    );
  }
}
