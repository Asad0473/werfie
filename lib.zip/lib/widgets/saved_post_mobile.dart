import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/saved_post_controller.dart';
import 'package:werfieapp/screens/search_screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/thread_post_card.dart';

import '../utils/colors.dart';
import '../utils/font.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';

// ignore: must_be_immutable
class MobileSavedPost extends StatefulWidget {
  final NewsfeedController newsFeedController;

  MobileSavedPost({@required this.newsFeedController});

  @override
  State<MobileSavedPost> createState() => _MobileSavedPostState();
}

class _MobileSavedPostState extends State<MobileSavedPost> {
  SavedPostController controller = Get.put(SavedPostController());

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();



  addBookmarksMetaTags(){
    MetaTags().addMetaTag(
      pageTitle: MetaTagValues.pageTitleBookmarks,
        metaTagDescription: MetaTagValues.bookmarksMetaDescription,
        metaTagKeywords: MetaTagValues.bookmarksMetaKeywords,
        ogTitle: MetaTagValues.bookmarksOGTitle,
        ogDescription: MetaTagValues.bookmarksOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  @override
  void initState() {
    addBookmarksMetaTags();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SavedPostController>(builder: (controller) {
      return WillPopScope(
        onWillPop: () async {



          controller.newsFeedControloler.isBrowseScreen = false;
          controller.newsFeedControloler.isNewsFeedScreen = true;
          controller.newsFeedControloler.isTrendsScreen = false;
          controller.newsFeedControloler.isWhoToFollowScreen = false;
          controller.newsFeedControloler.isNotificationScreen = false;
          controller.newsFeedControloler.isChatScreen = false;
          controller.newsFeedControloler.isSavedPostScreen = false;
          controller.newsFeedControloler.isProfileScreen = false;
          controller.newsFeedControloler.isSettingsScreen = false;
          controller.newsFeedControloler.isListScreen = false;
          controller.newsFeedControloler.update();
            Get.delete<SavedPostController>();

          Navigator.pop(context);
          return false;
        },
        child: Scaffold(
          appBar: !Responsive.isDesktop(context)
              ? kIsWeb
                  ? MediaQuery.of(context).size.width >= 500
                      ? PreferredSize(
                          preferredSize: Size(0.0, 0.0),
                          child: Container(),
                        )
                      : AppBar(
                          backgroundColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.black
                                  : Colors.white,
                          iconTheme: IconThemeData(
                            color: Color(0xFF4f515b),
                          ),
                          title: Row(
                            children: [
                              InkWell(
                                onTap: () {
                                  Get.delete<SavedPostController>();
                                  Get.back();
                                },
                                child: Icon(Icons.arrow_back),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Expanded(
                                child: Container(
                                  height: 45,
                                  width:
                                      MediaQuery.of(context).size.width * 0.7,
                                  child: TextField(
                                    style: LightStyles.baseTextTheme.headline2
                                        .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black),
                                    cursorColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              SearchScreen(),
                                        ),
                                      );
                                    },
                                    textAlignVertical: TextAlignVertical.bottom,
                                    decoration: InputDecoration(
                                      hintText: Strings.search,
                                      hintStyle:
                                          LightStyles.baseTextTheme.headline3,
                                      prefixIcon: Icon(
                                        Icons.search,
                                        size: 20,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(40),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(40),
                                        borderSide: BorderSide(
                                          width: 1,
                                          color: Colors.grey,
                                        ),
                                      ),
                                      fillColor: Colors.grey[250],
                                      filled: true,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          automaticallyImplyLeading: false,
                        )
                  : AppBar(
                      backgroundColor:
                          Theme.of(context).brightness == Brightness.dark
                              ? Colors.black
                              : Colors.white,
                      iconTheme: IconThemeData(
                        color: Color(0xFF4f515b),
                      ),
                      title: Row(
                        children: [
                          InkWell(
                            onTap: () {
                              Get.delete<SavedPostController>();
                              Get.back();
                            },
                            child: Icon(Icons.arrow_back),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: Container(
                              height: 45,
                              width: MediaQuery.of(context).size.width * 0.7,
                              child: TextField(
                                style: LightStyles.baseTextTheme.headline2
                                    .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                cursorColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          SearchScreen(),
                                    ),
                                  );
                                },
                                textAlignVertical: TextAlignVertical.bottom,
                                decoration: InputDecoration(
                                  hintText: Strings.search,
                                  hintStyle:
                                      LightStyles.baseTextTheme.headline3,
                                  prefixIcon: Icon(
                                    Icons.search,
                                    size: 20,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                    borderSide: BorderSide(
                                      width: 1,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  fillColor: Colors.grey[250],
                                  filled: true,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      automaticallyImplyLeading: false,
                    )
              : PreferredSize(
                  preferredSize: Size(0.0, 0.0),
                  child: Container(),
                ),
          // drawer: !Responsive.isDesktop(context)
          //     ? MainDrawer(newsFeedController)
          //     : Container(),
          // drawerEnableOpenDragGesture:
          //     !Responsive.isDesktop(context) ? false : true,
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 8),
              kIsWeb
                  ? ListTile(
                      title: Text(
                        Strings.bookmarks,
                        // style: Theme.of(context).textTheme.headline6.copyWith(
                        //       color: Colors.black,
                        //     ),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          //fontSize: kIsWeb ? 14.0 : 12.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      subtitle: Text(
                        '@' +
                            GetStorage().read(
                              'userName',
                            ),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          //color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontSize: kIsWeb ? 14 : 12,
                        ),
                      ),
                    )
                  : SizedBox(),

              // Expanded(
              //     child: controller?.isLoading == true
              //         ? Center(child: CircularProgressIndicator())
              //         : controller.savedPostList.length == 0 ||
              //                 controller.savedPostList.isEmpty
              //             ? Center(child: Text(Strings.noPosts))
              //             : ListView.builder(
              //                 shrinkWrap: true,
              //                 physics: ScrollPhysics(),
              //                 itemCount: controller.savedPostList.length,
              //                 itemBuilder: (context, index) {
              //                   return PostCard(
              //                     post: controller.savedPostList[index],
              //                     scaffoldKey: _scaffoldKey,
              //                     controller: newsFeedController,
              //                     savedController: controller,
              //                   );
              //                 },
              //               )),

              Expanded(
                child: controller?.isLoading == true
                    ? Center(
                        child: CircularProgressIndicator(
                        color: MyColors.BlueColor,
                      ))
                    : controller.savedPostList.length == 0 ||
                            controller.savedPostList.isEmpty
                        ? Center(
                            child: Text(
                            Strings.noPosts,
                            style: Styles.baseTextTheme.headline4.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 14.0 : 12.0,
                            ),
                          ))
                        : Theme(
                            data: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? Styles.appTheme
                                : ThemeData(
                                    backgroundColor: Colors.black,
                                    scrollbarTheme: ScrollbarThemeData(
                                      radius: Radius.circular(10.0),
                                      thumbColor: MaterialStateProperty.all(
                                          Colors.grey),
                                      trackColor: MaterialStateProperty.all(
                                          Color(0xFFf7f9f9)),
                                      trackBorderColor:
                                          MaterialStateProperty.all(
                                              Color(0xFFf7f9f9)),
                                      showTrackOnHover: true,
                                      trackVisibility:
                                          MaterialStateProperty.all(true),
                                      thickness: MaterialStateProperty.all(10),
                                      minThumbLength: 100,
                                      isAlwaysShown: true,
                                    ),
                                  ),
                            child: PagedL(
                              emptyStateWidget: Text(
                                Strings.noPosts,
                                style: Styles.baseTextTheme.headline4.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontSize: kIsWeb ? 14.0 : 12.0,
                                ),
                              ),
                              itemBuilder: _itemRow,
                              padding: EdgeInsets.only(
                                  top: 16.00, left: 4.00, right: 4.00),
                              loadingIndicator: Padding(
                                padding: EdgeInsets.all(16.00),
                                child: Center(
                                  child: CircularProgressIndicator(
                                    color: MyColors.BlueColor,
                                  ),
                                ),
                              ),
                              itemDataProvider: _fetchData,
                              list: controller.savedPostList,
                              listSize:
                                  _checkPage(controller.savedPostList.length)),
                        ),
              ),
            ],
          ),
        ),
      );
    });
  }

  // ignore: missing_return
  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Widget _itemRow(BuildContext context, Post post) {
    // ignore: can_be_null_after_null_aware
    int index = controller?.savedPostList.indexWhere((element) {
      return element.postId == post.postId;
    });
    if (index != -1)
      return controller.savedPostList[index].type == 'thread'
          ? ThreadPostCard(
              index: index,
              post: controller?.savedPostList[index],
              scaffoldKey: _scaffoldKey,
              controller: controller.newsFeedControloler,
              savedController: controller,
              savedItemId: controller?.savedPostList[index].savedItemId,
              saveCard: true,
            )
          : PostCard(
              index: index,
              post: controller?.savedPostList[index],
              scaffoldKey: _scaffoldKey,
              controller: controller.newsFeedControloler,
              savedController: controller,
              savedItemId: controller?.savedPostList[index].savedItemId,
              saveCard: true,
              deletePostId: 4,
            );
    return SizedBox();
  }

  Future<List<Post>> _fetchData(int page) async {
    return await widget.newsFeedController.getSavedPostPaged(page: page);
  }
}
