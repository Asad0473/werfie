import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/widgets/textformfield_screen.dart';
import '../models/create_post_model/create_post_model.dart';
import '../network/controller/news_feed_controller.dart';
import '../utils/colors.dart';
import '../utils/font.dart';
import '../utils/strings.dart';

class PostImageDescriptionForReply extends StatefulWidget {
  int ind;
  int addDescriptionCheck;

  PostImageDescriptionForReply({Key key, this.ind, this.addDescriptionCheck})
      : super(key: key);

  @override
  State<PostImageDescriptionForReply> createState() =>
      _PostImageDescriptionForReplyState();
}

class _PostImageDescriptionForReplyState
    extends State<PostImageDescriptionForReply> {
  NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  @override
  void initState() {
    if (newsfeedController.replayModelList[widget.ind].imageCounter == null ||
        widget.addDescriptionCheck == 1) {
      newsfeedController.replayModelList[widget.ind].imageCounter = 0;
      newsfeedController
              .replayModelList[widget.ind].imageDescriptionController =
          List.generate(4, (i) => TextEditingController());
      newsfeedController.replayModelList[widget.ind].descriptionCounter = 0;
    }

    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(context) {
    print("index asdasda ${widget.ind}");

    return GetBuilder<NewsfeedController>(builder: (controller) {
      return kIsWeb
          ? Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10.0)),
                color: Colors.white,
              ),
              height: 550,
              width: 550,
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                          onPressed: () {
                            newsfeedController
                                .modelList2[widget.ind].imageCounter = 0;
                            newsfeedController.update();
                            Navigator.pop(context);
                          },
                          icon: Icon(Icons.arrow_back)),
                      Text(
                        Strings.editImageDescription,
                        style: Styles.baseTextTheme.headline1.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Spacer(),
                      newsfeedController.replayModelList[widget.ind].mediaData2
                                  .length >
                              1
                          ? GestureDetector(
                              onTap: () {
                                if (newsfeedController
                                        .replayModelList[widget.ind]
                                        .imageCounter >=
                                    1) {
                                  newsfeedController.replayModelList[widget.ind]
                                      .imageCounter--;
                                  controller.update();
                                }
                              },
                              child: Container(
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white.withOpacity(0.5)
                                        : Colors.grey.withOpacity(0.5),
                                  ),
                                ),
                                child: Align(
                                    alignment: Alignment.center,
                                    child: newsfeedController
                                                .replayModelList[widget.ind]
                                                .imageCounter >=
                                            1
                                        ? Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 15,
                                          )
                                        : Icon(
                                            Icons.arrow_back,
                                            color: Colors.grey,
                                            size: 15,
                                          )),
                              ),
                            )
                          : SizedBox(),
                      SizedBox(
                        width: 5,
                      ),
                      newsfeedController.replayModelList[widget.ind].mediaData2
                                  .length >
                              1
                          ? GestureDetector(
                              onTap: () {
                                if (newsfeedController
                                        .replayModelList[widget.ind]
                                        .imageCounter <=
                                    newsfeedController
                                            .replayModelList[widget.ind]
                                            .mediaData2
                                            .length -
                                        2) {
                                  newsfeedController.replayModelList[widget.ind]
                                      .imageCounter++;
                                  controller.update();
                                }
                              },
                              child: Container(
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white.withOpacity(0.5)
                                          : Colors.grey.withOpacity(0.5)),
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: newsfeedController
                                              .replayModelList[widget.ind]
                                              .imageCounter <=
                                          newsfeedController
                                                  .replayModelList[widget.ind]
                                                  .mediaData2
                                                  .length -
                                              2
                                      ? Icon(
                                          Icons.arrow_forward,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          size: 15,
                                        )
                                      : Icon(
                                          Icons.arrow_forward,
                                          color: Colors.grey,
                                          size: 15,
                                        ),
                                ),
                              ),
                            )
                          : SizedBox(),
                      SizedBox(
                        width: 10,
                      ),
                      RoundedButton(
                        Strings.save,
                        () {
                          int index = 0;
                          newsfeedController.replayModelList[widget.ind]
                              .descriptionCounter = 0;
                          if (newsfeedController.replayModelList[widget.ind]
                                  .imageDescriptionController.length >
                              0) {
                            newsfeedController.replayModelList[widget.ind]
                                .imageDescriptionController
                                .forEach((element) {
                              if (element.text.isNotEmpty) {
                                newsfeedController.replayModelList[widget.ind]
                                    .descriptionCounter++;
                                newsfeedController
                                    .replayModelList[widget.ind]
                                    .mediaData2[index]
                                    .description = element.text;
                                controller.update();
                              }
                              index++;
                            });

                            newsfeedController
                                .replayModelList[widget.ind].imageCounter = 0;
                            controller.update();

                            // int length =  newsfeedController.modelList2[ind].mediaData2.length;
                            //
                            // int counter =0;
                            // newsfeedController.modelList2[ind].mediaData2.forEach((element) {
                            //
                            //   if(element.imageSave == true)
                            //     {
                            //
                            //       counter++;
                            //     }
                            // });
                            //
                            // if
                          }

                          Navigator.pop(context);
                        },
                        roundedButtonColor: newsfeedController.displayColor,
                        horizontalPadding: 15,
                        verticalPadding: 10,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                    ],
                  ),
                  Expanded(
                    flex: 2,
                    child: Image.network(
                      newsfeedController
                          .replayModelList[widget.ind]
                          .mediaData2[newsfeedController
                              .replayModelList[widget.ind].imageCounter]
                          .url,
                      // height: 420,
                      // width: Get.width,
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Expanded(
                    child: CustomFormField(
                      label: "Description",
                      hintText: "Description",
                      focusBorderColor: controller.displayColor,
                      labelStyle: Styles.baseTextTheme.headline2.copyWith(
                        color: controller.displayColor,
                        fontWeight: FontWeight.w400,
                        fontSize: kIsWeb ? 16 : 14,
                      ),
                      maxline: 5,
                      minLine: 2,
                      controller: newsfeedController.replayModelList[widget.ind]
                              .imageDescriptionController[
                          newsfeedController
                              .replayModelList[widget.ind].imageCounter],
                      onChange: (value) {
                        controller.update();
                      },
                      maxLength: 1000,
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      showDialog(
                          context: context,
                          builder: (BuildContext con) {
                            return AlertDialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                backgroundColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? MyColors.liteDark
                                    : Colors.white,
                                contentPadding: EdgeInsets.zero,
                                content: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 20, right: 20, top: 20),
                                  child: Container(
                                    height: 300,
                                    width: 300,
                                    child: SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "${Strings.addDescriptions}?",
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          Text(
                                            Strings
                                                .YouCanAddADescriptionSometimesCalledAltTextToYourPhotosSoTheyreAccessibleToEvenMorePeopleIncludingPeopleWhoAreBlindOrHaveLowVisionGoodDescriptionsAreConciseButPresentWhatsInYourPhotosAccuratelyEnoughToUnderstandTheirContext,
                                            style: TextStyle(
                                              height: 1.2,
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? MyColors.grey
                                                  : Colors.black,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 20,
                                          ),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: ElevatedButton(
                                                  // key: LoginController.formKey,
                                                  onPressed: () async {
                                                    Navigator.pop(context);

                                                    controller.update();
                                                  },
                                                  child: Text(
                                                    Strings.sure,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Colors.white,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    shadowColor:
                                                        Colors.transparent,
                                                    primary:
                                                        controller.displayColor,
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 20,
                                                            horizontal: 25),
                                                    elevation: 0.0,
                                                    shape: StadiumBorder(),
                                                    // minimumSize: Size(100, 40),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: ElevatedButton(
                                                  // key: LoginController.formKey,
                                                  onPressed: () async {
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    Strings.noThanks,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    shadowColor:
                                                        Colors.transparent,
                                                    primary: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.black
                                                        : Colors.white,
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 20,
                                                            horizontal: 25),
                                                    elevation: 0.0,
                                                    shape: StadiumBorder(),
                                                    side: BorderSide(
                                                      width: 1,
                                                      color: MyColors.grey,
                                                    ),
                                                    // minimumSize: Size(100, 40),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                )

                                //     Deactivation(
                                //   context2: context,
                                // ),
                                );
                          });
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          Strings.WhatIsAltText,
                          style: Styles.baseTextTheme.subtitle1.copyWith(
                            color: controller.displayColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
            )
          : WillPopScope(
              onWillPop: () {
                newsfeedController.modelList2[widget.ind].imageCounter = 0;
                newsfeedController.update();
                return;
              },
              child: Scaffold(
                  appBar: AppBar(
                    elevation: 0.0,
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    automaticallyImplyLeading: false,
                    title: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        SizedBox(
                          width: 5,
                        ),

                        // ),
                        Text(
                          Strings.editImageDescription,
                          style: Styles.baseTextTheme.headline1.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        newsfeedController.replayModelList[widget.ind]
                                    .mediaData2.length >
                                1
                            ? GestureDetector(
                                onTap: () {
                                  if (newsfeedController
                                          .replayModelList[widget.ind]
                                          .imageCounter >=
                                      1) {
                                    newsfeedController
                                        .replayModelList[widget.ind]
                                        .imageCounter--;
                                    controller.update();
                                  }
                                },
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white.withOpacity(0.5)
                                          : Colors.grey.withOpacity(0.5),
                                    ),
                                  ),
                                  child: Align(
                                      alignment: Alignment.center,
                                      child: newsfeedController
                                                  .replayModelList[widget.ind]
                                                  .imageCounter >=
                                              1
                                          ? Icon(
                                              Icons.arrow_back,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              size: 15,
                                            )
                                          : Icon(
                                              Icons.arrow_back,
                                              color: Colors.grey,
                                              size: 15,
                                            )),
                                ),
                              )
                            : SizedBox(),
                        SizedBox(
                          width: 5,
                        ),
                        newsfeedController.replayModelList[widget.ind]
                                    .mediaData2.length >
                                1
                            ? GestureDetector(
                                onTap: () {
                                  if (newsfeedController
                                          .replayModelList[widget.ind]
                                          .imageCounter <=
                                      newsfeedController
                                              .replayModelList[widget.ind]
                                              .mediaData2
                                              .length -
                                          2) {
                                    newsfeedController
                                        .replayModelList[widget.ind]
                                        .imageCounter++;
                                    controller.update();
                                  }
                                },
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white.withOpacity(0.5)
                                            : Colors.grey.withOpacity(0.5)),
                                  ),
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: newsfeedController
                                                .replayModelList[widget.ind]
                                                .imageCounter <=
                                            newsfeedController
                                                    .replayModelList[widget.ind]
                                                    .mediaData2
                                                    .length -
                                                2
                                        ? Icon(
                                            Icons.arrow_forward,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 15,
                                          )
                                        : Icon(
                                            Icons.arrow_forward,
                                            color: Colors.grey,
                                            size: 15,
                                          ),
                                  ),
                                ),
                              )
                            : SizedBox(),
                        SizedBox(
                          width: 10,
                        ),
                        Spacer(),
                        RoundedButton(
                          Strings.save,
                          () {
                            int index = 0;
                            newsfeedController.replayModelList[widget.ind]
                                .descriptionCounter = 0;
                            if (newsfeedController.replayModelList[widget.ind]
                                    .imageDescriptionController.length >
                                0) {
                              newsfeedController.replayModelList[widget.ind]
                                  .imageDescriptionController
                                  .forEach((element) {
                                if (element.text.isNotEmpty) {
                                  newsfeedController.replayModelList[widget.ind]
                                      .descriptionCounter++;
                                  newsfeedController
                                      .replayModelList[widget.ind]
                                      .mediaData2[index]
                                      .description = element.text;
                                  controller.update();
                                }
                                index++;
                              });
                              newsfeedController
                                  .replayModelList[widget.ind].imageCounter = 0;
                              controller.update();

                              // int length =  newsfeedController.modelList2[ind].mediaData2.length;
                              //
                              // int counter =0;
                              // newsfeedController.modelList2[ind].mediaData2.forEach((element) {
                              //
                              //   if(element.imageSave == true)
                              //     {
                              //
                              //       counter++;
                              //     }
                              // });
                              //
                              // if
                            }
                            controller.update();
                            Navigator.pop(context);
                          },
                          roundedButtonColor: newsfeedController.displayColor,
                          horizontalPadding: 3.0,
                          verticalPadding: 3.0,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                  ),
                  body: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(10.0)),
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Image.network(
                            newsfeedController
                                .replayModelList[widget.ind]
                                .mediaData2[newsfeedController
                                    .replayModelList[widget.ind].imageCounter]
                                .url,
                            // height: 420,
                            // width: Get.width,
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Expanded(
                          child: CustomFormField(
                            label: "Description",
                            hintText: "Description",
                            focusBorderColor: controller.displayColor,
                            labelStyle: Styles.baseTextTheme.headline2.copyWith(
                              color: controller.displayColor,
                              fontWeight: FontWeight.w400,
                              fontSize: kIsWeb ? 16 : 14,
                            ),
                            maxline: 5,
                            minLine: 2,
                            controller: newsfeedController
                                    .replayModelList[widget.ind]
                                    .imageDescriptionController[
                                newsfeedController
                                    .replayModelList[widget.ind].imageCounter],
                            onChange: (value) {
                              controller.update();
                            },
                            maxLength: 1000,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            showDialog(
                                context: context,
                                builder: (BuildContext con) {
                                  return AlertDialog(
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      backgroundColor:
                                          Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? MyColors.liteDark
                                              : Colors.white,
                                      contentPadding: EdgeInsets.zero,
                                      content: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 20, right: 20, top: 20),
                                        child: Container(
                                          height: 300,
                                          width: 300,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "${Strings.addDescriptions}?",
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  ),
                                                ),
                                                Text(
                                                  Strings
                                                      .YouCanAddADescriptionSometimesCalledAltTextToYourPhotosSoTheyreAccessibleToEvenMorePeopleIncludingPeopleWhoAreBlindOrHaveLowVisionGoodDescriptionsAreConciseButPresentWhatsInYourPhotosAccuratelyEnoughToUnderstandTheirContext,
                                                  style: TextStyle(
                                                    height: 1.2,
                                                    fontSize: 14,
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? MyColors.grey
                                                        : Colors.black,
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 20,
                                                ),
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: ElevatedButton(
                                                        // key: LoginController.formKey,
                                                        onPressed: () async {
                                                          Navigator.pop(
                                                              context);

                                                          controller.update();
                                                        },
                                                        child: Text(
                                                          Strings.sure,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Colors.white,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          shadowColor: Colors
                                                              .transparent,
                                                          primary: controller
                                                              .displayColor,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 20,
                                                                  horizontal:
                                                                      25),
                                                          elevation: 0.0,
                                                          shape:
                                                              StadiumBorder(),
                                                          // minimumSize: Size(100, 40),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: ElevatedButton(
                                                        // key: LoginController.formKey,
                                                        onPressed: () async {
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                        child: Text(
                                                          Strings.noThanks,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          shadowColor: Colors
                                                              .transparent,
                                                          primary: Theme.of(
                                                                          context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.black
                                                              : Colors.white,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 20,
                                                                  horizontal:
                                                                      25),
                                                          elevation: 0.0,
                                                          shape:
                                                              StadiumBorder(),
                                                          side: BorderSide(
                                                            width: 1,
                                                            color:
                                                                MyColors.grey,
                                                          ),
                                                          // minimumSize: Size(100, 40),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      )

                                      //     Deactivation(
                                      //   context2: context,
                                      // ),
                                      );
                                });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Strings.WhatIsAltText,
                                style: Styles.baseTextTheme.subtitle1.copyWith(
                                  color: controller.displayColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  )),
            );
    });
    // return Scaffold(
    //   body: GetBuilder<NewsfeedController>(
    //     builder: (controller) {
    //
    //       // return Obx(() {
    //       //
    //       // });
    //     },
    //   ),
    // );
  }
}

class PostImageDescription extends StatefulWidget {
  int ind;
  int addDescriptionCheck;

  PostImageDescription({Key key, this.ind, this.addDescriptionCheck})
      : super(key: key);

  @override
  State<PostImageDescription> createState() => _PostImageDescriptionState();
}

class _PostImageDescriptionState extends State<PostImageDescription> {
  NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  @override
  void initState() {
    if (newsfeedController.modelList2[widget.ind].imageCounter == null || widget.addDescriptionCheck == 1) {
      newsfeedController.modelList2[widget.ind].imageCounter = 0;
      newsfeedController.modelList2[widget.ind].imageDescriptionController = List.generate(4, (i) => TextEditingController());

      int i=0;
      newsfeedController.modelList2[widget.ind].mediaData2.forEach((element) {
        if(element.description!=null)
          {
            newsfeedController.modelList2[widget.ind].imageDescriptionController[i].text = element.description;
            i++;
          }

      });
     if(i>0)
       {
         // newsfeedController.modelList2[widget.ind].descriptionCounter = 0;

       }
     else{

       newsfeedController.modelList2[widget.ind].descriptionCounter = 0;
     }
    } else {
      newsfeedController.modelList2[widget.ind].imageCounter = 0;
    }

    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(context) {
    print("index asdasda ${widget.addDescriptionCheck}");

    return GetBuilder<NewsfeedController>(builder: (controller) {
      return kIsWeb
          ? Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10.0)),
                color: Colors.white,
              ),
              height: 550,
              width: 550,
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                          onPressed: () {
                            newsfeedController.modelList2[widget.ind].imageCounter = 0;
                            newsfeedController.update();
                            Navigator.pop(context);
                          },
                          icon: Icon(Icons.arrow_back)),
                      Text(
                        Strings.editImageDescription,
                        style: Styles.baseTextTheme.headline1.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Spacer(),
                      newsfeedController.modelList2[widget.ind].mediaData2.length > 1
                          ? GestureDetector(
                              onTap: () {
                                if (controller.modelList2[widget.ind].imageCounter >= 1) {
                                  controller
                                      .modelList2[widget.ind].imageCounter--;
                                  controller.update();
                                }
                              },
                              child: Container(
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white.withOpacity(0.5)
                                        : Colors.grey.withOpacity(0.5),
                                  ),
                                ),
                                child: Align(
                                    alignment: Alignment.center,
                                    child: controller.modelList2[widget.ind]
                                                .imageCounter >=
                                            1
                                        ? Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 15,
                                          )
                                        : Icon(
                                            Icons.arrow_back,
                                            color: Colors.grey,
                                            size: 15,
                                          )),
                              ),
                            )
                          : SizedBox(),
                      SizedBox(
                        width: 5,
                      ),
                      newsfeedController
                                  .modelList2[widget.ind].mediaData2.length >
                              1
                          ? GestureDetector(
                              onTap: () {
                                if (controller
                                        .modelList2[widget.ind].imageCounter <=
                                    newsfeedController.modelList2[widget.ind]
                                            .mediaData2.length -
                                        2) {
                                  controller
                                      .modelList2[widget.ind].imageCounter++;
                                  controller.update();
                                }
                              },
                              child: Container(
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white.withOpacity(0.5)
                                          : Colors.grey.withOpacity(0.5)),
                                ),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: newsfeedController
                                              .modelList2[widget.ind]
                                              .imageCounter <=
                                          newsfeedController
                                                  .modelList2[widget.ind]
                                                  .mediaData2
                                                  .length -
                                              2
                                      ? Icon(
                                          Icons.arrow_forward,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          size: 15,
                                        )
                                      : Icon(
                                          Icons.arrow_forward,
                                          color: Colors.grey,
                                          size: 15,
                                        ),
                                ),
                              ),
                            )
                          : SizedBox(),
                      SizedBox(
                        width: 10,
                      ),
                      RoundedButton(
                        Strings.save,
                        () {
                          int index = 0;
                          controller.modelList2[widget.ind].descriptionCounter = 0;
                          if (controller.modelList2[widget.ind].imageDescriptionController.length > 0) {
                            controller.modelList2[widget.ind].imageDescriptionController.forEach((element) {
                              if (element.text.isNotEmpty) {
                                controller.modelList2[widget.ind].descriptionCounter++;
                                newsfeedController.modelList2[widget.ind].mediaData2[index].description = element.text;
                                controller.update();
                              }
                              index++;
                            });

                            controller.modelList2[widget.ind].imageCounter = 0;
                            controller.update();

                            // int length =  newsfeedController.modelList2[ind].mediaData2.length;
                            //
                            // int counter =0;
                            // newsfeedController.modelList2[ind].mediaData2.forEach((element) {
                            //
                            //   if(element.imageSave == true)
                            //     {
                            //
                            //       counter++;
                            //     }
                            // });
                            //
                            // if
                          }

                          Navigator.pop(context);
                        },
                        roundedButtonColor: newsfeedController.displayColor,
                        horizontalPadding: 15,
                        verticalPadding: 10,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                    ],
                  ),
                  Expanded(
                    flex: 2,
                    child: Image.network(
                      newsfeedController
                          .modelList2[widget.ind]
                          .mediaData2[newsfeedController
                              .modelList2[widget.ind].imageCounter]
                          .url,
                      // height: 420,
                      // width: Get.width,
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Expanded(
                    child: CustomFormField(
                      label: "Description",
                      hintText: "Description",
                      focusBorderColor: controller.displayColor,
                      labelStyle: Styles.baseTextTheme.headline2.copyWith(
                        color: controller.displayColor,
                        fontWeight: FontWeight.w400,
                        fontSize: kIsWeb ? 16 : 14,
                      ),
                      maxline: 5,
                      minLine: 2,
                      controller: newsfeedController.modelList2[widget.ind]
                              .imageDescriptionController[
                          newsfeedController
                              .modelList2[widget.ind].imageCounter],
                      onChange: (value) {
                        controller.update();
                      },
                      maxLength: 1000,
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      showDialog(
                          context: context,
                          builder: (BuildContext con) {
                            return AlertDialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                backgroundColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? MyColors.liteDark
                                    : Colors.white,
                                contentPadding: EdgeInsets.zero,
                                content: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 20, right: 20, top: 20),
                                  child: Container(
                                    height: 300,
                                    width: 300,
                                    child: SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "${Strings.addDescriptions}?",
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          Text(
                                            Strings
                                                .YouCanAddADescriptionSometimesCalledAltTextToYourPhotosSoTheyreAccessibleToEvenMorePeopleIncludingPeopleWhoAreBlindOrHaveLowVisionGoodDescriptionsAreConciseButPresentWhatsInYourPhotosAccuratelyEnoughToUnderstandTheirContext,
                                            style: TextStyle(
                                              height: 1.2,
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? MyColors.grey
                                                  : Colors.black,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 20,
                                          ),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: ElevatedButton(
                                                  // key: LoginController.formKey,
                                                  onPressed: () async {
                                                    Navigator.pop(context);

                                                    controller.update();
                                                  },
                                                  child: Text(
                                                    Strings.sure,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Colors.white,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    shadowColor:
                                                        Colors.transparent,
                                                    primary:
                                                        controller.displayColor,
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 20,
                                                            horizontal: 25),
                                                    elevation: 0.0,
                                                    shape: StadiumBorder(),
                                                    // minimumSize: Size(100, 40),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: ElevatedButton(
                                                  // key: LoginController.formKey,
                                                  onPressed: () async {
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    Strings.noThanks,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    shadowColor:
                                                        Colors.transparent,
                                                    primary: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.black
                                                        : Colors.white,
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 20,
                                                            horizontal: 25),
                                                    elevation: 0.0,
                                                    shape: StadiumBorder(),
                                                    side: BorderSide(
                                                      width: 1,
                                                      color: MyColors.grey,
                                                    ),
                                                    // minimumSize: Size(100, 40),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                )

                                //     Deactivation(
                                //   context2: context,
                                // ),
                                );
                          });
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          Strings.WhatIsAltText,
                          style: Styles.baseTextTheme.subtitle1.copyWith(
                            color: controller.displayColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
            )
          : WillPopScope(
              onWillPop: () {
                newsfeedController.modelList2[widget.ind].imageCounter = 0;
                newsfeedController.update();
                return;
              },
              child: Scaffold(
                  appBar: AppBar(
                    elevation: 0.0,
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    automaticallyImplyLeading: false,
                    title: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        SizedBox(
                          width: 5,
                        ),

                        // ),
                        Text(
                          Strings.editImageDescription,
                          style: Styles.baseTextTheme.headline1.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        newsfeedController
                                    .modelList2[widget.ind].mediaData2.length >
                                1
                            ? GestureDetector(
                                onTap: () {
                                  if (newsfeedController.modelList2[widget.ind]
                                          .imageCounter >=
                                      1) {
                                    newsfeedController
                                        .modelList2[widget.ind].imageCounter--;
                                    controller.update();
                                  }
                                },
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white.withOpacity(0.5)
                                          : Colors.grey.withOpacity(0.5),
                                    ),
                                  ),
                                  child: Align(
                                      alignment: Alignment.center,
                                      child: newsfeedController
                                                  .modelList2[widget.ind]
                                                  .imageCounter >=
                                              1
                                          ? Icon(
                                              Icons.arrow_back,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              size: 15,
                                            )
                                          : Icon(
                                              Icons.arrow_back,
                                              color: Colors.grey,
                                              size: 15,
                                            )),
                                ),
                              )
                            : SizedBox(),
                        SizedBox(
                          width: 5,
                        ),
                        newsfeedController
                                    .modelList2[widget.ind].mediaData2.length >
                                1
                            ? GestureDetector(
                                onTap: () {
                                  if (newsfeedController.modelList2[widget.ind]
                                          .imageCounter <=
                                      newsfeedController.modelList2[widget.ind]
                                              .mediaData2.length -
                                          2) {
                                    newsfeedController
                                        .modelList2[widget.ind].imageCounter++;
                                    controller.update();
                                  }
                                },
                                child: Container(
                                  height: 30,
                                  width: 30,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white.withOpacity(0.5)
                                            : Colors.grey.withOpacity(0.5)),
                                  ),
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: newsfeedController
                                                .modelList2[widget.ind]
                                                .imageCounter <=
                                            newsfeedController
                                                    .modelList2[widget.ind]
                                                    .mediaData2
                                                    .length -
                                                2
                                        ? Icon(
                                            Icons.arrow_forward,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 15,
                                          )
                                        : Icon(
                                            Icons.arrow_forward,
                                            color: Colors.grey,
                                            size: 15,
                                          ),
                                  ),
                                ),
                              )
                            : SizedBox(),
                        SizedBox(
                          width: 10,
                        ),
                        Spacer(),
                        RoundedButton(
                          Strings.save,
                          () async {
                            int index = 0;
                            newsfeedController
                                .modelList2[widget.ind].descriptionCounter = 0;
                            if (newsfeedController.modelList2[widget.ind]
                                    .imageDescriptionController.length >
                                0) {
                              newsfeedController.modelList2[widget.ind]
                                  .imageDescriptionController
                                  .forEach((element) {
                                if (element.text.isNotEmpty) {
                                  print("/.........ass..asdas");
                                  newsfeedController.modelList2[widget.ind]
                                      .descriptionCounter++;
                                  newsfeedController
                                      .modelList2[widget.ind]
                                      .mediaData2[index]
                                      .description = element.text;
                                  controller.update();
                                }
                                index++;
                              });
                              controller.modelList2[widget.ind].imageCounter =
                                  0;
                              controller.update();
                              print(
                                  'One second has passed.'); // Prints after 1 second.

                              // int length =  newsfeedController.modelList2[ind].mediaData2.length;
                              //
                              // int counter =0;
                              // newsfeedController.modelList2[ind].mediaData2.forEach((element) {
                              //
                              //   if(element.imageSave == true)
                              //     {
                              //
                              //       counter++;
                              //     }
                              // });
                              //
                              // if
                            }
                            Navigator.pop(context);
                          },
                          roundedButtonColor: newsfeedController.displayColor,
                          horizontalPadding: 3.0,
                          verticalPadding: 3.0,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                  ),
                  body: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(10.0)),
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Image.network(
                            newsfeedController
                                .modelList2[widget.ind]
                                .mediaData2[newsfeedController
                                    .modelList2[widget.ind].imageCounter]
                                .url,
                            // height: 420,
                            // width: Get.width,
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Expanded(
                          child: CustomFormField(
                            label: "Description",
                            hintText: "Description",
                            focusBorderColor: controller.displayColor,
                            labelStyle: Styles.baseTextTheme.headline2.copyWith(
                              color: controller.displayColor,
                              fontWeight: FontWeight.w400,
                              fontSize: kIsWeb ? 16 : 14,
                            ),
                            maxline: 5,
                            minLine: 2,
                            controller: newsfeedController
                                    .modelList2[widget.ind]
                                    .imageDescriptionController[
                                newsfeedController
                                    .modelList2[widget.ind].imageCounter],
                            onChange: (value) {
                              controller.update();
                            },
                            maxLength: 1000,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            showDialog(
                                context: context,
                                builder: (BuildContext con) {
                                  return AlertDialog(
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      backgroundColor:
                                          Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? MyColors.liteDark
                                              : Colors.white,
                                      contentPadding: EdgeInsets.zero,
                                      content: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 20, right: 20, top: 20),
                                        child: Container(
                                          height: 300,
                                          width: 300,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "${Strings.addDescriptions}?",
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  ),
                                                ),
                                                Text(
                                                  Strings
                                                      .YouCanAddADescriptionSometimesCalledAltTextToYourPhotosSoTheyreAccessibleToEvenMorePeopleIncludingPeopleWhoAreBlindOrHaveLowVisionGoodDescriptionsAreConciseButPresentWhatsInYourPhotosAccuratelyEnoughToUnderstandTheirContext,
                                                  style: TextStyle(
                                                    height: 1.2,
                                                    fontSize: 14,
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? MyColors.grey
                                                        : Colors.black,
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 20,
                                                ),
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: ElevatedButton(
                                                        // key: LoginController.formKey,
                                                        onPressed: () async {
                                                          Navigator.pop(
                                                              context);

                                                          controller.update();
                                                        },
                                                        child: Text(
                                                          Strings.sure,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Colors.white,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          shadowColor: Colors
                                                              .transparent,
                                                          primary: controller
                                                              .displayColor,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 20,
                                                                  horizontal:
                                                                      25),
                                                          elevation: 0.0,
                                                          shape:
                                                              StadiumBorder(),
                                                          // minimumSize: Size(100, 40),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: ElevatedButton(
                                                        // key: LoginController.formKey,
                                                        onPressed: () async {
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                        child: Text(
                                                          Strings.noThanks,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          shadowColor: Colors
                                                              .transparent,
                                                          primary: Theme.of(
                                                                          context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.black
                                                              : Colors.white,
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  vertical: 20,
                                                                  horizontal:
                                                                      25),
                                                          elevation: 0.0,
                                                          shape:
                                                              StadiumBorder(),
                                                          side: BorderSide(
                                                            width: 1,
                                                            color:
                                                                MyColors.grey,
                                                          ),
                                                          // minimumSize: Size(100, 40),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      )

                                      //     Deactivation(
                                      //   context2: context,
                                      // ),
                                      );
                                });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                Strings.WhatIsAltText,
                                style: Styles.baseTextTheme.subtitle1.copyWith(
                                  color: controller.displayColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  )),
            );
    });
    // return Scaffold(
    //   body: GetBuilder<NewsfeedController>(
    //     builder: (controller) {
    //
    //       // return Obx(() {
    //       //
    //       // });
    //     },
    //   ),
    // );
  }
}







class PostImageDescriptionForWebHomeScreen extends StatefulWidget {
  int ind;
  int addDescriptionCheck;

  PostImageDescriptionForWebHomeScreen(
      {Key key, this.ind, this.addDescriptionCheck})
      : super(key: key);

  @override
  State<PostImageDescriptionForWebHomeScreen> createState() =>
      _PostImageDescriptionForWebHomeScreenState();
}

class _PostImageDescriptionForWebHomeScreenState
    extends State<PostImageDescriptionForWebHomeScreen> {
  NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  @override
  void initState() {
    if (newsfeedController.modelList3[widget.ind].imageCounter == null ||
        widget.addDescriptionCheck == 1) {
      newsfeedController.modelList3[widget.ind].imageCounter = 0;
      newsfeedController.modelList3[widget.ind].imageDescriptionController =
          List.generate(4, (i) => TextEditingController());
      newsfeedController.modelList3[widget.ind].descriptionCounter = 0;
    }

    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(context) {
    print("index asdasda ${widget.ind}");

    return GetBuilder<NewsfeedController>(builder: (controller) {
      return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10.0)),
          color: Colors.white,
        ),
        height: 550,
        width: 550,
        child: Column(
          children: [
            Row(
              children: [
                IconButton(
                    onPressed: () {
                      newsfeedController.modelList2[widget.ind].imageCounter =
                          0;
                      newsfeedController.update();
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.arrow_back)),
                Text(
                  Strings.editImageDescription,
                  style: Styles.baseTextTheme.headline1.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: kIsWeb ? 16 : 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Spacer(),
                newsfeedController.modelList3[widget.ind].mediaData2.length > 1
                    ? GestureDetector(
                        onTap: () {
                          if (newsfeedController
                                  .modelList3[widget.ind].imageCounter >=
                              1) {
                            newsfeedController
                                .modelList3[widget.ind].imageCounter--;
                            controller.update();
                          }
                        },
                        child: Container(
                          height: 30,
                          width: 30,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white.withOpacity(0.5)
                                  : Colors.grey.withOpacity(0.5),
                            ),
                          ),
                          child: Align(
                              alignment: Alignment.center,
                              child: newsfeedController.modelList3[widget.ind]
                                          .imageCounter >=
                                      1
                                  ? Icon(
                                      Icons.arrow_back,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      size: 15,
                                    )
                                  : Icon(
                                      Icons.arrow_back,
                                      color: Colors.grey,
                                      size: 15,
                                    )),
                        ),
                      )
                    : SizedBox(),
                SizedBox(
                  width: 5,
                ),
                newsfeedController.modelList3[widget.ind].mediaData2.length > 1
                    ? GestureDetector(
                        onTap: () {
                          if (newsfeedController
                                  .modelList3[widget.ind].imageCounter <=
                              newsfeedController.modelList3[widget.ind]
                                      .mediaData2.length -
                                  2) {
                            newsfeedController
                                .modelList3[widget.ind].imageCounter++;
                            controller.update();
                          }
                        },
                        child: Container(
                          height: 30,
                          width: 30,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white.withOpacity(0.5)
                                    : Colors.grey.withOpacity(0.5)),
                          ),
                          child: Align(
                            alignment: Alignment.center,
                            child: newsfeedController
                                        .modelList3[widget.ind].imageCounter <=
                                    newsfeedController.modelList3[widget.ind]
                                            .mediaData2.length -
                                        2
                                ? Icon(
                                    Icons.arrow_forward,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    size: 15,
                                  )
                                : Icon(
                                    Icons.arrow_forward,
                                    color: Colors.grey,
                                    size: 15,
                                  ),
                          ),
                        ),
                      )
                    : SizedBox(),
                SizedBox(
                  width: 10,
                ),
                RoundedButton(
                  Strings.save,
                  () {
                    int index = 0;
                    newsfeedController
                        .modelList3[widget.ind].descriptionCounter = 0;
                    if (newsfeedController.modelList3[widget.ind]
                            .imageDescriptionController.length >
                        0) {
                      newsfeedController
                          .modelList3[widget.ind].imageDescriptionController
                          .forEach((element) {
                        if (element.text.isNotEmpty) {
                          newsfeedController
                              .modelList3[widget.ind].descriptionCounter++;
                          newsfeedController.modelList3[widget.ind]
                              .mediaData2[index].description = element.text;
                          controller.update();
                        }
                        index++;
                      });

                      newsfeedController.modelList3[widget.ind].imageCounter =
                          0;
                      controller.update();

                      // int length =  newsfeedController.modelList2[ind].mediaData2.length;
                      //
                      // int counter =0;
                      // newsfeedController.modelList2[ind].mediaData2.forEach((element) {
                      //
                      //   if(element.imageSave == true)
                      //     {
                      //
                      //       counter++;
                      //     }
                      // });
                      //
                      // if
                    }

                    Navigator.pop(context);
                  },
                  roundedButtonColor: newsfeedController.displayColor,
                  horizontalPadding: 15,
                  verticalPadding: 10,
                ),
                SizedBox(
                  width: 10,
                ),
              ],
            ),
            Expanded(
              flex: 2,
              child: Image.network(
                newsfeedController
                    .modelList3[widget.ind]
                    .mediaData2[
                        newsfeedController.modelList3[widget.ind].imageCounter]
                    .url,
                // height: 420,
                // width: Get.width,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Expanded(
              child: CustomFormField(
                label: "Description",
                hintText: "Description",
                focusBorderColor: controller.displayColor,
                labelStyle: Styles.baseTextTheme.headline2.copyWith(
                  color: controller.displayColor,
                  fontWeight: FontWeight.w400,
                  fontSize: kIsWeb ? 16 : 14,
                ),
                maxline: 5,
                minLine: 2,
                controller: newsfeedController
                        .modelList3[widget.ind].imageDescriptionController[
                    newsfeedController.modelList3[widget.ind].imageCounter],
                onChange: (value) {
                  controller.update();
                },
                maxLength: 1000,
              ),
            ),
            InkWell(
              onTap: () {
                showDialog(
                    context: context,
                    builder: (BuildContext con) {
                      return AlertDialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          backgroundColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? MyColors.liteDark
                                  : Colors.white,
                          contentPadding: EdgeInsets.zero,
                          content: Padding(
                            padding: const EdgeInsets.only(
                                left: 20, right: 20, top: 20),
                            child: Container(
                              height: 300,
                              width: 300,
                              child: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "${Strings.addDescriptions}?",
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                    Text(
                                      Strings
                                          .YouCanAddADescriptionSometimesCalledAltTextToYourPhotosSoTheyreAccessibleToEvenMorePeopleIncludingPeopleWhoAreBlindOrHaveLowVisionGoodDescriptionsAreConciseButPresentWhatsInYourPhotosAccuratelyEnoughToUnderstandTheirContext,
                                      style: TextStyle(
                                        height: 1.2,
                                        fontSize: 14,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? MyColors.grey
                                            : Colors.black,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: ElevatedButton(
                                            // key: LoginController.formKey,
                                            onPressed: () async {
                                              Navigator.pop(context);

                                              controller.update();
                                            },
                                            child: Text(
                                              Strings.sure,
                                              style: Styles
                                                  .baseTextTheme.headline2
                                                  .copyWith(
                                                color: Colors.white,
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            style: ElevatedButton.styleFrom(
                                              shadowColor: Colors.transparent,
                                              primary: controller.displayColor,
                                              padding: EdgeInsets.symmetric(
                                                  vertical: 20, horizontal: 25),
                                              elevation: 0.0,
                                              shape: StadiumBorder(),
                                              // minimumSize: Size(100, 40),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: ElevatedButton(
                                            // key: LoginController.formKey,
                                            onPressed: () async {
                                              Navigator.pop(context);
                                            },
                                            child: Text(
                                              Strings.noThanks,
                                              style: Styles
                                                  .baseTextTheme.headline2
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            style: ElevatedButton.styleFrom(
                                              shadowColor: Colors.transparent,
                                              primary: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.black
                                                  : Colors.white,
                                              padding: EdgeInsets.symmetric(
                                                  vertical: 20, horizontal: 25),
                                              elevation: 0.0,
                                              shape: StadiumBorder(),
                                              side: BorderSide(
                                                width: 1,
                                                color: MyColors.grey,
                                              ),
                                              // minimumSize: Size(100, 40),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )

                          //     Deactivation(
                          //   context2: context,
                          // ),
                          );
                    });
              },
              child: Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    Strings.WhatIsAltText,
                    style: Styles.baseTextTheme.subtitle1.copyWith(
                      color: controller.displayColor,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      );
    });
    // return Scaffold(
    //   body: GetBuilder<NewsfeedController>(
    //     builder: (controller) {
    //
    //       // return Obx(() {
    //       //
    //       // });
    //     },
    //   ),
    // );
  }
}
