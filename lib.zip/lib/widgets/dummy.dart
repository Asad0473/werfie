// AlertDialog(
// contentPadding:
// const EdgeInsets
//     .fromLTRB(
// 0.0,
// 0.0,
// 0.0,
// 0.0),
// content: StatefulBuilder(
// builder: (context,
// StateSetter setState) {
// return Container(
// height:
// Get.height * 0.70,
// width:
// Get.width * 0.45,
// child: Column(
// children: [
// ListTile(
// leading:
// IconButton(
// onPressed:
// () {
// SingleTone
//     .instance
//     .selectedLocation =
// null;
// setState(() {});
// Navigator.of(
// context)
//     .pop();
//
//
//
//
// },
// icon:
// Icon(
// Icons.close,
// color:
// Colors.black87,
// )),
// title: Text(
// 'Create New List',
// style: TextStyle(
// fontSize: 14),),
// trailing:
// RaisedButton(
// shape: RoundedRectangleBorder(
// borderRadius:
// BorderRadius.circular(15)),
// color: Colors
//     .grey[
// 500],
// // background
// textColor:
// Colors
//     .white,
// // foreground
// onPressed:
// () async{
// DataListCreated data= await controller.createList(
// isChecked:
// controller.isChecked,type: "create",);
// if(data != null){
// nameList=data.name;
// crateId=data.id.toString();
// Navigator.pop(context);
// controller.SuggestedPost(list_Id: data.id.toString(),name: data.name);
// }
// showDialog<String>(
// context: context,
// builder: (BuildContext context) =>
// GetBuilder<ListController>(
// assignId: true,
// id: "edit_suggestion",
// builder: (controller) =>
// AlertDialog(
// contentPadding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
// content: Container(
// height: Get.height * 0.70,
// width: Get.width * 0.45,
// child: SingleChildScrollView(
// child: Column(
// children: [
// ListTile(
// leading: IconButton(
// onPressed: () {
// SingleTone.instance.selectedLocation = null;
// setState(() {});
// Navigator.of(context).pop();
// },
// icon: Icon(
// Icons.close,
// color: Colors.black87,
// )),
// title: Text(
// 'Add To Your List',
// style: TextStyle(color: Colors.black, fontWeight: FontWeight.w800),
// ),
// trailing: RaisedButton(
// shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
// color: Colors.grey[500],
// // backgroundRtab
// textColor: Colors.white,
// // foreground
// onPressed: () async{
// print("list create button");
// controller.selectedList = await controller.listDetail(listId : data.id);
// // Navigator.pop(context);
//
// controller.newsfeedController.isListDetailScreen = true;
// controller.newsfeedController.isSearch = false;
// controller.newsfeedController.isFilter = false;
// controller.newsfeedController.isFilterScreen = false;
// controller.newsfeedController.isTrendsScreen = false;
// controller.newsfeedController.isNewsFeedScreen = false;
// controller.newsfeedController.isBrowseScreen = false;
// controller.newsfeedController.isNotificationScreen = false;
// controller.newsfeedController.isWhoToFollowScreen = false;
// controller.newsfeedController.isSavedPostScreen = false;
// controller.newsfeedController.isChatScreen = false;
// controller.newsfeedController.isPostDetails = false;
// controller.newsfeedController.isProfileScreen = false;
// controller.newsfeedController.searchText.text = '';
// controller.newsfeedController.isListScreen = false;
// controller.newsfeedController.isFollwerScreen = false;
// controller.newsfeedController.isSettingsScreen = false;
// controller.newsfeedController.navRoute = "isChatScreen";
// controller.newsfeedController.update();
//
//
//
//
// controller.update();
//
// controller.newsfeedController.update();
// Navigator.pop(context);
// },
// child: Text('Done'),
// )),
// Container(
// child: SingleChildScrollView(
// child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
// SizedBox(height: 20.0),
// DefaultTabController(
// length: 2, // length of tabs
// initialIndex: 1,
// child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
// Container(
// child: TabBar(
// labelColor: Colors.blue,
// unselectedLabelColor: Colors.black,
// tabs: [
// Tab(text: 'Members ${controller.addMemberList.length}'),
// Tab(text: 'Suggested'),
// ],
// ),
// ),
// Container(
// height: Get.width*0.3, //height of TabBarView
// decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.grey, width: 0.5))),
// child: TabBarView(children: <Widget>[
// Container(
// height: Get.width*0.27,
// child:  SingleChildScrollView(
// child: Column(
// children: List.generate(
// controller.addMemberList.length,
// (index) => ListTile(
// leading: Container(
// height: 40,
// width: 40,
// decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(10), image: DecorationImage(image: NetworkImage(controller.addMemberList[
// index]
//     .authorProfileImage == null ?"https://www.challengetires.com/assets/img/placeholder.jpg" :controller.addMemberList[
// index]
//     .authorProfileImage), fit: BoxFit.fill)),
// ),
// title: Text(controller.addMemberList[index].username),
// subtitle: Row(
// children: [
// Text(controller.addMemberList[index].authorName),
// SizedBox(
// width: 4,
// ),
// Text(controller.addMemberList[index].username),
// ],
// ),
// trailing: ElevatedButton(
// style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), primary:  Colors.blueAccent ),
// onPressed:
//
// //     :
// () {
// setState(() {
// // isFollow = false;
//
// print("index >>>>>>>>>>>>>>>>>>>>>>>>$index");
//
// controller.addMemberList.removeAt(index);
//
// controller.modelSuggestList.forEach((element) {
// if(element.id == controller.addMemberList[index].id){
// element.isFollow = false;
// }
// });
//
//
// controller.update();
// controller.update(["edit_suggestion"]);
// // controller.deletePost(controller.addMemberList[index].id);
// // dataList.remove(
// //     controller.  listOfDiscover[index]);
// });
// controller.update();
// controller.update(["edit_suggestion"]);
// controller.unFollowRemoveMethod(list_Id:data.id.toString(), member_id:controller.addMemberList[index].id.toString(),type:"member");
// // controller.addMemberList.removeAt(i);
// },
// child:
// // isFollow == false
// //     ? Text(
// //   "Add",
// //   style: Theme.of(context).textTheme.headline6.copyWith(
// //     fontSize: 14,
// //     fontWeight: FontWeight.w700,
// //     color: Colors.white,
// //   ),
// // )
// //     :
// Text(
// "Remove",
// style: Theme.of(context).textTheme.headline6.copyWith(
// fontSize: 14,
// fontWeight: FontWeight.w700,
// color: Colors.white,
// ),
// )))),
// ),
// ),
// ),
// Container(
// child: SingleChildScrollView(
// child: Column(
// children: [
// Padding(
// padding: EdgeInsets.only(top: 10, right: 10, bottom: 10, left: 10),
// child: TextField(
// autofocus: true,
// // controller: controller.chatSearchTEC,
// // focusNode: controller.chatSearchTextFocus,
// onChanged: (value) async {
// controller.modelSuggestList = await controller.SuggestedPost(list_Id: data.id.toString(),name:value);
// },
// textAlignVertical: TextAlignVertical.center,
// decoration: InputDecoration(
// hintText: Strings.searchPeople,
// hintStyle: TextStyle(fontSize: 16),
// prefixIcon: Icon(Icons.search, size: 16),
// border: OutlineInputBorder(
// borderRadius: BorderRadius.circular(40),
// borderSide: BorderSide(
// width: 2,
// style: BorderStyle.none,
// ),
// ),
// enabledBorder: OutlineInputBorder(
// borderRadius: BorderRadius.circular(40),
// borderSide: BorderSide(
// width: 2,
// style: BorderStyle.none,
// ),
// ),
// fillColor: Colors.grey[250],
// ),
// ),
// ),
//
// SizedBox(
// height: Get.width*0.25,
// child: controller.modelSuggestList.isEmpty || controller.modelSuggestList == null?Center(child: Padding(
// padding: const EdgeInsets.only(top:20.0),
// child: Text("No results"),
// ),) :SingleChildScrollView(child:Column(
// children: List.generate(
// controller.modelSuggestList.length,
// (index) => ListTile(
// leading: Container(
// height: 40,
// width: 40,
// decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(10), image: DecorationImage(image: NetworkImage(
// controller.modelSuggestList[index].authorProfileImage==null?
// "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
//     : controller.modelSuggestList[index].authorProfileImage
// ), fit: BoxFit.fill)),
// ),
// title: Text(controller.modelSuggestList[index].username),
// subtitle: Row(
// children: [
// Text(controller.modelSuggestList[index].authorName),
// SizedBox(
// width: 4,
// ),
// Text(controller.modelSuggestList[index].username),
// ],
// ),
// trailing:
// ElevatedButton(
// style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), primary: controller.modelSuggestList[index].isFollow ? Colors.blueAccent : Color(0xFFedab30)),
// onPressed: controller.modelSuggestList[index].isFollow == false
// ? () async{
//
//
// controller.modelSuggestList[index].isFollow = true;
// controller.addMemberList.add(controller.modelSuggestList[index]);
//
// controller.update(["edit_suggestion"]);
// controller.update();
// print("list  fllow suggestion id check ${controller.modelSuggestList[index].id}");
// print("list  fllow data id check ${data.id}");
// controller.memberAdd(data.id.toString(), controller.modelSuggestList[index].id,"member");
//
//
//
// }
//     : () {
//
// controller.modelSuggestList[index].isFollow == false;
//
// controller.modelSuggestList.forEach((element) {
// if(element.id == controller.modelSuggestList[index].id ){
// element.isFollow = false;
// }
// });
// for(int i=0; i< controller.addMemberList.length; i++  ){
// if(controller.addMemberList[i].id == controller.modelSuggestList[index].id){
// controller.addMemberList.removeAt(i);
// }
// }
// controller.update(["edit_suggestion"]);
// controller.update();
//
// controller.deletePost(controller.modelSuggestList[index].id);
// // dataList.remove(
// //     controller.  listOfDiscover[index]);
//
//
// controller.update(["edit_suggestion"]);
// controller.update();
// print("list  unfllow suggestion id check ${controller.modelSuggestList[index].id}");
// print("list  unfllow data id check ${data.id}");
// controller.unFollowRemoveMethod( list_Id:data.id.toString(), member_id:controller.modelSuggestList[index].id.toString(),type:"member");
// },
// child: controller.modelSuggestList[index].isFollow == false
// ? Text(
// "Add",
// style: Theme.of(context).textTheme.headline6.copyWith(
// fontSize: 14,
// fontWeight: FontWeight.w700,
// color: Colors.white,
// ),
// )
//     : Text(
// "Remove",
// style: Theme.of(context).textTheme.headline6.copyWith(
// fontSize: 14,
// fontWeight: FontWeight.w700,
// color: Colors.white,
// ),
// )))),
// )),
// ),
// ],
// ),
// ),
// ),
// ]))
// ])),
// ]),
// ),
// ),
// ],
// ),
// ),
// )),
// ),
// );
// },
// child: Text(
// 'Next'),
// )
// ),
// SizedBox(
// height: Get.height * 0.60,
//
// child: SingleChildScrollView(
// child: Column(
// children: [
// Padding(
// padding:
// const EdgeInsets
//     .only(
// left: 2,
// right:
// 2),
// child:
// Container(
// width: Get
//     .width,
// height: Get
//     .height *
// 0.25,
// decoration: BoxDecoration(
// color: Colors
//     .grey[500]),
// child:
//
// imageAvailable ==
// false ?
// Center(
// child:
// CircleAvatar(radius: 30,
// backgroundColor:
// Colors
//     .black54,
// child:
// IconButton(
// onPressed: () async {
// final image = await ImagePickerWeb
//     .getImageAsBytes();
// setState;
// setState(() {
// imageAvailable = true;imageFile = image;
// });
//
//
// print(
// "image agiye hai");
// print(
// "controller.imageSelected ${image}");
//
//
// },
// icon:
// Icon(
// Icons
//     .camera_alt,
// color: Colors
//     .white,
// ),
// splashColor:
// Colors
//     .black,
// ),
//
// )
//
//
// )
//     : Stack(
// children: [
//
//
// Container(height:Get.height,width:Get.width,
//
//
// child:  Image.memory(imageFile,fit: BoxFit.fill,),
//
//
//
//
// ),
// Positioned(
// top: 0,
// right: 0,
// child: Padding(
// padding:  EdgeInsets.all(8.0),
// child: Row(
// children: [
// Card(
// color: Colors.black26,
// shape: RoundedRectangleBorder(
// borderRadius: BorderRadius.circular(80),
// ),
// child: Center(child: IconButton(onPressed: () async {
// final image = await ImagePickerWeb
//     .getImageAsBytes();
// setState;
// setState(() {
// imageAvailable = true;imageFile = image;
// });
//
//
//
//
//
// }, icon: Icon(Icons.camera_alt,color: Colors.white,size: 25,)))
// ),
// SizedBox(width: 10,),
// Card(
// color: Colors.black26,
// shape: RoundedRectangleBorder(
// borderRadius: BorderRadius.circular(80),
// ),
// child: Center(child: IconButton(onPressed: ()  {
//
//
// setState;
// setState(() {
// imageAvailable = false;imageFile = null;
// });
//
//
//
//
//
// }, icon: Icon(Icons.close,color: Colors.white,size: 25,)))
// ),
// ],
// )
// ),),
// ] ),
// )
//
// ),
//
// SizedBox(
// height: 20,
// ),
// CustomFormField(
// label: "Name",
// controller:
// controller
//     .userNameController,
// onChange:
// (value) {
// controller
//     .userNameController
//     .text =
// value;
// controller
//     .update();
// },
// ),
// SizedBox(
// height: 20,
// ),
// Padding(
// padding:
// const EdgeInsets
//     .only(
// left:
// 15,
// right:
// 15),
// child: SizedBox(
// height: 130,
// child:
// TextFormField(
// controller:
// controller
//     .descriptionController,
// onChanged:
// (value) {
// // value = controller
// // .descriptionController
// // .text  ;
// controller
//     .update();
// },
// maxLines: 2,
// maxLength:
// 100,
// decoration: InputDecoration(
// border: OutlineInputBorder(
// borderRadius: BorderRadius
//     .circular(
// 10)),
// contentPadding: const EdgeInsets
//     .only(
// bottom: 30,
// top: 10,
// left: 15,
// right: 5),
// focusedBorder: const OutlineInputBorder(
// borderSide: BorderSide(
// color:
// Colors
//     .blue,
// )),
// filled: true,
// label: Text(
// "Descriptions"),
// hintStyle: const TextStyle(
// color: Colors
//     .black,
// fontWeight: FontWeight
//     .bold),
// fillColor: Colors
//     .white),
// cursorColor:
// Colors
//     .blue,
// ),
// ),
// ),
// ListTile(
// trailing:
// CheckBoxList(),
// title: Text(
// Strings
//     .private,
// style: Theme
//     .of(
// context)
//     .textTheme
//     .headline6
//     .copyWith(
// fontSize:
// 16,
// fontWeight:
// FontWeight
//     .w800,
// color: Colors
//     .black,
// ),
// ),
// subtitle: Text(
// "When you make a List private, only you can see it.",
// style: Theme
//     .of(
// context)
//     .textTheme
//     .headline6
//     .copyWith(
// fontSize:
// 16,
// fontWeight:
// FontWeight
//     .w800,
// color: Colors
//     .black26,
// ),
// ),
// ),
// ],),
// ),
// )
// ],
// ),
// );
// }),
// ),
