import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/filter_screen.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/rich_text.dart';

import '../models/translationData_model.dart';
import '../network/controller/mobile_comments_controller.dart';
import '../network/singleTone.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import 'TextToSpeech/TextToSpeechWidget.dart';
import 'comments_screen.dart';


///newFeed
class PostTextDescription extends StatefulWidget {
  PostTextDescription({
    Key key,
    @required this.post,
    this.isCommentScreen = false,
    this.controller,
    this.showMomentScreen,
    this.editMomentScreen,
    this.translationCheck,
    this.translationData,
    this.width,
    this.commentId,
    this.deletePostId
  }) : super(key: key);

  final Post post;
  final bool isCommentScreen;
  final NewsfeedController controller;
  bool showMomentScreen = false;
  bool editMomentScreen = false;
  final double width;
  TranslationData translationData;
  int commentId;
  int deletePostId;

  bool translationCheck;

  @override
  _PostTextDescriptionState createState() => _PostTextDescriptionState();
}

class _PostTextDescriptionState extends State<PostTextDescription> {
  String firstHalf = "";
  String secondHalf = "";

  List<String> str = [];

  // List<dynamic> listw = postText.
  // NewsfeedController controller = Get.find<NewsfeedController>();
  bool _readMore = false;
  bool showFull = false;
  bool containHashTag = true;
  String postText ;
  int postLanguageId;

  @override
  void initState() {
    var postData = widget.post.body;
    postText = widget.post.body;
    postLanguageId = widget.post.languageId;
    var words = postData.split(" ");
    for (String word in words) {
      // Perform your checks on the 'word' here
      if (!word.contains("#")) {
        containHashTag = false;
      }
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.post.body.length > 200 && !showFull) {
      firstHalf = "";
      firstHalf = widget.post.body.substring(0, 200) + "....";
      secondHalf = widget.post.body.substring(200, widget.post.body.length);
    } else {
      firstHalf = widget.post.body;
    }

    if (widget.translationData != null &&
        widget.translationCheck == true &&
        widget.translationData.data[0].body.length > 200) {
      firstHalf = "";
      // print("iiiiii");
      if(!showFull){
        firstHalf =
            widget.translationData.data[0].body.substring(0, 200) + "....";
      } else {
        firstHalf = widget.translationData.data[0].body;
      }

      secondHalf = widget.translationData.data[0].body
          .substring(200, widget.translationData.data[0].body.length);
    }
    // else {
    //   firstHalf = widget.post.body;
    // }

    //
    // print("translationCheck  ${firstHalf.length}");
    // print("body  ${firstHalf}");
    // print("translationCheck  ${widget.controller.translationData}");

    if(widget.post.translation.value == true){
      postText = widget.post.translationData.data[0].body;
      postLanguageId = widget.controller.languageData.myLang.id;

    }else{
      postText = widget.post.body;
      postLanguageId = widget.post.languageId;
    }

    return widget.controller.languageData == null
        ? SizedBox()
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                kIsWeb || widget.isCommentScreen
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichTextView(
                            context,
                            widget.translationData == null ? widget.post.body.length > 200 ? firstHalf : widget.post.body : widget.translationCheck == true ? widget.translationData.data[0].body.length > 200 ? firstHalf : widget.translationData.data[0].body : widget.post.body.length > 200 ? firstHalf : widget.post.body,
                            _readMore,
                            widget.controller,
                            widget.post.authorId,
                            Get.isDarkMode? Colors.white
                                : Colors.black,
                            widget.post,
                            position: widget.translationCheck == false ||
                                    widget.translationCheck == null
                                ? widget.post.languageDirection == "ltr"
                                    ? "ltr"
                                    : "rtl"
                                : widget.translationData != null
                                    ? widget.translationData.data[0]
                                        .languageDirection
                                    : "ltr",
                            width: kIsWeb ? widget.width - 20 : widget.width,
                          ),

                          widget.post.location != null
                              ? Text(
                                  "from ${widget.post.location}",
                                  // style: TextStyle(
                                  //   color: Colors.grey.shade400
                                  // ),
                                  style: Get.isDarkMode
                                      ? TextStyle(
                                          color: Colors.white,
                                        )
                                      : TextStyle(color: Colors.grey.shade400),
                                )
                              : const SizedBox(),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              widget.post.body.length > 200 ? Align(
                                alignment: Alignment.bottomLeft,
                                child: InkWell(
                                  onTap: kIsWeb
                                      ? () async {
                                    setState(() {
                                      showFull = !showFull;
                                    });

                                    /*
                                            SingleTone.instance.commentId = widget.commentId;
                                            if (widget.commentId == 1) {
                                              MobileCommentsController mobileController;
                                              if (Get.isRegistered<MobileCommentsController>()) {
                                                mobileController = await Get.find<MobileCommentsController>();
                                                widget.controller.selectedPost2 = await mobileController.getSingleNewsFeedItem(widget.post.postId, isReload: true);
                                                widget.controller.getCommentsList = await mobileController.getCommentsPostLists(postId: widget.post.postId);
                                              } else {
                                                mobileController = await Get.put(MobileCommentsController());
                                              }
                                            }

                                            widget.controller.post = widget.post;
                                            widget.controller.postId = widget.post.postId;
                                            SingleTone.instance.post_Id = widget.post.postId;
                                            widget.controller.navRoute = "isPostDetail";
                                            widget.controller.detailPageCounter++;
                                            // print("postcard");

                                            if (widget.controller.navRoute == "isPostDetail")
                                            {
                                              Get.toNamed(FluroRouters.mainScreen + "/postDetail/" + widget.post.postId
                                                          .toString());
                                            } else {
                                              Get.toNamed(FluroRouters.mainScreen + "/postDetail/" + widget.post.postId.toString());
                                            }
                                            // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.postId.toString());

                                            // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.postId.toString()));

                                            // print(
                                            //     'post id:${widget.controller.postId}');
                                            // print(
                                            //     'singtone post id:${SingleTone.instance.post_Id}');



                                            widget.controller.selectedPost2 = await widget.controller.getSingleNewsFeedItem(widget.post.postId, isReload: true).whenComplete(()  async {



                                              // if(widget.translationCheck==true)
                                              //   {
                                              //     widget.controller.isShowMoreCheck = true;
                                              //     widget.controller.update();
                                              //     var value  = await  widget.controller.newsFeedTranslation( widget.post.postId, widget.controller.languageData.myLang.code);
                                              //
                                              //     widget.controller.selectedPost2[0].translationData=value;
                                              //
                                              //
                                              //     widget. controller.selectedPost2[0].translation.value = true;
                                              //     print("post.translationData ${ widget.controller.selectedPost2[0].translationData.data[0].body}");
                                              //     widget.  controller.update(
                                              //         ['translate']);
                                              //
                                              //     widget.controller.isShowMoreCheck = false;
                                              //     widget.controller.update();
                                              //
                                              //
                                              //   }


                                            });

                                            if(widget.translationCheck==true &&  widget.controller.selectedPost2.isNotEmpty )
                                            {
                                              widget.controller.isShowMoreCheck = true;
                                              widget.controller.update();
                                              // var value  = await  widget.controller.newsFeedTranslation( widget.post.postId, widget.controller.languageData.myLang.code);



                                              // print("post.translationData......... ${widget.controller.selectedPost2.length}");
                                              // print("post.translationData......... ${widget.post.translationData.data[0].body}");


                                              widget.controller.selectedPost2[0].translationData = widget.post.translationData;


                                              widget. controller.selectedPost2[0].translation.value = true;
                                              // print("post.translationData ${ widget.controller.selectedPost2[0].translationData.data[0].body}");
                                              widget.  controller.update(
                                                  ['translate']);

                                              widget.controller.isShowMoreCheck = false;
                                              widget.controller.update();


                                            }

                                            */

                                    // widget.controller.update();
                                    // Get.toNamed(FluroRouters.werfDetailScreen+"/${post.postId}");
                                  }
                                      : () async {
                                    setState(() {
                                      showFull = true;
                                    });

                                    debugPrint("Show More clicked");
                                    /*
                                            if (widget.commentId == 1) {
                                              if (Get.isRegistered<
                                                  MobileCommentsController>()) {
                                                Get.delete<
                                                    MobileCommentsController>();
                                              }

                                              Route route = MaterialPageRoute(
                                                  builder: (context) =>
                                                      CommentsScreen(
                                                        postId:
                                                            widget.post.postId,
                                                        thread_no: null,
                                                      ));
                                              Navigator.pushReplacement(
                                                  context, route);
                                            }
                                            else {
                                              widget.controller.selectedPost =
                                                  widget.post;
                                              widget
                                                  .controller.commentController
                                                  .clear();
                                              widget.controller.selectedPost =
                                                  widget.post;
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (BuildContext
                                                              context) =>
                                                          CommentsScreen(
                                                            postId: widget
                                                                .post.postId,
                                                            thread_no: null,
                                                          )));
                                              widget.controller.postId =
                                                  widget.post.postId;

                                              //    controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
                                              // controller.isPostDetails = true;
                                              // controller.postDetail =
                                              //     await controller.getSingleNewsFeedItem(post.postId);
                                            }
                                            */
                                  },

                                  // _readMore = !_readMore;
                                  // setState(() {});

                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Visibility(
                                      visible: widget.post.body.length > 200 && !showFull ? true :  widget.post.body.length > 200  ? true : false,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Icon(showFull ?Icons.expand_less_rounded : Icons.expand_more_rounded,color: MyColors.werfieBlue,),
                                          Text(
                                            widget.post.body.length > 200 && !showFull ? Strings.showMore :  widget.post.body.length > 200  ? Strings.showLess : "",
                                            style: Get.isDarkMode
                                                ? TextStyle(
                                                color: widget
                                                    .controller.displayColor,
                                                fontSize: 12,
                                                fontWeight: FontWeight.normal)
                                                : TextStyle(
                                                fontSize: 12,
                                                color: widget
                                                    .controller.displayColor,
                                                fontWeight: FontWeight.normal),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ): const SizedBox(),
                              kIsWeb ? widget.post.body.length > 0 ?
                              Obx(() {
                                return widget.post.translationLoadere
                                    .value == true ?
                                const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                    )) :
                                widget.controller.languageData != null ?
                                widget.controller.languageData.myLang
                                    .id != widget.post.languageId
                                    ? GestureDetector(
                                  onTap: () async {
                                    print(
                                        "View translated hit");
                                    widget.post.translationLoadere
                                        .value = true;
                                    bool success = false;

                                    print(
                                        "controller.languageData.myLang.id ${widget.controller
                                            .languageData.myLang
                                            .code}");
                                    widget.post.translationData =
                                    await widget.controller.newsFeedTranslation(widget.post.postId, widget.controller.languageData.myLang.code);

                                    print(
                                        "post.translationData ${widget.post
                                            .translationData
                                            .data[0].body}");

                                    if (widget.post.translationData !=
                                        null) {
                                      widget.post.translationLoadere
                                          .value =
                                      false;

                                      if (widget.post.translation
                                          .value == false) {
                                        print(
                                            "controller.translationData.data[0].body ${widget.controller
                                                .translationData
                                                .data[0]
                                                .body}");
                                        widget.post.translation.value =
                                        true;
                                        widget.controller.update(
                                            ['translate']);
                                      }
                                      else if (widget.post.translation
                                          .value == true) {
                                        widget.post.translation.value =
                                        false;
                                        widget.controller.update(
                                            ['translate']);
                                      }
                                    }
                                    else {
                                      widget.post.translationLoadere
                                          .value = false;
                                      widget.controller.update();
                                    }
                                  },

                                  child:

                                  widget.post.translation.value == true
                                      ?

                                  Padding(
                                    padding: EdgeInsets.only(
                                        bottom: 0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        SizedBox(width: 2,),
                                        Icon(Icons.language_rounded,color: MyColors.werfieBlue,size: 14,),
                                        SizedBox(width: 2,),
                                        Text(
                                            Strings.viewOriginal,

                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.normal,
                                                color: widget.controller
                                                    .displayColor

                                            )
                                        ),
                                      ],
                                    ),
                                  )
                                      : Padding(
                                    padding: EdgeInsets.only(
                                        bottom: 0, top: 0),
                                    child:containHashTag? SizedBox() : Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        SizedBox(width: 2,),
                                        Icon(Icons.language_rounded,color: MyColors.werfieBlue,size: 14,),
                                        SizedBox(width: 2,),
                                        Text(
                                            widget.controller.languageData
                                                .appLang.id == 2
                                                ? "يترجم"
                                                : Strings
                                                .viewTranslated,

                                            style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.normal,
                                                color: widget.controller
                                                    .displayColor

                                            )
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                                    : SizedBox()
                                    : SizedBox();
                              }) : SizedBox() : SizedBox(),
                              TextToSpeechWidget(text: postText,languageId: postLanguageId,key: Key(widget.post.postId.toString()),),

                            ],
                          ),


                          // : widget.post.body.length >= 10
                          //     ? Align(
                          //         alignment: Alignment.bottomLeft,
                          //         child: SizedBox(
                          //           width: 100,
                          //           child: InkWell(
                          //             onTap: () {
                          //               _readMore = !_readMore;
                          //               setState(() {});
                          //             },
                          //             child: Align(
                          //               alignment: Alignment.bottomLeft,
                          //               child:Text(
                          //
                          //                 widget.post.body.length >= 30
                          //                     ? _readMore
                          //                         ? Strings.showLess
                          //                         : Strings.showMore
                          //                     : "",
                          //                 style: Theme.of(context).brightness == Brightness.dark ?
                          //                 TextStyle(color: Colors.white,fontSize: 12,fontWeight: FontWeight.bold
                          //                 )
                          //                     : TextStyle(fontSize: 12,color: Colors.black,
                          //                     fontWeight: FontWeight.bold
                          //                 ),
                          //               ),
                          //             ),
                          //           ),
                          //         ),
                          //       )
                          //     : SizedBox(),
                        ],
                      )
                    : Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ///ASAD
                            RichTextView(
                              context,
                              widget.translationData == null
                                  ? widget.post.body.length > 200
                                      ? firstHalf
                                      : widget.post.body
                                  : widget.translationCheck == true
                                      ? widget.translationData.data[0].body
                                                  .length >
                                              200
                                          ? firstHalf
                                          : widget.translationData.data[0].body
                                      : widget.post.body.length > 200
                                          ? firstHalf
                                          : widget.post.body,
                              _readMore,
                              widget.controller,
                              widget.post.authorId,
                              Get.isDarkMode
                                  ? Colors.white
                                  : Colors.black,
                              widget.post,
                              position: widget.translationCheck == false ||
                                      widget.translationCheck == null
                                  ? widget.post.languageDirection == "ltr"
                                      ? "ltr"
                                      : "rtl"
                                  : widget.translationData != null
                                      ? widget.translationData.data[0]
                                          .languageDirection
                                      : "ltr",
                              width: widget.width,
                            ),
                            widget.post.location != null
                                ? Text(
                                    "from ${widget.post.location}",
                                    // style: TextStyle(
                                    //     color: Colors.grey.shade400
                                    // ),
                                    style: Get.isDarkMode
                                        ? TextStyle(
                                            color: Colors.white,
                                            fontSize: 12,
                                          )
                                        : TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey.shade400,
                                          ),
                                  )
                                : const SizedBox(),

                            Row(
                              children: [
                                Visibility(
                                  visible:widget.post.body.length > 200,
                                  child: Align(
                                     alignment: Alignment.bottomLeft,
                                     child: InkWell(
                                       onTap: kIsWeb
                                           ? () async {
                                         setState(() {
                                           if(showFull){
                                             showFull = false;
                                           }else {
                                             showFull = true;
                                           }
                                         });
                                         /*
                                               SingleTone.instance.commentId =
                                                   widget.commentId;
                                               if (widget.commentId == 1) {
                                                 MobileCommentsController
                                                     mobileController;
                                                 if (Get.isRegistered<
                                                     MobileCommentsController>()) {
                                                   mobileController = await Get.find<
                                                       MobileCommentsController>();
                                                   widget.controller
                                                           .selectedPost2 =
                                                       await mobileController
                                                           .getSingleNewsFeedItem(
                                                               widget
                                                                   .post.postId,
                                                               isReload: true);
                                                   widget.controller
                                                           .getCommentsList =
                                                       await mobileController
                                                           .getCommentsPostLists(
                                                               postId: widget
                                                                   .post.postId);
                                                 } else {
                                                   mobileController = await Get.put(
                                                       MobileCommentsController());
                                                 }
                                               }

                                               widget.controller.postId =
                                                   widget.post.postId;
                                               SingleTone.instance.post_Id =
                                                   widget.post.postId;
                                               // controller.threadNumber = null;
                                               // controller.selectedPost = post;
                                               widget.controller.navRoute =
                                                   "isPostDetail";
                                               widget.controller
                                                   .detailPageCounter++;
                                               // print("postcard");

                                               if (widget.controller.navRoute ==
                                                   "isPostDetail") {
                                                 Get.toNamed(
                                                     FluroRouters.mainScreen +
                                                         "/postDetail/" +
                                                         widget.post.postId
                                                             .toString());
                                               } else {
                                                 Get.toNamed(
                                                     FluroRouters.mainScreen +
                                                         "/postDetail/" +
                                                         widget.post.postId
                                                             .toString());
                                               }
                                               // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.postId.toString());

                                               // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.postId.toString()));

                                               // print(
                                               //     'post id:${widget.controller.postId}');
                                               // print(
                                               //     'singtone post id:${SingleTone.instance.post_Id}');
                                               widget.controller.selectedPost2 = await widget.controller.getSingleNewsFeedItem(widget.post.postId, isReload: true);
                                               widget.controller.update();
                                               // Get.toNamed(FluroRouters.werfDetailScreen+"/${post.postId}");
                                         */
                                             }
                                           : () async {
                                         setState(() {
                                           if(showFull){
                                             showFull = false;
                                           }else {
                                             showFull = true;
                                           }
                                         });

                                         debugPrint("Show More clicked");
                                         /*
                                               if (widget.commentId == 1) {
                                                 if (Get.isRegistered<
                                                     MobileCommentsController>()) {
                                                   Get.delete<
                                                       MobileCommentsController>();
                                                 }

                                                 widget.controller.post = widget.post;
                                                 widget.controller.post.translation.value = widget.translationCheck;


                                                 widget.controller.update();

                                                 Route route = MaterialPageRoute(
                                                     builder: (context) =>
                                                         CommentsScreen(
                                                           postId: widget
                                                               .post.postId,
                                                           thread_no: null,
                                                         ));
                                                 Navigator.pushReplacement(
                                                     context, route);



                                                 //
                                                 // if(widget.translationCheck==true)
                                                 // {
                                                 //   widget.controller.isShowMoreCheck = true;
                                                 //   widget.controller.update();
                                                 //   var value  = await  widget.controller.newsFeedTranslation( widget.post.postId, widget.controller.languageData.myLang.code);
                                                 //
                                                 //   widget.controller.selectedPost2[0].translationData=value;
                                                 //
                                                 //
                                                 //   widget. controller.selectedPost2[0].translation.value = true;
                                                 //   print("post.translationData ${ widget.controller.selectedPost2[0].translationData.data[0].body}");
                                                 //   widget.  controller.update(
                                                 //       ['translate']);
                                                 //
                                                 //   widget.controller.isShowMoreCheck = false;
                                                 //   widget.controller.update();
                                                 //
                                                 //
                                                 // }







                                               } else {
                                                 widget.controller.selectedPost =
                                                     widget.post;
                                                 widget.controller
                                                     .commentController
                                                     .clear();
                                                 widget.controller.selectedPost =
                                                     widget.post;


                                                 widget.controller.post = widget.post;
                                                 widget.controller.post.translation.value = widget.translationCheck;
                                                 // print("widget.controller.post.translation.value ${widget.controller.post.translation.value}");
                                                 Navigator.push(
                                                     context,
                                                     MaterialPageRoute(
                                                         builder: (BuildContext
                                                                 context) =>
                                                             CommentsScreen(
                                                               postId: widget
                                                                   .post.postId,
                                                               thread_no: null,
                                                             )));
                                                 widget.controller.postId =
                                                     widget.post.postId;

                                                 //    controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
                                                 // controller.isPostDetails = true;
                                                 // controller.postDetail =
                                                 //     await controller.getSingleNewsFeedItem(post.postId);
                                               }
                                               */
                                             },

                                       // _readMore = !_readMore;
                                       // setState(() {});

                                       child: Align(
                                         alignment: Alignment.bottomLeft,
                                         child: Row(
                                           children: [
                                             Icon(showFull ?Icons.expand_less_rounded : Icons.expand_more_rounded,color: MyColors.werfieBlue,),
                                             Text(
                                               showFull ? Strings.showLess+"  ":  Strings.showMore + "  ",
                                               style: Get.isDarkMode
                                                   ? TextStyle(
                                                       color: widget
                                                           .controller.displayColor,
                                                       fontSize: 12,
                                                       fontWeight: FontWeight.normal)
                                                   : TextStyle(
                                                       fontSize: 12,
                                                       color: widget
                                                           .controller.displayColor,
                                                       fontWeight: FontWeight.normal),
                                             ),
                                           ],
                                         ),
                                       ),
                                     ),
                                   ),
                                ),

                                    !kIsWeb ? widget.post.body.length > 0 ?
                                    widget.post.translationLoader == true ?
                                    const Padding(
                                      padding: EdgeInsets.symmetric(vertical: 10.0),
                                      child: SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                        ),
                                      ),
                                    ) :
                                    widget.controller.languageData != null ?
                                    widget.controller.languageData.myLang
                                        .id != widget.post.languageId ?
                                    Obx(() {
                                      var post = widget.post;
                                      var controller = widget.controller;
                                      return GestureDetector(
                                        onTap: () async {
                                 post.translationLoader = true;
                                 controller.updateControllers(widget.deletePostId);

                                 bool success = false;

                                 post.translationData =
                                 await controller.newsFeedTranslation(
                                     post.postId,
                                     controller.languageData
                                         .myLang.code);

                                 if (post.translationData != null) {
                                   post.translationLoader = false;
                                   controller.updateControllers(widget.deletePostId);

                                   if (post.translation
                                       .value == false) {
                                     print(
                                         "controller.translationData.data[0].body ${controller
                                             .translationData
                                             .data[0].body}");
                                     post.translation.value =
                                     true;
                                     controller.update(['translate']);
                                   }
                                   else if (post.translation.value == true) {
                                     post.translation.value =
                                     false;
                                     controller.update(['translate']);
                                   }
                                 }
                                 else {
                                   post.translationLoader = false;
                                   controller.updateControllers(widget.deletePostId);
                                   controller.update();
                                 }
                                        },

                                        child:

                                        post.translation.value == true ?
                                        Padding(
                                 padding: EdgeInsets.only(bottom: 0),
                                 child: Row(
                                   mainAxisAlignment: MainAxisAlignment.center,
                                   crossAxisAlignment: CrossAxisAlignment.center,
                                   children: [
                                     Icon(Icons.language_rounded,color: MyColors.werfieBlue,size: 14,),
                                     SizedBox(width: 2,),
                                     Text(
                                         Strings.viewOriginal,

                                         style: TextStyle(
                                             color: controller
                                                 .displayColor,
                                             fontSize: 12,
                                             fontWeight: FontWeight.normal

                                         )
                                     ),
                                   ],
                                 ),
                                        ) : Padding(
                                 padding: const EdgeInsets.only(bottom: 0, top: 0),
                                 child:containHashTag ? SizedBox() :  Row(
                                   mainAxisAlignment: MainAxisAlignment.center,
                                   crossAxisAlignment: CrossAxisAlignment.center,
                                   children: [
                                     Icon(Icons.language_rounded,color: MyColors.werfieBlue,size: 14,),
                                     SizedBox(width: 2,),
                                     Text(
                                         controller.languageData.appLang.id == 2
                                             ? "يترجم"
                                             : Strings.viewTranslated,
                                         style: TextStyle(
                                             color: controller
                                                 .displayColor,
                                             fontSize: 12,
                                             fontWeight: FontWeight.normal

                                         )
                                     ),
                                   ],
                                 ),
                                        ),
                                      );
                                    }) : SizedBox() : SizedBox()
                                        : SizedBox() : SizedBox(),
                                    TextToSpeechWidget(text: postText,languageId: postLanguageId,),
                              ],
                            ),



                            //             LayoutBuilder(
                            //   builder: (BuildContext context, BoxConstraints constraints) {
                            //     assert(constraints.hasBoundedWidth);
                            //     final double maxWidth = constraints.maxWidth;
                            //     // Create a TextSpan with data
                            //     final text = Text(
                            //        widget.post.body,
                            //       maxLines: 5,
                            //     );
                            //     // Layout and measure link
                            //     TextPainter textPainter = TextPainter(
                            //       text: link,
                            //       textDirection: TextDirection.rtl,
                            //       //better to pass this from master widget if ltr and rtl both supported
                            //        maxLines: 5,
                            //       ellipsis: '...',
                            //     );
                            //     textPainter.layout(minWidth: constraints.minWidth, maxWidth: maxWidth);
                            //     final linkSize = textPainter.size;
                            //     // Layout and measure text
                            //     textPainter.text = text as InlineSpan;
                            //     textPainter.layout(minWidth: constraints.minWidth, maxWidth: maxWidth);
                            //     final textSize = textPainter.size;
                            //     // Get the endIndex of data
                            //     int endIndex;
                            //     final pos = textPainter.getPositionForOffset(Offset(
                            //       textSize.width - linkSize.width,
                            //       textSize.height,
                            //     ));
                            //     endIndex = textPainter.getOffsetBefore(pos.offset);
                            //     var textSpan;
                            //
                            //
                            //     print("textPainter.maxLines ${textPainter.maxLines}");
                            //     if (textPainter.didExceedMaxLines) {
                            //       return
                            //         Align(
                            //
                            //           alignment: Alignment.bottomLeft,
                            //           child: InkWell(
                            //             onTap:
                            //
                            //             kIsWeb
                            //                 ? () async {
                            //               SingleTone.instance.commentId = widget.commentId;
                            //               if (widget.commentId == 1) {
                            //                 MobileCommentsController mobileController;
                            //                 if (Get.isRegistered<
                            //                     MobileCommentsController>()) {
                            //                   mobileController =
                            //                   await Get.find<MobileCommentsController>();
                            //                   widget.controller.selectedPost2 =
                            //                   await mobileController.getSingleNewsFeedItem(
                            //                       widget.post.postId, isReload: true);
                            //                   widget.controller.getCommentsList =
                            //                   await mobileController.getCommentsPostLists(
                            //                       postId: widget.post.postId);
                            //                 } else {
                            //                   mobileController =
                            //                   await Get.put(MobileCommentsController());
                            //                 }
                            //               }
                            //
                            //               widget.controller.postId = widget.post.postId;
                            //               SingleTone.instance.post_Id = widget.post.postId;
                            //               // controller.threadNumber = null;
                            //               // controller.selectedPost = post;
                            //               widget.controller.navRoute = "isPostDetail";
                            //               widget.controller.detailPageCounter++;
                            //               print("postcard");
                            //
                            //
                            //               if (widget.controller.navRoute == "isPostDetail") {
                            //                 Get.toNamed(
                            //                     FluroRouters.mainScreen + "/postDetail/" +
                            //                         widget.post.postId.toString());
                            //               } else {
                            //                 Get.toNamed(
                            //                     FluroRouters.mainScreen + "/postDetail/" +
                            //                         widget.post.postId.toString());
                            //               }
                            //               // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.postId.toString());
                            //
                            //               // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.postId.toString()));
                            //
                            //
                            //               print('post id:${widget.controller.postId}');
                            //               print('singtone post id:${SingleTone.instance
                            //                   .post_Id}');
                            //               widget.controller.selectedPost2 =
                            //               await widget.controller.getSingleNewsFeedItem(
                            //                   widget.post.postId, isReload: true);
                            //               widget.controller.update();
                            //               // Get.toNamed(FluroRouters.werfDetailScreen+"/${post.postId}");
                            //
                            //
                            //             }
                            //                 : () async {
                            //               if (widget.commentId == 1) {
                            //                 if (Get.isRegistered<
                            //                     MobileCommentsController>()) {
                            //                   Get.delete<
                            //                       MobileCommentsController>();
                            //                 }
                            //
                            //                 Route route = MaterialPageRoute(
                            //                     builder: (context) =>
                            //                         CommentsScreen(
                            //                           postId: widget.post.postId,
                            //                           thread_no: null,));
                            //                 Navigator.pushReplacement(context, route);
                            //               }
                            //               else {
                            //                 widget.controller.selectedPost = widget.post;
                            //                 widget.controller.commentController.clear();
                            //                 widget.controller.selectedPost = widget.post;
                            //                 Navigator.push(context, MaterialPageRoute(
                            //                     builder: (BuildContext context) =>
                            //                         CommentsScreen(
                            //                           postId: widget.post.postId,
                            //                           thread_no: null,)));
                            //                 widget.controller.postId = widget.post.postId;
                            //
                            //                 //    controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
                            //                 // controller.isPostDetails = true;
                            //                 // controller.postDetail =
                            //                 //     await controller.getSingleNewsFeedItem(post.postId);
                            //               }
                            //             },
                            //
                            //             // _readMore = !_readMore;
                            //             // setState(() {});
                            //
                            //             child: Align(
                            //               alignment: Alignment.bottomLeft,
                            //               child: Text(
                            //                 Strings.showMore,
                            //                 style: Theme
                            //                     .of(context)
                            //                     .brightness == Brightness.dark ?
                            //                 TextStyle(color: widget.controller.werfieBlue,
                            //                     fontSize: 12,
                            //                     fontWeight: FontWeight.bold
                            //                 )
                            //                     : TextStyle(fontSize: 13,
                            //                     color: widget.controller.werfieBlue,
                            //                     fontWeight: FontWeight.bold
                            //                 ),
                            //               ),
                            //             ),
                            //           ),
                            //         );
                            //     }
                            //     else {
                            //       return
                            //         SizedBox();
                            //     }
                            //   }
                            // )

                            // LayoutBuilder(builder: (context, constraints){
                            //
                            //
                            //   final span = TextSpan(text:widget.post.body,style: Styles.baseTextTheme.headline2.copyWith(
                            //   fontSize: 15,
                            //     height: 1.3,
                            //     fontWeight: FontWeight.w400,
                            //   ),);
                            //   final tp =TextPainter(text:span,maxLines: 6,textDirection: TextDirection.ltr);
                            //   tp.layout(maxWidth: widget.width);
                            //
                            //   print(  "tp.didExceedMaxLines    ${tp.didExceedMaxLines}");
                            //
                            //   TextSelection selection = TextSelection(baseOffset: 0, extentOffset: widget.post.body.length);
                            //
                            //   // List<TextBox> boxes = textPainter.getBoxesForSelection(selection);
                            //   // int numberOfLines = boxes.length;
                            //   //
                            //   // final span = TextSpan(text:widget.post.body,style: Styles.baseTextTheme.headline2.copyWith(
                            //   // fontSize: 15,
                            //   //   height: 1.3,
                            //   //   fontWeight: FontWeight.w400,
                            //   // ),);
                            //   // final tp = TextPainter(text: span, textDirection: TextDirection.ltr);
                            //   // tp.layout(maxWidth: widget.width);
                            //   // widget.post.numLines = '\n'.allMatches(widget.post.body).length + 1;
                            //   // widget.post.numLines = tp.computeLineMetrics().length;
                            //
                            //
                            //
                            //  if( tp.didExceedMaxLines ==true){
                            //
                            //
                            //    return
                            //      Align(
                            //
                            //        alignment: Alignment.bottomLeft,
                            //        child: InkWell(
                            //          onTap:
                            //
                            //          kIsWeb
                            //              ? () async {
                            //            SingleTone.instance.commentId = widget.commentId;
                            //            if (widget.commentId == 1) {
                            //              MobileCommentsController mobileController;
                            //              if (Get.isRegistered<MobileCommentsController>()) {
                            //                mobileController =
                            //                await Get.find<MobileCommentsController>();
                            //                widget.controller.selectedPost2 =
                            //                await mobileController.getSingleNewsFeedItem(
                            //                    widget. post.postId, isReload: true);
                            //                widget. controller.getCommentsList =
                            //                await mobileController.getCommentsPostLists(
                            //                    postId: widget.post.postId);
                            //              } else {
                            //                mobileController =
                            //                await Get.put(MobileCommentsController());
                            //              }
                            //            }
                            //
                            //            widget.controller.postId =widget. post.postId;
                            //            SingleTone.instance.post_Id =widget. post.postId;
                            //            // controller.threadNumber = null;
                            //            // controller.selectedPost = post;
                            //            widget. controller.navRoute = "isPostDetail";
                            //            widget. controller.detailPageCounter++;
                            //            print("postcard");
                            //
                            //
                            //
                            //            if (widget.controller.navRoute == "isPostDetail") {
                            //              Get.toNamed(FluroRouters.mainScreen + "/postDetail/" +
                            //                  widget. post.postId.toString());
                            //            } else {
                            //              Get.toNamed(FluroRouters.mainScreen + "/postDetail/" +
                            //                  widget. post.postId.toString());
                            //            }
                            //            // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.postId.toString());
                            //
                            //            // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.postId.toString()));
                            //
                            //
                            //            print('post id:${widget.controller.postId}');
                            //            print('singtone post id:${SingleTone.instance.post_Id}');
                            //            widget.controller.selectedPost2 = await  widget.controller.getSingleNewsFeedItem(widget.post.postId, isReload: true);
                            //            widget. controller.update();
                            //            // Get.toNamed(FluroRouters.werfDetailScreen+"/${post.postId}");
                            //
                            //
                            //          }
                            //              : () async {
                            //            if (widget.commentId == 1) {
                            //              if (Get.isRegistered<
                            //                  MobileCommentsController>()) {
                            //                Get.delete<
                            //                    MobileCommentsController>();
                            //              }
                            //
                            //              Route route = MaterialPageRoute(builder: (context) =>
                            //                  CommentsScreen(
                            //                    postId:widget. post.postId, thread_no: null,));
                            //              Navigator.pushReplacement(context, route);
                            //            }
                            //            else {
                            //              widget.   controller.selectedPost = widget.post;
                            //              widget. controller.commentController.clear();
                            //              widget. controller.selectedPost =widget. post;
                            //              Navigator.push(context, MaterialPageRoute(
                            //                  builder: (BuildContext context) =>
                            //                      CommentsScreen(
                            //                        postId:widget. post.postId, thread_no: null,)));
                            //              widget.  controller.postId = widget.post.postId;
                            //
                            //              //    controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
                            //              // controller.isPostDetails = true;
                            //              // controller.postDetail =
                            //              //     await controller.getSingleNewsFeedItem(post.postId);
                            //            }
                            //          },
                            //
                            //          // _readMore = !_readMore;
                            //          // setState(() {});
                            //
                            //          child: Align(
                            //            alignment: Alignment.bottomLeft,
                            //            child: Text(
                            //              Strings.showMore,
                            //              style: Theme.of(context).brightness == Brightness.dark ?
                            //              TextStyle(color: widget.controller.werfieBlue,fontSize: 12,fontWeight: FontWeight.bold
                            //              )
                            //                  : TextStyle(fontSize: 13,color:widget.controller.werfieBlue,
                            //                  fontWeight: FontWeight.bold
                            //              ),
                            //            ),
                            //          ),
                            //        ),
                            //      );
                            //  }
                            //  else{
                            //
                            //    return
                            //    SizedBox();
                            //  }
                            //
                            //  }
                            // ),

                            //    : SizedBox(),

                            // if(widget.post.authorId == s)

                            // kIsWeb
                            //     ? widget.post.body.length >= 100
                            //         ? Align(
                            //             alignment: Alignment.bottomLeft,
                            //             child: SizedBox(
                            //               width: widget.showMomentScreen==true || widget.editMomentScreen==true?20: 100,
                            //               child: InkWell(
                            //                 onTap: () {
                            //                   _readMore = !_readMore;
                            //                   setState(() {});
                            //                 },
                            //                 child: Align(
                            //                   alignment: Alignment.bottomLeft,
                            //                   child:
                            //                   widget.post.type=='thread'?
                            //                       Text(widget.post.body,
                            //                         // style: TextStyle(
                            //                         //     fontSize: 12,
                            //                         //     fontWeight: FontWeight.bold),
                            //                         style: Theme.of(context).brightness == Brightness.dark ?
                            //                         TextStyle(color: Colors.white,fontSize: 12, fontWeight: FontWeight.bold
                            //                         )
                            //                             : TextStyle(fontSize: 12,color: Colors.black,
                            //                             fontWeight: FontWeight.bold
                            //                         ),
                            //                       )
                            //                  : Text(
                            //                     widget.post.body.length >= 30
                            //                         ? _readMore
                            //                             ? Strings.showLess
                            //                             : Strings.showMore
                            //                         : "",
                            //                     style: Theme.of(context).brightness == Brightness.dark ?
                            //                     TextStyle(color: Colors.white,fontSize: 12, fontWeight: FontWeight.bold
                            //                     )
                            //                         : TextStyle(fontSize: 12,color: Colors.black,
                            //                         fontWeight: FontWeight.bold
                            //                     ),
                            //                   ),
                            //                 ),
                            //               ),
                            //             ),
                            //           )
                            //         : SizedBox()
                            //     : widget.post.body.length >= 10
                            //         ? Align(
                            //             alignment: Alignment.bottomLeft,
                            //             child: SizedBox(
                            //               width: 100,
                            //               child: InkWell(
                            //                 onTap: () {
                            //                   _readMore = !_readMore;
                            //                   setState(() {});
                            //                 },
                            //                 child: Align(
                            //                   alignment: Alignment.bottomLeft,
                            //                   child: widget.post.body.length >= 30
                            //                       ? Text(
                            //                           _readMore
                            //                               ? Strings.showLess
                            //                               : Strings.showMore,
                            //                     style: Theme.of(context).brightness == Brightness.dark ?
                            //                     TextStyle(color: Colors.white,fontSize: 12, fontWeight: FontWeight.bold
                            //                     )
                            //                         : TextStyle(fontSize: 12,color: Colors.black,
                            //                         fontWeight: FontWeight.bold
                            //                     ),
                            //                         )
                            //                       : SizedBox(),
                            //                 ),
                            //               ),
                            //             ),
                            //           )
                            //         : SizedBox(),
                          ],
                        ),
                      ),

              ]);
  }

  List<MyText> medthodToGetString(String str) {
    // String str = 'GitHub is a development google.com inspired #by the way you work. From google.com';
    List<MyText> textSpanList = [];
    List<String> divString = str.split(' ');
    // str.runes.forEach((int rune) {
    //   divString.add(new String.fromCharCode(rune));
    //   print(divString);
    // });
    divString.forEach((element) {
      if (element.contains('#')) {
        textSpanList.add(
          MyText(
            text: element + ' ',
            // style: Theme.of(context).textTheme.bodyText1.copyWith(
            //       color: Colors.blue,
            //       fontSize: 16,
            //     ),
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: widget.controller.displayColor,
            ),

            // TextStyle(
            //   color: Colors.blue,
            //   fontSize: 16,
            // ),
            callback: (context, string) async {
              // Get.find<NewsfeedController>().isSearch = true;
              try {
                widget.controller.isProfileScreen = false;
                widget.controller.isFilterScreen = true;
                await widget.controller.onSearchTextChanged(string);
                // controller.update();

                print("payload");
                print("${widget.controller.searchResult[0].id}");
                print("${widget.controller.searchResult[0].type}");
                print("payload");
                widget.controller.searchSelected =
                    widget.controller.searchResult[0];
                await widget.controller.filterUsers(
                  id: 0.toString(),
                  type: "tag",
                  tag: string,
                );
                widget.controller.searchText.text = string;
                widget.controller.isProfileScreen = false;
                widget.controller.isSettingsScreen = false;
                widget.controller.isSavedPostScreen = false;
                widget.controller.isNewsFeedScreen = false;
                widget.controller.isOtherUserProfileScreen = false;
                widget.controller.isChatScreen = false;
                widget.controller.isChatScreenWeb = false;
                widget.controller.isBrowseScreen = false;
                widget.controller.isClickWhoToFollow = false;
                widget.controller.isFollwerScreen = false;
                widget.controller.isPostDetails = false;
                Future.delayed(Duration(seconds: 3), () {
                  kIsWeb
                      ? widget.controller.update()
                      : Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => FilteredScreen(
                                    newsfeedController:
                                        Get.find<NewsfeedController>(),
                                  )));
                });
              } catch (_) {}
            },
          ),
        );
      } else if (element.contains('\$')) {
        textSpanList.add(
          MyText(
            text: element + ' ',
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: widget.controller.displayColor,
            ),

            // TextStyle(
            //   color: Colors.blue,
            //   fontSize: 16,
            // ),
            callback: (context, string) async {
              // Get.find<NewsfeedController>().isSearch = true;
              try {
                widget.controller.isProfileScreen = false;
                widget.controller.isFilterScreen = true;
                await widget.controller.onSearchTextChanged(string);
                // controller.update();

                print("payload");
                print("${widget.controller.searchResult[0].id}");
                print("${widget.controller.searchResult[0].type}");
                print("payload");
                widget.controller.searchSelected =
                    widget.controller.searchResult[0];
                await widget.controller.filterUsers(
                  id: 0.toString(),
                  type: "cash_tag",
                  tag: string,
                );
                widget.controller.searchText.text = string;
                widget.controller.isProfileScreen = false;
                widget.controller.isSettingsScreen = false;
                widget.controller.isSavedPostScreen = false;
                widget.controller.isNewsFeedScreen = false;
                widget.controller.isOtherUserProfileScreen = false;
                widget.controller.isChatScreen = false;
                widget.controller.isChatScreenWeb = false;
                widget.controller.isBrowseScreen = false;
                widget.controller.isClickWhoToFollow = false;
                widget.controller.isFollwerScreen = false;
                widget.controller.isPostDetails = false;
                Future.delayed(Duration(seconds: 3), () {
                  kIsWeb
                      ? widget.controller.update()
                      : Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => FilteredScreen(
                                    newsfeedController:
                                        Get.find<NewsfeedController>(),
                                  )));
                });
              } catch (_) {}
            },
          ),
        );
      } else if (check(element)) {
        //    element.contains('.com') || element.contains('https') || element.contains('http');
        textSpanList.add(
          MyText(
            text: element + ' ',
            // style: Theme.of(context).textTheme.bodyText1.copyWith(
            //     color: Colors.blue,
            //     fontSize: 16,
            //     decoration: TextDecoration.underline),
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: widget.controller.displayColor,
            ),

            //  TextStyle(
            //     color: Colors.blue,
            //     fontSize: 16,
            //     decoration: TextDecoration.underline),
            callback: (context, string) async {
              await canLaunch(string)
                  ? await launch(string)
                  : throw 'Could not launch $string';
            },
          ),
        );
      } else {
        textSpanList.add(
          MyText(
            text: element + ' ',
            // style: Theme.of(context).textTheme.bodyText1.copyWith(
            //       color: Colors.grey[700],
            //       fontSize: 16,
            //     ),
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w400,
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
            ),

            //  TextStyle(
            //   color: Colors.grey[700],
            //   fontSize: 16,
            // ),
            callback: (context, string) {
              UtilsMethods.toastMessageShow(
                widget.controller.displayColor,
                widget.controller.displayColor,
                widget.controller.displayColor,
                message: 'SIMPLETEXT',
              );
              // ScaffoldMessenger.of(context).showSnackBar(
              //   SnackBar(
              //     content: Text("SIMPLETEXT",
              //       style: Theme.of(context).brightness == Brightness.dark ?
              //       TextStyle(color: Colors.white,fontSize: 16,
              //       )
              //           : TextStyle(fontSize: 16,
              //         color: Colors.black,
              //       ),),
              //   ),
              // );
            },
          ),
        );
      }
    });
    return textSpanList;
  }

  bool check(String url) {
    RegExp exp =
        new RegExp(r'(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+');
    Iterable<RegExpMatch> matches = exp.allMatches(url);
    if (matches.length > 0) {
      // https://api.flutter.dev/flutter/widgets/RichText-class.html
      return true;
    } else
      return false;
  }
}




///detail page
class PostTextDescriptionDetailScreen extends StatefulWidget {
  PostTextDescriptionDetailScreen(
      {Key key,
      @required this.post,
      this.isCommentScreen = false,
      this.controller,
      this.showMomentScreen,
      this.editMomentScreen,
      this.translationCheck,
      this.translationData,
      this.width})
      : super(key: key);

  final Post post;
  final bool isCommentScreen;
  final NewsfeedController controller;
  bool showMomentScreen = false;
  bool editMomentScreen = false;
  final double width;
  TranslationData translationData;

  bool translationCheck;

  @override
  _PostTextDescriptionDetailScreenState createState() =>
      _PostTextDescriptionDetailScreenState();
}

class _PostTextDescriptionDetailScreenState
    extends State<PostTextDescriptionDetailScreen> {
  List<String> str = [];

  // List<dynamic> listw = postText.
  // NewsfeedController controller = Get.find<NewsfeedController>();
  bool _readMore = false;
  String postText ;
  int postLanguageId;

  @override
  void initState() {
    postText = widget.post.body;
    postLanguageId = widget.post.languageId;
    super.initState();
  }
  @override
  Widget build(BuildContext context) {

    if(widget.post.translation.value == true){
      postText = widget.post.translationData.data[0].body;
      postLanguageId = widget.controller.languageData.myLang.id;

    }else{
      postText = widget.post.body;
      postLanguageId = widget.post.languageId;
    }


    return widget.controller.languageData == null
        ? SizedBox()
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                kIsWeb || widget.isCommentScreen
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          RichTextViewForDetailScreen(
                            context,
                            widget.translationData == null
                                ? widget.post.body
                                : widget.translationCheck == true
                                    ? widget.translationData.data[0].body
                                    : widget.post.body,
                            _readMore,
                            widget.controller,
                            widget.post.authorId,
                            Get.isDarkMode? Colors.white
                                : Colors.black,
                            widget.post,
                            position: widget.translationCheck == false ||
                                    widget.translationCheck == null
                                ? widget.post.languageDirection == "ltr"
                                    ? "ltr"
                                    : "rtl"
                                : widget.translationData != null
                                    ? widget.translationData.data[0]
                                        .languageDirection
                                    : "ltr",
                            showMomentScreen: widget.showMomentScreen,
                            editMomentScreen: widget.editMomentScreen,
                            shouldGiveFixedHeight: true,
                            width: widget.width,
                          ),

                          widget.post.location != null
                              ? Text(
                                  "from ${widget.post.location}",
                                  // style: TextStyle(
                                  //   color: Colors.grey.shade400
                                  // ),
                                  style: Get.isDarkMode? TextStyle(
                                          color: Colors.white,
                                        )
                                      : TextStyle(color: Colors.grey.shade400),
                                )
                              :  const SizedBox(),
                          TextToSpeechWidget(text: postText,languageId: postLanguageId,),

                          // kIsWeb && widget.post.body.length >= 100 && widget.controller.isPostDetails ==false
                          //     ? Align(
                          //
                          //   alignment: Alignment.bottomLeft,
                          //   child: SizedBox(
                          //     width: widget.showMomentScreen==true || widget.editMomentScreen==true?20: 100,
                          //     child: InkWell(
                          //       onTap: () {
                          //
                          //         _readMore = !_readMore;
                          //         setState(() {});
                          //       },
                          //       child: Align(
                          //         alignment: Alignment.bottomLeft,
                          //         child: Text(
                          //           Strings.showMore,
                          //           style: Theme.of(context).brightness == Brightness.dark ?
                          //           TextStyle(color: Colors.white,fontSize: 12,fontWeight: FontWeight.bold
                          //           )
                          //               : TextStyle(fontSize: 12,color: Colors.black,
                          //               fontWeight: FontWeight.bold
                          //           ),
                          //         ),
                          //       ),
                          //     ),
                          //   ),
                          // )
                          //     : SizedBox()
                          // : widget.post.body.length >= 10
                          //     ? Align(
                          //         alignment: Alignment.bottomLeft,
                          //         child: SizedBox(
                          //           width: 100,
                          //           child: InkWell(
                          //             onTap: () {
                          //               _readMore = !_readMore;
                          //               setState(() {});
                          //             },
                          //             child: Align(
                          //               alignment: Alignment.bottomLeft,
                          //               child:Text(
                          //
                          //                 widget.post.body.length >= 30
                          //                     ? _readMore
                          //                         ? Strings.showLess
                          //                         : Strings.showMore
                          //                     : "",
                          //                 style: Theme.of(context).brightness == Brightness.dark ?
                          //                 TextStyle(color: Colors.white,fontSize: 12,fontWeight: FontWeight.bold
                          //                 )
                          //                     : TextStyle(fontSize: 12,color: Colors.black,
                          //                     fontWeight: FontWeight.bold
                          //                 ),
                          //               ),
                          //             ),
                          //           ),
                          //         ),
                          //       )
                          //     : SizedBox(),
                        ],
                      )
                    : Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ///ASAD
                            Row(
                              children: [
                                RichTextViewForDetailScreen(
                                  context,
                                  widget.translationData == null
                                      ? widget.post.body
                                      : widget.translationCheck == true
                                          ? widget.translationData.data[0].body
                                          : widget.post.body,
                                  _readMore,
                                  widget.controller,
                                  widget.post.authorId,
                                  Get.isDarkMode? Colors.white
                                      : Colors.black,
                                  widget.post,
                                  position: widget.translationCheck == false ||
                                          widget.translationCheck == null
                                      ? widget.post.languageDirection == "ltr"
                                          ? "ltr"
                                          : "rtl"
                                      : widget.translationData != null
                                          ? widget.translationData.data[0]
                                              .languageDirection
                                          : "ltr",
                                  width: widget.width,
                                ),
                                TextToSpeechWidget(text: postText,languageId: postLanguageId,),
                              ],
                            ),
                            widget.post.location != null
                                ? Text(
                                    "from ${widget.post.location}",
                                    // style: TextStyle(
                                    //     color: Colors.grey.shade400
                                    // ),
                                    style:Get.isDarkMode
                                        ? TextStyle(
                                            color: Colors.white,
                                            fontSize: 12,
                                          )
                                        : TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey.shade400,
                                          ),
                                  )
                                : const SizedBox(),

                            // if(widget.post.authorId == s)

                            // kIsWeb
                            //     ? widget.post.body.length >= 100
                            //         ? Align(
                            //             alignment: Alignment.bottomLeft,
                            //             child: SizedBox(
                            //               width: widget.showMomentScreen==true || widget.editMomentScreen==true?20: 100,
                            //               child: InkWell(
                            //                 onTap: () {
                            //                   _readMore = !_readMore;
                            //                   setState(() {});
                            //                 },
                            //                 child: Align(
                            //                   alignment: Alignment.bottomLeft,
                            //                   child:
                            //                   widget.post.type=='thread'?
                            //                       Text(widget.post.body,
                            //                         // style: TextStyle(
                            //                         //     fontSize: 12,
                            //                         //     fontWeight: FontWeight.bold),
                            //                         style: Theme.of(context).brightness == Brightness.dark ?
                            //                         TextStyle(color: Colors.white,fontSize: 12, fontWeight: FontWeight.bold
                            //                         )
                            //                             : TextStyle(fontSize: 12,color: Colors.black,
                            //                             fontWeight: FontWeight.bold
                            //                         ),
                            //                       )
                            //                  : Text(
                            //                     widget.post.body.length >= 30
                            //                         ? _readMore
                            //                             ? Strings.showLess
                            //                             : Strings.showMore
                            //                         : "",
                            //                     style: Theme.of(context).brightness == Brightness.dark ?
                            //                     TextStyle(color: Colors.white,fontSize: 12, fontWeight: FontWeight.bold
                            //                     )
                            //                         : TextStyle(fontSize: 12,color: Colors.black,
                            //                         fontWeight: FontWeight.bold
                            //                     ),
                            //                   ),
                            //                 ),
                            //               ),
                            //             ),
                            //           )
                            //         : SizedBox()
                            //     : widget.post.body.length >= 10
                            //         ? Align(
                            //             alignment: Alignment.bottomLeft,
                            //             child: SizedBox(
                            //               width: 100,
                            //               child: InkWell(
                            //                 onTap: () {
                            //                   _readMore = !_readMore;
                            //                   setState(() {});
                            //                 },
                            //                 child: Align(
                            //                   alignment: Alignment.bottomLeft,
                            //                   child: widget.post.body.length >= 30
                            //                       ? Text(
                            //                           _readMore
                            //                               ? Strings.showLess
                            //                               : Strings.showMore,
                            //                     style: Theme.of(context).brightness == Brightness.dark ?
                            //                     TextStyle(color: Colors.white,fontSize: 12, fontWeight: FontWeight.bold
                            //                     )
                            //                         : TextStyle(fontSize: 12,color: Colors.black,
                            //                         fontWeight: FontWeight.bold
                            //                     ),
                            //                         )
                            //                       : SizedBox(),
                            //                 ),
                            //               ),
                            //             ),
                            //           )
                            //         : SizedBox(),
                          ],
                        ),
                      ),

              ]);
  }

  List<MyText> medthodToGetString(String str) {
    // String str = 'GitHub is a development google.com inspired #by the way you work. From google.com';
    List<MyText> textSpanList = [];
    List<String> divString = str.split(' ');
    // str.runes.forEach((int rune) {
    //   divString.add(new String.fromCharCode(rune));
    //   print(divString);
    // });
    print("klnklnlknlknlknklnlkn");
    divString.forEach((element) {
      if (element.contains('#')) {
        textSpanList.add(
          MyText(
            text: element + ' ',
            // style: Theme.of(context).textTheme.bodyText1.copyWith(
            //       color: Colors.blue,
            //       fontSize: 16,
            //     ),
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: widget.controller.displayColor,
            ),

            // TextStyle(
            //   color: Colors.blue,
            //   fontSize: 16,
            // ),
            callback: (context, string) async {
              // Get.find<NewsfeedController>().isSearch = true;
              try {
                widget.controller.isProfileScreen = false;
                widget.controller.isFilterScreen = true;
                await widget.controller.onSearchTextChanged(string);
                // controller.update();

                print("payload");
                print("${widget.controller.searchResult[0].id}");
                print("${widget.controller.searchResult[0].type}");
                print("payload");
                widget.controller.searchSelected =
                    widget.controller.searchResult[0];
                await widget.controller.filterUsers(
                  id: 0.toString(),
                  type: "tag",
                  tag: string,
                );
                widget.controller.searchText.text = string;
                widget.controller.isProfileScreen = false;
                widget.controller.isSettingsScreen = false;
                widget.controller.isSavedPostScreen = false;
                widget.controller.isNewsFeedScreen = false;
                widget.controller.isOtherUserProfileScreen = false;
                widget.controller.isChatScreen = false;
                widget.controller.isChatScreenWeb = false;
                widget.controller.isBrowseScreen = false;
                widget.controller.isClickWhoToFollow = false;
                widget.controller.isFollwerScreen = false;
                widget.controller.isPostDetails = false;
                Future.delayed(Duration(seconds: 3), () {
                  kIsWeb
                      ? widget.controller.update()
                      : Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => FilteredScreen(
                                    newsfeedController:
                                        Get.find<NewsfeedController>(),
                                  )));
                });
              } catch (_) {}
            },
          ),
        );
      } else if (element.contains('\$')) {
        textSpanList.add(
          MyText(
            text: element + ' ',
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: widget.controller.displayColor,
            ),

            // TextStyle(
            //   color: Colors.blue,
            //   fontSize: 16,
            // ),
            callback: (context, string) async {
              // Get.find<NewsfeedController>().isSearch = true;
              try {
                widget.controller.isProfileScreen = false;
                widget.controller.isFilterScreen = true;
                await widget.controller.onSearchTextChanged(string);
                // controller.update();

                print("payload");
                print("${widget.controller.searchResult[0].id}");
                print("${widget.controller.searchResult[0].type}");
                print("payload");
                widget.controller.searchSelected =
                    widget.controller.searchResult[0];
                await widget.controller.filterUsers(
                  id: 0.toString(),
                  type: "cash_tag",
                  tag: string,
                );
                widget.controller.searchText.text = string;
                widget.controller.isProfileScreen = false;
                widget.controller.isSettingsScreen = false;
                widget.controller.isSavedPostScreen = false;
                widget.controller.isNewsFeedScreen = false;
                widget.controller.isOtherUserProfileScreen = false;
                widget.controller.isChatScreen = false;
                widget.controller.isChatScreenWeb = false;
                widget.controller.isBrowseScreen = false;
                widget.controller.isClickWhoToFollow = false;
                widget.controller.isFollwerScreen = false;
                widget.controller.isPostDetails = false;
                Future.delayed(Duration(seconds: 3), () {
                  kIsWeb
                      ? widget.controller.update()
                      : Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => FilteredScreen(
                                    newsfeedController:
                                        Get.find<NewsfeedController>(),
                                  )));
                });
              } catch (_) {}
            },
          ),
        );
      } else if (check(element)) {
        //    element.contains('.com') || element.contains('https') || element.contains('http');
        textSpanList.add(
          MyText(
            text: element + ' ',
            // style: Theme.of(context).textTheme.bodyText1.copyWith(
            //     color: Colors.blue,
            //     fontSize: 16,
            //     decoration: TextDecoration.underline),
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: widget.controller.displayColor,
            ),

            //  TextStyle(
            //     color: Colors.blue,
            //     fontSize: 16,
            //     decoration: TextDecoration.underline),
            callback: (context, string) async {
              await canLaunch(string)
                  ? await launch(string)
                  : throw 'Could not launch $string';
            },
          ),
        );
      } else {
        textSpanList.add(
          MyText(
            text: element + ' ',
            // style: Theme.of(context).textTheme.bodyText1.copyWith(
            //       color: Colors.grey[700],
            //       fontSize: 16,
            //     ),
            style: Styles.baseTextTheme.headline2.copyWith(
              fontSize: 15,
              fontWeight: FontWeight.w400,
              color: Get.isDarkMode
                  ? Colors.white
                  : Colors.black,
            ),

            //  TextStyle(
            //   color: Colors.grey[700],
            //   fontSize: 16,
            // ),
            callback: (context, string) {
              UtilsMethods.toastMessageShow(
                widget.controller.displayColor,
                widget.controller.displayColor,
                widget.controller.displayColor,
                message: 'SIMPLETEXT',
              );
              // ScaffoldMessenger.of(context).showSnackBar(
              //   SnackBar(
              //     content: Text("SIMPLETEXT",
              //       style: Theme.of(context).brightness == Brightness.dark ?
              //       TextStyle(color: Colors.white,fontSize: 16,
              //       )
              //           : TextStyle(fontSize: 16,
              //         color: Colors.black,
              //       ),),
              //   ),
              // );
            },
          ),
        );
      }
    });
    return textSpanList;
  }

  bool check(String url) {
    RegExp exp =
        new RegExp(r'(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+');
    Iterable<RegExpMatch> matches = exp.allMatches(url);
    if (matches.length > 0) {
      // https://api.flutter.dev/flutter/widgets/RichText-class.html
      return true;
    } else
      return false;
  }
}

class MyText {
  final String text;
  final TextStyle style;
  final void Function(BuildContext, String) callback;

  MyText({
    this.text,
    this.style,
    this.callback,
  });
}
