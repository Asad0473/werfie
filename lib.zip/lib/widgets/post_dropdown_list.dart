import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/utils/strings.dart';

// ignore: must_be_immutable
class PostDropdownList extends StatefulWidget {
  DummyData dataController = Get.find();
  final postIndex;

  PostDropdownList(this.postIndex);

  @override
  _PostDropdownListState createState() => _PostDropdownListState();
}

class _PostDropdownListState extends State<PostDropdownList> {
  @override
  Widget build(BuildContext context) {
    var _isExpanded = false;
    return DropdownButton(
      isDense: true,
      iconSize: 16,
      underline: Container(),
      onChanged: (val) {},
      onTap: () {
        _isExpanded = !_isExpanded;
        setState(() {});
      },
      icon: Icon(Icons.more_horiz),
      isExpanded: _isExpanded,
      items: [
        DropdownMenuItem(
          child: InkWell(
            onTap: () {
              widget.dataController.deletePost(widget.postIndex);
            },
            child: SizedBox(
              width: 70,
              child: FittedBox(
                child: Text(
                  Strings.hidePost,
                  style: Theme.of(context).brightness == Brightness.dark
                      ? TextStyle(
                          color: Colors.white,
                        )
                      : TextStyle(
                          color: Colors.black,
                        ),
                ),
              ),
            ),
          ),
        ),
        DropdownMenuItem(
          child: SizedBox(
            width: 70,
            child: FittedBox(
                child: Text(
              Strings.savePost,
              style: Theme.of(context).brightness == Brightness.dark
                  ? TextStyle(
                      color: Colors.white,
                    )
                  : TextStyle(
                      color: Colors.black,
                    ),
            )),
          ),
        ),
      ],
    );
  }
}
