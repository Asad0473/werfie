import 'package:flutter/material.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/custom_image_view.dart';

import '../../utils/asset_string.dart';

class AuthBackGround extends StatelessWidget {
  final Widget body;
  const AuthBackGround({Key key, this.body}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return

      Container(
        decoration: const BoxDecoration(
    image: DecorationImage(
    image: AssetImage(AppImages.authPngBackGround),
    fit: BoxFit.cover,
    ),),
    child: body,
    );
  }
}
