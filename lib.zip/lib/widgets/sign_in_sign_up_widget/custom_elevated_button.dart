import 'package:flutter/material.dart';
import '../../utils/login_theme/theme_helper.dart';
import 'base_button.dart';

class CustomElevatedButton extends BaseButton {
  CustomElevatedButton({
    Key key,
    this.decoration,
    this.leftIcon,
    this.rightIcon,
    EdgeInsets margin,
    VoidCallback onPressed,
    ButtonStyle buttonStyle,
    Alignment alignment,
    TextStyle buttonTextStyle,
    bool isDisabled,
    double height,
    double width,
    @required String text,
  }) : super(
          text: text,
          onPressed: onPressed,
          buttonStyle: buttonStyle,
          isDisabled: isDisabled,
          buttonTextStyle: buttonTextStyle,
          height: height,
          width: width,
          alignment: alignment,
          margin: margin,
        );

  final BoxDecoration decoration;

  final Widget leftIcon;

  final Widget rightIcon;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
            alignment: alignment ?? Alignment.center,
            child: buildElevatedButtonWidget,
          )
        : buildElevatedButtonWidget;
  }

  Widget get buildElevatedButtonWidget => Container(
        height: height ?? 60,
        width: width ?? double.maxFinite,
        margin: margin,
        decoration: decoration??BoxDecoration(
          borderRadius: BorderRadius.circular(10),
            color: appTheme.blueColorHere,
            boxShadow:  [
              BoxShadow(
                color: appTheme.blueColorHere,
                offset: const Offset(0, 0),
                blurRadius: 8,
                spreadRadius: 0,
              ),
            ]),


        child: ElevatedButton(

          style: buttonStyle?? ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              )),
          onPressed: isDisabled ?? false ? null : onPressed ?? () {},
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              leftIcon ?? const SizedBox.shrink(),
              Text(
                text,
                style: buttonTextStyle ??   TextStyle(
                  color: appTheme.whiteA700,
                  fontSize: 19,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
              ),
              rightIcon ?? const SizedBox.shrink(),
            ],
          ),
        ),
      );
}
