import 'package:flutter/material.dart';

import '../../utils/login_theme/theme_helper.dart';


class CustomPasswordField extends StatefulWidget {
  CustomPasswordField({
    Key key,
    this.alignment,
    this.width,
    this.scrollPadding,
    this.controller,
    this.focusNode,
    this.autofocus = true,
    this.textStyle,
    this.obscureText = false,
    this.textInputAction = TextInputAction.next,
    this.textInputType = TextInputType.text,
    this.maxLines,
    this.hintText,
    this.hintStyle,
    this.prefix,
    this.prefixConstraints,
    this.suffix,
    this.suffixConstraints,
    this.contentPadding,
    this.borderDecoration,
    this.fillColor,
    this.height,
    this.filled = true,
    this.validator,
    this.onTap,
    this.errorText,
    this.onPress,
    this.nextInputField,
    this.onChanged,
    this.onValueEntered,
    this.showCursor,
    this.nextNode


  }) : super(
    key: key,
  );

  final Alignment alignment;

  final double width;
  final double height;

  final TextEditingController scrollPadding;

  final TextEditingController controller;

  final FocusNode focusNode;

  final bool autofocus;

  final TextStyle textStyle;

  final bool obscureText;

  final TextInputAction textInputAction;

  final TextInputType textInputType;

  final int maxLines;

  final String hintText;

  final TextStyle hintStyle;

  final Widget prefix;

  final BoxConstraints prefixConstraints;

  final Widget suffix;

  final BoxConstraints suffixConstraints;

  final EdgeInsets contentPadding;

  final InputBorder borderDecoration;

  final Color fillColor;
  final bool filled;
  final Function(String) onValueEntered;
  final Function(String) onChanged;
  var nextInputField;
  final String errorText;
  final showCursor;
  Function onPress;
  Function onTap;
  var nextNode;

  final FormFieldValidator<String> validator;

  @override
  State<CustomPasswordField> createState() => _CustomPasswordFieldState();
}

class _CustomPasswordFieldState extends State<CustomPasswordField> {
  var _isObsecure = true;
  @override
  Widget build(BuildContext context) {
    return widget.alignment != null
        ? Align(
      alignment: widget.alignment ?? Alignment.center,
      child: textFormFieldWidget(context),
    )
        : textFormFieldWidget(context);
  }

  Widget textFormFieldWidget(BuildContext context) =>TextFormField(
    showCursor: widget.showCursor,
    onFieldSubmitted: (_) =>
        FocusScope.of(context).requestFocus(widget.nextNode),
    focusNode: widget.focusNode,
    scrollPadding:
    EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
    controller: widget.controller,
    onTapOutside: (event) {
      if (widget.focusNode != null) {
        widget.focusNode?.unfocus();
      } else {
        FocusManager.instance.primaryFocus?.unfocus();
      }
    },
    autofocus: widget.autofocus,
    style: widget.textStyle ?? theme.textTheme.bodyLarge,
    obscureText: _isObsecure,
    textInputAction: widget.textInputAction,
    keyboardType: widget.textInputType,
    maxLines: widget.maxLines ?? 1,
    decoration: decoration,
    validator: widget.validator,
    onChanged: (String val) => widget.onChanged(val),
  );

  InputDecoration get decoration => InputDecoration(
    errorText:widget.errorText ,
    errorBorder:OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(
        width: 0,
        style: BorderStyle.none,
        color:Colors.red,
      ),
    ),
    hintText: widget.hintText ?? "",
    hintStyle: widget.hintStyle ??
        // theme.textTheme.headlineMedium,
        TextStyle(
          color: appTheme.blueGray700,
          fontSize: 16,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
        ),
    prefixIcon: widget.prefix,
    prefixIconConstraints: widget.prefixConstraints,
    suffixIcon: Padding(
      padding: const EdgeInsets.only(right: 10),
      child: IconButton(
        icon: Icon(
          _isObsecure ? Icons.visibility_off : Icons.visibility,
        ),
        onPressed: () {
          setState(() {
            _isObsecure = !_isObsecure;
          });
        },
      ),
    ),
    suffixIconConstraints: widget.suffixConstraints,
    isDense: true,
    contentPadding: widget.contentPadding ??
        const EdgeInsets.only(
          left: 20,
          top: 10,
          bottom: 10,
        ),
    fillColor: widget.fillColor ??
        // Colors.grey.shade50,
        appTheme.whiteA700,
    filled: widget.filled,
    border: widget.borderDecoration ??
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
    enabledBorder: widget.borderDecoration ??
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:  BorderSide(
            width: 2,
            style: BorderStyle.none,
            color:appTheme.blueColorHere,
          ),
        ),
    focusedBorder: widget.borderDecoration ??
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:  BorderSide(
            width: 2,
            style: BorderStyle.none,
            color:appTheme.blueColorHere,
          ),
        ),
  );
}
