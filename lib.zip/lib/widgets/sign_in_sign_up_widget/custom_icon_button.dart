import 'package:flutter/material.dart';

import '../../utils/login_theme/theme_helper.dart';


class CustomIconButton extends StatelessWidget {
  const CustomIconButton({
    Key key,
    this.alignment,
    this.height,
    this.width,
    this.padding,
    this.decoration,
    this.child,
    this.onTap,
  this.focusNode
  }) : super(
          key: key,
        );

  final Alignment alignment;

  final double height;

  final double width;

  final EdgeInsetsGeometry padding;

  final BoxDecoration decoration;

  final Widget child;

  final VoidCallback onTap;
  final FocusNode focusNode;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
            alignment: alignment ?? Alignment.center,
            child: iconButtonWidget,
          )
        : iconButtonWidget;
  }

  Widget get iconButtonWidget => Container(


        height: height ?? 32,
        width: width ?? 32,
        child: IconButton(
          focusNode: focusNode,
          padding: EdgeInsets.zero,
          icon: Container(
            height: height ?? 32,
            width: width ?? 32,
            padding: padding ?? EdgeInsets.zero,
            decoration: decoration ??
                BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                ),
            child: child,
          ),
          onPressed: onTap,
        ),
      );
}
