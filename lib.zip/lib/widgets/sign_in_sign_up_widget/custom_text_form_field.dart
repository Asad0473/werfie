import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../utils/login_theme/theme_helper.dart';


class CustomTextFormField extends StatefulWidget {
   CustomTextFormField({
    Key key,
    this.alignment,
    this.width,
    this.scrollPadding,
    this.controller,
    this.focusNode,
    this.autofocus = true,
    this.textStyle,
    this.obscureText = false,
    this.textInputAction = TextInputAction.next,
    this.textInputType = TextInputType.text,
    this.maxLines,
    this.hintText,
    this.hintStyle,
    this.prefix,
    this.prefixConstraints,
    this.suffix,
    this.suffixConstraints,
    this.contentPadding,
    this.borderDecoration,
    this.fillColor,
    this.height,
    this.filled = true,
    this.validator,
    this.onTap,
    this.errorText,
    this.onPress,
    this.nextInputField,
    this.onChanged,
    this.onValueEntered,
    this.showCursor,
this.inputFormatters,
     this.autovalidateMode,
     this.enabled,

  }) : super(
          key: key,
        );
   List<TextInputFormatter> inputFormatters;
  final Alignment alignment;

  final double width;
  final double height;

  final TextEditingController scrollPadding;

  final TextEditingController controller;

  final FocusNode focusNode;

  final bool autofocus;

  final TextStyle textStyle;

  final bool obscureText;

  final TextInputAction textInputAction;

  final TextInputType textInputType;

  final int maxLines;

  final String hintText;

  final TextStyle hintStyle;

  final Widget prefix;

  final BoxConstraints prefixConstraints;

  final Widget suffix;

  final BoxConstraints suffixConstraints;

  final EdgeInsets contentPadding;

  final InputBorder borderDecoration;
   AutovalidateMode autovalidateMode;
  final Color fillColor;
  final bool filled;
  final Function(String) onValueEntered;
  final Function(String) onChanged;
  var nextInputField;
  final String errorText;
  final showCursor;
  Function onPress;
  Function onTap;
   bool enabled;


  final FormFieldValidator<String> validator;

  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  @override
  Widget build(BuildContext context) {
    return
      widget.alignment != null
        ? Align(
            alignment: widget.alignment ?? Alignment.center,
            child: textFormFieldWidget(context),
          )
        : textFormFieldWidget(context);
  }

  Widget textFormFieldWidget(BuildContext context) => TextFormField(
    inputFormatters: widget.inputFormatters??[],
    enabled: widget.enabled,
    showCursor: widget.showCursor,
    autovalidateMode: widget.autovalidateMode,
    onFieldSubmitted: (_) =>
        FocusScope.of(context).requestFocus(widget.nextInputField),
    focusNode: widget.focusNode,
    scrollPadding:
    EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
    controller: widget.controller,
    onTapOutside: (event) {
      if (widget.focusNode != null) {
        widget.focusNode?.unfocus();
      } else {
        FocusManager.instance.primaryFocus?.unfocus();
      }
    },
    autofocus: widget.autofocus,
    style: widget.textStyle ?? theme.textTheme.bodyLarge,
    obscureText: widget.obscureText,
    textInputAction: widget.textInputAction,
    keyboardType: widget.textInputType,
    maxLines: widget.maxLines ?? 1,
    decoration: decoration,
    validator: widget.validator,
    onChanged: (String val) => widget.onChanged(val),
  );

  InputDecoration get decoration => InputDecoration(

    errorText:widget.errorText ,
    errorBorder:OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(
        width: 0,
        style: BorderStyle.none,
        color:Colors.red,
      ),
    ),
        hintText: widget.hintText ?? "",
        hintStyle: widget.hintStyle ??

           // theme.textTheme.headlineMedium,
            TextStyle(
          color: appTheme.blueGray700,
          fontSize: 16,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
        ),
        prefixIcon: widget.prefix,
        prefixIconConstraints: widget.prefixConstraints,
        suffixIcon: widget.suffix,
        suffixIconConstraints: widget.suffixConstraints,
        isDense: true,
        contentPadding: widget.contentPadding ??
            const EdgeInsets.only(
              left: 20,
              top: 10,
              bottom: 10,
            ),
        fillColor: widget.fillColor ??
           // Colors.grey.shade50,
            appTheme.whiteA700,
        filled: widget.filled,
        border: widget.borderDecoration ??
            OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
        enabledBorder: widget.borderDecoration ??
            OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide:  BorderSide(
                width: 1,
                style: BorderStyle.none,
                color:appTheme.blueColorHere,
              ),
            ),
        focusedBorder: widget.borderDecoration ??
            OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
                borderSide:  BorderSide(
                  width: 1,
                  style: BorderStyle.none,
                  color:appTheme.blueColorHere,
                ),
            ),
      );
}
