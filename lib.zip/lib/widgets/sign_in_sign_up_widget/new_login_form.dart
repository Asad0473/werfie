import 'dart:convert';
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:g_recaptcha_v3/g_recaptcha_v3.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:routemaster/routemaster.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:the_apple_sign_in/scope.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:werfieapp/components/custom_dialog.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/account_lockout_controller.dart';

import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/fluro_router.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/routes.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';
import 'package:werfieapp/web_views/web_guest_user/components/textButton.dart';

import '../../components/input_field.dart';
import '../../components/input_password_field.dart';
import '../../screens/language_settings.dart';
import '../../screens/reset_password_screen.dart';
import '../../services/AuthService.dart';
import '../../services/captcha_service.dart';
import '../../utils/colors.dart';
import '../../utils/font.dart';
import '../../utils/loading_dialog_builder.dart';
import '../../utils/login_theme/app_decoration.dart';
import '../../utils/login_theme/custom_text_style.dart';
import '../../utils/login_theme/theme_helper.dart';
import '../dialogs/LoginWithWorldNoorDialog.dart';
import '../sign_up_dialog.dart';
import 'auth_back_ground.dart';
import 'custom_elevated_button.dart';
import 'custom_icon_button.dart';
import 'custom_image_view.dart';
import 'custom_password_field.dart';
import 'custom_text_form_field.dart';


class NewLoginForm extends StatefulWidget {
  int isFromWorldNoorApp;
  bool isAutoLogin = false;
  final LoginController loginController;

  NewLoginForm(BuildContext context, controller, formKey, id,

      {Key key, this.isFromWorldNoorApp = 0,this.isAutoLogin = false,this.loginController}) : super(key: key);

  @override
  State<NewLoginForm> createState() => _NewLoginFormState();
}

class _NewLoginFormState extends State<NewLoginForm> {
  int id;

  LoginController controller = Get.find<LoginController>();
  var languageDropVal = 'English';

  SharedPreferences shared;

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final storage = GetStorage();

  bool errorText = false;
  bool isCaptchaSelected = false;
  String createdViewId = 'map_element';

  bool isCheckedGlobal = false;
  WebViewController webviewController;
  bool validationcheck = false;
  String email = '';
  String password = '';

  String get emailError {
    final text = controller.email.text;
    if (text.isEmpty) {
      return Strings.emailFieldCannotBeEmpty;
    } /*else if (!RegExp(
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(text)) {
      return Strings.pleaseProvideAValidEmail;
    } */else {
      return null;
    }
  }

  String get passwordError {
    final text = controller.password.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    }
    else {
      return null;
    }
  }

  static const platform = const MethodChannel('worldnoor');

  Future<Map<String, dynamic>> futureBuilderGetDataFromWorldNoorApp;

  @override
  void initState() {

    if (!kIsWeb) {
      if (Platform.isAndroid || Platform.isIOS) {
        futureBuilderGetDataFromWorldNoorApp = getDataFromWorldNoorApp();
      }

    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return

     AuthBackGround(
    body:
    Container(
      color:

      kIsWeb && id==2?
      Colors.transparent:
      kIsWeb? Colors.grey.shade100:
      Colors.transparent,
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [

          !kIsWeb ?
          _buildLanguageChangeWidget()
              :const SizedBox(),

            const SizedBox(height:kIsWeb?0: 20),

            _buildWerfieLogoWidget(),
            const SizedBox(height:kIsWeb?10: 35),
            _buildSignInText(text: Strings.signInToYourAccount ),
            const SizedBox(height:kIsWeb?10: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Shortcuts(
                      shortcuts: {
                        LogicalKeySet(LogicalKeyboardKey.tab): EnterName(),
                      },
                      child: Actions(
                        actions: {
                          EnterName: CallbackAction<EnterName>(onInvoke: (_) {
                            controller.focus1.unfocus();
                            FocusScope.of(context).requestFocus(controller.focus2);
                          }),
                        },
                        child: Container(
                          child: errorText == false
                              ? CustomTextFormField(
                            focusNode: controller.focus1,
                            controller:   controller.email,
                            textInputAction: TextInputAction.next,
                            onChanged: (value) {
                              setState(() {
                                email = value;
                              });

                            },
                            validator: (value) {
                              return value.isEmpty
                                  ? Strings.emailFieldCannotBeEmpty : null;
                              //return UtilsMethods.validateEmail(value);
                            },
                            hintText: Strings.enterEmailPhone,
                            textInputType: TextInputType.text,
                            suffix: Container(
                              margin: const EdgeInsets.fromLTRB(
                                  30, 20, 25, 20),
                              child: GestureDetector(
                                onTap: (){
                                  controller.email.text='';
                                },
                                child: CustomImageShow(
                                  imagePath: AppImages.crossXImage,
                                  height: 18,
                                  width: 18,
                                ),
                              ),
                            ),
                            suffixConstraints: const BoxConstraints(),
                          )
                              : ValueListenableBuilder(
                            valueListenable: controller.email,
                            builder: (BuildContext context,
                                TextEditingValue value, Widget child) {
                              return CustomTextFormField(
                                focusNode: controller.focus1,
                                controller:   controller.email,
                                hintText: Strings.enterEmailPhone,
                                textInputType:
                                TextInputType.emailAddress,
                                errorText: emailError,
                                onChanged: (value) {
                                  setState(() {
                                    email = value;
                                  });

                                },
                                suffix: Container(
                                  margin: const EdgeInsets.fromLTRB(
                                      30, 20, 25, 20),
                                  child: GestureDetector(
                                    onTap: (){
                                      controller.email.text='';
                                    },
                                    child: CustomImageShow(
                                      imagePath: AppImages.crossXImage,
                                      height: 18,
                                      width: 18,
                                    ),
                                  ),
                                ),
                                suffixConstraints: const BoxConstraints(
                                  //  maxHeight: 60,
                                ),
                              );
                            },
                            // child: ,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height:kIsWeb?20: 20),
                    Shortcuts(
                      shortcuts: {
                        LogicalKeySet(LogicalKeyboardKey.tab): EnterPasswords(),
                      },
                      child: Actions(
                        actions: {
                          EnterPasswords:
                          CallbackAction<EnterPasswords>(onInvoke: (_) {
                            controller.focus2.unfocus();
                            FocusScope.of(context).requestFocus(controller.focus3);
                          }),
                        },
                        child: errorText == false
                            ? Padding(
                          padding: const EdgeInsets.only(right: 1),
                          child: CustomPasswordField(
                            focusNode: controller.focus2,
                            nextNode: controller.focus4,
                            textInputAction: TextInputAction.next,
                            contentPadding:  const EdgeInsets.symmetric(
                              horizontal: 20,vertical: 18
                            ),
                            onChanged: (value) {
                              setState(() {
                                password = value;
                              });
                            },
                            controller: controller.password,
                            hintText: Strings.enterYourPassword,
                            hintStyle:   TextStyle(
                              color: appTheme.blueGray700,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400,
                            ),
                            textInputType:
                            TextInputType.visiblePassword,
                            obscureText: true,
                          //  contentPadding:const EdgeInsets.symmetric(horizontal: 15,vertical: 10) ,

                            validator: (value) {
                              return UtilsMethods.validatePassword(value);
                            },
                          ),
                        )
                            : ValueListenableBuilder(
                              valueListenable: controller.password,
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return Padding(
                                  padding: const EdgeInsets.only(right: 1),
                                  child: CustomPasswordField(
                                    controller: controller.password,
                                    hintText: Strings.enterYourPassword,
                                    hintStyle:   TextStyle(
                                      color: appTheme.blueGray700,
                                      fontSize: 25,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w400,
                                    ),
                                    textInputAction: TextInputAction.done,
                                    textInputType:
                                    TextInputType.visiblePassword,
                                   // contentPadding: const EdgeInsets.symmetric(horizontal: 15,vertical: 30),
                                    obscureText: true,
                                    errorText: passwordError,
                                    onChanged: (value) {
                                      setState(() {
                                        password = value;
                                      });
                                    },

                                    validator: (value) {
                                      return UtilsMethods.validatePassword(value);
                                    },
                                  ),
                                );
                              },
                              //  child: ,
                            ),
                      ),
                    ),
                    const SizedBox(height:kIsWeb?10: 21),
                    Shortcuts(
                      shortcuts: {
                        LogicalKeySet(LogicalKeyboardKey.tab): LostPassword(),
                      },
                      child: Actions(
                        actions: {
                          LostPassword: CallbackAction<LostPassword>(onInvoke: (_) {
                            controller.focus3.unfocus();
                            FocusScope.of(context).requestFocus(controller.focus4);
                          }),
                        },
                        child: TextButton(
                          onPressed: () {
                            formKey.currentState?.reset();
                            if (!kIsWeb) {
                              Get.to(
                                // MaterialPageRoute(
                                //   builder: (context) =>
                                ResetPasswordScreen(),
                                // ),
                              );
                            } else {
                              Navigator.pop(context);
                              Get.toNamed(FluroRouters.resetPasswordScreen);
                              /* Routemaster.of(context).push(
                          AppRoute.resetPasswordScreen,
                        );*/
                            }
                          },
                          focusNode: controller.focus3,
                          child: Text(
                            Strings.forgotPassword,
                            style: TextStyle(
                              color: appTheme.blueGray700,
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400,
                            ),

                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height:kIsWeb?20: 35),
                    Shortcuts(
                      shortcuts: {
                        LogicalKeySet(LogicalKeyboardKey.tab): LoginButton(),
                      },
                      child: Actions(
                          actions: {
                            LoginButton: CallbackAction<LoginButton>(onInvoke: (_) {
                              controller.focus4.unfocus();
                              FocusScope.of(context).requestFocus(controller.focus5);
                            }),
                          },
                          child: Container(
                            width: Get.width,
                            child: RawKeyboardListener(
                              focusNode: controller.LoginFocusNode,
                              onKey: (RawKeyEvent event) async {
                                if (event.logicalKey == LogicalKeyboardKey.enter) {
                                  if (email.isNotEmpty && password.isNotEmpty) {
                                    if (formKey.currentState.validate()) {
                                      DialogBuilder(context).showLoadingIndicator();
                                      // print("Print me");
                                      if (kIsWeb) {
                                        bool _isNotABot =
                                        await RecaptchaService.isNotABot();

                                        if (!_isNotABot) {
                                          Fluttertoast.showToast(
                                              msg:
                                              Strings.itSeemsLikeYouAreARobot,
                                              toastLength: Toast.LENGTH_SHORT,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 1,
                                              backgroundColor: Colors.red,
                                              textColor: Colors.white,
                                              fontSize: 16.0);
                                          DialogBuilder(context).hideOpenDialog();
                                          return;
                                        }
                                      }

                                      /*   showDialog(
                              // barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    backgroundColor:
                                    Color(0xFFFFFFFF).withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding: EdgeInsets.zero,
                                    content: Container(
                                      height: 100,
                                      width: 80,
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                        children: [
                                          SpinKitCircle(
                                            color: Theme.of(context).primaryColor,
                                            size: 50.0,
                                          ),
                                          Text(
                                            Strings.pleaseWait,
                                            style: TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  );
                                });*/
                                      // if(!isCaptchaSelected){
                                      //   Fluttertoast.showToast(
                                      //       msg: 'Please check the captcha',
                                      //       toastLength: Toast.LENGTH_SHORT,
                                      //       gravity: ToastGravity.CENTER,
                                      //       timeInSecForIosWeb: 1,
                                      //       backgroundColor: Colors.red,
                                      //       textColor: Colors.white,
                                      //       fontSize: 16.0);
                                      //   return;
                                      // }

                                      var response = await controller
                                          .login(queryParameters: {
                                        "email": controller.email.text,
                                        "password": controller.password.text
                                      }, token: {
                                        "Authorization": " Bearer ${Url.webAPIKey}"
                                      });

                                      var jsonResponse =
                                      jsonDecode(response.toString());
                                      // print("jsonResponse $jsonResponse");

                                      var responseCode = jsonResponse['meta']['code'];
                                      var responseMessage =
                                      jsonResponse['meta']['message'];
                                      var userName = jsonResponse['data']['username'];
                                      var token = jsonResponse['data']['token'];
                                      var userId = jsonResponse['data']['id'];
                                      var email = jsonResponse['data']['email'];
                                      shared = await SharedPreferences.getInstance();
                                      if (responseCode == 200) {
                                        Get.find<AccountLockoutController>().resetAttemptTime();
                                        Get.find<AccountLockoutController>().resetAttempts();
                                        controller.updateInitialWelcomeMsg(true);


                                        shared.setString("email", email.toString());

                                        shared.setString("token", token.toString());
                                        shared.setString(
                                            "userName", userName.toString());
                                        shared.setBool('guestUser', true);
                                        shared.setBool('socialLogin', false);
                                        storage.write('id', userId);
                                        storage.write("token", token.toString());
                                        storage.write("email", email.toString());

                                        storage.write(
                                            "CurrentEmail", controller.email.text);

                                        storage.write(
                                            "userName", userName.toString());

                                        storage.write("remember", isCheckedGlobal);

                                        controller.email.clear();
                                        controller.password.clear();
                                        controller.generateFCMToken(context);
                                        //  NewsfeedController newsfeedController;
                                        // newsfeedController=
                                        if (Get.isRegistered<NewsfeedController>()) {
                                          Get.delete<NewsfeedController>();
                                          if (kDebugMode) {
                                            print(
                                                'newfees controller is removed at login  controller1');
                                          }
                                          Get.put(NewsfeedController(
                                            linkId: controller.postId != null
                                                ? controller.postId
                                                : null,
                                            profileId: controller.profileId != null
                                                ? controller.profileId
                                                : null,
                                          ));
                                        } else {
                                          Get.put(NewsfeedController(
                                            linkId: controller.postId != null
                                                ? controller.postId
                                                : null,
                                            profileId: controller.profileId != null
                                                ? controller.profileId
                                                : null,
                                          ));
                                          if (kDebugMode) {

                                          }
                                        }

                                        // newsfeedController .languageData= await newsfeedController.getLanguages();
                                        Get.find<NewsfeedController>().languageData =
                                        await Get.find<NewsfeedController>()
                                            .getLanguages();
                                        int index = Get.find<NewsfeedController>()
                                            .languagesList
                                            .indexWhere((element) {
                                          return Get.find<NewsfeedController>()
                                              .languageData
                                              .appLang
                                              .id ==
                                              element.id;
                                        });

                                        int index2 = Get.find<NewsfeedController>()
                                            .translationLanguage
                                            .indexWhere((element) {
                                          return Get.find<NewsfeedController>()
                                              .languageData
                                              .myLang
                                              .id ==
                                              element.id;
                                        });

                                        Get.find<NewsfeedController>().dropdownValue =
                                        Get.find<NewsfeedController>()
                                            .languagesList[index];

                                        Get.find<NewsfeedController>()
                                            .dropdownValue1 =
                                        Get.find<NewsfeedController>()
                                            .translationLanguage[index2];

                                        // print("idhr sdfsdf");

                                        // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                        //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                        //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                        //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                        // );
                                        //
                                        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                        Get.find<NewsfeedController>()
                                            .selectedAppLanguageInfoId =
                                            Get.find<NewsfeedController>()
                                                .languageData
                                                .appLang
                                                .id;

                                        Get.find<NewsfeedController>().upDateLocale(
                                            Get.find<NewsfeedController>()
                                                .languageData
                                                .appLang
                                                .code);
                                        Get.find<NewsfeedController>().update();

                                        if (kIsWeb) {
                                          if (id == 2) {
                                            SingleTone.instance.socialLogin = false;
                                            DialogBuilder(context).hideOpenDialog();

                                            // Navigator.pop(context);
                                            // Routemaster.of(context).pop();

                                            String userName =
                                            shared.getString("userName");
                                            // print({
                                            //   "userName on mainScreen :  $userName"
                                            // });
                                            // print(
                                            //     'postsid:${controller.postId}');
                                            // print(
                                            //     'profileId:${controller.profileId}');
                                            Get.offNamed(FluroRouters.mainScreen);

                                            // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                            //
                                            //
                                            //   "userName": shared.getString("userName"),
                                            //   "postId": controller.postId != null
                                            //       ? controller.postId
                                            //       : null,
                                            //   "profileId": controller.profileId != null
                                            //       ? controller.profileId
                                            //       : null
                                            // });
                                          } else {
                                            SingleTone.instance.socialLogin = false;
                                            // Routemaster.of(context).pop();
                                            // Navigator.pop(context);
                                            DialogBuilder(context).hideOpenDialog();

                                            String userName =
                                            shared.getString("userName");
                                            // print({
                                            //   "userName on mainScreen :  $userName"
                                            // });
                                            // print(
                                            //     'postsid:${controller.postId}');
                                            // print(
                                            //     'profileId:${controller.profileId}');
                                            Get.offNamed(FluroRouters.mainScreen);

                                            // Routemaster.of(context).replace(
                                            //     AppRoute.mainScreen, queryParameters: {
                                            //
                                            //
                                            //   "userName": shared.getString("userName"),
                                            //   "postId": controller.postId != null
                                            //       ? controller.postId
                                            //       : null,
                                            //   "profileId": controller.profileId != null
                                            //       ? controller.profileId
                                            //       : null
                                            // });
                                          }
                                        } else {
                                          SingleTone.instance.socialLogin = false;
                                          // Get.back();
                                          DialogBuilder(context).hideOpenDialog();

                                          Get.offAll(MainScreen(isLoggedInFromPosh: true,), arguments: {
                                            "userName": shared.getString("userName"),
                                            "postId": controller.postId != null
                                                ? controller.postId
                                                : null,
                                            "profileId": controller.profileId != null
                                                ? controller.profileId
                                                : null
                                          });
                                        }

                                        // Get.offAll(MainScreen(
                                        //   userName: shared.getString("userName"),
                                        //   postId: controller.postId != null
                                        //       ? controller.postId
                                        //       : null,
                                        //   profileId: controller.profileId != null
                                        //       ? controller.profileId
                                        //       : null,
                                        // ));
                                        // Navigator.of(context).pushAndRemoveUntil(
                                        //     MaterialPageRoute(
                                        //         builder: (context) => MainScreen(
                                        //               userName: userName,
                                        //               postId: controller.postId != null
                                        //                   ? controller.postId
                                        //                   : null,
                                        //               profileId: controller.profileId != null
                                        //                   ? controller.profileId
                                        //                   : null,
                                        //             )),
                                        //     (Route<dynamic> route) => false);
                                        // Navigator.push(
                                        //   context,
                                        //   MaterialPageRoute(
                                        //     builder: (BuildContext context) =>
                                        //         MainScreen(userName: userName),
                                        // ),
                                        // );
                                      } else if (responseCode == 204) {
                                        DialogBuilder(context).hideOpenDialog();
                                        Fluttertoast.showToast(
                                            msg: responseMessage,
                                            toastLength: Toast.LENGTH_LONG,
                                            timeInSecForIosWeb: 5);
                                        Navigator.pop(context);
                                        showDialog(
                                          context: context,
                                          builder: (context) => OtpDialog(
                                            onSubmit: (otp) async {
                                              DialogBuilder(context)
                                                  .showLoadingIndicator();

                                              var response = await controller
                                                  .login(queryParameters: {
                                                "email": controller.email.text,
                                                "password": controller.password.text,
                                                "code": otp
                                              }, token: {
                                                "Authorization":
                                                " Bearer ${Url.webAPIKey}"
                                              });
                                              var jsonResponse =
                                              jsonDecode(response.toString());

                                              // print("jsonResponse $jsonResponse");

                                              var responseCode =
                                              jsonResponse['meta']['code'];
                                              var responseMessage =
                                              jsonResponse['meta']['message'];
                                              var userName =
                                              jsonResponse['data']['username'];
                                              var token =
                                              jsonResponse['data']['token'];
                                              var userId = jsonResponse['data']['id'];

                                              var email =
                                              jsonResponse['data']['email'];

                                              DialogBuilder(context).hideOpenDialog();

                                              if (responseCode == 200) {
                                                shared.setString(
                                                    "token", token.toString());
                                                shared.setString(
                                                    "userName", userName.toString());

                                                shared.setString(
                                                    "email", email.toString());

                                                storage.write(
                                                    "email", email.toString());

                                                shared.setBool('guestUser', true);
                                                shared.setBool('socialLogin', false);
                                                storage.write('id', userId);
                                                storage.write(
                                                    "token", token.toString());

                                                storage.write("CurrentEmail",
                                                    controller.email.text);
                                                storage.write(
                                                    "userName", userName.toString());

                                                storage.write(
                                                    "remember", isCheckedGlobal);

                                                controller.email.clear();
                                                controller.password.clear();
                                                controller.generateFCMToken(context);
                                                if (Get.isRegistered<
                                                    NewsfeedController>()) {
                                                  Get.delete<NewsfeedController>();
                                                  if (kDebugMode) {
                                                    print(
                                                        'newfees controller is removed at login  controller0');
                                                  }
                                                  Get.put(NewsfeedController(
                                                    linkId: controller.postId != null
                                                        ? controller.postId
                                                        : null,
                                                    profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                                  ));
                                                } else {
                                                  Get.put(NewsfeedController(
                                                    linkId: controller.postId != null
                                                        ? controller.postId
                                                        : null,
                                                    profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                                  ));
                                                  if (kDebugMode) {
                                                    print(
                                                        'newfees controller is initalized at login  controller0');
                                                  }
                                                }

                                                // Get.put(NewsfeedController(
                                                //   linkId: controller.postId != null ? controller.postId : null,
                                                //   profileId: controller.profileId != null ? controller.profileId : null,
                                                // ));

                                                Get.find<NewsfeedController>()
                                                    .languageData = await Get.find<
                                                    NewsfeedController>()
                                                    .getLanguages();
                                                int index =
                                                Get.find<NewsfeedController>()
                                                    .languagesList
                                                    .indexWhere((element) {
                                                  return Get.find<
                                                      NewsfeedController>()
                                                      .languageData
                                                      .appLang
                                                      .id ==
                                                      element.id;
                                                });

                                                int index2 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage
                                                    .indexWhere((element) {
                                                  return Get.find<
                                                      NewsfeedController>()
                                                      .languageData
                                                      .myLang
                                                      .id ==
                                                      element.id;
                                                });

                                                Get.find<NewsfeedController>()
                                                    .dropdownValue =
                                                Get.find<NewsfeedController>()
                                                    .languagesList[index];

                                                Get.find<NewsfeedController>()
                                                    .dropdownValue1 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage[index2];

                                                // print("idhr sdfsdf");

                                                // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                                //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                                //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                                //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                                // );
                                                //
                                                // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                                // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                                // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                                Get.find<NewsfeedController>()
                                                    .selectedAppLanguageInfoId =
                                                    Get.find<NewsfeedController>()
                                                        .languageData
                                                        .appLang
                                                        .id;

                                                Get.find<NewsfeedController>()
                                                    .upDateLocale(
                                                    Get.find<NewsfeedController>()
                                                        .languageData
                                                        .appLang
                                                        .code);
                                                Get.find<NewsfeedController>()
                                                    .update();

                                                if (kIsWeb) {
                                                  if (id == 2) {
                                                    SingleTone.instance.socialLogin =
                                                    false;

                                                    Get.offNamed(
                                                        FluroRouters.mainScreen);

                                                    // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                    //
                                                    //
                                                    //   "userName": shared.getString("userName"),
                                                    //   "postId": controller.postId != null
                                                    //       ? controller.postId
                                                    //       : null,
                                                    //   "profileId": controller.profileId != null
                                                    //       ? controller.profileId
                                                    //       : null
                                                    // });
                                                  } else {
                                                    SingleTone.instance.socialLogin =
                                                    false;
                                                    Navigator.pop(context);

                                                    Get.offNamed(
                                                        FluroRouters.mainScreen);

                                                    // Routemaster.of(context).replace(
                                                    //     AppRoute.mainScreen, queryParameters: {
                                                    //
                                                    //
                                                    //   "userName": shared.getString("userName"),
                                                    //   "postId": controller.postId != null
                                                    //       ? controller.postId
                                                    //       : null,
                                                    //   "profileId": controller.profileId != null
                                                    //       ? controller.profileId
                                                    //       : null
                                                    // });
                                                  }
                                                } else {
                                                  SingleTone.instance.socialLogin =
                                                  false;
                                                  Get.back();
                                                  Get.offAll(MainScreen(),
                                                      arguments: {
                                                        "userName": shared
                                                            .getString("userName"),
                                                        "postId":
                                                        controller.postId != null
                                                            ? controller.postId
                                                            : null,
                                                        "profileId":
                                                        controller.profileId !=
                                                            null
                                                            ? controller.profileId
                                                            : null
                                                      });
                                                }

                                                // Get.offAll(MainScreen(
                                                //   userName: shared.getString("userName"),
                                                //   postId: controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   profileId: controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null,
                                                // ));
                                                // Navigator.of(context).pushAndRemoveUntil(
                                                //     MaterialPageRoute(
                                                //         builder: (context) => MainScreen(
                                                //               userName: userName,
                                                //               postId: controller.postId != null
                                                //                   ? controller.postId
                                                //                   : null,
                                                //               profileId: controller.profileId != null
                                                //                   ? controller.profileId
                                                //                   : null,
                                                //             )),
                                                //     (Route<dynamic> route) => false);
                                                // Navigator.push(
                                                //   context,
                                                //   MaterialPageRoute(
                                                //     builder: (BuildContext context) =>
                                                //         MainScreen(userName: userName),
                                                // ),
                                                // );
                                              } else if (responseCode == 204) {
                                                Fluttertoast.showToast(
                                                    msg: responseMessage,
                                                    toastLength: Toast.LENGTH_LONG,
                                                    timeInSecForIosWeb: 5);
                                              } else if (responseCode == 205) {
                                                Fluttertoast.showToast(
                                                    msg: responseMessage,
                                                    toastLength: Toast.LENGTH_LONG,
                                                    timeInSecForIosWeb: 5);
                                              } else {
                                                Navigator.of(context).pop();

                                                customDialog(
                                                  context,
                                                  isSuccess: true,
                                                  message: Strings
                                                      .emailOrPasswordIsIncorrect,
                                                );
                                              }
                                            },
                                          ),
                                        );
                                      } else if (responseCode == 205) {
                                        Fluttertoast.showToast(
                                            msg: responseMessage,
                                            toastLength: Toast.LENGTH_LONG,
                                            timeInSecForIosWeb: 5);
                                      }  else if(responseCode == 405){
                                        DialogBuilder(context)
                                            .hideOpenDialog();
                                        Fluttertoast.showToast(
                                            msg:
                                            responseMessage,
                                            toastLength: Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.BOTTOM,
                                            timeInSecForIosWeb: 5,
                                            backgroundColor: Colors.red,
                                            textColor: Colors.white,
                                            webBgColor: "linear-gradient(to right, #FF0000FF, #FF0000FF)",
                                            webPosition: "center",
                                            fontSize: kIsWeb ? 18 : 16.0);
                                      } else {
                                        lockAccount(controller.email.text);
                                        Navigator.of(context).pop();

                                        customDialog(
                                          context,
                                          isSuccess: true,
                                          message: Strings.emailOrPasswordIsIncorrect,
                                        );
                                      }
                                    }
                                  }
                                  else {
                                    setState(() {
                                      errorText = true;
                                    });
                                  }
                                }

                              },
                              child: kIsWeb
                                  ?
                              CustomElevatedButton(
                                onPressed: ()async {
                                  {
                                    if (email.isNotEmpty &&
                                        password.isNotEmpty) {
                                       if (formKey.currentState.validate())
                                      {
                                        DialogBuilder(context)
                                            .showLoadingIndicator();
                                        // print("Print me 2");
                                        if (kIsWeb) {
                                          bool _isNotABot =
                                          await RecaptchaService
                                              .isNotABot();

                                          if (!_isNotABot) {
                                            Fluttertoast.showToast(
                                                msg:Strings.itSeemsLikeYouAreARobot,
                                                toastLength: Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 1,
                                                backgroundColor: Colors.red,
                                                textColor: Colors.white,
                                                fontSize: 16.0);
                                            DialogBuilder(context)
                                                .hideOpenDialog();
                                            return;
                                          }
                                        }

                                        /*   showDialog(
                              // barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    backgroundColor:
                                    Color(0xFFFFFFFF).withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding: EdgeInsets.zero,
                                    content: Container(
                                      height: 100,
                                      width: 80,
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                        children: [
                                          SpinKitCircle(
                                            color: Theme.of(context).primaryColor,
                                            size: 50.0,
                                          ),
                                          Text(
                                            Strings.pleaseWait,
                                            style: TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  );
                                });*/
                                        // if(!isCaptchaSelected){
                                        //   Fluttertoast.showToast(
                                        //       msg: 'Please check the captcha',
                                        //       toastLength: Toast.LENGTH_SHORT,
                                        //       gravity: ToastGravity.CENTER,
                                        //       timeInSecForIosWeb: 1,
                                        //       backgroundColor: Colors.red,
                                        //       textColor: Colors.white,
                                        //       fontSize: 16.0);
                                        //   return;
                                        // }

                                        var response = await controller
                                            .login(queryParameters: {
                                          "email": controller.email.text,
                                          "password": controller.password.text
                                        }, token: {
                                          "Authorization":
                                          " Bearer ${Url.webAPIKey}"
                                        });

                                        var jsonResponse =
                                        jsonDecode(response.toString());
                                        // print("jsonResponse $jsonResponse");

                                        var responseCode =
                                        jsonResponse['meta']['code'];
                                        var responseMessage =
                                        jsonResponse['meta']['message'];
                                        var userName =
                                        jsonResponse['data']['username'];
                                        var token =
                                        jsonResponse['data']['token'];
                                        var userId = jsonResponse['data']['id'];
                                        var email =
                                        jsonResponse['data']['email'];
                                        shared = await SharedPreferences
                                            .getInstance();
                                        if (responseCode == 200) {
                                          controller
                                              .updateInitialWelcomeMsg(true);
                                          Get.find<AccountLockoutController>().resetAttemptTime();
                                          Get.find<AccountLockoutController>().resetAttempts();


                                          shared.setString(
                                              "email", email.toString());

                                          shared.setString(
                                              "token", token.toString());
                                          shared.setString(
                                              "userName", userName.toString());
                                          shared.setBool('guestUser', true);
                                          shared.setBool('socialLogin', false);
                                          storage.write('id', userId);
                                          storage.write(
                                              "token", token.toString());
                                          storage.write(
                                              "email", email.toString());

                                          storage.write("CurrentEmail",
                                              controller.email.text);

                                          storage.write(
                                              "userName", userName.toString());

                                          storage.write(
                                              "remember", isCheckedGlobal);

                                          controller.email.clear();
                                          controller.password.clear();
                                          controller.generateFCMToken(context);
                                          //  NewsfeedController newsfeedController;
                                          // newsfeedController=
                                          if (Get.isRegistered<
                                              NewsfeedController>()) {
                                            Get.delete<NewsfeedController>();
                                            if (kDebugMode) {
                                              print(
                                                  'newfees controller is removed at login  controller1');
                                            }
                                            Get.put(NewsfeedController(
                                              linkId: controller.postId != null
                                                  ? controller.postId
                                                  : null,
                                              profileId:
                                              controller.profileId != null
                                                  ? controller.profileId
                                                  : null,
                                            ));
                                          } else {
                                            Get.put(NewsfeedController(
                                              linkId: controller.postId != null
                                                  ? controller.postId
                                                  : null,
                                              profileId:
                                              controller.profileId != null
                                                  ? controller.profileId
                                                  : null,
                                            ));

                                          }

                                          // newsfeedController .languageData= await newsfeedController.getLanguages();
                                          Get.find<NewsfeedController>()
                                              .languageData = await Get.find<
                                              NewsfeedController>()
                                              .getLanguages();
                                          int index =
                                          Get.find<NewsfeedController>()
                                              .languagesList
                                              .indexWhere((element) {
                                            return Get.find<
                                                NewsfeedController>()
                                                .languageData
                                                .appLang
                                                .id ==
                                                element.id;
                                          });

                                          int index2 =
                                          Get.find<NewsfeedController>()
                                              .translationLanguage
                                              .indexWhere((element) {
                                            return Get.find<
                                                NewsfeedController>()
                                                .languageData
                                                .myLang
                                                .id ==
                                                element.id;
                                          });

                                          Get.find<NewsfeedController>()
                                              .dropdownValue =
                                          Get.find<NewsfeedController>()
                                              .languagesList[index];

                                          Get.find<NewsfeedController>()
                                              .dropdownValue1 =
                                          Get.find<NewsfeedController>()
                                              .translationLanguage[index2];

                                          // print("idhr sdfsdf");

                                          // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                          //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                          //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                          //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                          // );
                                          //
                                          // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                          // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                          // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                          Get.find<NewsfeedController>()
                                              .selectedAppLanguageInfoId =
                                              Get.find<NewsfeedController>()
                                                  .languageData
                                                  .appLang
                                                  .id;

                                          Get.find<NewsfeedController>()
                                              .upDateLocale(
                                              Get.find<NewsfeedController>()
                                                  .languageData
                                                  .appLang
                                                  .code);
                                          Get.find<NewsfeedController>()
                                              .update();

                                          if (kIsWeb) {
                                            if (id == 2) {
                                              SingleTone.instance.socialLogin =
                                              false;
                                              DialogBuilder(context)
                                                  .hideOpenDialog();

                                              // Navigator.pop(context);
                                              // Routemaster.of(context).pop();

                                              String userName =
                                              shared.getString("userName");
                                              // print({
                                              //   "userName on mainScreen :  $userName"
                                              // });
                                              // print(
                                              //     'postsid:${controller.postId}');
                                              // print(
                                              //     'profileId:${controller.profileId}');
                                              Get.offNamed(
                                                  FluroRouters.mainScreen);

                                              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                              //
                                              //
                                              //   "userName": shared.getString("userName"),
                                              //   "postId": controller.postId != null
                                              //       ? controller.postId
                                              //       : null,
                                              //   "profileId": controller.profileId != null
                                              //       ? controller.profileId
                                              //       : null
                                              // });
                                            } else {
                                              SingleTone.instance.socialLogin =
                                              false;
                                              // Routemaster.of(context).pop();
                                              // Navigator.pop(context);
                                              DialogBuilder(context)
                                                  .hideOpenDialog();

                                              String userName =
                                              shared.getString("userName");
                                              // print({
                                              //   "userName on mainScreen :  $userName"
                                              // });
                                              // print(
                                              //     'postsid:${controller.postId}');
                                              // print(
                                              //     'profileId:${controller.profileId}');
                                              Get.offNamed(
                                                  FluroRouters.mainScreen);

                                              // Routemaster.of(context).replace(
                                              //     AppRoute.mainScreen, queryParameters: {
                                              //
                                              //
                                              //   "userName": shared.getString("userName"),
                                              //   "postId": controller.postId != null
                                              //       ? controller.postId
                                              //       : null,
                                              //   "profileId": controller.profileId != null
                                              //       ? controller.profileId
                                              //       : null
                                              // });
                                            }
                                          } else {
                                            SingleTone.instance.socialLogin =
                                            false;
                                            // Get.back();
                                            DialogBuilder(context)
                                                .hideOpenDialog();

                                            Get.offAll(MainScreen(),
                                                arguments: {
                                                  "userName": shared
                                                      .getString("userName"),
                                                  "postId":
                                                  controller.postId != null
                                                      ? controller.postId
                                                      : null,
                                                  "profileId":
                                                  controller.profileId !=
                                                      null
                                                      ? controller.profileId
                                                      : null
                                                });
                                          }

                                          // Get.offAll(MainScreen(
                                          //   userName: shared.getString("userName"),
                                          //   postId: controller.postId != null
                                          //       ? controller.postId
                                          //       : null,
                                          //   profileId: controller.profileId != null
                                          //       ? controller.profileId
                                          //       : null,
                                          // ));
                                          // Navigator.of(context).pushAndRemoveUntil(
                                          //     MaterialPageRoute(
                                          //         builder: (context) => MainScreen(
                                          //               userName: userName,
                                          //               postId: controller.postId != null
                                          //                   ? controller.postId
                                          //                   : null,
                                          //               profileId: controller.profileId != null
                                          //                   ? controller.profileId
                                          //                   : null,
                                          //             )),
                                          //     (Route<dynamic> route) => false);
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (BuildContext context) =>
                                          //         MainScreen(userName: userName),
                                          // ),
                                          // );
                                        } else if (responseCode == 204) {
                                          DialogBuilder(context)
                                              .hideOpenDialog();
                                          Fluttertoast.showToast(
                                              msg: responseMessage,
                                              toastLength: Toast.LENGTH_LONG,
                                              timeInSecForIosWeb: 5);
                                          Navigator.pop(context);
                                          showDialog(
                                            context: context,
                                            builder: (context) => OtpDialog(
                                              onSubmit: (otp) async {
                                                DialogBuilder(context)
                                                    .showLoadingIndicator();

                                                var response = await controller
                                                    .login(queryParameters: {
                                                  "email":
                                                  controller.email.text,
                                                  "password":
                                                  controller.password.text,
                                                  "code": otp
                                                }, token: {
                                                  "Authorization":
                                                  " Bearer ${Url.webAPIKey}"
                                                });
                                                var jsonResponse = jsonDecode(
                                                    response.toString());


                                                var responseCode =
                                                jsonResponse['meta']
                                                ['code'];
                                                var responseMessage =
                                                jsonResponse['meta']
                                                ['message'];
                                                var userName =
                                                jsonResponse['data']
                                                ['username'];
                                                var token = jsonResponse['data']
                                                ['token'];
                                                var userId =
                                                jsonResponse['data']['id'];

                                                var email = jsonResponse['data']
                                                ['email'];

                                                DialogBuilder(context)
                                                    .hideOpenDialog();

                                                if (responseCode == 200) {
                                                  shared.setString("token",
                                                      token.toString());
                                                  shared.setString("userName",
                                                      userName.toString());

                                                  shared.setString("email",
                                                      email.toString());

                                                  storage.write("email",
                                                      email.toString());

                                                  shared.setBool(
                                                      'guestUser', true);
                                                  shared.setBool(
                                                      'socialLogin', false);
                                                  storage.write('id', userId);
                                                  storage.write("token",
                                                      token.toString());

                                                  storage.write("CurrentEmail",
                                                      controller.email.text);
                                                  storage.write("userName",
                                                      userName.toString());

                                                  storage.write("remember",
                                                      isCheckedGlobal);

                                                  controller.email.clear();
                                                  controller.password.clear();
                                                  controller.generateFCMToken(
                                                      context);
                                                  if (Get.isRegistered<
                                                      NewsfeedController>()) {
                                                    Get.delete<
                                                        NewsfeedController>();
                                                    if (kDebugMode) {
                                                      print(
                                                          'newfees controller is removed at login  controller0');
                                                    }
                                                    Get.put(NewsfeedController(
                                                      linkId: controller
                                                          .postId !=
                                                          null
                                                          ? controller.postId
                                                          : null,
                                                      profileId: controller
                                                          .profileId !=
                                                          null
                                                          ? controller.profileId
                                                          : null,
                                                    ));
                                                  } else {
                                                    Get.put(NewsfeedController(
                                                      linkId: controller
                                                          .postId !=
                                                          null
                                                          ? controller.postId
                                                          : null,
                                                      profileId: controller
                                                          .profileId !=
                                                          null
                                                          ? controller.profileId
                                                          : null,
                                                    ));
                                                    if (kDebugMode) {
                                                      print(
                                                          'newfees controller is initalized at login  controller0');
                                                    }
                                                  }

                                                  // Get.put(NewsfeedController(
                                                  //   linkId: controller.postId != null ? controller.postId : null,
                                                  //   profileId: controller.profileId != null ? controller.profileId : null,
                                                  // ));

                                                  Get.find<NewsfeedController>()
                                                      .languageData =
                                                  await Get.find<
                                                      NewsfeedController>()
                                                      .getLanguages();
                                                  int index = Get.find<
                                                      NewsfeedController>()
                                                      .languagesList
                                                      .indexWhere((element) {
                                                    return Get.find<
                                                        NewsfeedController>()
                                                        .languageData
                                                        .appLang
                                                        .id ==
                                                        element.id;
                                                  });

                                                  int index2 = Get.find<
                                                      NewsfeedController>()
                                                      .translationLanguage
                                                      .indexWhere((element) {
                                                    return Get.find<
                                                        NewsfeedController>()
                                                        .languageData
                                                        .myLang
                                                        .id ==
                                                        element.id;
                                                  });

                                                  Get.find<NewsfeedController>()
                                                      .dropdownValue = Get.find<
                                                      NewsfeedController>()
                                                      .languagesList[index];

                                                  Get.find<NewsfeedController>()
                                                      .dropdownValue1 = Get.find<
                                                      NewsfeedController>()
                                                      .translationLanguage[index2];

                                                  // print("idhr sdfsdf");

                                                  // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                                  //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                                  //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                                  //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                                  // );
                                                  //
                                                  // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                                  // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                                  // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                                  Get.find<NewsfeedController>()
                                                      .selectedAppLanguageInfoId =
                                                      Get.find<
                                                          NewsfeedController>()
                                                          .languageData
                                                          .appLang
                                                          .id;

                                                  Get.find<NewsfeedController>()
                                                      .upDateLocale(Get.find<
                                                      NewsfeedController>()
                                                      .languageData
                                                      .appLang
                                                      .code);
                                                  Get.find<NewsfeedController>()
                                                      .update();

                                                  if (kIsWeb) {
                                                    if (id == 2) {
                                                      SingleTone.instance
                                                          .socialLogin = false;

                                                      Get.offNamed(FluroRouters
                                                          .mainScreen);

                                                      // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                      //
                                                      //
                                                      //   "userName": shared.getString("userName"),
                                                      //   "postId": controller.postId != null
                                                      //       ? controller.postId
                                                      //       : null,
                                                      //   "profileId": controller.profileId != null
                                                      //       ? controller.profileId
                                                      //       : null
                                                      // });
                                                    } else {
                                                      SingleTone.instance
                                                          .socialLogin = false;
                                                      Navigator.pop(context);

                                                      Get.offNamed(FluroRouters
                                                          .mainScreen);

                                                      // Routemaster.of(context).replace(
                                                      //     AppRoute.mainScreen, queryParameters: {
                                                      //
                                                      //
                                                      //   "userName": shared.getString("userName"),
                                                      //   "postId": controller.postId != null
                                                      //       ? controller.postId
                                                      //       : null,
                                                      //   "profileId": controller.profileId != null
                                                      //       ? controller.profileId
                                                      //       : null
                                                      // });
                                                    }
                                                  } else {
                                                    SingleTone.instance
                                                        .socialLogin = false;
                                                    Get.back();
                                                    Get.offAll(MainScreen(),
                                                        arguments: {
                                                          "userName":
                                                          shared.getString(
                                                              "userName"),
                                                          "postId": controller
                                                              .postId !=
                                                              null
                                                              ? controller
                                                              .postId
                                                              : null,
                                                          "profileId": controller
                                                              .profileId !=
                                                              null
                                                              ? controller
                                                              .profileId
                                                              : null
                                                        });
                                                  }

                                                  // Get.offAll(MainScreen(
                                                  //   userName: shared.getString("userName"),
                                                  //   postId: controller.postId != null
                                                  //       ? controller.postId
                                                  //       : null,
                                                  //   profileId: controller.profileId != null
                                                  //       ? controller.profileId
                                                  //       : null,
                                                  // ));
                                                  // Navigator.of(context).pushAndRemoveUntil(
                                                  //     MaterialPageRoute(
                                                  //         builder: (context) => MainScreen(
                                                  //               userName: userName,
                                                  //               postId: controller.postId != null
                                                  //                   ? controller.postId
                                                  //                   : null,
                                                  //               profileId: controller.profileId != null
                                                  //                   ? controller.profileId
                                                  //                   : null,
                                                  //             )),
                                                  //     (Route<dynamic> route) => false);
                                                  // Navigator.push(
                                                  //   context,
                                                  //   MaterialPageRoute(
                                                  //     builder: (BuildContext context) =>
                                                  //         MainScreen(userName: userName),
                                                  // ),
                                                  // );
                                                } else if (responseCode ==
                                                    204) {
                                                  Fluttertoast.showToast(
                                                      msg: responseMessage,
                                                      toastLength:
                                                      Toast.LENGTH_LONG,
                                                      timeInSecForIosWeb: 5);
                                                } else if (responseCode ==
                                                    205) {
                                                  Fluttertoast.showToast(
                                                      msg: responseMessage,
                                                      toastLength:
                                                      Toast.LENGTH_LONG,
                                                      timeInSecForIosWeb: 5);
                                                } else {
                                                  Navigator.of(context).pop();

                                                  customDialog(
                                                    context,
                                                    isSuccess: true,
                                                    message: Strings
                                                        .emailOrPasswordIsIncorrect,
                                                  );
                                                }
                                              },
                                            ),
                                          );
                                        } else if (responseCode == 205) {
                                          Fluttertoast.showToast(
                                              msg: responseMessage,
                                              toastLength: Toast.LENGTH_LONG,
                                              timeInSecForIosWeb: 5);
                                        } else if(responseCode == 405){
                                          DialogBuilder(context)
                                              .hideOpenDialog();
                                          Fluttertoast.showToast(
                                              msg:
                                              responseMessage,
                                              toastLength: Toast.LENGTH_SHORT,
                                              gravity: ToastGravity.BOTTOM,
                                              timeInSecForIosWeb: 5,
                                              backgroundColor: Colors.red,
                                              textColor: Colors.white,
                                              webBgColor: "linear-gradient(to right, #FF0000FF, #FF0000FF)",
                                              webPosition: "center",
                                              fontSize: kIsWeb ? 18 : 16.0);
                                        } else {
                                          Navigator.of(context).pop();
                                          lockAccount(controller.email.text);

                                          customDialog(
                                            context,
                                            isSuccess: true,
                                            message: Strings
                                                .emailOrPasswordIsIncorrect,
                                          );
                                        }
                                      }
                                    } else {
                                      setState(() {
                                        errorText = true;
                                      });
                                    }
                                  }
                                },
                                text:Strings.signIn ,
                                margin: const EdgeInsets.only(right: 1),
                              )

                                  : CustomElevatedButton(
                                onPressed: ()async {
                                  // var internetStatus=await UtilsMethods.checkInternet();
                                  // if(internetStatus!=true){
                                  //   UtilsMethods.toastMessageShow(Colors.red, Colors.red, Colors.red,
                                  //     message: Strings.noInternetAvailable,
                                  //   );
                                  // }
                                  // else{

                                  if (email.length != '' &&
                                      password.length != '') {
                                     if (formKey.currentState.validate())
                                    {
                                      DialogBuilder(context)
                                          .showLoadingIndicator();
                                      // print("Print me 3");
                                      if (kIsWeb) {
                                        bool _isNotABot =
                                        await RecaptchaService.isNotABot();

                                        if (!_isNotABot) {
                                          Fluttertoast.showToast(
                                              msg:
                                              Strings.itSeemsLikeYouAreARobot,
                                              toastLength: Toast.LENGTH_SHORT,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb: 1,
                                              backgroundColor: Colors.red,
                                              textColor: Colors.white,
                                              fontSize: 16.0);
                                          return;
                                        }
                                      }

                                      /*   showDialog(
                              // barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    backgroundColor:
                                    Color(0xFFFFFFFF).withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding: EdgeInsets.zero,
                                    content: Container(
                                      height: 100,
                                      width: 80,
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                        children: [
                                          SpinKitCircle(
                                            color: Theme.of(context).primaryColor,
                                            size: 50.0,
                                          ),
                                          Text(
                                            Strings.pleaseWait,
                                            style: TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  );
                                });*/

                                      //Uncomment for captcha mobile step 1
                                      // if (isCaptchaSelected == true) {
                                      var response = await controller
                                          .login(queryParameters: {
                                        "email": controller.email.text,
                                        "password": controller.password.text
                                      }, token: {
                                        "Authorization":
                                        " Bearer ${Url.webAPIKey}"
                                      });

                                      var jsonResponse =
                                      jsonDecode(response.toString());

                                      var responseCode =
                                      jsonResponse['meta']['code'];
                                      var responseMessage =
                                      jsonResponse['meta']['message'];
                                      var userName =
                                      jsonResponse['data']['username'];
                                      var token =
                                      jsonResponse['data']['token'];
                                      var userId = jsonResponse['data']['id'];
                                      var email =
                                      jsonResponse['data']['email'];
                                      shared = await SharedPreferences
                                          .getInstance();
                                      if (responseCode == 200) {
                                        Get.find<AccountLockoutController>().resetAttemptTime();
                                        Get.find<AccountLockoutController>().resetAttempts();
                                        controller
                                            .updateInitialWelcomeMsg(true);

                                        shared.setString(
                                            "email", email.toString());

                                        shared.setString(
                                            "token", token.toString());
                                        shared.setString(
                                            "userName", userName.toString());
                                        shared.setBool('guestUser', true);
                                        shared.setBool('socialLogin', false);
                                        storage.write('id', userId);
                                        storage.write(
                                            "token", token.toString());
                                        storage.write(
                                            "email", email.toString());

                                        storage.write("CurrentEmail",
                                            controller.email.text);

                                        storage.write(
                                            "userName", userName.toString());

                                        storage.write(
                                            "remember", isCheckedGlobal);

                                        controller.email.clear();
                                        controller.password.clear();
                                        controller.generateFCMToken(context);
                                        //  NewsfeedController newsfeedController;
                                        // newsfeedController=
                                        if (Get.isRegistered<
                                            NewsfeedController>()) {
                                          Get.delete<NewsfeedController>();
                                          if (kDebugMode) {
                                            print(
                                                'newfees controller is removed at login  controller1');
                                          }
                                          Get.put(NewsfeedController(
                                            linkId: controller.postId != null
                                                ? controller.postId
                                                : null,
                                            profileId:
                                            controller.profileId != null
                                                ? controller.profileId
                                                : null,
                                          ));
                                        } else {
                                          Get.put(NewsfeedController(
                                            linkId: controller.postId != null
                                                ? controller.postId
                                                : null,
                                            profileId:
                                            controller.profileId != null
                                                ? controller.profileId
                                                : null,
                                          ));

                                        }

                                        // newsfeedController .languageData= await newsfeedController.getLanguages();

                                        Get.find<NewsfeedController>()
                                            .languageData = await Get.find<
                                            NewsfeedController>()
                                            .getLanguages();
                                        int index =
                                        Get.find<NewsfeedController>()
                                            .languagesList
                                            .indexWhere((element) {
                                          return Get.find<
                                              NewsfeedController>()
                                              .languageData
                                              .appLang
                                              .id ==
                                              element.id;
                                        });

                                        int index2 =
                                        Get.find<NewsfeedController>()
                                            .translationLanguage
                                            .indexWhere((element) {
                                          return Get.find<
                                              NewsfeedController>()
                                              .languageData
                                              .myLang
                                              .id ==
                                              element.id;
                                        });

                                        Get.find<NewsfeedController>()
                                            .dropdownValue =
                                        Get.find<NewsfeedController>()
                                            .languagesList[index];

                                        Get.find<NewsfeedController>()
                                            .dropdownValue1 =
                                        Get.find<NewsfeedController>()
                                            .translationLanguage[index2];

                                        // print("idhr sdfsdf");

                                        // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                        //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                        //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                        //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                        // );
                                        //
                                        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                        Get.find<NewsfeedController>()
                                            .selectedAppLanguageInfoId =
                                            Get.find<NewsfeedController>()
                                                .languageData
                                                .appLang
                                                .id;

                                        String langCode = Get.find<NewsfeedController>().languageData.appLang.code;
                                        Get.find<NewsfeedController>()
                                            .upDateLocale(langCode);

                                        if (controller.selectedLanguage != null && controller.selectedLanguage.code != langCode){
                                          await Get.find<NewsfeedController>().languagesRequest(
                                              languageId: controller.selectedLanguage != null
                                                  ? controller.selectedLanguage.id.toString()
                                                  : 1.toString(),
                                              autoTranslate: 1.toString(),
                                              appLanguageId: controller.selectedLanguage.id,
                                              appLanguage: controller.selectedLanguage.name,
                                              appLanguageCode: controller.selectedLanguage.code);
                                        }

                                        Get.find<NewsfeedController>()
                                            .update();

                                        if (kIsWeb) {
                                          if (id == 2) {
                                            SingleTone.instance.socialLogin =
                                            false;
                                            DialogBuilder(context)
                                                .hideOpenDialog();

                                            // Navigator.pop(context);
                                            // Routemaster.of(context).pop();

                                            String userName =
                                            shared.getString("userName");
                                            // print({
                                            //   "userName on mainScreen :  $userName"
                                            // });
                                            // print(
                                            //     'postsid:${controller.postId}');
                                            // print(
                                            //     'profileId:${controller.profileId}');
                                            Get.offNamed(
                                                FluroRouters.mainScreen);

                                            // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                            //
                                            //
                                            //   "userName": shared.getString("userName"),
                                            //   "postId": controller.postId != null
                                            //       ? controller.postId
                                            //       : null,
                                            //   "profileId": controller.profileId != null
                                            //       ? controller.profileId
                                            //       : null
                                            // });
                                          } else {
                                            SingleTone.instance.socialLogin =
                                            false;
                                            // Routemaster.of(context).pop();
                                            // Navigator.pop(context);
                                            DialogBuilder(context)
                                                .hideOpenDialog();

                                            String userName =
                                            shared.getString("userName");
                                            // print({
                                            //   "userName on mainScreen :  $userName"
                                            // });
                                            // print(
                                            //     'postsid:${controller.postId}');
                                            // print(
                                            //     'profileId:${controller.profileId}');
                                            Get.offNamed(
                                                FluroRouters.mainScreen);

                                            // Routemaster.of(context).replace(
                                            //     AppRoute.mainScreen, queryParameters: {
                                            //
                                            //
                                            //   "userName": shared.getString("userName"),
                                            //   "postId": controller.postId != null
                                            //       ? controller.postId
                                            //       : null,
                                            //   "profileId": controller.profileId != null
                                            //       ? controller.profileId
                                            //       : null
                                            // });
                                          }
                                        } else {
                                          SingleTone.instance.socialLogin =
                                          false;
                                          // Get.back();
                                          DialogBuilder(context)
                                              .hideOpenDialog();

                                          Get.offAll(MainScreen(),
                                              arguments: {
                                                "userName": shared
                                                    .getString("userName"),
                                                "postId":
                                                controller.postId != null
                                                    ? controller.postId
                                                    : null,
                                                "profileId":
                                                controller.profileId !=
                                                    null
                                                    ? controller.profileId
                                                    : null
                                              });
                                        }

                                        // Get.offAll(MainScreen(
                                        //   userName: shared.getString("userName"),
                                        //   postId: controller.postId != null
                                        //       ? controller.postId
                                        //       : null,
                                        //   profileId: controller.profileId != null
                                        //       ? controller.profileId
                                        //       : null,
                                        // ));
                                        // Navigator.of(context).pushAndRemoveUntil(
                                        //     MaterialPageRoute(
                                        //         builder: (context) => MainScreen(
                                        //               userName: userName,
                                        //               postId: controller.postId != null
                                        //                   ? controller.postId
                                        //                   : null,
                                        //               profileId: controller.profileId != null
                                        //                   ? controller.profileId
                                        //                   : null,
                                        //             )),
                                        //     (Route<dynamic> route) => false);
                                        // Navigator.push(
                                        //   context,
                                        //   MaterialPageRoute(
                                        //     builder: (BuildContext context) =>
                                        //         MainScreen(userName: userName),
                                        // ),
                                        // );
                                      } else if (responseCode == 204) {
                                        DialogBuilder(context)
                                            .hideOpenDialog();
                                        Fluttertoast.showToast(
                                            msg: responseMessage,
                                            toastLength: Toast.LENGTH_LONG,
                                            timeInSecForIosWeb: 5);
                                        showDialog(
                                          context: context,
                                          builder: (context) => OtpDialog(
                                            onSubmit: (otp) async {
                                              DialogBuilder(context)
                                                  .showLoadingIndicator();

                                              var response = await controller
                                                  .login(queryParameters: {
                                                "email":
                                                controller.email.text,
                                                "password":
                                                controller.password.text,
                                                "code": otp
                                              }, token: {
                                                "Authorization":
                                                " Bearer ${Url.webAPIKey}"
                                              });
                                              var jsonResponse = jsonDecode(
                                                  response.toString());



                                              var responseCode =
                                              jsonResponse['meta']
                                              ['code'];
                                              var responseMessage =
                                              jsonResponse['meta']
                                              ['message'];
                                              var userName =
                                              jsonResponse['data']
                                              ['username'];
                                              var token = jsonResponse['data']
                                              ['token'];
                                              var userId =
                                              jsonResponse['data']['id'];

                                              var email = jsonResponse['data']
                                              ['email'];

                                              DialogBuilder(context)
                                                  .hideOpenDialog();

                                              if (responseCode == 200) {
                                                Navigator.of(context).pop();
                                                shared.setString("token",
                                                    token.toString());
                                                shared.setString("userName",
                                                    userName.toString());

                                                shared.setString("email",
                                                    email.toString());

                                                storage.write("email",
                                                    email.toString());

                                                shared.setBool(
                                                    'guestUser', true);
                                                shared.setBool(
                                                    'socialLogin', false);
                                                storage.write('id', userId);
                                                storage.write("token",
                                                    token.toString());

                                                storage.write("CurrentEmail",
                                                    controller.email.text);
                                                storage.write("userName",
                                                    userName.toString());

                                                storage.write("remember",
                                                    isCheckedGlobal);

                                                controller.email.clear();
                                                controller.password.clear();
                                                controller.generateFCMToken(
                                                    context);
                                                if (Get.isRegistered<
                                                    NewsfeedController>()) {
                                                  Get.delete<
                                                      NewsfeedController>();
                                                  if (kDebugMode) {
                                                    print(
                                                        'newfees controller is removed at login  controller0');
                                                  }
                                                  Get.put(NewsfeedController(
                                                    linkId: controller
                                                        .postId !=
                                                        null
                                                        ? controller.postId
                                                        : null,
                                                    profileId: controller
                                                        .profileId !=
                                                        null
                                                        ? controller.profileId
                                                        : null,
                                                  ));
                                                } else {
                                                  Get.put(NewsfeedController(
                                                    linkId: controller
                                                        .postId !=
                                                        null
                                                        ? controller.postId
                                                        : null,
                                                    profileId: controller
                                                        .profileId !=
                                                        null
                                                        ? controller.profileId
                                                        : null,
                                                  ));
                                                  if (kDebugMode) {
                                                    print(
                                                        'newfees controller is initalized at login  controller0');
                                                  }
                                                }

                                                // Get.put(NewsfeedController(
                                                //   linkId: controller.postId != null ? controller.postId : null,
                                                //   profileId: controller.profileId != null ? controller.profileId : null,
                                                // ));

                                                Get.find<NewsfeedController>()
                                                    .languageData =
                                                await Get.find<
                                                    NewsfeedController>()
                                                    .getLanguages();
                                                int index = Get.find<
                                                    NewsfeedController>()
                                                    .languagesList
                                                    .indexWhere((element) {
                                                  return Get.find<
                                                      NewsfeedController>()
                                                      .languageData
                                                      .appLang
                                                      .id ==
                                                      element.id;
                                                });

                                                int index2 = Get.find<
                                                    NewsfeedController>()
                                                    .translationLanguage
                                                    .indexWhere((element) {
                                                  return Get.find<
                                                      NewsfeedController>()
                                                      .languageData
                                                      .myLang
                                                      .id ==
                                                      element.id;
                                                });

                                                Get.find<NewsfeedController>()
                                                    .dropdownValue = Get.find<
                                                    NewsfeedController>()
                                                    .languagesList[index];

                                                Get.find<NewsfeedController>()
                                                    .dropdownValue1 = Get.find<
                                                    NewsfeedController>()
                                                    .translationLanguage[index2];

                                                // print("idhr sdfsdf");

                                                // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                                //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                                //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                                //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                                // );
                                                //
                                                // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                                // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                                // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                                Get.find<NewsfeedController>()
                                                    .selectedAppLanguageInfoId =
                                                    Get.find<
                                                        NewsfeedController>()
                                                        .languageData
                                                        .appLang
                                                        .id;

                                                Get.find<NewsfeedController>()
                                                    .upDateLocale(Get.find<
                                                    NewsfeedController>()
                                                    .languageData
                                                    .appLang
                                                    .code);
                                                Get.find<NewsfeedController>()
                                                    .update();

                                                if (kIsWeb) {
                                                  if (id == 2) {
                                                    SingleTone.instance
                                                        .socialLogin = false;
                                                    // Navigator.pop(context);
                                                    // Routemaster.of(context).pop();

                                                    String userName =
                                                    shared.getString(
                                                        "userName");
                                                    // print({
                                                    //   "userName on mainScreen :  $userName"
                                                    // });
                                                    // print(
                                                    //     'postsid:${controller.postId}');
                                                    // print(
                                                    //     'profileId:${controller.profileId}');
                                                    Get.offNamed(FluroRouters
                                                        .mainScreen);

                                                    // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                    //
                                                    //
                                                    //   "userName": shared.getString("userName"),
                                                    //   "postId": controller.postId != null
                                                    //       ? controller.postId
                                                    //       : null,
                                                    //   "profileId": controller.profileId != null
                                                    //       ? controller.profileId
                                                    //       : null
                                                    // });
                                                  } else {
                                                    SingleTone.instance
                                                        .socialLogin = false;
                                                    // Routemaster.of(context).pop();
                                                    Navigator.pop(context);

                                                    String userName =
                                                    shared.getString(
                                                        "userName");
                                                    // print({
                                                    //   "userName on mainScreen :  $userName"
                                                    // });
                                                    // print(
                                                    //     'postsid:${controller.postId}');
                                                    // print(
                                                    //     'profileId:${controller.profileId}');
                                                    Get.offNamed(FluroRouters
                                                        .mainScreen);

                                                    // Routemaster.of(context).replace(
                                                    //     AppRoute.mainScreen, queryParameters: {
                                                    //
                                                    //
                                                    //   "userName": shared.getString("userName"),
                                                    //   "postId": controller.postId != null
                                                    //       ? controller.postId
                                                    //       : null,
                                                    //   "profileId": controller.profileId != null
                                                    //       ? controller.profileId
                                                    //       : null
                                                    // });
                                                  }
                                                } else {
                                                  SingleTone.instance
                                                      .socialLogin = false;
                                                  Get.back();
                                                  Get.offAll(MainScreen(isLoggedInFromPosh: true,),
                                                      arguments: {
                                                        "userName":
                                                        shared.getString(
                                                            "userName"),
                                                        "postId": controller
                                                            .postId !=
                                                            null
                                                            ? controller
                                                            .postId
                                                            : null,
                                                        "profileId": controller
                                                            .profileId !=
                                                            null
                                                            ? controller
                                                            .profileId
                                                            : null
                                                      });
                                                }

                                                // Get.offAll(MainScreen(
                                                //   userName: shared.getString("userName"),
                                                //   postId: controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   profileId: controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null,
                                                // ));
                                                // Navigator.of(context).pushAndRemoveUntil(
                                                //     MaterialPageRoute(
                                                //         builder: (context) => MainScreen(
                                                //               userName: userName,
                                                //               postId: controller.postId != null
                                                //                   ? controller.postId
                                                //                   : null,
                                                //               profileId: controller.profileId != null
                                                //                   ? controller.profileId
                                                //                   : null,
                                                //             )),
                                                //     (Route<dynamic> route) => false);
                                                // Navigator.push(
                                                //   context,
                                                //   MaterialPageRoute(
                                                //     builder: (BuildContext context) =>
                                                //         MainScreen(userName: userName),
                                                // ),
                                                // );
                                              } else if (responseCode ==
                                                  204) {
                                                Fluttertoast.showToast(
                                                    msg: responseMessage,
                                                    toastLength:
                                                    Toast.LENGTH_LONG,
                                                    timeInSecForIosWeb: 5);
                                              } else if (responseCode ==
                                                  205) {
                                                Fluttertoast.showToast(
                                                    msg: responseMessage,
                                                    toastLength:
                                                    Toast.LENGTH_LONG,
                                                    timeInSecForIosWeb: 5);
                                              } else {
                                                Navigator.of(context).pop();

                                                customDialog(
                                                  context,
                                                  isSuccess: true,
                                                  message: Strings
                                                      .emailOrPasswordIsIncorrect,
                                                );
                                              }
                                            },
                                          ),
                                        );
                                      } else if (responseCode == 205) {
                                        Fluttertoast.showToast(
                                            msg: responseMessage,
                                            toastLength: Toast.LENGTH_LONG,
                                            timeInSecForIosWeb: 5);
                                      }  else if(responseCode == 405){
                                        DialogBuilder(context)
                                            .hideOpenDialog();
                                        Fluttertoast.showToast(
                                            msg:
                                            responseMessage,
                                            toastLength: Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.BOTTOM,
                                            timeInSecForIosWeb: 5,
                                            backgroundColor: Colors.red,
                                            textColor: Colors.white,
                                            webBgColor: "linear-gradient(to right, #FF0000FF, #FF0000FF)",
                                            webPosition: "center",
                                            fontSize: kIsWeb ? 18 : 16.0);
                                      } else {
                                        Navigator.of(context).pop();
                                        lockAccount(controller.email.text);
                                        customDialog(
                                          context,
                                          isSuccess: true,
                                          message: Strings
                                              .emailOrPasswordIsIncorrect,
                                        );
                                      }

                                      //Uncomment for captcha mobile step 2
                                      /*  } else {
                                          showDialog(
                                            context: context,barrierDismissible: false,
                                            builder: (ctx) => AlertDialog(
                                              title: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  const Text("Captcha"),
                                                  SizedBox(height: 20,),
                                                  const Text("Note: Please scroll horizontally\n if the checkbox is not visible!!!",style: TextStyle(fontSize: 12,fontWeight: FontWeight.w400,color: Colors.red,),),

                                                ],
                                              ),
                                              content: Container(height:200,
                                                  width: 200,
                                                  alignment: Alignment.centerRight,
                                                  child: WebViewWidget(controller: webviewController)),
                                                  // child:   WebViewScreen(String: webviewController.)),
                                              actions: <Widget>[
                                                TextButton(
                                                  onPressed: () {
                                                    DialogBuilder(context).hideOpenDialog();
                                                    Navigator.of(ctx).pop();
                                                  },
                                                  child: Container(
                                                    padding: const EdgeInsets.all(14),
                                                    child: const Text("Cancel"),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          );
                                        }*/
                                    }
                                  } else {
                                    setState(() {
                                      errorText = true;
                                    });
                                  }
                                  // }
                                },
                                text: Strings.signIn,
                                margin: const EdgeInsets.only(right: 1),
                              )
                            ),
                          )),
                    ),

                    const SizedBox(height:kIsWeb?20: 45),
                    _buildLine(context),
                    const SizedBox(height:kIsWeb?20: 45),
                    _buildSocialLogin(context),
                    const SizedBox(height:kIsWeb?20: 45),



                  ],
                ),
              ),
            ),
           !kIsWeb?  Text(Strings.doNotHaveAnAccount,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 23,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
            ):const SizedBox(),
            const SizedBox(height: 5),
           !kIsWeb? GestureDetector(
              onTap: (){
                if (!kIsWeb) {
                    Get.to (SignUpDialog());
                } else {

                }
              },
              child: Text(Strings.registerHere,
                style: TextStyle(
                  color: appTheme.blueColorHere,
                  fontSize: 23,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ):const SizedBox(),
            const SizedBox(height:kIsWeb?0: 50),
          ],
        ),
    ),
    );

  }
  Widget _buildWerfieLogoWidget(){
    return  CustomImageShow(
      imagePath: AppImages.newWerfieLogoPng,
      height: 39,
      width: 162,
    );
  }

  Widget _buildSignInText({@required String text}){
    return Text(
      text,
      style: CustomTextStyles
          .headlineMediumPoppinsSecondaryContainer,
    );
  }


  /// Section line widget
  Widget _buildLine(BuildContext context) {
    final mediaSize= MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.only(right: 1),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        // crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              top: 9,
              bottom: 6,
            ),
            child: SizedBox(
              width:
            !kIsWeb?  mediaSize.width*0.25:mediaSize.width*0.05,
              child: const Divider(),
            ),
          ),
          Text(
            Strings.orContinueWith,
            style: theme.textTheme.titleSmall,
          ),
          Padding(
            padding: const EdgeInsets.only(
              top: 9,
              bottom: 6,
            ),
            child: SizedBox(
              width:
              !kIsWeb?  mediaSize.width*0.25:mediaSize.width*0.05,
              child: const Divider(),
            ),
          ),
        ],
      ),
    );
  }

  /// Section social login
  Widget _buildSocialLogin(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
///google login
        Shortcuts(
          shortcuts: {
            LogicalKeySet(LogicalKeyboardKey.tab): GoogleSignupButton(),
          },
          child: Actions(
            actions: {
              GoogleSignupButton:
              CallbackAction<GoogleSignupButton>(onInvoke: (_) {
                controller.focus5.unfocus();
                FocusScope.of(context).requestFocus(controller.focus1);
              }),
            },
            child: Column(
              children: [
                _buildSocialLoginButton(
                  imagePath: AppImages.googleImageLogo,
                  onTap:_googleLogin,
                  focusNode: controller.focus5,
                ),
                Text(Strings.google,style: TextStyle(
                  color: appTheme.blueGray700,
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),)
              ],
            ),

          ),
        ),
/// apple login
        !kIsWeb
            ? Platform.isIOS
            ? Column(
              children: [
                _buildSocialLoginButton( imagePath: AppImages.appleSvgLogo, onTap:_appleLogin ,),
                Text(Strings.apple,style: TextStyle(
                  color: appTheme.blueGray700,
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),)
              ],
            )
            : const SizedBox.shrink()
            : Column(
              children: [
                _buildSocialLoginButton( imagePath: AppImages.appleSvgLogo, onTap:_appleLogin ,),
                Text(Strings.apple,style: TextStyle(
                  color: appTheme.blueGray700,
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),)
              ],
            ),

/// word noor login
        Column(
          children: [
            _buildSocialLoginButton( imagePath: AppImages.worldNoorImageLogo, onTap: _worldNoorLogin,),
            Text(Strings.worldNoor,style: TextStyle(
              color: appTheme.blueGray700,
              fontSize: 14,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),)
          ],
        ),

      ],
    );
  }

  Widget _buildSocialLoginButton({@required String imagePath, @required VoidCallback onTap, FocusNode focusNode }){
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: Container(

        height: 60,
        //  width: 117,
        padding: const EdgeInsets.symmetric(
          horizontal: 37,
          vertical: 10,
        ),
        decoration: AppDecoration.fillWhiteA.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder10,
        ),
        child: CustomIconButton(
          onTap: onTap,
          focusNode:focusNode ,
          padding: const EdgeInsets.all(3),
          alignment: Alignment.center,
          child: MouseRegion(
            cursor: SystemMouseCursors.click,
            child: CustomImageShow(
              imagePath: imagePath,
            ),
          ),
        ),
      ),
    );
  }
  Widget _buildLanguageChangeWidget(){
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: const EdgeInsets.only(right: 25,top: 45),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          //  crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: (){
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (BuildContext context) =>
                            LanguageSettings(fromLoginPage: true,)));
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    widget.loginController.selectedLanguage != null ? widget.loginController.selectedLanguage.name : "English",
                    style: TextStyle(
                      color: Theme.of(context)
                          .brightness ==
                          Brightness.dark
                          ? Colors.white
                          : MyColors.black,
                      fontSize: 17,
                      fontWeight: FontWeight.w400,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 3,left: 2),
                    child: Icon(Icons.keyboard_arrow_down,
                      size: 15,
                      color: Colors.grey,
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  verifyCaptchaToken(String token) async {
    Uri uri = Uri.parse('https://www.google.com/recaptcha/api/siteverify');
    final response = await http.post(uri, body: {
      'secret': '6LcIi0EoAAAAABSab2GFSPnihdHzMZ2-u9rYUOdY',
      'response': token,
    }, headers: {
      'Access-Control-Allow-Origin': '*'
    });
    final Map<String, dynamic> jsonResponse = json.decode(response.body);
    LoggingUtils.printValue("API RESPONSE VERIFY CAPTCHA", jsonResponse);

    if (jsonResponse['success']) {
      LoggingUtils.printValue("API RESPONSE VERIFY CAPTCHA", response.body);
      isCaptchaSelected = true;
      Navigator.of(context).pop();
      DialogBuilder(context).showLoadingIndicator();

      var apiresponse = await controller.login(queryParameters: {
        "email": controller.email.text,
        "password": controller.password.text
      }, token: {
        "Authorization": " Bearer ${Url.webAPIKey}"
      });

      var jsonResponse = jsonDecode(apiresponse.toString());

      var responseCode = jsonResponse['meta']['code'];
      var userName = jsonResponse['data']['username'];
      var token = jsonResponse['data']['token'];
      var userId = jsonResponse['data']['id'];
      var email = jsonResponse['data']['email'];
      shared = await SharedPreferences.getInstance();
      if (responseCode == 200) {
        shared.setString("email", email.toString());

        shared.setString("token", token.toString());
        shared.setString("userName", userName.toString());
        shared.setBool('guestUser', true);
        shared.setBool('socialLogin', false);
        storage.write('id', userId);
        storage.write("token", token.toString());
        storage.write("email", email.toString());

        storage.write("CurrentEmail", controller.email.text);

        storage.write("userName", userName.toString());

        storage.write("remember", isCheckedGlobal);

        controller.email.clear();
        controller.password.clear();
        controller.generateFCMToken(context);
        //  NewsfeedController newsfeedController;
        // newsfeedController=
        if (Get.isRegistered<NewsfeedController>()) {
          Get.delete<NewsfeedController>();
          if (kDebugMode) {
            print('newfees controller is removed at login  controller1');
          }
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
            controller.profileId != null ? controller.profileId : null,
          ));
        } else {
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
            controller.profileId != null ? controller.profileId : null,
          ));

        }

        // newsfeedController .languageData= await newsfeedController.getLanguages();
        Get.find<NewsfeedController>().languageData =
        await Get.find<NewsfeedController>().getLanguages();
        int index =
        Get.find<NewsfeedController>().languagesList.indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.appLang.id ==
              element.id;
        });

        int index2 = Get.find<NewsfeedController>()
            .translationLanguage
            .indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.myLang.id ==
              element.id;
        });

        Get.find<NewsfeedController>().dropdownValue =
        Get.find<NewsfeedController>().languagesList[index];

        Get.find<NewsfeedController>().dropdownValue1 =
        Get.find<NewsfeedController>().translationLanguage[index2];

        // print("idhr sdfsdf");

        // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
        //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
        //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
        //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
        // );
        //
        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

        Get.find<NewsfeedController>().selectedAppLanguageInfoId =
            Get.find<NewsfeedController>().languageData.appLang.id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>().languageData.appLang.code);
        Get.find<NewsfeedController>().update();

        if (kIsWeb) {
          if (id == 2) {
            SingleTone.instance.socialLogin = false;
            DialogBuilder(context).hideOpenDialog();

            // Navigator.pop(context);
            // Routemaster.of(context).pop();

            String userName = shared.getString("userName");
            // print({
            //   "userName on mainScreen :  $userName"
            // });
            // print(
            //     'postsid:${controller.postId}');
            // print(
            //     'profileId:${controller.profileId}');
            Get.offNamed(FluroRouters.mainScreen);

            // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
            //
            //
            //   "userName": shared.getString("userName"),
            //   "postId": controller.postId != null
            //       ? controller.postId
            //       : null,
            //   "profileId": controller.profileId != null
            //       ? controller.profileId
            //       : null
            // });
          } else {
            SingleTone.instance.socialLogin = false;
            // Routemaster.of(context).pop();
            // Navigator.pop(context);
            DialogBuilder(context).hideOpenDialog();

            String userName = shared.getString("userName");
            // print({
            //   "userName on mainScreen :  $userName"
            // });
            // print(
            //     'postsid:${controller.postId}');
            // print(
            //     'profileId:${controller.profileId}');
            Get.offNamed(FluroRouters.mainScreen);

            // Routemaster.of(context).replace(
            //     AppRoute.mainScreen, queryParameters: {
            //
            //
            //   "userName": shared.getString("userName"),
            //   "postId": controller.postId != null
            //       ? controller.postId
            //       : null,
            //   "profileId": controller.profileId != null
            //       ? controller.profileId
            //       : null
            // });
          }
        } else {
          SingleTone.instance.socialLogin = false;
          // Get.back();
          DialogBuilder(context).hideOpenDialog();

          Get.offAll(MainScreen(), arguments: {
            "userName": shared.getString("userName"),
            "postId": controller.postId != null ? controller.postId : null,
            "profileId":
            controller.profileId != null ? controller.profileId : null
          });
        }

        // Get.offAll(MainScreen(
        //   userName: shared.getString("userName"),
        //   postId: controller.postId != null
        //       ? controller.postId
        //       : null,
        //   profileId: controller.profileId != null
        //       ? controller.profileId
        //       : null,
        // ));
        // Navigator.of(context).pushAndRemoveUntil(
        //     MaterialPageRoute(
        //         builder: (context) => MainScreen(
        //               userName: userName,
        //               postId: controller.postId != null
        //                   ? controller.postId
        //                   : null,
        //               profileId: controller.profileId != null
        //                   ? controller.profileId
        //                   : null,
        //             )),
        //     (Route<dynamic> route) => false);
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (BuildContext context) =>
        //         MainScreen(userName: userName),
        // ),
        // );
      } else {
        // Navigator.of(context).pop();
        DialogBuilder(context).hideOpenDialog();

        customDialog(
          context,
          isSuccess: true,
          message: Strings.emailOrPasswordIsIncorrect,
        );
      }
    } else {
      LoggingUtils.printValue("API RESPONSE VERIFY CAPTCHA", response.body);

      isCaptchaSelected = false;
    }
  }

  Future <void> _googleLogin() async{
    // var internetStatus=await UtilsMethods.checkInternet();
    // if(internetStatus!=true){
    //   UtilsMethods.toastMessageShow(Colors.red, Colors.red, Colors.red,
    //     message: Strings.noInternetAvailable,
    //   );
    // }
    // else{
    var response;
    UtilsMethods utillMethod = UtilsMethods();
    await utillMethod
        .signInWithGoogle()
        .then((value) async {
      /* if(!kIsWeb)*/ {
        showDialog(
            barrierDismissible: false,
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                backgroundColor:
                const Color(0xFFFFFFFF).withOpacity(0.2),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                        Radius.circular(10.0))),
                insetPadding: const EdgeInsets.symmetric(
                    horizontal: 0, vertical: 0),
                contentPadding: EdgeInsets.zero,
                content: SizedBox(
                  height: 100,
                  width: 80,
                  child: Column(
                    mainAxisAlignment:
                    MainAxisAlignment.spaceAround,
                    children: [
                      SpinKitCircle(
                        color:
                        Theme.of(context).primaryColor,
                        size: 50.0,
                      ),
                      Text(
                        Strings.pleaseWait,
                        style:
                        const TextStyle(color: Colors.white),
                      )
                    ],
                  ),
                ),
              );
            });
      }
      response =
      await controller.SocialLogin(queryParameters: {
        "email": value.email,
        "firstname": value.displayName ?? "",
        "login_type": 'google',
        "social_id": value.uid,
      }, token: {
        "Authorization": " Bearer ${Url.webAPIKey}"
      });
      //print("LOGIN WITH GGOGLE");
      //print(response);
      var jsonResponse = jsonDecode(response.toString());
      // storage.write("email", value.email.toString());
      // shared.setString("email", value.email.toString());

      var responseCode = jsonResponse['meta']['code'];
      var userName = jsonResponse['data']['username'];
      var token = jsonResponse['data']['token'];
      var userId = jsonResponse['data']['id'];
      var email = jsonResponse['data']['email'];
      shared = await SharedPreferences.getInstance();
      if (responseCode == 200) {
        storage.write("email", email.toString());

        shared.setString("token", token.toString());
        shared.setString("userName", userName.toString());
        storage.write('id', userId);
        storage.write("token", token.toString());
        shared.setBool('guestUser', true);
        shared.setBool('socialLogin', true);
        storage.write("userName", userName.toString());

        storage.write("remember", isCheckedGlobal);

        controller.generateFCMToken(context);
        controller.updateInitialWelcomeMsg(true);

        if (Get.isRegistered<NewsfeedController>()) {
          Get.delete<NewsfeedController>();
          if (kDebugMode) {
            print(
                'newfees controller is removed at login  controller0');
          }
          Get.put(NewsfeedController(
            linkId: controller.postId != null
                ? controller.postId
                : null,
            profileId: controller.profileId != null
                ? controller.profileId
                : null,
          ));
        } else {
          Get.put(NewsfeedController(
            linkId: controller.postId != null
                ? controller.postId
                : null,
            profileId: controller.profileId != null
                ? controller.profileId
                : null,
          ));
          if (kDebugMode) {
            print(
                'newfees controller is initalized at login  controller0');
          }
        }

        Get.find<NewsfeedController>().languageData =
        await Get.find<NewsfeedController>()
            .getLanguages();
        Get.find<NewsfeedController>()
            .selectedAppLanguageInfoId =
            Get.find<NewsfeedController>()
                .languageData
                .appLang
                .id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>()
                .languageData
                .appLang
                .code);
        Get.find<NewsfeedController>().update();
        {
          if (kIsWeb) {
            if (id == 2) {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              // Routemaster.of(context).pop();
              String userName =
              shared.getString("userName");
              // print(
              //     {"userName on mainScreen :  $userName"});
              // print('postsid:${controller.postId}');
              // print('profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);
              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            } else {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              String userName =
              shared.getString("userName");
              // print(
              //     {"userName on mainScreen :  $userName"});
              // print('postsid:${controller.postId}');
              // print('profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);

              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            }
            debugPrint(
                'Welcome Message Showing web 0 ${controller.isShowWelcomeMsg}');
          } else {
            SingleTone.instance.socialLogin = true;
            print('route is else here');
            Get.back();

            Get.offAll(MainScreen(), arguments: {
              "userName": shared.getString("userName"),
              "postId": controller.postId != null
                  ? controller.postId
                  : null,
              "profileId": controller.profileId != null
                  ? controller.profileId
                  : null
            });
            debugPrint(
                'Welcome Message Showing 0 ${controller.isShowWelcomeMsg}');
          }
        }
      }
    });

  }
  Future <void> _appleLogin()async {
    LoginController loginController;
    if (Get.isRegistered<LoginController>()) {
      loginController = Get.find<LoginController>();
    } else {
      loginController = Get.put(LoginController());
    }
    var response;
    // doSignInApple();
    UtilsMethods utillMethod = UtilsMethods();
    AuthService authService = AuthService();
    await authService.signInWithApple(scopes: [
      Scope.email,
      Scope.fullName
    ]).then((value) async {
      print('uid: ${value}');
      print('uid: ${value.uid}');
      print('uid: ${value.email}');
      print('uid: ${value.displayName}');
      if (value.email == null ||
          value.displayName == null ||
          value.uid == null ||
          value.email.isEmpty ||
          value.displayName.isEmpty ||
          value.uid.isEmpty) {
        Get.snackbar(Strings.error,
            Strings.somThingWentWrongWithConfiguration);
      } else if (value.email.contains("privaterelay")) {
        Get.snackbar(Strings.alert,
            Strings.pleaseAllowEmailToContinueWithWerfie);
        await FirebaseAuth.instance.signOut();

        print('uid: please allow email to continue');
      } else {
        showDialog(
            barrierDismissible: false,
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                backgroundColor:
                const Color(0xFFFFFFFF).withOpacity(0.2),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                        Radius.circular(10.0))),
                insetPadding: const EdgeInsets.symmetric(
                    horizontal: 0, vertical: 0),
                contentPadding: EdgeInsets.zero,
                content: SizedBox(
                  height: 100,
                  width: 80,
                  child: Column(
                    mainAxisAlignment:
                    MainAxisAlignment.spaceAround,
                    children: [
                      SpinKitCircle(
                        color: Theme.of(context)
                            .primaryColor,
                        size: 50.0,
                      ),
                      Text(
                        Strings.pleaseWait,
                        style: const TextStyle(
                            color: Colors.white),
                      )
                    ],
                  ),
                ),
              );
            });
      }
      response = await controller.SocialLogin(
          queryParameters: {
            "email": value.email,
            "firstname": value.displayName,
            "login_type": 'apple',
            "social_id": value.uid,
          },
          token: {
            "Authorization": " Bearer ${Url.webAPIKey}"
          });
      var jsonResponse =
      jsonDecode(response.toString());
      // storage.write("email", value.email.toString());
      // shared.setString("email", value.email.toString());

      var responseCode = jsonResponse['meta']['code'];
      var userName = jsonResponse['data']['username'];
      var token = jsonResponse['data']['token'];
      var userId = jsonResponse['data']['id'];
      var email = jsonResponse['data']['email'];
      shared = await SharedPreferences.getInstance();
      if (responseCode == 200) {
        storage.write("email", email.toString());

        shared.setString("token", token.toString());
        shared.setString(
            "userName", userName.toString());
        storage.write('id', userId);
        storage.write("token", token.toString());
        shared.setBool('guestUser', true);
        shared.setBool('socialLogin', true);
        storage.write("userName", userName.toString());

        storage.write("remember", isCheckedGlobal);

        controller.generateFCMToken(context);
        controller.updateInitialWelcomeMsg(true);

        Get.put(NewsfeedController(
          // linkId: controller.postId != null ? controller.postId : null,
          // profileId: controller.profileId != null ? controller.profileId : null,
        ));
        Get.find<NewsfeedController>().languageData =
        await Get.find<NewsfeedController>()
            .getLanguages();
        Get.find<NewsfeedController>()
            .selectedAppLanguageInfoId =
            Get.find<NewsfeedController>()
                .languageData
                .appLang
                .id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>()
                .languageData
                .appLang
                .code);
        Get.find<NewsfeedController>().update();
        {
          if (kIsWeb) {
            if (id == 2) {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              // Routemaster.of(context).pop();
              String userName =
              shared.getString("userName");
              // print({
              //   "userName on mainScreen :  $userName"
              // });
              // print('postsid:${controller.postId}');
              // print(
              //     'profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);
              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            } else {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              String userName =
              shared.getString("userName");
              // print({
              //   "userName on mainScreen :  $userName"
              // });
              // print('postsid:${controller.postId}');
              // print(
              //     'profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);

              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            }
          } else {
            SingleTone.instance.socialLogin = true;
            print('route is else here');
            Get.back();

            Get.offAll(MainScreen(), arguments: {
              "userName": shared.getString("userName"),
              "postId": controller.postId != null
                  ? controller.postId
                  : null,
              "profileId": controller.profileId != null
                  ? controller.profileId
                  : null
            });
          }
        }
      }
    });

    /* utillMethod.signInWithApple().then((value)  async {
                    print("user detaile");
                    print(value);

                    print(value.email);
                    print(value.identityToken);
                    print(value.givenName);
                    final signInWithAppleEndpoint = Uri(
                      scheme: 'https',
                      host: 'flutter-sign-in-with-apple-example.glitch.me',
                      path: '/sign_in_with_apple',
                      queryParameters: <String, String>{
                        'code': value.authorizationCode,
                        if (value.givenName != null)
                          'firstName': value.givenName,
                        if (value.familyName != null)
                          'lastName': value.familyName,
                        'useBundleId':
                        !kIsWeb && (Platform.isIOS || Platform.isMacOS)
                            ? 'true'
                            : 'false',
                        if (value.state != null) 'state': value.state,
                      },
                    );

                    final session = await http.Client().post(
                      signInWithAppleEndpoint,
                    );
                      print("<=================== SESSION ===============>");
                      print(session.body);
                    // print(value.user.displayName);
                    // print(value.user.phoneNumber);
                    // print(value.user.photoURL);
                  });*/
  }
  Future<void>_worldNoorLogin() async {
    //dialogLoginWithWorldNoor();
    if(kIsWeb){
      LoginWithWorldNoor().dialogLoginWithWorldNoorUsingCredentials(context);
    }else {
      LoginWithWorldNoor().dialogLoginWithWorldNoor(context,
          futureBuilderGetDataFromWorldNoorApp: futureBuilderGetDataFromWorldNoorApp,
          socialLoginWithPosh: socialLoginWithPosh);
    }
  }
  Future<Map<String, dynamic>> getDataFromWorldNoorApp() async {
    var extraData;
    Map<String, dynamic> dataFromWorldNoorApp;
    try {
      final String result = await platform.invokeMethod('readDataFromWorldNoor');
      extraData = result;
      dataFromWorldNoorApp = json.decode(extraData);
      if (dataFromWorldNoorApp != null &&
          dataFromWorldNoorApp.isNotEmpty &&
          (dataFromWorldNoorApp["isAutoLogin"] as bool || widget.isAutoLogin)) {
        if(widget.isFromWorldNoorApp != 2)
          socialLoginWithPosh(dataFromWorldNoorApp);
      }
    } on PlatformException catch (e) {
      extraData = "Failed to get data: '${e.message}'.";
    }

    print("========> WORLD NOOR MAP DATA");
    print(dataFromWorldNoorApp);
    return dataFromWorldNoorApp;
  }



  socialLoginWithPosh(Map<String, dynamic> map) async {
    var response;

    try {
      DialogBuilder(context).showLoadingIndicator();
      response = await controller.SocialLogin(queryParameters: {
        "login_type": 'posh',
        "social_id": map["poshId"],
        "wntoken": map["token"]
      }, token: {
        "Authorization": " Bearer ${Url.webAPIKey}"
      });
      var jsonResponse = jsonDecode(response.toString());
      // storage.write("email", value.email.toString());
      // shared.setString("email", value.email.toString());

      var responseCode = jsonResponse['meta']['code'];
      var userName = jsonResponse['data']['username'];
      var token = jsonResponse['data']['token'];
      var userId = jsonResponse['data']['id'];
      var email = jsonResponse['data']['email'];
      shared = await SharedPreferences.getInstance();
      if (responseCode == 200) {
        storage.write("email", email.toString());

        shared.setString("token", token.toString());
        shared.setString("userName", userName.toString());
        storage.write('id', userId);
        storage.write("token", token.toString());
        shared.setBool('guestUser', true);
        shared.setBool('socialLogin', true);
        storage.write("userName", userName.toString());

        storage.write("remember", isCheckedGlobal);

        controller.generateFCMToken(context);
        controller.updateInitialWelcomeMsg(true);

        if (Get.isRegistered<NewsfeedController>()) {
          Get.delete<NewsfeedController>();
          if (kDebugMode) {
            print('newfees controller is removed at login  controller0');
          }
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
            controller.profileId != null ? controller.profileId : null,
          ));
        } else {
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
            controller.profileId != null ? controller.profileId : null,
          ));
        }

        Get.find<NewsfeedController>().languageData =
        await Get.find<NewsfeedController>().getLanguages();
        Get.find<NewsfeedController>().selectedAppLanguageInfoId =
            Get.find<NewsfeedController>().languageData.appLang.id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>().languageData.appLang.code);
        Get.find<NewsfeedController>().update();
        {
          if (kIsWeb) {
            if (id == 2) {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              // Routemaster.of(context).pop();
              String userName = shared.getString("userName");
              // print(
              //     {"userName on mainScreen :  $userName"});
              // print('postsid:${controller.postId}');
              // print('profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);
              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            } else {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              String userName = shared.getString("userName");
              // print(
              //     {"userName on mainScreen :  $userName"});
              // print('postsid:${controller.postId}');
              // print('profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);

              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            }
            debugPrint(
                'Welcome Message Showing web 0 ${controller.isShowWelcomeMsg}');
          } else {
            SingleTone.instance.socialLogin = true;
            print('route is else here');
            Get.back();
            DialogBuilder(context).hideOpenDialog();

            Get.offAll(
                MainScreen(
                  isLoggedInFromPosh: true,
                ),
                arguments: {
                  "userName": shared.getString("userName"),
                  "postId":
                  controller.postId != null ? controller.postId : null,
                  "profileId":
                  controller.profileId != null ? controller.profileId : null
                });
          }
        }
      } else {
        Fluttertoast.showToast(
          msg: jsonResponse['meta']['message'].toString(),
          toastLength: Toast.LENGTH_SHORT,
          // or Toast.LENGTH_LONG
          gravity: ToastGravity.BOTTOM,
          // Location of the toast message
          timeInSecForIosWeb: 1,
          // Time duration for which the message will be displayed
          backgroundColor: Colors.grey,
          textColor: Colors.white,
          fontSize: 16.0,
        );
        DialogBuilder(context).hideOpenDialog();
      }
    } catch (e) {
      print("EXCEPTION SOCIAL LOGIN WITH POSH MOBILE");
      Fluttertoast.showToast(
        msg: Strings.sorryForTheInconvenience,
        toastLength: Toast.LENGTH_SHORT,
        // or Toast.LENGTH_LONG
        gravity: ToastGravity.BOTTOM,
        // Location of the toast message
        timeInSecForIosWeb: 1,
        // Time duration for which the message will be displayed
        backgroundColor: Colors.grey,
        textColor: Colors.white,
        fontSize: 16.0,
      );
      DialogBuilder(context).hideOpenDialog();
    }

    // }
  }

  login(String emailAndPhone,String password){


  }

  lockAccount(String email){

    //print("<======== Account Lockout Called ========>");
    final accountLockoutController = Get.find<AccountLockoutController>();
    accountLockoutController.incorrectAttempts.value++;
    accountLockoutController.lastAttemptTime.value = DateTime.now();
    accountLockoutController.saveLastAttemptTime(accountLockoutController.lastAttemptTime.value);
    // Only restart timer if necessary (up to 4 attempts)

    //if (accountLockoutController.incorrectAttempts.value <= 4) {
      accountLockoutController.startResetTimer(email);
    //}
    //print("=====> incorrectAttempts ${accountLockoutController.incorrectAttempts.value}");
    //print("=====> incorrect Time ${accountLockoutController.lastAttemptTime.value}");


  }
}


class OtpDialog extends StatefulWidget {
  final Function(String otp) onSubmit;

  const OtpDialog({Key key, this.onSubmit}) : super(key: key);

  @override
  _OtpDialogState createState() => _OtpDialogState();
}

class _OtpDialogState extends State<OtpDialog> {
  final TextEditingController _otpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        Strings.twoFactorAuthentication,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
      ),
      content: /*TextField(
        controller: _otpController,
        keyboardType: TextInputType.number,
        maxLength: 6,
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly,
        ],
        decoration: InputDecoration(hintText: 'Enter OTP'),
      )*/
      Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            Strings.enterDigitsVerificationCodeSentToYourRegisteredEmail,
            style: const TextStyle(
              fontSize: 14,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          PinCodeTextField(
            controller: _otpController,
            length: 6,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            obscureText: false,
            keyboardType: TextInputType.number,
            appContext: context,
            autoFocus: true,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(Strings.cancel),
        ),
        TextButton(
          onPressed: () {
            widget.onSubmit(_otpController.text);
          },
          child: Text(Strings.submit),
        ),
      ],
    );
  }
}



class LostPassword extends Intent {}

class GoogleSignupButton extends Intent {}

class LoginButton extends Intent {}

class EnterPasswords extends Intent {}

class EnterName extends Intent {}

class CustomCheck extends StatefulWidget {
  final email;
  final password;
  bool globalCheck;

  CustomCheck({this.email = "", this.password = "", this.globalCheck});

  @override
  _CustomCheckState createState() => _CustomCheckState();
}

class _CustomCheckState extends State<CustomCheck> {
  bool isChecked = false;
  final storage = GetStorage();

  @override
  Widget build(BuildContext context) {
    return Checkbox(
        value: isChecked,
        onChanged: (value) {
          setState(() {
            isChecked = value;
            widget.globalCheck = value;
            if (isChecked) {
              storage.write("email", widget.email.toString());
              storage.write("password", widget.password.toString());
            } else {
              storage.remove("email");
              storage.remove("password");
            }
          });
        });
  }
}
