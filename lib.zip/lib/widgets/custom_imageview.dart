import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class CustomImageView extends StatefulWidget {
  final imageUrl;

  const CustomImageView(this.imageUrl, {Key key, imagePath}) : super(key: key);

  @override
  _CustomImageViewState createState() => _CustomImageViewState();
}

class _CustomImageViewState extends State<CustomImageView> {
  // TransformationController _transformationController =
  //     TransformationController();
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Container(
        child: widget.imageUrl.runtimeType == String
            ? Image.asset(
                widget.imageUrl,
              )
            : kIsWeb
                ? Image.network(
                    widget.imageUrl,
                  )
                : Image.file(
                    widget.imageUrl,
                  ),
      ),
    );
  }
}
