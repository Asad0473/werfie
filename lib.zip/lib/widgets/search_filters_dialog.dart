import 'package:flutter/material.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/web_views/web_newsfeed_right_section.dart';

import '../utils/font.dart';

// ignore: must_be_immutable
class SearchFilterDialog extends StatelessWidget {
  NewsfeedController controller;

  SearchFilterDialog(this.controller);

  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(
      builder: (context, setState) {
        return Container(
          // width: Get.width * 0.9,
          height: 450,
          decoration: BoxDecoration(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.grey.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    left: 20, right: 20, top: 10, bottom: 10),
                child: Row(
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        Strings.searchFilter,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                    ),
                    Spacer(),
                    Align(
                      alignment: Alignment.centerRight,
                      child: IconButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: Icon(Icons.close),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: 0.1,
                width: MediaQuery.of(context).size.width,
                color: Colors.grey.withOpacity(1),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: const EdgeInsets.only(top: 10.0, left: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        Strings.people,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      FilterPeopleButton(
                        value: 1,
                        controller: controller,
                        title: Strings.fromAnyone,
                        onTap: (value) {
                          setState(() {
                            controller.people = value;
                            controller.filterUsers(
                              id: controller.searchSelected.id,
                              type: controller.searchSelected.type,
                              tag: controller.searchText.text.isNotEmpty
                                  ? controller.searchText.text
                                  : null,
                            );

                            controller.update();
                          });
                        },
                      ),
                      FilterPeopleButton(
                        value: 2,
                        controller: controller,
                        title: Strings.peopleYouFollow,
                        onTap: (value) {
                          setState(() {
                            controller.people = value;
                            controller.filterUsers(
                              id: controller.searchSelected.id,
                              type: controller.searchSelected.type,
                              tag: controller.searchText.text.isNotEmpty
                                  ? controller.searchText.text
                                  : null,
                            );

                            controller.update();
                          });
                        },
                      ),
                      Text(
                        Strings.location,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      FilterPlaceButton(
                        value: 1,
                        controller: controller,
                        title: Strings.anywhere,
                        onTap: (value) {
                          setState(() {
                            controller.place = value;
                            controller.filterUsers(
                              id: controller.searchSelected.id,
                              type: controller.searchSelected.type,
                              tag: controller.searchText.text.isNotEmpty
                                  ? controller.searchText.text
                                  : null,
                            );

                            controller.update();
                          });
                        },
                      ),
                      FilterPlaceButton(
                        value: 2,
                        controller: controller,
                        title: Strings.nearYou,
                        onTap: (value) {
                          setState(() {
                            controller.place = value;
                            controller.filterUsers(
                              id: controller.searchSelected.id,
                              type: controller.searchSelected.type,
                              tag: controller.searchText.text.isNotEmpty
                                  ? controller.searchText.text
                                  : null,
                            );

                            controller.update();
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                height: 0.1,
                width: MediaQuery.of(context).size.width,
                color: Colors.grey.withOpacity(0.2),
              ),
              // Padding(
              //   padding:
              //       const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              //   child: Align(
              //       alignment: Alignment.centerLeft,
              //       child: InkWell(
              //         onTap: () {},
              //         child: Text(
              //           Strings.advancedSearch,
              //           style: Theme.of(context).textTheme.headline6.copyWith(
              //                 fontSize: 14,
              //                 fontWeight: FontWeight.w700,
              //                 color: Colors.blueAccent,
              //               ),
              //         ),
              //       )),
              // ),
            ],
          ),
        );
      },
    );
  }
}
