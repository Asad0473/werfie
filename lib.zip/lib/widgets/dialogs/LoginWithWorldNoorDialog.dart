import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/apis/login/posh_login_api.dart';

import '../../utils/colors.dart';
import '../../utils/loading_dialog_builder.dart';
import '../../utils/utils_methods.dart';

class LoginWithWorldNoor {
  dialogLoginWithWorldNoor(BuildContext context,
      {Future<Map<String, dynamic>> futureBuilderGetDataFromWorldNoorApp,
      Function(Map<String, dynamic>) socialLoginWithPosh}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                  borderRadius: BorderRadius.circular(35),
                  child: Image.asset(
                    "assets/worldnoor/worldnoor_logo.png",
                    width: 50,
                    height: 50,
                  )),
              const SizedBox(
                width: 5,
              ),
              const Text(
                'WorldNoor',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          content: Container(
            width: kIsWeb ? 420 : null,
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Divider(
                  color: Colors.black26,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    !kIsWeb
                        ? FutureBuilder(
                            future: futureBuilderGetDataFromWorldNoorApp,
                            builder: (context, dataSnapshot) {
                              if (dataSnapshot.connectionState ==
                                  ConnectionState.waiting) {
                                return const Center(
                                  child: CircularProgressIndicator(),
                                );
                              } else {
                                if (dataSnapshot.error != null) {
                                  return Container();
                                } else {
                                  Map<String, dynamic> map = dataSnapshot.data;
                                  return map != null && map.isNotEmpty && map['poshId'] != null && map['poshId'] != "" /*&& map["isAutoLogin"] as bool*/
                                      ? Container(
                                          margin: const EdgeInsets.only(top: 0),
                                          width: MediaQuery.of(context).size.width-100,
                                          child: TextButton(
                                            style: ButtonStyle(
                                              shape: MaterialStateProperty.all<
                                                      RoundedRectangleBorder>(
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              0),
                                                      side: BorderSide(
                                                          color:
                                                              Colors.white))),
                                              overlayColor:
                                                  MaterialStateProperty
                                                      .resolveWith<Color>((Set<
                                                              MaterialState>
                                                          states) {
                                                if (states.contains(
                                                    MaterialState.focused))
                                                  return Colors.grey;
                                                if (states.contains(
                                                    MaterialState.hovered))
                                                  return Colors.grey;
                                                if (states.contains(
                                                    MaterialState.pressed))
                                                  return Colors.blue;
                                                return null; // Defer to the widget's default.
                                              }),
                                            ),
                                            onPressed: () {
                                              socialLoginWithPosh(map);
                                            },
                                            //  icon: icon,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Container(
                                                  width: 45,
                                                  height: 45,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                        color: Colors.black12,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              25)),
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            35),
                                                    child: FadeInImage(
                                                      fit: BoxFit.cover,
                                                      width: 40,
                                                      height: 40,
                                                      placeholder: const AssetImage(
                                                          'assets/images/profile_normal.png'),
                                                      image: NetworkImage(map[
                                                                  'profilePic'] !=
                                                              null
                                                          ? map['profilePic']
                                                          : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(
                                                  width: 15,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.start,
                                                    children: [
                                                      Text(
                                                        map["name"] ?? "",
                                                        style: const TextStyle(
                                                            color: Colors.black,
                                                            fontSize: 18,
                                                            fontWeight:
                                                                FontWeight.w400),
                                                      ),
                                                      Text(
                                                        map["email"] ?? "",
                                                        style: const TextStyle(
                                                            color: Colors.black38,
                                                            fontSize: 16,
                                                            fontWeight:
                                                                FontWeight.w300),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : Container();
                                }
                              }
                            })
                        : const SizedBox.shrink(),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        dialogLoginWithWorldNoorUsingCredentials(context);
                      },
                      // Add functionality for the "Add Another Account" button
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                                color: Colors.black12,
                                borderRadius: BorderRadius.circular(25)),
                            child: Icon(
                              Icons.add,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(
                            width: 15,
                          ),
                          const Text(
                            "Add another Account",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.w400),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Divider(
                  color: Colors.black26,
                ),
                Padding(
                  padding: EdgeInsets.all(15),
                  child: RichText(
                    text: const TextSpan(
                      style: TextStyle(
                        fontSize: 14.0,
                        color: Colors.black54,
                      ),
                      children: <TextSpan>[
                        TextSpan(
                            text: 'Worldnoor ',
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black54)),
                        TextSpan(
                          text:
                              'values your privacy and security. By logging into',
                          style: TextStyle(
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                        TextSpan(
                          text: ' Werfie',
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.black54),
                        ),
                        TextSpan(
                          text: ' through ',
                          style: TextStyle(
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                        TextSpan(
                            text: 'Worldnoor ',
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black54)),
                        TextSpan(
                            text:
                                'rest assured that your information and data are treated with the utmost confidentiality. Our commitment to your privacy means that your data will not be shared or compromised. ',
                            style: TextStyle(fontWeight: FontWeight.normal)),
                      ],
                    ),
                  ),
                ),
                /*Text(
                    'Worldnoor values your privacy and security. By logging into Werfie through Worldnoor, rest assured that your information and data are treated with the utmost confidentiality. Our commitment to your privacy means that your data will not be shared or compromised.',
                    style: TextStyle(
                      fontSize: 14.0,
                      color: Colors.grey,
                    ),
                  ),*/
              ],
            ),
          ),
        );
      },
    );
  }

  dialogLoginWithWorldNoorUsingCredentials(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        TextEditingController emailAndPhoneController = TextEditingController();
        TextEditingController passwordController = TextEditingController();
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                  borderRadius: BorderRadius.circular(35),
                  child: Image.asset(
                    "assets/worldnoor/worldnoor_logo.png",
                    width: 50,
                    height: 50,
                  )),
              const SizedBox(
                width: 5,
              ),
              const Text(
                'Worldnoor',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          content: Container(
            width: kIsWeb ? 420 : null,
            padding: const EdgeInsets.only(left: 15.0, right: 15),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Text(
                    'Worldnoor is your gateway to enter all apps developed by Posh. Create your Worldnoor ID or login if you already have one.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 15.0,
                        color: Colors.black,
                        fontWeight: FontWeight.w500),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: emailAndPhoneController,
                  style: const TextStyle(color: Colors.black54),
                  keyboardType: TextInputType.text,
                  autofocus: false,
                  textAlign: TextAlign.start,
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    filled: true,
                    isDense: true,
                    fillColor: MyColors.greyFill,
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                          const BorderSide(width: 1, color: Colors.black12),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                          const BorderSide(width: 1, color: Colors.black12),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    hintText: 'Email or Phone',
                    hintStyle: const TextStyle(
                        color: Colors.black45,
                        fontWeight: FontWeight.w600,
                        fontSize: 14),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: passwordController,
                  style: const TextStyle(color: Colors.black54),
                  keyboardType: TextInputType.text,
                  obscureText: true,
                  autofocus: false,
                  textAlign: TextAlign.start,
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    filled: true,
                    isDense: true,
                    fillColor: MyColors.greyFill,
                    enabledBorder: OutlineInputBorder(
                      borderSide:
                          const BorderSide(width: 1, color: Colors.black12),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide:
                          const BorderSide(width: 1, color: Colors.black12),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    hintText: 'Password',
                    hintStyle: const TextStyle(
                        color: Colors.black45,
                        fontWeight: FontWeight.w600,
                        fontSize: 14),
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          if (emailAndPhoneController.text.isNotEmpty && passwordController.text.isNotEmpty) {
                            loginWithPosh(context, emailAndPhoneController.text, passwordController.text);
                          }else{
                            UtilsMethods.toastMessageShow(
                              MyColors.werfieBlue,
                              MyColors.werfieBlue,
                              MyColors.werfieBlue,
                              message: "Invalid Email/phone or Password",
                            );
                          }
                        },
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                              MyColors.worldNoorBlue),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  15.0), // Adjust the radius as needed
                            ),
                          ),
                          elevation: MaterialStateProperty.resolveWith<double>(
                            (Set<MaterialState> states) {
                              return 0.0;
                            },
                          ),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.all(12.0),
                          child: Text(
                            'Login with Worldnoor',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Colors.black54,
                    ),
                    children: <TextSpan>[
                      TextSpan(
                          text: 'Or ',
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.black)),
                      TextSpan(
                        text: 'Create an Account',
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {

                            launch(
                                'https://worldnoor.com/');
                          },
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: MyColors.worldNoorBlue),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: RichText(
                    text: const TextSpan(
                      style: TextStyle(
                        fontSize: 14.0,
                        color: Colors.black54,
                      ),
                      children: <TextSpan>[
                        TextSpan(
                            text: 'Worldnoor ',
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black54)),
                        TextSpan(
                          text:
                              'values your privacy and security. By logging into',
                          style: TextStyle(
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                        TextSpan(
                          text: ' Werfie',
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Colors.black54),
                        ),
                        TextSpan(
                          text: ' through ',
                          style: TextStyle(
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                        TextSpan(
                            text: 'Worldnoor ',
                            style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black54)),
                        TextSpan(
                            text:
                                'rest assured that your information and data are treated with the utmost confidentiality. Our commitment to your privacy means that your data will not be shared or compromised. ',
                            style: TextStyle(fontWeight: FontWeight.normal)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  loginWithPosh(BuildContext context, String email, String password) async {
    DialogBuilder(context).showLoadingIndicator();
    try {
      PoshLoginAPIRes signUpAPIRes = await PoshLoginApi().login(context, email, password);
      if (signUpAPIRes.success) {
        //DialogBuilder(context).hideOpenDialog();
      } else {
        DialogBuilder(context).hideOpenDialog();
        UtilsMethods.toastMessageShow(
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          message: signUpAPIRes.message,
        );
      }
    } catch (e) {
      DialogBuilder(context).hideOpenDialog();
    }
  }
}
