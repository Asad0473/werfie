import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:werfieapp/models/ReportUserModel/ReportUserSubCategory.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../models/ReportUserModel/ReportUserCategories.dart';
import '../../models/post.dart';
import '../../network/apis/reportUserAndWerf/ReportUserAndWerfApi.dart';
import '../../utils/utils_methods.dart';

class ReportUserAndWerfDialog {
  showReportUserDialog(BuildContext context, Post post, Function() blockUser,
      Function() muteUser, ReportType reportType, int messageId) {
    List<ReportUserCategories> reportUserCategoryList =
        ReportUserCategories.getReportCategoriesList();
    List<ReportUserSubCategory> listReportUserSubCategory = [];

    ReportUserCategories selectedCategory;
    ReportUserSubCategory selectedSubCategory;
    String buttonText = 'Next';
    bool showSubCategory = false;
    bool showSubmit = false;

    if (kIsWeb) {
      return showDialog(
          context: context,
          builder: (BuildContext context) {
            return StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
              return AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15.0)),
                contentPadding: EdgeInsets.zero,
                titlePadding: const EdgeInsets.only(left: 15, top: 15),
                actionsPadding: const EdgeInsets.only(
                    bottom: 15, top: 15, left: 50, right: 50),
                title: Row(
                  children: [
                    GestureDetector(
                      child: const Icon(Icons.clear),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    const Text(
                      "Gathering info",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                content: Container(
                  height: 550,
                  width: 550,
                  padding: const EdgeInsets.only(top: 15, right: 15, left: 15),
                  child: SingleChildScrollView(
                    child: selectedCategory != null &&
                            selectedSubCategory != null &&
                            showSubmit
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const SizedBox(
                                height: 25,
                              ),
                              Row(
                                children: [
                                  const SizedBox(
                                    width: 50,
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: const [
                                        Text(
                                          "Thanks for helping make Werfie better for everyone",
                                          style: TextStyle(
                                              fontSize: 28,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          'We know it wasn’t easy, so we appreciate you taking the time to answer those questions.',
                                          style: TextStyle(
                                            color: Colors.black54,
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              Container(
                                margin: const EdgeInsets.only(
                                    left: 50, top: 30, right: 20),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: const [
                                        Expanded(
                                          child: Text(
                                            'What’s happening now',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      children: const [
                                        Expanded(
                                          child: Padding(
                                            padding:
                                                EdgeInsets.only(right: 18.0),
                                            child: Text(
                                              'We received your report. We’ll hide the reported post from your timeline in the meantime.',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: const [
                                        Expanded(
                                          child: Text(
                                            "What\'s next",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      children: const [
                                        Expanded(
                                          child: Padding(
                                            padding:
                                                EdgeInsets.only(right: 18.0),
                                            child: Text(
                                              'It\'ll take a few days for our team to review your report. We\'ll notify you if we found a rule violation and we\'ll let you know the actions we\'re taking as a result.',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: const [
                                        Expanded(
                                          child: Text(
                                            "Additional things you can do in the meantime",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                right: 18.0),
                                            child: Text(
                                              'Remove @${post.userInfo.firstname} posts from your timeline without unfollowing or blocking them.',
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: ElevatedButton(
                                            onPressed: muteUser,
                                            style: ElevatedButton.styleFrom(
                                              elevation: 0,
                                              backgroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(50.0),
                                              ),
                                              side: const BorderSide(
                                                width: 0.5,
                                                color: Colors.black54,
                                              ),
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Mute @${post.userInfo.firstname}",
                                                style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w700,
                                                    color: Colors.black),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                right: 18.0),
                                            child: Text(
                                              'Block @${post.userInfo.firstname} from following you, viewing your posts, or messaging you. By blocking them, you also won\'t see any posts or notifications from them.',
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: ElevatedButton(
                                            onPressed: () {
                                              blockUser();
                                            },
                                            style: ElevatedButton.styleFrom(
                                              elevation: 0,
                                              backgroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(50.0),
                                              ),
                                              side: const BorderSide(
                                                width: 0.5,
                                                color: Colors.black54,
                                              ),
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Block @${post.userInfo.firstname}",
                                                style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w700,
                                                    color: Colors.black),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ],
                          )
                        : showSubCategory
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    height: 25,
                                  ),
                                  Row(
                                    children: [
                                      const SizedBox(
                                        width: 50,
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              listReportUserSubCategory
                                                  .first.title,
                                              style: const TextStyle(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Text(
                                              'Choose the best',
                                              style: TextStyle(
                                                color: Colors.black54,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(
                                        left: 50, top: 30, right: 20),
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      // Wr
                                      physics: const ScrollPhysics(),
                                      // ap content vertically
                                      scrollDirection: Axis.vertical,
                                      itemCount:
                                          listReportUserSubCategory.length,
                                      itemBuilder: (context, index) {
                                        ReportUserSubCategory option =
                                            listReportUserSubCategory[index];
                                        return Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    option.name,
                                                    style: const TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ),
                                                Radio<ReportUserSubCategory>(
                                                  key: Key(index.toString()),
                                                  value: option,
                                                  groupValue:
                                                      selectedSubCategory,
                                                  onChanged:
                                                      (ReportUserSubCategory
                                                          value) {
                                                    print(value.name);
                                                    selectedSubCategory = value;

                                                    setState(() {});
                                                  },
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 18.0),
                                                    child: Text(
                                                      option.description,
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color:
                                                              Colors.black54),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 15,
                                            )
                                          ],
                                        );
                                      },
                                    ),
                                  )
                                ],
                              )
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    height: 25,
                                  ),
                                  Row(
                                    children: [
                                      const SizedBox(
                                        width: 50,
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const Text(
                                              "What type of issue are you reporting?",
                                              style: TextStyle(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                whyAreWeAskingThisDialog(
                                                    context);
                                              },
                                              child: const Text(
                                                'Why are we asking this?',
                                                style: TextStyle(
                                                  color: Colors.blue,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(
                                        left: 50, top: 30, right: 20),
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      // Wr
                                      physics: const ScrollPhysics(),
                                      // ap content vertically
                                      scrollDirection: Axis.vertical,
                                      itemCount: reportUserCategoryList.length,
                                      itemBuilder: (context, index) {
                                        ReportUserCategories option =
                                            reportUserCategoryList[index];
                                        return Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    option.name,
                                                    style: const TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ),
                                                Radio<ReportUserCategories>(
                                                  key: Key(index.toString()),
                                                  value: option,
                                                  groupValue: selectedCategory,
                                                  onChanged:
                                                      (ReportUserCategories
                                                          value) {
                                                    print(value.name);
                                                    selectedCategory = value;
                                                    listReportUserSubCategory =
                                                        value.listSubCategory;
                                                    setState(() {});
                                                  },
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 18.0),
                                                    child: Text(
                                                      option.description,
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color:
                                                              Colors.black54),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 15,
                                            )
                                          ],
                                        );
                                      },
                                    ),
                                  )
                                ],
                              ),
                  ),
                ),
                actions: [
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: showSubCategory &&
                                  selectedSubCategory == null
                              ? null
                              : selectedCategory != null
                                  ? () {
                                      showSubCategory = true;
                                      buttonText = 'Next';
                                      if (selectedCategory != null &&
                                          selectedSubCategory != null &&
                                          showSubmit == true) {
                                        reportUserAndWerfApiCall(
                                            context,
                                            selectedCategory.name,
                                            selectedSubCategory.name,
                                            reportType == ReportType.werf
                                                ? post.postId
                                                : reportType == ReportType.user
                                                    ? post.authorId
                                                    : 0,
                                            reportType,
                                            messageId);
                                      }

                                      if (selectedCategory != null &&
                                          selectedSubCategory != null) {
                                        buttonText = 'Done';
                                        showSubmit = true;
                                      }

                                      setState(() {});
                                    }
                                  : null,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: MyColors.werfieBlue,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50.0),
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Text(
                              buttonText,
                              style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      )
                    ],
                  )
                ],
              );
            });
          });
    } else {
      showBottomSheetForMobile(
          context, post, blockUser, muteUser, reportType, messageId);
    }
  }

  reportUserAndWerfApiCall(BuildContext context, String category,
      String subCategory, int id, ReportType type, int messageId) async {
    ReportUserAndWerfAPIRes reportUserAndWerfAPIRes =
        await ReportUserAndWerfApi()
            .report(category, subCategory, id, type, messageId);
    if (reportUserAndWerfAPIRes.success) {
      Navigator.pop(context);
      UtilsMethods.toastMessageShow(
          MyColors.werfieBlue, MyColors.werfieBlue, MyColors.werfieBlue,
          message: "Thank you for providing you\r feed back");
    } else {
      UtilsMethods.toastMessageShow(
          MyColors.werfieBlue, MyColors.werfieBlue, MyColors.werfieBlue,
          message: Strings.someThingWentWrong);
    }
  }

  whyAreWeAskingThisDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15.0)),
              contentPadding: EdgeInsets.zero,
              content: Container(
                width: 300,
                height: 280,
                padding: const EdgeInsets.only(top: 15, right: 15, left: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      height: 25,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text(
                                "Why are we asking this?",
                                style: TextStyle(
                                    fontSize: 28, fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              Text(
                                'Rather than having you figure out what rule someone violated, we want to know what you’re experiencing or seeing. This helps us figure out what’s going on here and resolve the issue more quickly and accurately.',
                                style: TextStyle(
                                  color: Colors.black54,
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: MyColors.werfieBlue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50.0),
                          ),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            "Got it",
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                )
              ],
            );
          });
        });
  }

  showBottomSheetForMobile(
      BuildContext context,
      Post post,
      Function() blockUser,
      Function() muteUser,
      ReportType reportType,
      int messageId) {
    List<ReportUserCategories> reportUserCategoryList =
        ReportUserCategories.getReportCategoriesList();
    List<ReportUserSubCategory> listReportUserSubCategory = [];

    ReportUserCategories selectedCategory;
    ReportUserSubCategory selectedSubCategory;
    String buttonText = 'Next';
    bool showSubCategory = false;
    bool showSubmit = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return Container(
            padding:  EdgeInsets.only(top:  Platform.isIOS ? 56 :56, right: 15, left: 15,bottom: Platform.isIOS ? 30 : 10),
            child: Column(
              children: [
                Row(
                  children: [
                    GestureDetector(
                      child: const Icon(Icons.clear),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    const Text(
                      "Gathering info",
                      style:
                      TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: selectedCategory != null &&
                            selectedSubCategory != null &&
                            showSubmit
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const SizedBox(
                                height: 25,
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: const [
                                        Text(
                                          "Thanks for helping make Werfie better for everyone",
                                          style: TextStyle(
                                              fontSize: 28,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Text(
                                          'We know it wasn’t easy, so we appreciate you taking the time to answer those questions.',
                                          style: TextStyle(
                                            color: Colors.black54,
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 30, right: 20),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: const [
                                        Expanded(
                                          child: Text(
                                            'What’s happening now',
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      children: const [
                                        Expanded(
                                          child: Padding(
                                            padding: EdgeInsets.only(right: 18.0),
                                            child: Text(
                                              'We received your report. We’ll hide the reported post from your timeline in the meantime.',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: const [
                                        Expanded(
                                          child: Text(
                                            "What\'s next",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      children: const [
                                        Expanded(
                                          child: Padding(
                                            padding: EdgeInsets.only(right: 18.0),
                                            child: Text(
                                              'It\'ll take a few days for our team to review your report. We\'ll notify you if we found a rule violation and we\'ll let you know the actions we\'re taking as a result.',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: const [
                                        Expanded(
                                          child: Text(
                                            "Additional things you can do in the meantime",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(right: 18.0),
                                            child: Text(
                                              'Remove @${post.userInfo.firstname} posts from your timeline without unfollowing or blocking them.',
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: ElevatedButton(
                                            onPressed: muteUser,
                                            style: ElevatedButton.styleFrom(
                                              elevation: 0,
                                              backgroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(50.0),
                                              ),
                                              side: const BorderSide(
                                                width: 0.5,
                                                color: Colors.black54,
                                              ),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Mute @${post.userInfo.firstname}",
                                                style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w700,
                                                    color: Colors.black),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding:
                                                const EdgeInsets.only(right: 18.0),
                                            child: Text(
                                              'Block @${post.userInfo.firstname} from following you, viewing your posts, or messaging you. By blocking them, you also won\'t see any posts or notifications from them.',
                                              style: const TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  color: Colors.black54),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: ElevatedButton(
                                            onPressed: () {
                                              blockUser();
                                            },
                                            style: ElevatedButton.styleFrom(
                                              elevation: 0,
                                              backgroundColor: Colors.white,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(50.0),
                                              ),
                                              side: const BorderSide(
                                                width: 0.5,
                                                color: Colors.black54,
                                              ),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Text(
                                                "Block @${post.userInfo.firstname}",
                                                style: const TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w700,
                                                    color: Colors.black),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ],
                          )
                        : showSubCategory
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    height: 25,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              listReportUserSubCategory.first.title,
                                              style: const TextStyle(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            const Text(
                                              'Choose the best',
                                              style: TextStyle(
                                                color: Colors.black54,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(
                                        top: 30, right: 20),
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      // Wr
                                      physics: const ScrollPhysics(),
                                      // ap content vertically
                                      scrollDirection: Axis.vertical,
                                      itemCount: listReportUserSubCategory.length,
                                      itemBuilder: (context, index) {
                                        ReportUserSubCategory option =
                                            listReportUserSubCategory[index];
                                        return Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceBetween,
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    option.name,
                                                    style: const TextStyle(
                                                        fontWeight: FontWeight.bold),
                                                  ),
                                                ),
                                                Radio<ReportUserSubCategory>(
                                                  key: Key(index.toString()),
                                                  value: option,
                                                  groupValue: selectedSubCategory,
                                                  onChanged:
                                                      (ReportUserSubCategory value) {
                                                    print(value.name);
                                                    selectedSubCategory = value;

                                                    setState(() {});
                                                  },
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(
                                                        right: 18.0),
                                                    child: Text(
                                                      option.description,
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color: Colors.black54),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 15,
                                            )
                                          ],
                                        );
                                      },
                                    ),
                                  )
                                ],
                              )
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(
                                    height: 25,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const Text(
                                              "What type of issue are you reporting?",
                                              style: TextStyle(
                                                  fontSize: 28,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                whyAreWeAskingThisDialog(context);
                                              },
                                              child: const Text(
                                                'Why are we asking this?',
                                                style: TextStyle(
                                                  color: Colors.blue,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(
                                         top: 30, right: 20),
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      // Wr
                                      physics: const ScrollPhysics(),
                                      // ap content vertically
                                      scrollDirection: Axis.vertical,
                                      itemCount: reportUserCategoryList.length,
                                      itemBuilder: (context, index) {
                                        ReportUserCategories option =
                                            reportUserCategoryList[index];
                                        return Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceBetween,
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    option.name,
                                                    style: const TextStyle(
                                                        fontWeight: FontWeight.bold),
                                                  ),
                                                ),
                                                Radio<ReportUserCategories>(
                                                  key: Key(index.toString()),
                                                  value: option,
                                                  groupValue: selectedCategory,
                                                  onChanged:
                                                      (ReportUserCategories value) {
                                                    print(value.name);
                                                    selectedCategory = value;
                                                    listReportUserSubCategory =
                                                        value.listSubCategory;
                                                    setState(() {});
                                                  },
                                                ),
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(
                                                        right: 18.0),
                                                    child: Text(
                                                      option.description,
                                                      style: const TextStyle(
                                                          fontWeight:
                                                              FontWeight.normal,
                                                          color: Colors.black54),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 15,
                                            )
                                          ],
                                        );
                                      },
                                    ),
                                  )
                                ],
                              ),
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: showSubCategory &&
                            selectedSubCategory == null
                            ? null
                            : selectedCategory != null
                            ? () {
                          showSubCategory = true;
                          buttonText = 'Next';
                          if (selectedCategory != null &&
                              selectedSubCategory != null &&
                              showSubmit == true) {
                            reportUserAndWerfApiCall(
                                context,
                                selectedCategory.name,
                                selectedSubCategory.name,
                                reportType == ReportType.werf
                                    ? post.postId
                                    : reportType == ReportType.user
                                    ? post.authorId
                                    : 0,
                                reportType,
                                messageId);
                          }

                          if (selectedCategory != null &&
                              selectedSubCategory != null) {
                            buttonText = 'Done';
                            showSubmit = true;
                          }

                          setState(() {});
                        }
                            : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: MyColors.werfieBlue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50.0),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Text(
                            buttonText,
                            style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
          );
        });
      },
    );
  }
}
