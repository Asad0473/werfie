// ignore: duplicate_ignore
// ignore_for_file: must_be_immutable

import 'dart:async';
import 'dart:convert';

import 'package:aligned_dialog/aligned_dialog.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl/intl.dart';
import 'package:werfieapp/components/input_field.dart';
import 'package:werfieapp/models/chatUserModel.dart';
import 'package:werfieapp/models/message.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/models/scrapping.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/emojis.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/video_call/video_call_home.dart';
import 'package:werfieapp/video_call/utilities/video_call_utilities.dart';
import 'package:werfieapp/video_call/widgets/call_buttons.dart';
import 'package:werfieapp/widgets/blue_tick.dart';
import 'package:werfieapp/widgets/chewie_videoplayer.dart';
import 'package:werfieapp/widgets/expandble_menu.dart';
import 'package:werfieapp/widgets/forward_message_dialog.dart';
import 'package:werfieapp/widgets/new_message_dialog.dart';
import 'package:werfieapp/widgets/newsfeed_carousel.dart';
import 'package:werfieapp/widgets/overlay.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_linkify/flutter_linkify.dart';

import '../models/post.dart';
import '../network/apis/reportUserAndWerf/ReportUserAndWerfApi.dart';
import '../utils/asset_string.dart';
import '../utils/chat_utils.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../video_call/controller/video_call_controller.dart';
import '../web_views/web_view_screen.dart';
import 'dialogs/ReportUserAndWerfDialog.dart';

class ChatScreenMobile extends StatelessWidget {
  final NewsfeedController controller;
  final bool isRequested;
  final bool isFromMessagePopup;

  ChatScreenMobile(this.controller, this.isRequested,
      {this.isFromMessagePopup = false});

  @override
  Widget build(BuildContext context) {
    return !kIsWeb
        ? GetBuilder<NewsfeedController>(builder: (controller) {
      return Material(
        child: SafeArea(child: ChatUIScreen(controller,isRequested)),
      );
    })
        : ChatUIScreen(controller,isRequested, isFromMessagePopup: isFromMessagePopup,);

    // Scaffold(
    //   body:  );
  }
}

bool checkEmoji = false;

String a;

class ChatUIScreen extends StatefulWidget {
  final NewsfeedController controller;
  final bool isRequested;
  final bool isFromMessagePopup;

  ChatUIScreen(this.controller, this.isRequested, {this.isFromMessagePopup = false});

  @override
  State<ChatUIScreen> createState() => _ChatUIScreenState();
}

class _ChatUIScreenState extends State<ChatUIScreen>
    with SingleTickerProviderStateMixin {
  bool isEmojiVisible = false;
  bool isKeyboardVisible = false;
  int _selectedTab = 0;
  StreamSubscription<bool> keyboardSubscription;
  TabController _tabController;
  bool showCursor = true;
  ScrollController _scrollController;


  void scrollListener() {
    if (isShrink != lastStatus) {
      {
        lastStatus = isShrink;
        setState(() {

        });
      }
      setState(() {

      });
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(scrollListener);
    _scrollController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  bool lastStatus = true;
  double heights = 200;

  bool get isShrink {
    return _scrollController != null && _scrollController.hasClients &&
        _scrollController.offset > (heights - 70);
  }


  final focusNode = FocusNode();
  bool isPortrait = false;
  double width = 0,
      height = 0;

  @override
  void initState() {
    super.initState();


    // print("dfad message notification : " + widget.isFromMessagePopup.toString());
    widget.controller.replyToMsgModel = null;
    _tabController = TabController(vsync: this, length: emojis.length);
    _scrollController = ScrollController();
    var keyboardVisibilityController = KeyboardVisibilityController();
    keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
          if (visible && isEmojiVisible) {
            isEmojiVisible = false;
            if (this.mounted) {
              // check whether the state object is in tree
              setState(() {
                // make changes here
              });
            }
          } else {}
        });

    _scrollController = ScrollController()
      ..addListener(scrollListener);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    widget.controller.messageController.addListener(() {
      if (widget.controller.messageController.text
          .trim()
          .length > 0) {
        // print(widget.controller.messageController.text);
        widget.controller.isSendMsg = false;
        widget.controller.isChatTextEmpty = false;
        widget.controller.update();
      } else {
        widget.controller.isChatTextEmpty = true;
        widget.controller.update();
      }
    });

    width = MediaQuery
        .of(context)
        .size
        .width;
    height = MediaQuery
        .of(context)
        .size
        .height;
    isPortrait = height > width ? true : false;
    _tabController.addListener(() {
      _selectedTab = _tabController.index;
      if (!isPortrait) {
        _scrollController.jumpTo(_selectedTab * height * .075);
      }
      if (this.mounted) {
        // check whether the state object is in tree
        setState(() {
          // make changes here
        });
      }
      // setState(() {});
    });
  }


  var overlay = OverlayBuilder();

  final _formKey = GlobalKey<FormState>();

  Widget _buildFab(BuildContext context) {
    final icons = [
      Icons.image_outlined,
      Icons.video_collection_outlined,
      // Icons.gif_outlined,
      Icons.attach_file_outlined
    ];

    return AnchoredOverlay(
      showOverlay: true,
      overlayBuilder: (context, offset) {
        return CenterAbout(
          position: Offset(offset.dx, offset.dy - icons.length * 35.0),
          child: ExpandableMenu(
            icons: icons,
            onIconTapped: (index) {
              // print('YE HO GYA');
            },
          ),
        );
      },
      child: FloatingActionButton(
        heroTag: UniqueKey(),

        mini: true,
        child: Icon(Icons.add),
        onPressed: () {},
      ),
    );
  }

  void _clickWho(Member post) async {
    widget.controller.otherUserId = post.id;
    widget.controller.isProfileScreen = false;
    widget.controller.isWhoToFollowScreen = false;
    widget.controller.isOtherUserProfileScreen = true;
    widget.controller.isTrendsScreen = false;
    widget.controller.isNewsFeedScreen = false;
    widget.controller.isBrowseScreen = false;
    widget.controller.isNotificationScreen = false;
    widget.controller.isChatScreen = false;
    widget.controller.isPostDetails = false;
    widget.controller.isSettingsScreen = false;
    widget.controller.isListScreen = false;

    try {
      Get
          .find<NewsfeedController>()
          .userInfo = UserProfile();
      Get
          .find<NewsfeedController>()
          .userInfo = await widget.controller.getOtherUserProfile(post.id);

      await Get.find<OtherUserController>().filterUsersPostPagged(
          "posts", page: 1);
      Get
          .find<OtherUserController>()
          .userPosts
          .forEach((element) {
        element.mute = Get
            .find<NewsfeedController>()
            .userInfo
            .muted;
      });
      Get.find<OtherUserController>().update();
    } catch (_) {};
    widget.controller.update();
  }

  void _clickChatUser(ChatUserModel post) async {
    widget.controller.otherUserId = post.memberId;
    widget.controller.isProfileScreen = false;
    widget.controller.isWhoToFollowScreen = false;
    widget.controller.isOtherUserProfileScreen = true;
    widget.controller.isTrendsScreen = false;
    widget.controller.isNewsFeedScreen = false;
    widget.controller.isBrowseScreen = false;
    widget.controller.isNotificationScreen = false;
    widget.controller.isChatScreen = false;
    widget.controller.isPostDetails = false;
    widget.controller.isSettingsScreen = false;
    widget.controller.isListScreen = false;

    try {
      Get
          .find<NewsfeedController>()
          .userInfo = UserProfile();
      Get
          .find<NewsfeedController>()
          .userInfo =
      await widget.controller.getOtherUserProfile(post.memberId);

      await Get.find<OtherUserController>().filterUsersPostPagged(
          "posts", page: 1);
      Get
          .find<OtherUserController>()
          .userPosts
          .forEach((element) {
        element.mute = Get
            .find<NewsfeedController>()
            .userInfo
            .muted;
      });
      Get.find<OtherUserController>().update();
    } catch (_) {}
    widget.controller.update();
  }

  @override
  Widget build(BuildContext context) {
    final cross = (MediaQuery
        .of(context)
        .size
        .width * .025).round();

    bool allowDeleteMsgs = true;
    if (widget.controller.isMessageSelected){
      // Checking if the user has selected any message which was sent by other user.
      // If other user message is selected, we do not allow them to delete. - K
      var userId = widget.controller.storage.read("id");
      List<MessageModel> otherUserMsgList = [];
      otherUserMsgList = widget.controller.selectedMessages.where((element) => element.userId != userId).toList();
      if (otherUserMsgList != null && otherUserMsgList.isNotEmpty){
        allowDeleteMsgs = false;
      }
    }

    if (widget.controller.chatIndex < 0) return const SizedBox();

    return widget.controller.forwardMsgLoading == true || widget.controller.isDeletingConversation
        ? Center(child: CircularProgressIndicator()) :

      // Scaffold(
      // body: NestedScrollView(
      //   controller: _scrollController,
      //   headerSliverBuilder: (context, innerBoxIsScrolled) {
      //     return [
      //       SliverAppBar(
      //         elevation: 0,
      //         backgroundColor: Theme.of(context).brightness == Brightness.dark?Colors.black:Colors.white.withOpacity(0.9),
      //         automaticallyImplyLeading: false,
      //         pinned: true,
      //         expandedHeight: 250,
      //
      //         flexibleSpace: FlexibleSpaceBar(
      //           centerTitle: true,
      //           titlePadding: EdgeInsets.zero,
      //           collapseMode: CollapseMode.parallax,
      //           title: isShrink ? Container() : null,
      //           background: Container(),
      //         ),
      //
      //       ),
      //     ];
      //   },
      //  body:
      Material(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              // height: 100,
              decoration: BoxDecoration(
                color: Theme
                    .of(context)
                    .brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white54,
                // border: Border(
                //   bottom: BorderSide(color: Colors.grey[300], width: 2),
                // ),
              ),
              child:

            widget.controller.isMessageSelected
                ? Padding(
              padding: const EdgeInsets.only(left: 10.0, top: 10, bottom: 6),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      widget.controller.isMessageSelected = false;
                      widget.controller.selecteMessagesId.clear();
                      widget.controller.selectedMessages.clear();
                      for (int i = 0;
                      i < widget.controller.messages.length;
                      i++) {
                        widget.controller.messages[i].isMessageSelected =
                        false;
                        widget.controller.update();
                      }
                    },
                    icon: Icon(Icons.arrow_back,
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors.white : Colors
                          .black,
                      size: 25,
                    ),
                  ),
                  Spacer(),
                  IconButton(
                    color: Colors.blue,
                    onPressed: () {
                      widget.controller.isMessageSelected = false;

                      for (int i = 0;
                      i < widget.controller.messages.length;
                      i++) {
                        widget.controller.messages[i].isMessageSelected =
                        false;
                        widget.controller.update();
                      }
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            contentPadding: EdgeInsets.zero,
                            insetPadding: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            content: ForwardMessageDialogBox(),
                          );
                        },
                      );
                    },
                    icon: Icon(Icons.arrow_forward),
                  ),
                  IconButton(
                    color: allowDeleteMsgs ? Colors.red : Colors.black12,
                    onPressed: () {
                      if (allowDeleteMsgs){
                        // We let the user delete only the messages sent by themselves.
                        // In the for loop, we check and take only the messages which sent by themselves to delete. - K
                        List<int> selectedMessagesIdToDelete = [];
                        for (int i = 0; i <
                            widget.controller.selectedMessages.length; i++) {
                          if (widget.controller.selectedMessages[i].userId ==
                              widget.controller.storage.read("id")) {
                            selectedMessagesIdToDelete.add(widget.controller
                                .selectedMessages[i].id);
                          }
                        }

                        widget.controller.deleteMsg(null, true,
                            multipleIds: selectedMessagesIdToDelete);
                        // widget.controller.selecteMessagesId);
                        widget.controller.selecteMessagesId.clear();
                        widget.controller.selectedMessages.clear();
                        widget.controller.isMessageSelected = false;
                        widget.controller.update();
                      }

                    },
                    icon: Icon(Icons.delete),
                  ),
                ],
              ),
            )
                :

              !widget.isFromMessagePopup ? Padding(
                padding: const EdgeInsets.only(
                    left: 10.0, top: 10, bottom: 6, right: 5),
                child: InkWell(
                  onTap: kIsWeb
                      ? () {
                    widget.controller.showOverlay = false;
                    widget.controller.infoChatInfo = true;
                    if (widget.controller.chatName.conversationType == "single"){
                      widget.controller.getSnoozeNotification("message");
                    } else {
                      widget.controller.getSnoozeNotification("message");
                      widget.controller.getSnoozeNotification("mention");
                    }

                    widget.controller.update();
                  }
                      : () {
                    widget.controller.showOverlay = false;
                    widget.controller.update();

                    ///Edit group for mobile
                    showModalBottomSheet(
                        isDismissible: false,
                        isScrollControlled: true,
                        backgroundColor: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors.black : Colors
                            .white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20))),
                        context: context,
                        builder: (context) {
                          return StatefulBuilder(
                              builder: (context, setState) {
                                return Container(
                                  height: widget.controller.chatName
                                      .conversationType ==
                                      'single'
                                      ? Get.height / 1.9
                                      : Get.height / 1.5,
                                  child: SingleChildScrollView(
                                    child: Column(
                                      children: [
                                        Container(
                                          // height: Get.height/9,

                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  IconButton(
                                                      onPressed: () {
                                                        Navigator.of(
                                                            context)
                                                            .pop();
                                                        widget.controller.showOverlay = true;
                                                        widget.controller
                                                            .update();
                                                      },
                                                      icon: Icon(
                                                          Icons.close)),
                                                  SizedBox(
                                                    width: 20,
                                                  ),
                                                  Text(
                                                    widget.controller.chatName
                                                        .conversationType ==
                                                        "group"
                                                        ? Strings.groupInfo
                                                        : Strings.chatInfo,
                                                    style: Styles.baseTextTheme
                                                        .headline2.copyWith(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark ? Colors
                                                          .white : Colors.black,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Container(
                                                margin: EdgeInsets.only(
                                                    top: 10, bottom: 10),
                                                height: 1,
                                                color: Colors.grey.withOpacity(
                                                    0.4),
                                                width: Get.width,
                                              ),
                                              widget.controller.chatName.conversationType == "group" ? ListTile(

                                                leading:


                                                CircleAvatar(
                                                  backgroundImage:
                                                  widget.controller.chatName
                                                      .profileImage != null &&
                                                      widget.controller.chatName
                                                          .profileImage != "null"
                                                      ?

                                                  NetworkImage(
                                                      widget.controller.chatName
                                                          .profileImage
                                                    // 'assets/images/person_placeholder.png'

                                                  )
                                                      :

                                                  widget.controller
                                                      .tempProfileImageGroupChat !=
                                                      null
                                                      ?
                                                  MemoryImage(widget.controller
                                                      .tempProfileImageGroupChat)
                                                      :
                                                  widget.controller.chatName
                                                      .groupImage != null &&
                                                      widget.controller.chatName
                                                          .groupImage != "null" ?
                                                  NetworkImage(
                                                      widget.controller.chatName
                                                          .groupImage
                                                    // 'assets/images/person_placeholder.png'

                                                  )


                                                      :
                                                  AssetImage(
                                                      'assets/images/person_placeholder.png'

                                                  ),
                                                ),
                                                trailing: widget
                                                    .controller
                                                    .chatName
                                                    .conversationType !=
                                                    "group"
                                                    ? SizedBox()
                                                    : InkWell(
                                                  child: Text(
                                                    Strings.edit,
                                                    // style: TextStyle(
                                                    //     color: Colors
                                                    //         .blueAccent),
                                                    style: Styles.baseTextTheme
                                                        .headline2.copyWith(
                                                      color: widget.controller
                                                          .displayColor,
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 14,

                                                    ),),
                                                  onTap: () {
                                                    widget.controller
                                                        .profileImageGroupChat =
                                                    null;
                                                    widget.controller.update();

                                                    showDialog(
                                                      context:
                                                      context,
                                                      builder:
                                                          (BuildContext
                                                      context) {
                                                        return StatefulBuilder(
                                                            builder:
                                                                (context,
                                                                setState) {
                                                              return AlertDialog(
                                                                contentPadding:
                                                                EdgeInsets.zero,
                                                                insetPadding:
                                                                EdgeInsets.zero,
                                                                shape:
                                                                RoundedRectangleBorder(
                                                                  borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                      20),
                                                                ),
                                                                content:
                                                                Container(
                                                                  height:
                                                                  300,
                                                                  width:
                                                                  400,
                                                                  child:
                                                                  Form(
                                                                    key:
                                                                    _formKey,
                                                                    child:
                                                                    Column(
                                                                      crossAxisAlignment: CrossAxisAlignment
                                                                          .center,
                                                                      mainAxisAlignment: MainAxisAlignment
                                                                          .spaceBetween,
                                                                      children: [
                                                                        Column(
                                                                          children: [
                                                                            ListTile(
                                                                              title: Text(
                                                                                Strings.editGroup,
                                                                                style: Styles
                                                                                    .baseTextTheme
                                                                                    .headline2
                                                                                    .copyWith(
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                  //fontSize: 14,
                                                                                  fontWeight: FontWeight
                                                                                      .bold,
                                                                                ),
                                                                              ),
                                                                              leading: IconButton(
                                                                                icon: Icon(
                                                                                  Icons
                                                                                      .close,
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                ),
                                                                                onPressed: () {
                                                                                  Navigator
                                                                                      .of(
                                                                                      context)
                                                                                      .pop();
                                                                                },
                                                                              ),
                                                                              trailing: MaterialButton(
                                                                                child: Text(
                                                                                    Strings
                                                                                        .save,
                                                                                    style: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? TextStyle(
                                                                                      color: Colors
                                                                                          .white,
                                                                                    )
                                                                                        : TextStyle(
                                                                                        color: Colors
                                                                                            .black)),
                                                                                onPressed: widget
                                                                                    .controller
                                                                                    .groupName ==
                                                                                    null &&
                                                                                    widget
                                                                                        .controller
                                                                                        .profileImageGroupChat ==
                                                                                        null
                                                                                    ? null
                                                                                    : () {
                                                                                  if (widget
                                                                                      .controller
                                                                                      .groupName !=
                                                                                      null &&
                                                                                      widget
                                                                                          .controller
                                                                                          .profileImageGroupChat !=
                                                                                          null) {
                                                                                    _formKey
                                                                                        .currentState
                                                                                        .save();
                                                                                    widget
                                                                                        .controller
                                                                                        .updateGroupName(
                                                                                        context,
                                                                                        groupName: widget
                                                                                            .controller
                                                                                            .groupName,
                                                                                        conversationId: widget
                                                                                            .controller
                                                                                            .chatName
                                                                                            .conversationId);
                                                                                    widget
                                                                                        .controller
                                                                                        .update();
                                                                                    widget
                                                                                        .controller
                                                                                        .updateGroupImage(
                                                                                      conversationId: widget
                                                                                          .controller
                                                                                          .chatName
                                                                                          .conversationId,
                                                                                      groupProfileImage: widget
                                                                                          .controller
                                                                                          .profileImageGroupChat,
                                                                                    );
                                                                                    widget
                                                                                        .controller
                                                                                        .tempGroupName =
                                                                                        widget
                                                                                            .controller
                                                                                            .groupName;
                                                                                    widget
                                                                                        .controller
                                                                                        .tempProfileImageGroupChat =
                                                                                        widget
                                                                                            .controller
                                                                                            .profileImageGroupChat;
                                                                                    widget
                                                                                        .controller
                                                                                        .update();
                                                                                  } else
                                                                                  if (widget
                                                                                      .controller
                                                                                      .groupName !=
                                                                                      null) {
                                                                                    _formKey
                                                                                        .currentState
                                                                                        .save();
                                                                                    //
                                                                                    // print(
                                                                                    //     widget
                                                                                    //         .controller
                                                                                    //         .groupName);
                                                                                    // print(
                                                                                    //     widget
                                                                                    //         .controller
                                                                                    //         .groupName);
                                                                                    // print(
                                                                                    //     widget
                                                                                    //         .controller
                                                                                    //         .groupName);
                                                                                    // print(
                                                                                    //     widget
                                                                                    //         .controller
                                                                                    //         .groupName);
                                                                                    widget
                                                                                        .controller
                                                                                        .updateGroupName(
                                                                                        context,
                                                                                        groupName: widget
                                                                                            .controller
                                                                                            .groupName,
                                                                                        conversationId: widget
                                                                                            .controller
                                                                                            .chatName
                                                                                            .conversationId);
                                                                                    widget
                                                                                        .controller
                                                                                        .tempGroupName =
                                                                                        widget
                                                                                            .controller
                                                                                            .groupName;
                                                                                    widget
                                                                                        .controller
                                                                                        .update();
                                                                                  } else
                                                                                  if (widget
                                                                                      .controller
                                                                                      .profileImageGroupChat !=
                                                                                      null) {
                                                                                    widget
                                                                                        .controller
                                                                                        .updateGroupImage(
                                                                                      conversationId: widget
                                                                                          .controller
                                                                                          .chatName
                                                                                          .conversationId,
                                                                                      groupProfileImage: widget
                                                                                          .controller
                                                                                          .profileImageGroupChat,
                                                                                    );
                                                                                    widget
                                                                                        .controller
                                                                                        .tempProfileImageGroupChat =
                                                                                        widget
                                                                                            .controller
                                                                                            .profileImageGroupChat;
                                                                                    widget
                                                                                        .controller
                                                                                        .update();
                                                                                  }
                                                                                },
                                                                                color: widget
                                                                                    .controller
                                                                                    .displayColor,
                                                                                shape: RoundedRectangleBorder(
                                                                                    borderRadius: BorderRadius
                                                                                        .circular(
                                                                                        20.0)),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              color: Colors
                                                                                  .grey
                                                                                  .withOpacity(
                                                                                  0.1),
                                                                              height: 1,
                                                                              width: Get
                                                                                  .width,
                                                                              margin: EdgeInsets
                                                                                  .only(
                                                                                  top: 5,
                                                                                  bottom: 20),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                        Stack(
                                                                          alignment: Alignment
                                                                              .center,
                                                                          children: [

                                                                            widget
                                                                                .controller
                                                                                .tempProfileImageGroupChat !=
                                                                                null
                                                                                ?
                                                                            CircleAvatar(
                                                                              maxRadius: 60,
                                                                              minRadius: 60,
                                                                              backgroundImage: MemoryImage(
                                                                                  widget
                                                                                      .controller
                                                                                      .tempProfileImageGroupChat),
                                                                              backgroundColor: Colors
                                                                                  .white,
                                                                            )
                                                                                :


                                                                            widget
                                                                                .controller
                                                                                .profileImageGroupChat !=
                                                                                null
                                                                                ? CircleAvatar(
                                                                              maxRadius: 60,
                                                                              minRadius: 60,
                                                                              backgroundImage: MemoryImage(
                                                                                  widget
                                                                                      .controller
                                                                                      .profileImageGroupChat),
                                                                              backgroundColor: Colors
                                                                                  .white,
                                                                            )
                                                                                :

                                                                            widget
                                                                                .controller
                                                                                .chatName
                                                                                .conversationType ==
                                                                                'group' &&
                                                                                widget
                                                                                    .controller
                                                                                    .chatName
                                                                                    .groupImage !=
                                                                                    null
                                                                                ?

                                                                            CircleAvatar(
                                                                              backgroundImage: NetworkImage(
                                                                                  widget
                                                                                      .controller
                                                                                      .chatName
                                                                                      .groupImage),
                                                                              minRadius: 60,
                                                                              maxRadius: 60,
                                                                            )
                                                                                : CircleAvatar(
                                                                              backgroundImage: AssetImage(
                                                                                  'assets/images/person_placeholder.png'),
                                                                              minRadius: 60,
                                                                              maxRadius: 60,
                                                                            ),
                                                                            IconButton(
                                                                                onPressed: () async {
                                                                                  widget
                                                                                      .controller
                                                                                      .tempProfileImageGroupChat =
                                                                                  null;
                                                                                  widget
                                                                                      .controller
                                                                                      .update();
                                                                                  widget
                                                                                      .controller
                                                                                      .profileImageGroupChat =
                                                                                  await widget
                                                                                      .controller
                                                                                      .callGetImage();
                                                                                  setState(() {});
                                                                                },
                                                                                icon: Icon(
                                                                                  Icons
                                                                                      .camera_alt_outlined,
                                                                                  size: 25,
                                                                                  color: Colors
                                                                                      .black,
                                                                                )),
                                                                          ],
                                                                        ),
                                                                        Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              8.0),
                                                                          child: TextFormField(
                                                                            cursorColor: Colors
                                                                                .blue,
                                                                            initialValue: widget
                                                                                .controller
                                                                                .groupName ==
                                                                                'null'
                                                                                ? ''
                                                                                : widget
                                                                                .controller
                                                                                .groupName,
                                                                            onSaved: (
                                                                                val) {
                                                                              widget
                                                                                  .controller
                                                                                  .groupName =
                                                                                  val;
                                                                            },
                                                                            decoration: new InputDecoration(
                                                                              fillColor: Colors
                                                                                  .grey[250],
                                                                              label: Text(Strings.enterGroupChatTitle
                                                                                  ),
                                                                              labelStyle: Styles
                                                                                  .baseTextTheme
                                                                                  .headline2
                                                                                  .copyWith(
                                                                                color: Theme
                                                                                    .of(
                                                                                    context)
                                                                                    .brightness ==
                                                                                    Brightness
                                                                                        .dark
                                                                                    ? Colors
                                                                                    .white
                                                                                    : Colors
                                                                                    .black,
                                                                                fontSize: 14,
                                                                              ),
                                                                              focusedBorder: OutlineInputBorder(
                                                                                borderRadius: BorderRadius
                                                                                    .circular(
                                                                                    5),
                                                                                borderSide: BorderSide(
                                                                                    color: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .colorScheme
                                                                                        .secondary,
                                                                                    width: 1.0),
                                                                              ),
                                                                              enabledBorder: OutlineInputBorder(
                                                                                borderRadius: BorderRadius
                                                                                    .circular(
                                                                                    5),
                                                                                borderSide: BorderSide(
                                                                                  color: Colors
                                                                                      .grey
                                                                                      .withOpacity(
                                                                                      0.6),
                                                                                  width: 1.0,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              );
                                                            });
                                                      },
                                                    );
                                                  },
                                                ),
                                                // title: Row(
                                                //   children: [
                                                //     Text(
                                                //         "${widget.controller.groupName != null ? widget.controller.groupName : widget.controller.chatName.name}",
                                                //         style: Theme.of(context).brightness == Brightness.dark ?
                                                //         TextStyle(color: Colors.white,
                                                //
                                                //         )
                                                //             : TextStyle( color: Colors.black
                                                //         )),
                                                //   ],
                                                // ),
                                                title: chatTitle(),
                                              ) : SizedBox(),
                                              widget.controller.chatName.conversationType == "group" ? Container(
                                                margin: EdgeInsets.only(
                                                    top: 10, bottom: 10),
                                                height: 1,
                                                color: Colors.grey
                                                    .withOpacity(0.4),
                                                width: Get.width,
                                              ) : SizedBox(),
                                              widget.controller.chatName.conversationType == "group" ? Padding(
                                                padding:
                                                const EdgeInsets.only(
                                                    top: 8.0,
                                                    bottom: 8.0,
                                                    left: 15),
                                                child: Text(
                                                  Strings.peopleInThisChat,
                                                  // style: TextStyle(
                                                  //     color: Colors
                                                  //         .blueAccent,
                                                  //     fontSize: 18),
                                                  style: Styles.baseTextTheme
                                                      .headline2.copyWith(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark ? Colors
                                                        .white : Colors.black,
                                                    // fontSize: 14,
                                                    fontWeight: FontWeight.bold,
                                                  ),),
                                              ) : SizedBox(),
                                              widget.controller.chatName
                                                  .conversationType != "group"
                                                  ? GestureDetector(
                                                // onTap: kIsWeb ? () {
                                                //   Get
                                                //       .find<NewsfeedController>()
                                                //       .userInfo = UserProfile();
                                                //   Get.find<NewsfeedController>()
                                                //       .update();
                                                //   _clickChatUser(widget
                                                //       .controller
                                                //       .chatName
                                                //   );
                                                // }
                                                //     : () async {
                                                //   _clickChatUser(widget
                                                //       .controller.chatName
                                                //   );
                                                //   Navigator.push(context,
                                                //       MaterialPageRoute(builder: (
                                                //           BuildContext context) =>
                                                //           OtherUsersProfile(
                                                //               controller: widget
                                                //                   .controller)));
                                                // },
                                                child: ListTile(
                                                  leading:
                                                  CircleAvatar(
                                                    backgroundImage:
                                                    widget.controller.chatName
                                                        .profileImage != null &&
                                                        widget.controller.chatName
                                                            .profileImage !=
                                                            "null"
                                                        ?

                                                    NetworkImage(
                                                        widget.controller.chatName
                                                            .profileImage
                                                      // 'assets/images/person_placeholder.png'

                                                    )
                                                        : AssetImage(
                                                        'assets/images/person_placeholder.png'

                                                    ),
                                                  ),
                                                  // trailing:
                                                  //     MaterialButton(
                                                  //   shape: RoundedRectangleBorder(
                                                  //       borderRadius:
                                                  //           BorderRadius
                                                  //               .circular(
                                                  //                   20.0)),
                                                  //   child: Text(
                                                  //     controller
                                                  //             .chatName
                                                  //             .singlePersonFollow
                                                  //         ? Strings
                                                  //             .unFollow
                                                  //         : Strings
                                                  //             .follow,
                                                  //     style: TextStyle(
                                                  //         color: Colors
                                                  //             .white),
                                                  //   ),
                                                  //   onPressed: () {
                                                  //     controller
                                                  //             .chatName
                                                  //             .singlePersonFollow
                                                  //         ? {
                                                  //             controller
                                                  //                 .chatName
                                                  //                 .singlePersonFollow = false,
                                                  //             setState(
                                                  //                 () {}),
                                                  //             controller
                                                  //                 .update(),
                                                  //             controller.addFollowing(
                                                  //                 controller.chatName.memberId,
                                                  //                 "unfollow")
                                                  //           }
                                                  //         : {
                                                  //             controller
                                                  //                 .chatName
                                                  //                 .singlePersonFollow = true,
                                                  //             setState(
                                                  //                 () {}),
                                                  //             controller
                                                  //                 .update(),
                                                  //             controller.addFollowing(
                                                  //                 controller.chatName.memberId,
                                                  //                 "follow"),
                                                  //           };
                                                  //   },
                                                  //   color: Theme.of(
                                                  //           context)
                                                  //       .colorScheme
                                                  //       .secondary,
                                                  // ),
                                                  title: Text(
                                                    "${widget.controller.chatName
                                                        .name}",
                                                    style: Styles.baseTextTheme
                                                        .headline2.copyWith(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark ? Colors
                                                          .white : Colors.black,
                                                      fontSize: 14,
                                                      fontWeight: FontWeight.bold,
                                                    ),),
                                                  subtitle: Text(
                                                    "${widget.controller.chatName
                                                        .username == null
                                                        ? Strings.groupsTabChat
                                                        : widget.controller
                                                        .chatName
                                                        .username}",
                                                    style: Styles.baseTextTheme
                                                        .headline2.copyWith(
                                                      //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                      fontSize: kIsWeb ? 14 : 12,
                                                      fontWeight: FontWeight.w400,
                                                    ),),
                                                  onTap: kIsWeb ? () {
                                                    Get
                                                        .find<NewsfeedController>()
                                                        .userInfo = UserProfile();
                                                    Get.find<NewsfeedController>()
                                                        .update();
                                                    _clickChatUser(widget
                                                        .controller
                                                        .chatName
                                                    );
                                                    Get.toNamed(FluroRouters.mainScreen +
                                                        "/profile/" +
                                                        widget.controller.otherUserId
                                                            .toString());
                                                  }
                                                      : () async {
                                                    _clickChatUser(widget
                                                        .controller.chatName
                                                    );
                                                    Navigator.push(context,
                                                        MaterialPageRoute(builder: (
                                                            BuildContext context) =>
                                                            OtherUsersProfile(
                                                                controller: widget
                                                                    .controller)));
                                                  },
                                                ),
                                              )
                                                  : Column(

                                                ///2nd list
                                                children: List.generate(
                                                    widget.controller.chatName
                                                        .members.length,
                                                        (ind) {
                                                      return GestureDetector(
                                                        // onTap: kIsWeb ? () {
                                                        //   if (widget.controller
                                                        //       .userProfile
                                                        //       .userId != widget
                                                        //       .controller.chatName
                                                        //       .members[ind].id) {
                                                        //     Get
                                                        //         .find<
                                                        //         NewsfeedController>()
                                                        //         .userInfo =
                                                        //         UserProfile();
                                                        //     Get.find<
                                                        //         NewsfeedController>()
                                                        //         .update();
                                                        //     _clickWho(widget
                                                        //         .controller
                                                        //         .chatName
                                                        //         .members[ind]);
                                                        //   }
                                                        // }
                                                        //     : () async {
                                                        //   print(
                                                        //       'check userids ${widget
                                                        //           .controller
                                                        //           .userProfile
                                                        //           .userId} and ${widget
                                                        //           .controller
                                                        //           .chatName
                                                        //           .members[ind]
                                                        //           .id}');
                                                        //   if (widget.controller
                                                        //       .userProfile
                                                        //       .userId != widget
                                                        //       .controller.chatName
                                                        //       .members[ind].id) {
                                                        //     _clickWho(widget
                                                        //         .controller
                                                        //         .chatName
                                                        //         .members[ind]);
                                                        //     Navigator.push(
                                                        //         context,
                                                        //         MaterialPageRoute(
                                                        //             builder: (
                                                        //                 BuildContext context) =>
                                                        //                 OtherUsersProfile(
                                                        //                     controller: widget
                                                        //                         .controller)));
                                                        //   }
                                                        // },
                                                        child: ListTile(
                                                          leading:
                                                          CircleAvatar(
                                                            backgroundImage:
                                                            widget.controller
                                                                .chatName
                                                                .members[ind]
                                                                .profileImage !=
                                                                null && widget
                                                                .controller
                                                                .chatName
                                                                .members[ind]
                                                                .profileImage !=
                                                                "null" ?
                                                            NetworkImage(
                                                                widget.controller
                                                                    .chatName
                                                                    .members[ind]
                                                                    .profileImage
                                                              // 'assets/images/person_placeholder.png'

                                                            ) : AssetImage(
                                                                'assets/images/person_placeholder.png'),
                                                          ),
                                                          // trailing: controller
                                                          //             .chatName
                                                          //             .members[
                                                          //                 ind]
                                                          //             .id
                                                          //             .toString() ==
                                                          //         controller
                                                          //             .storage
                                                          //             .read('id')
                                                          //             .toString()
                                                          //     ? SizedBox()
                                                          //     : MaterialButton(
                                                          //         shape: RoundedRectangleBorder(
                                                          //             borderRadius:
                                                          //                 BorderRadius.circular(20.0)),
                                                          //         child:
                                                          //             Text(
                                                          //           controller.chatName.members[ind].follow
                                                          //               ? "Unfollow"
                                                          //               : "Follow",
                                                          //           style:
                                                          //               TextStyle(color: Colors.white),
                                                          //         ),
                                                          //         onPressed:
                                                          //             () async {
                                                          //           if (controller.chatName.members[ind].follow ==
                                                          //               false) {
                                                          //             // controller.followSuggestionsList[index].isFollow =
                                                          //             //     true;
                                                          //             controller.update();
                                                          //             await controller.addFollowing(controller.chatName.members[ind].id,
                                                          //                 "follow");
                                                          //           } else if (controller.chatName.members[ind].follow ==
                                                          //               true) {
                                                          //             // controller.followSuggestionsList[index].isFollow =
                                                          //             //     false;
                                                          //             await controller.addFollowing(controller.chatName.members[ind].id,
                                                          //                 "unFollow");
                                                          //             controller.update();
                                                          //           }
                                                          //           print(
                                                          //               "Followed Id yahha");
                                                          //           // print(
                                                          //           //     "${controller.followSuggestionsList[index].id}");
                                                          //         },
                                                          //         color: Theme.of(context)
                                                          //             .colorScheme
                                                          //             .secondary,
                                                          //       ),
                                                          title:widget.controller.chatUserList[ind].name ==null ||widget.controller.chatUserList[ind].name =="" ||widget.controller.chatUserList[ind].name =="null"?
                                                          Text(Strings.werfieUser,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness.dark
                                                                  ? Colors.white
                                                                  : Colors.black,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight
                                                                  .bold,
                                                            ),
                                                          ):
                                                          Text(
                                                            "${widget.controller
                                                                .chatName
                                                                .members[ind]
                                                                .firstname} ${widget
                                                                .controller
                                                                .chatName
                                                                .members[ind]
                                                                .lastname}",
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness.dark
                                                                  ? Colors.white
                                                                  : Colors.black,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight
                                                                  .bold,
                                                            ),),
                                                          subtitle: widget.controller.chatName.members[ind].username ==null ||widget.controller.chatName.members[ind].username =="" ||widget.controller.chatName.members[ind].username =="null"?
                                                          Text("",
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline2
                                                                  .copyWith(
                                                                // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                fontSize: kIsWeb
                                                                    ? 14
                                                                    : 12,
                                                                fontWeight: FontWeight
                                                                    .w400,
                                                              )):
                                                          Text(
                                                            "${widget.controller
                                                                .chatName
                                                                .members[ind]
                                                                .username}",
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 12,
                                                              fontWeight: FontWeight
                                                                  .w400,
                                                            ),),
                                                          onTap: kIsWeb ? () {
                                                            if (widget.controller
                                                                .userProfile
                                                                .userId != widget
                                                                .controller.chatName
                                                                .members[ind].id) {
                                                              Get
                                                                  .find<
                                                                  NewsfeedController>()
                                                                  .userInfo =
                                                                  UserProfile();
                                                              Get.find<
                                                                  NewsfeedController>()
                                                                  .update();
                                                              _clickWho(widget
                                                                  .controller
                                                                  .chatName
                                                                  .members[ind]);
                                                              Get.toNamed(FluroRouters.mainScreen +
                                                                  "/profile/" +
                                                                  widget.controller.otherUserId
                                                                      .toString());
                                                            }
                                                          }
                                                              : () async {
                                                            print(
                                                                'check userids ${widget
                                                                    .controller
                                                                    .userProfile
                                                                    .userId} and ${widget
                                                                    .controller
                                                                    .chatName
                                                                    .members[ind]
                                                                    .id}');
                                                            if (widget.controller
                                                                .userProfile
                                                                .userId != widget
                                                                .controller.chatName
                                                                .members[ind].id) {
                                                              _clickWho(widget
                                                                  .controller
                                                                  .chatName
                                                                  .members[ind]);
                                                              Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                      builder: (
                                                                          BuildContext context) =>
                                                                          OtherUsersProfile(
                                                                              controller: widget
                                                                                  .controller)));
                                                            }
                                                          },
                                                        ),
                                                      );
                                                    }),
                                              ),
                                              SizedBox(
                                                height: 10,
                                              ),
                                              widget.controller.chatName
                                                  .conversationType ==
                                                  'single'
                                                  ? SizedBox()
                                                  : Center(
                                                  child: InkWell(
                                                    child: Text(
                                                      Strings.addPeople,
                                                      style: Styles.baseTextTheme
                                                          .headline2.copyWith(
                                                        color: widget.controller
                                                            .displayColor,
                                                        fontSize: 14,
                                                        fontWeight: FontWeight
                                                            .bold,
                                                      ),),
                                                    onTap: () {
                                                      showDialog(
                                                        context:
                                                        context,
                                                        builder:
                                                            (BuildContext
                                                        context) {
                                                          return AlertDialog(
                                                            contentPadding:
                                                            EdgeInsets
                                                                .zero,
                                                            insetPadding:
                                                            EdgeInsets
                                                                .zero,
                                                            shape:
                                                            RoundedRectangleBorder(
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  20),
                                                            ),
                                                            content:
                                                            NewMessageDialogBox(
                                                              isAddingMembersToChat:
                                                              true,
                                                              conversationId: widget
                                                                  .controller
                                                                  .chatName
                                                                  .conversationId,
                                                            ),
                                                          );
                                                        },
                                                      );
                                                    },
                                                  )),
                                              notificationSettings(context, setState),
                                              Container(
                                                margin: const EdgeInsets.only(top: 5, bottom: 5),
                                                height: 1,
                                                color: Colors.grey.withOpacity(0.4),
                                                width: Get.width,
                                              ),
                                              widget.controller.chatName
                                                  .conversationType == 'single'
                                                  ? Center(
                                                  child: InkWell(
                                                    child: Text(
                                                        Strings.deleteConversation,
                                                        // style: TextStyle(
                                                        //     color: Colors
                                                        //         .red
                                                        //         .withOpacity(
                                                        //             0.5),
                                                        //     fontSize: 18),
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2.copyWith(
                                                          color: Colors.red,
                                                          fontSize: 14,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                        )),
                                                    onTap: () async {
                                                      await widget
                                                          .controller
                                                          .deleteConversation(
                                                          widget
                                                              .controller
                                                              .chatName
                                                              .conversationId);
                                                      Navigator.of(
                                                          context)
                                                          .pop();
                                                      Navigator.of(
                                                          context)
                                                          .pop();
                                                      widget.controller
                                                          .chatUserList =
                                                      await widget
                                                          .controller
                                                          .getChat();
                                                      // await widget.controller.getMessageRequest();

                                                      widget.controller
                                                          .update();
                                                    },
                                                  ))
                                                  : Center(
                                                  child: InkWell(
                                                    child: Text(
                                                        Strings
                                                            .leaveConversation,
                                                        // style: TextStyle(
                                                        //     color: Colors
                                                        //         .red
                                                        //         .withOpacity(
                                                        //             0.5),
                                                        //     fontSize: 18),
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2.copyWith(
                                                          color: Colors.red,
                                                          fontSize: 14,
                                                          fontWeight: FontWeight
                                                              .bold,
                                                        )),
                                                    onTap: () async {
                                                      await widget
                                                          .controller
                                                          .leaveConversation(
                                                          widget
                                                              .controller
                                                              .chatName
                                                              .conversationId);
                                                      Navigator.of(
                                                          context)
                                                          .pop();
                                                      Navigator.of(
                                                          context)
                                                          .pop();
                                                      widget.controller
                                                          .chatUserList =
                                                      await widget
                                                          .controller
                                                          .getChat();

                                                      widget.controller
                                                          .update();
                                                    },
                                                  )),
                                              SizedBox(height: 10,),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              });
                        });
                  },
                  child: ListTile(
                    mouseCursor: MouseCursor.defer,
                    contentPadding: EdgeInsets.zero,

                    leading:
                    // controller.groupName != null ? controller.groupName :
                    Container(
                      width: kIsWeb ? MediaQuery
                          .of(context)
                          .size
                          .width <= 1050 ? 100 : 70
                          : 100,
                      child: Row(
                        children: [
                          // SizedBox(width: 10,),
                          kIsWeb
                              ? MediaQuery
                              .of(context)
                              .size
                              .width <= 1050
                              ? IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                            onPressed: () async {
                              widget.controller.onChatsChange = true;
                              widget.controller.isChatScreenWeb = false;
                              // widget.controller.navRoute = "isChatScreen";
                              // widget.controller.chatUserList = await widget.controller.getChat();
                              // print(" controller.chatUserList ${widget.controller.chatUserList}");
                              // // print("preesssseddd");
                              widget.controller.update();
                            },
                          )
                              : SizedBox()
                              : IconButton(
                            icon: Icon(
                              Icons.arrow_back,
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          SizedBox(
                            width: 50,
                            child: widget.controller.chatName
                                // != null ? controller.chatName.profileImage
                                ==
                                null
                                ? Container(
                                width: 24,
                                child: Center(
                                  child: SpinKitCircle(
                                    color: Colors.grey,
                                    size: 40,
                                  ),
                                ))
                                : ClipRRect(
                              borderRadius: BorderRadius.circular(50),
                              child: FadeInImage(
                                // fit: BoxFit.fill,
                                fit: BoxFit.fitWidth,
                                width: 50,
                                height: 50,
                                placeholder: AssetImage(
                                    'assets/images/person_placeholder.png'),
                                image: widget.controller.chatName
                                    .conversationType ==
                                    'single'
                                    ? widget.controller.chatName
                                    .profileImage !=
                                    null
                                    ? NetworkImage(
                                    widget.controller.chatName.profileImage
                                )
                                    : AssetImage(
                                    'assets/images/person_placeholder.png')
                                    : widget.controller.chatName
                                    .conversationType == 'group' ?
                                widget.controller.tempProfileImageGroupChat !=
                                    null ?
                                MemoryImage(
                                    widget.controller.tempProfileImageGroupChat) :

                                widget.controller.chatName.groupImage != null
                                    ?


                                NetworkImage(widget
                                    .controller
                                    .chatName
                                    .groupImage)
                                    : AssetImage(
                                    'assets/images/person_placeholder.png')
                                    : AssetImage(
                                    'assets/images/person_placeholder.png'),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    title: chatTitle(),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        videoCallButton(),
                        IconButton(
                          onPressed: kIsWeb
                              ? () {
                            widget.controller.showOverlay = false;
                            widget.controller.infoChatInfo = true;
                            if (widget.controller.chatName.conversationType == "single"){
                              widget.controller.getSnoozeNotification("message");
                            } else {
                              widget.controller.getSnoozeNotification("message");
                              widget.controller.getSnoozeNotification("mention");
                            }
                            widget.controller.update();
                          }
                              : () {

                            widget.controller.showOverlay = false;
                            widget.controller.update();

                            ///Edit group for mobile
                            showModalBottomSheet(
                                isDismissible: false,
                                isScrollControlled: true,
                                backgroundColor: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? Colors.black : Colors
                                    .white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(20),
                                        topRight: Radius.circular(20))),
                                context: context,
                                builder: (context) {
                                  return StatefulBuilder(
                                      builder: (context, setState) {
                                        return Container(
                                          height: widget.controller.chatName
                                              .conversationType ==
                                              'single'
                                              ? Get.height / 1.9
                                              : Get.height / 1.5,
                                          child: SingleChildScrollView(
                                            child: Column(
                                              children: [
                                                Container(
                                                  // height: Get.height/9,

                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    children: [
                                                      Row(
                                                        children: [
                                                          IconButton(
                                                              onPressed: () {
                                                                Navigator.of(
                                                                    context)
                                                                    .pop();
                                                                widget.controller
                                                                    .showOverlay =
                                                                true;
                                                                widget.controller
                                                                    .update();
                                                              },
                                                              icon: Icon(
                                                                  Icons.close)),
                                                          SizedBox(
                                                            width: 20,
                                                          ),
                                                          Text(
                                                            widget.controller.chatName
                                                                .conversationType ==
                                                                "group"
                                                                ? Strings.groupInfo
                                                                : Strings.chatInfo,
                                                            style: Styles.baseTextTheme
                                                                .headline2.copyWith(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness.dark ? Colors
                                                                  .white : Colors.black,
                                                              fontWeight: FontWeight.bold,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.only(
                                                            top: 10, bottom: 10),
                                                        height: 1,
                                                        color: Colors.grey.withOpacity(
                                                            0.4),
                                                        width: Get.width,
                                                      ),
                                                      widget.controller.chatName.conversationType == "group" ? ListTile(

                                                        leading:


                                                        CircleAvatar(
                                                          backgroundImage:
                                                          widget.controller.chatName
                                                              .profileImage != null &&
                                                              widget.controller.chatName
                                                                  .profileImage != "null"
                                                              ?

                                                          NetworkImage(
                                                              widget.controller.chatName
                                                                  .profileImage
                                                            // 'assets/images/person_placeholder.png'

                                                          )
                                                              :

                                                          widget.controller
                                                              .tempProfileImageGroupChat !=
                                                              null
                                                              ?
                                                          MemoryImage(widget.controller
                                                              .tempProfileImageGroupChat)
                                                              :
                                                          widget.controller.chatName
                                                              .groupImage != null &&
                                                              widget.controller.chatName
                                                                  .groupImage != "null" ?
                                                          NetworkImage(
                                                              widget.controller.chatName
                                                                  .groupImage
                                                            // 'assets/images/person_placeholder.png'

                                                          )


                                                              :
                                                          AssetImage(
                                                              'assets/images/person_placeholder.png'

                                                          ),
                                                        ),
                                                        trailing: widget
                                                            .controller
                                                            .chatName
                                                            .conversationType !=
                                                            "group"
                                                            ? SizedBox()
                                                            : InkWell(
                                                          child: Text(
                                                            Strings.edit,
                                                            // style: TextStyle(
                                                            //     color: Colors
                                                            //         .blueAccent),
                                                            style: Styles.baseTextTheme
                                                                .headline2.copyWith(
                                                              color: widget.controller
                                                                  .displayColor,
                                                              fontWeight: FontWeight.bold,
                                                              fontSize: 14,

                                                            ),),
                                                          onTap: () {
                                                            widget.controller
                                                                .profileImageGroupChat =
                                                            null;
                                                            widget.controller.update();

                                                            showDialog(
                                                              context:
                                                              context,
                                                              builder:
                                                                  (BuildContext
                                                              context) {
                                                                return StatefulBuilder(
                                                                    builder:
                                                                        (context,
                                                                        setState) {
                                                                      return AlertDialog(
                                                                        contentPadding:
                                                                        EdgeInsets.zero,
                                                                        insetPadding:
                                                                        EdgeInsets.zero,
                                                                        shape:
                                                                        RoundedRectangleBorder(
                                                                          borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                              20),
                                                                        ),
                                                                        content:
                                                                        Container(
                                                                          height:
                                                                          300,
                                                                          width:
                                                                          400,
                                                                          child:
                                                                          Form(
                                                                            key:
                                                                            _formKey,
                                                                            child:
                                                                            Column(
                                                                              crossAxisAlignment: CrossAxisAlignment
                                                                                  .center,
                                                                              mainAxisAlignment: MainAxisAlignment
                                                                                  .spaceBetween,
                                                                              children: [
                                                                                Column(
                                                                                  children: [
                                                                                    ListTile(
                                                                                      title: Text(
                                                                                        Strings.editGroup,
                                                                                        style: Styles
                                                                                            .baseTextTheme
                                                                                            .headline2
                                                                                            .copyWith(
                                                                                          color: Theme
                                                                                              .of(
                                                                                              context)
                                                                                              .brightness ==
                                                                                              Brightness
                                                                                                  .dark
                                                                                              ? Colors
                                                                                              .white
                                                                                              : Colors
                                                                                              .black,
                                                                                          //fontSize: 14,
                                                                                          fontWeight: FontWeight
                                                                                              .bold,
                                                                                        ),
                                                                                      ),
                                                                                      leading: IconButton(
                                                                                        icon: Icon(
                                                                                          Icons
                                                                                              .close,
                                                                                          color: Theme
                                                                                              .of(
                                                                                              context)
                                                                                              .brightness ==
                                                                                              Brightness
                                                                                                  .dark
                                                                                              ? Colors
                                                                                              .white
                                                                                              : Colors
                                                                                              .black,
                                                                                        ),
                                                                                        onPressed: () {
                                                                                          Navigator
                                                                                              .of(
                                                                                              context)
                                                                                              .pop();
                                                                                        },
                                                                                      ),
                                                                                      trailing: MaterialButton(
                                                                                        child: Text(
                                                                                            Strings
                                                                                                .save,
                                                                                            style: Theme
                                                                                                .of(
                                                                                                context)
                                                                                                .brightness ==
                                                                                                Brightness
                                                                                                    .dark
                                                                                                ? TextStyle(
                                                                                              color: Colors
                                                                                                  .white,
                                                                                            )
                                                                                                : TextStyle(
                                                                                                color: Colors
                                                                                                    .black)),
                                                                                        onPressed: widget
                                                                                            .controller
                                                                                            .groupName ==
                                                                                            null &&
                                                                                            widget
                                                                                                .controller
                                                                                                .profileImageGroupChat ==
                                                                                                null
                                                                                            ? null
                                                                                            : () {
                                                                                          if (widget
                                                                                              .controller
                                                                                              .groupName !=
                                                                                              null &&
                                                                                              widget
                                                                                                  .controller
                                                                                                  .profileImageGroupChat !=
                                                                                                  null) {
                                                                                            _formKey
                                                                                                .currentState
                                                                                                .save();
                                                                                            widget
                                                                                                .controller
                                                                                                .updateGroupName(
                                                                                                context,
                                                                                                groupName: widget
                                                                                                    .controller
                                                                                                    .groupName,
                                                                                                conversationId: widget
                                                                                                    .controller
                                                                                                    .chatName
                                                                                                    .conversationId);
                                                                                            widget
                                                                                                .controller
                                                                                                .update();
                                                                                            widget
                                                                                                .controller
                                                                                                .updateGroupImage(
                                                                                              conversationId: widget
                                                                                                  .controller
                                                                                                  .chatName
                                                                                                  .conversationId,
                                                                                              groupProfileImage: widget
                                                                                                  .controller
                                                                                                  .profileImageGroupChat,
                                                                                            );
                                                                                            widget
                                                                                                .controller
                                                                                                .tempGroupName =
                                                                                                widget
                                                                                                    .controller
                                                                                                    .groupName;
                                                                                            widget
                                                                                                .controller
                                                                                                .tempProfileImageGroupChat =
                                                                                                widget
                                                                                                    .controller
                                                                                                    .profileImageGroupChat;
                                                                                            widget
                                                                                                .controller
                                                                                                .update();
                                                                                          } else
                                                                                          if (widget
                                                                                              .controller
                                                                                              .groupName !=
                                                                                              null) {
                                                                                            _formKey
                                                                                                .currentState
                                                                                                .save();

                                                                                            print(
                                                                                                widget
                                                                                                    .controller
                                                                                                    .groupName);
                                                                                            print(
                                                                                                widget
                                                                                                    .controller
                                                                                                    .groupName);
                                                                                            print(
                                                                                                widget
                                                                                                    .controller
                                                                                                    .groupName);
                                                                                            print(
                                                                                                widget
                                                                                                    .controller
                                                                                                    .groupName);
                                                                                            widget
                                                                                                .controller
                                                                                                .updateGroupName(
                                                                                                context,
                                                                                                groupName: widget
                                                                                                    .controller
                                                                                                    .groupName,
                                                                                                conversationId: widget
                                                                                                    .controller
                                                                                                    .chatName
                                                                                                    .conversationId);
                                                                                            widget
                                                                                                .controller
                                                                                                .tempGroupName =
                                                                                                widget
                                                                                                    .controller
                                                                                                    .groupName;
                                                                                            widget
                                                                                                .controller
                                                                                                .update();
                                                                                          } else
                                                                                          if (widget
                                                                                              .controller
                                                                                              .profileImageGroupChat !=
                                                                                              null) {
                                                                                            widget
                                                                                                .controller
                                                                                                .updateGroupImage(
                                                                                              conversationId: widget
                                                                                                  .controller
                                                                                                  .chatName
                                                                                                  .conversationId,
                                                                                              groupProfileImage: widget
                                                                                                  .controller
                                                                                                  .profileImageGroupChat,
                                                                                            );
                                                                                            widget
                                                                                                .controller
                                                                                                .tempProfileImageGroupChat =
                                                                                                widget
                                                                                                    .controller
                                                                                                    .profileImageGroupChat;
                                                                                            widget
                                                                                                .controller
                                                                                                .update();
                                                                                          }
                                                                                        },
                                                                                        color: widget
                                                                                            .controller
                                                                                            .displayColor,
                                                                                        shape: RoundedRectangleBorder(
                                                                                            borderRadius: BorderRadius
                                                                                                .circular(
                                                                                                20.0)),
                                                                                      ),
                                                                                    ),
                                                                                    Container(
                                                                                      color: Colors
                                                                                          .grey
                                                                                          .withOpacity(
                                                                                          0.1),
                                                                                      height: 1,
                                                                                      width: Get
                                                                                          .width,
                                                                                      margin: EdgeInsets
                                                                                          .only(
                                                                                          top: 5,
                                                                                          bottom: 20),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                Stack(
                                                                                  alignment: Alignment
                                                                                      .center,
                                                                                  children: [

                                                                                    widget
                                                                                        .controller
                                                                                        .tempProfileImageGroupChat !=
                                                                                        null
                                                                                        ?
                                                                                    CircleAvatar(
                                                                                      maxRadius: 60,
                                                                                      minRadius: 60,
                                                                                      backgroundImage: MemoryImage(
                                                                                          widget
                                                                                              .controller
                                                                                              .tempProfileImageGroupChat),
                                                                                      backgroundColor: Colors
                                                                                          .white,
                                                                                    )
                                                                                        :


                                                                                    widget
                                                                                        .controller
                                                                                        .profileImageGroupChat !=
                                                                                        null
                                                                                        ? CircleAvatar(
                                                                                      maxRadius: 60,
                                                                                      minRadius: 60,
                                                                                      backgroundImage: MemoryImage(
                                                                                          widget
                                                                                              .controller
                                                                                              .profileImageGroupChat),
                                                                                      backgroundColor: Colors
                                                                                          .white,
                                                                                    )
                                                                                        :

                                                                                    widget
                                                                                        .controller
                                                                                        .chatName
                                                                                        .conversationType ==
                                                                                        'group' &&
                                                                                        widget
                                                                                            .controller
                                                                                            .chatName
                                                                                            .groupImage !=
                                                                                            null
                                                                                        ?

                                                                                    CircleAvatar(
                                                                                      backgroundImage: NetworkImage(
                                                                                          widget
                                                                                              .controller
                                                                                              .chatName
                                                                                              .groupImage),
                                                                                      minRadius: 60,
                                                                                      maxRadius: 60,
                                                                                    )
                                                                                        : CircleAvatar(
                                                                                      backgroundImage: AssetImage(
                                                                                          'assets/images/person_placeholder.png'),
                                                                                      minRadius: 60,
                                                                                      maxRadius: 60,
                                                                                    ),
                                                                                    IconButton(
                                                                                        onPressed: () async {
                                                                                          widget
                                                                                              .controller
                                                                                              .tempProfileImageGroupChat =
                                                                                          null;
                                                                                          widget
                                                                                              .controller
                                                                                              .update();
                                                                                          widget
                                                                                              .controller
                                                                                              .profileImageGroupChat =
                                                                                          await widget
                                                                                              .controller
                                                                                              .callGetImage();
                                                                                          setState(() {});
                                                                                        },
                                                                                        icon: Icon(
                                                                                          Icons
                                                                                              .camera_alt_outlined,
                                                                                          size: 25,
                                                                                          color: Colors
                                                                                              .black,
                                                                                        )),
                                                                                  ],
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets
                                                                                      .all(
                                                                                      8.0),
                                                                                  child: TextFormField(
                                                                                    cursorColor: Colors
                                                                                        .blue,
                                                                                    initialValue: widget
                                                                                        .controller
                                                                                        .groupName ==
                                                                                        'null'
                                                                                        ? ''
                                                                                        : widget
                                                                                        .controller
                                                                                        .groupName,
                                                                                    onSaved: (
                                                                                        val) {
                                                                                      widget
                                                                                          .controller
                                                                                          .groupName =
                                                                                          val;
                                                                                    },
                                                                                    decoration: new InputDecoration(
                                                                                      fillColor: Colors
                                                                                          .grey[250],
                                                                                      label: Text(
                                                                                          Strings.enterGroupChatTitle),
                                                                                      labelStyle: Styles
                                                                                          .baseTextTheme
                                                                                          .headline2
                                                                                          .copyWith(
                                                                                        color: Theme
                                                                                            .of(
                                                                                            context)
                                                                                            .brightness ==
                                                                                            Brightness
                                                                                                .dark
                                                                                            ? Colors
                                                                                            .white
                                                                                            : Colors
                                                                                            .black,
                                                                                        fontSize: 14,
                                                                                      ),
                                                                                      focusedBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius
                                                                                            .circular(
                                                                                            5),
                                                                                        borderSide: BorderSide(
                                                                                            color: Theme
                                                                                                .of(
                                                                                                context)
                                                                                                .colorScheme
                                                                                                .secondary,
                                                                                            width: 1.0),
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius
                                                                                            .circular(
                                                                                            5),
                                                                                        borderSide: BorderSide(
                                                                                          color: Colors
                                                                                              .grey
                                                                                              .withOpacity(
                                                                                              0.6),
                                                                                          width: 1.0,
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    });
                                                              },
                                                            );
                                                          },
                                                        ),
                                                        // title: Row(
                                                        //   children: [
                                                        //     Text(
                                                        //         "${widget.controller.groupName != null ? widget.controller.groupName : widget.controller.chatName.name}",
                                                        //         style: Theme.of(context).brightness == Brightness.dark ?
                                                        //         TextStyle(color: Colors.white,
                                                        //
                                                        //         )
                                                        //             : TextStyle( color: Colors.black
                                                        //         )),
                                                        //   ],
                                                        // ),
                                                        /*title: Text(
                                                          "${widget.controller.chatName
                                                              .username == null
                                                              ? Strings.groupsTabChat
                                                              : widget.controller.chatName
                                                              .username}",
                                                          style: Styles.baseTextTheme
                                                              .headline2.copyWith(
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark ? Colors
                                                                .white : Colors.black,
                                                            // fontSize: 14,
                                                            fontWeight: FontWeight.bold,
                                                          ),),*/
                                                        title: chatTitle(),
                                                      ) : SizedBox(),
                                                      widget.controller.chatName.conversationType == "group" ? Container(
                                                        margin: EdgeInsets.only(
                                                            top: 10, bottom: 10),
                                                        height: 1,
                                                        color: Colors.grey
                                                            .withOpacity(0.4),
                                                        width: Get.width,
                                                      ) : SizedBox(),
                                                      widget.controller.chatName.conversationType == "group" ? Padding(
                                                        padding:
                                                        const EdgeInsets.only(
                                                            top: 8.0,
                                                            bottom: 8.0,
                                                            left: 15),
                                                        child: Text(
                                                          Strings.peopleInThisChat,
                                                          // style: TextStyle(
                                                          //     color: Colors
                                                          //         .blueAccent,
                                                          //     fontSize: 18),
                                                          style: Styles.baseTextTheme
                                                              .headline2.copyWith(
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark ? Colors
                                                                .white : Colors.black,
                                                            // fontSize: 14,
                                                            fontWeight: FontWeight.bold,
                                                          ),),
                                                      ) : SizedBox(),
                                                      widget.controller.chatName
                                                          .conversationType != "group"
                                                          ? GestureDetector(
                                                        // onTap: kIsWeb ? () {
                                                        //   Get
                                                        //       .find<NewsfeedController>()
                                                        //       .userInfo = UserProfile();
                                                        //   Get.find<NewsfeedController>()
                                                        //       .update();
                                                        //   _clickChatUser(widget
                                                        //       .controller
                                                        //       .chatName
                                                        //   );
                                                        // }
                                                        //     : () async {
                                                        //   _clickChatUser(widget
                                                        //       .controller.chatName
                                                        //   );
                                                        //   Navigator.push(context,
                                                        //       MaterialPageRoute(builder: (
                                                        //           BuildContext context) =>
                                                        //           OtherUsersProfile(
                                                        //               controller: widget
                                                        //                   .controller)));
                                                        // },
                                                        child: ListTile(
                                                          leading:
                                                          CircleAvatar(
                                                            backgroundImage:
                                                            widget.controller.chatName
                                                                .profileImage != null &&
                                                                widget.controller.chatName
                                                                    .profileImage !=
                                                                    "null"
                                                                ?

                                                            NetworkImage(
                                                                widget.controller.chatName
                                                                    .profileImage
                                                              // 'assets/images/person_placeholder.png'

                                                            )
                                                                : AssetImage(
                                                                'assets/images/person_placeholder.png'

                                                            ),
                                                          ),
                                                          // trailing:
                                                          //     MaterialButton(
                                                          //   shape: RoundedRectangleBorder(
                                                          //       borderRadius:
                                                          //           BorderRadius
                                                          //               .circular(
                                                          //                   20.0)),
                                                          //   child: Text(
                                                          //     controller
                                                          //             .chatName
                                                          //             .singlePersonFollow
                                                          //         ? Strings
                                                          //             .unFollow
                                                          //         : Strings
                                                          //             .follow,
                                                          //     style: TextStyle(
                                                          //         color: Colors
                                                          //             .white),
                                                          //   ),
                                                          //   onPressed: () {
                                                          //     controller
                                                          //             .chatName
                                                          //             .singlePersonFollow
                                                          //         ? {
                                                          //             controller
                                                          //                 .chatName
                                                          //                 .singlePersonFollow = false,
                                                          //             setState(
                                                          //                 () {}),
                                                          //             controller
                                                          //                 .update(),
                                                          //             controller.addFollowing(
                                                          //                 controller.chatName.memberId,
                                                          //                 "unfollow")
                                                          //           }
                                                          //         : {
                                                          //             controller
                                                          //                 .chatName
                                                          //                 .singlePersonFollow = true,
                                                          //             setState(
                                                          //                 () {}),
                                                          //             controller
                                                          //                 .update(),
                                                          //             controller.addFollowing(
                                                          //                 controller.chatName.memberId,
                                                          //                 "follow"),
                                                          //           };
                                                          //   },
                                                          //   color: Theme.of(
                                                          //           context)
                                                          //       .colorScheme
                                                          //       .secondary,
                                                          // ),
                                                          title: Text(
                                                            "${widget.controller.chatName
                                                                .name}",
                                                            style: Styles.baseTextTheme
                                                                .headline2.copyWith(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness.dark ? Colors
                                                                  .white : Colors.black,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight.bold,
                                                            ),),
                                                          subtitle: Text(
                                                            "${widget.controller.chatName
                                                                .username == null
                                                                ? Strings.groupsTabChat
                                                                : widget.controller
                                                                .chatName
                                                                .username}",
                                                            style: Styles.baseTextTheme
                                                                .headline2.copyWith(
                                                              //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize: kIsWeb ? 14 : 12,
                                                              fontWeight: FontWeight.w400,
                                                            ),),
                                                          onTap: kIsWeb ? () {
                                                            Get
                                                                .find<NewsfeedController>()
                                                                .userInfo = UserProfile();
                                                            Get.find<NewsfeedController>()
                                                                .update();
                                                            _clickChatUser(widget
                                                                .controller
                                                                .chatName
                                                            );
                                                            Get.toNamed(FluroRouters.mainScreen +
                                                                "/profile/" +
                                                                widget.controller.otherUserId
                                                                    .toString());
                                                          }
                                                              : () async {
                                                            _clickChatUser(widget
                                                                .controller.chatName
                                                            );
                                                            Navigator.push(context,
                                                                MaterialPageRoute(builder: (
                                                                    BuildContext context) =>
                                                                    OtherUsersProfile(
                                                                        controller: widget
                                                                            .controller)));
                                                          },
                                                        ),
                                                      )
                                                          : Column(

                                                        ///2nd list
                                                        children: List.generate(
                                                            widget.controller.chatName
                                                                .members.length,
                                                                (ind) {
                                                              return GestureDetector(
                                                                // onTap: kIsWeb ? () {
                                                                //   if (widget.controller
                                                                //       .userProfile
                                                                //       .userId != widget
                                                                //       .controller.chatName
                                                                //       .members[ind].id) {
                                                                //     Get
                                                                //         .find<
                                                                //         NewsfeedController>()
                                                                //         .userInfo =
                                                                //         UserProfile();
                                                                //     Get.find<
                                                                //         NewsfeedController>()
                                                                //         .update();
                                                                //     _clickWho(widget
                                                                //         .controller
                                                                //         .chatName
                                                                //         .members[ind]);
                                                                //   }
                                                                // }
                                                                //     : () async {
                                                                //   print(
                                                                //       'check userids ${widget
                                                                //           .controller
                                                                //           .userProfile
                                                                //           .userId} and ${widget
                                                                //           .controller
                                                                //           .chatName
                                                                //           .members[ind]
                                                                //           .id}');
                                                                //   if (widget.controller
                                                                //       .userProfile
                                                                //       .userId != widget
                                                                //       .controller.chatName
                                                                //       .members[ind].id) {
                                                                //     _clickWho(widget
                                                                //         .controller
                                                                //         .chatName
                                                                //         .members[ind]);
                                                                //     Navigator.push(
                                                                //         context,
                                                                //         MaterialPageRoute(
                                                                //             builder: (
                                                                //                 BuildContext context) =>
                                                                //                 OtherUsersProfile(
                                                                //                     controller: widget
                                                                //                         .controller)));
                                                                //   }
                                                                // },
                                                                child: ListTile(
                                                                  leading:
                                                                  CircleAvatar(
                                                                    backgroundImage:
                                                                    widget.controller
                                                                        .chatName
                                                                        .members[ind]
                                                                        .profileImage !=
                                                                        null && widget
                                                                        .controller
                                                                        .chatName
                                                                        .members[ind]
                                                                        .profileImage !=
                                                                        "null" ?
                                                                    NetworkImage(
                                                                        widget.controller
                                                                            .chatName
                                                                            .members[ind]
                                                                            .profileImage
                                                                      // 'assets/images/person_placeholder.png'

                                                                    ) : AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                                  ),
                                                                  // trailing: controller
                                                                  //             .chatName
                                                                  //             .members[
                                                                  //                 ind]
                                                                  //             .id
                                                                  //             .toString() ==
                                                                  //         controller
                                                                  //             .storage
                                                                  //             .read('id')
                                                                  //             .toString()
                                                                  //     ? SizedBox()
                                                                  //     : MaterialButton(
                                                                  //         shape: RoundedRectangleBorder(
                                                                  //             borderRadius:
                                                                  //                 BorderRadius.circular(20.0)),
                                                                  //         child:
                                                                  //             Text(
                                                                  //           controller.chatName.members[ind].follow
                                                                  //               ? "Unfollow"
                                                                  //               : "Follow",
                                                                  //           style:
                                                                  //               TextStyle(color: Colors.white),
                                                                  //         ),
                                                                  //         onPressed:
                                                                  //             () async {
                                                                  //           if (controller.chatName.members[ind].follow ==
                                                                  //               false) {
                                                                  //             // controller.followSuggestionsList[index].isFollow =
                                                                  //             //     true;
                                                                  //             controller.update();
                                                                  //             await controller.addFollowing(controller.chatName.members[ind].id,
                                                                  //                 "follow");
                                                                  //           } else if (controller.chatName.members[ind].follow ==
                                                                  //               true) {
                                                                  //             // controller.followSuggestionsList[index].isFollow =
                                                                  //             //     false;
                                                                  //             await controller.addFollowing(controller.chatName.members[ind].id,
                                                                  //                 "unFollow");
                                                                  //             controller.update();
                                                                  //           }
                                                                  //           print(
                                                                  //               "Followed Id yahha");
                                                                  //           // print(
                                                                  //           //     "${controller.followSuggestionsList[index].id}");
                                                                  //         },
                                                                  //         color: Theme.of(context)
                                                                  //             .colorScheme
                                                                  //             .secondary,
                                                                  //       ),
                                                                  title:widget.controller.chatUserList[ind].name ==null ||widget.controller.chatUserList[ind].name =="" ||widget.controller.chatUserList[ind].name =="null"?
                                                                  Text(Strings.werfieUser,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      color: Theme
                                                                          .of(context)
                                                                          .brightness ==
                                                                          Brightness.dark
                                                                          ? Colors.white
                                                                          : Colors.black,
                                                                      fontSize: 14,
                                                                      fontWeight: FontWeight
                                                                          .bold,
                                                                    ),
                                                                  ):
                                                                  Text(
                                                                    "${widget.controller
                                                                        .chatName
                                                                        .members[ind]
                                                                        .firstname} ${widget
                                                                        .controller
                                                                        .chatName
                                                                        .members[ind]
                                                                        .lastname}",
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      color: Theme
                                                                          .of(context)
                                                                          .brightness ==
                                                                          Brightness.dark
                                                                          ? Colors.white
                                                                          : Colors.black,
                                                                      fontSize: 14,
                                                                      fontWeight: FontWeight
                                                                          .bold,
                                                                    ),),
                                                                  subtitle: widget.controller.chatName.members[ind].username ==null ||widget.controller.chatName.members[ind].username =="" ||widget.controller.chatName.members[ind].username =="null"?
                                                                  Text("",
                                                                      style: Styles
                                                                          .baseTextTheme
                                                                          .headline2
                                                                          .copyWith(
                                                                        // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                        fontSize: kIsWeb
                                                                            ? 14
                                                                            : 12,
                                                                        fontWeight: FontWeight
                                                                            .w400,
                                                                      )):
                                                                  Text(
                                                                    "${widget.controller
                                                                        .chatName
                                                                        .members[ind]
                                                                        .username}",
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      fontSize: kIsWeb
                                                                          ? 14
                                                                          : 12,
                                                                      fontWeight: FontWeight
                                                                          .w400,
                                                                    ),),
                                                                  onTap: kIsWeb ? () {
                                                                    if (widget.controller
                                                                        .userProfile
                                                                        .userId != widget
                                                                        .controller.chatName
                                                                        .members[ind].id) {
                                                                      Get
                                                                          .find<
                                                                          NewsfeedController>()
                                                                          .userInfo =
                                                                          UserProfile();
                                                                      Get.find<
                                                                          NewsfeedController>()
                                                                          .update();
                                                                      _clickWho(widget
                                                                          .controller
                                                                          .chatName
                                                                          .members[ind]);
                                                                      Get.toNamed(FluroRouters.mainScreen +
                                                                          "/profile/" +
                                                                          widget.controller.otherUserId
                                                                              .toString());
                                                                    }
                                                                  }
                                                                      : () async {
                                                                    print(
                                                                        'check userids ${widget
                                                                            .controller
                                                                            .userProfile
                                                                            .userId} and ${widget
                                                                            .controller
                                                                            .chatName
                                                                            .members[ind]
                                                                            .id}');
                                                                    if (widget.controller
                                                                        .userProfile
                                                                        .userId != widget
                                                                        .controller.chatName
                                                                        .members[ind].id) {
                                                                      _clickWho(widget
                                                                          .controller
                                                                          .chatName
                                                                          .members[ind]);
                                                                      Navigator.push(
                                                                          context,
                                                                          MaterialPageRoute(
                                                                              builder: (
                                                                                  BuildContext context) =>
                                                                                  OtherUsersProfile(
                                                                                      controller: widget
                                                                                          .controller)));
                                                                    }
                                                                  },
                                                                ),
                                                              );
                                                            }),
                                                      ),
                                                      SizedBox(
                                                        height: 10,
                                                      ),
                                                      widget.controller.chatName
                                                          .conversationType ==
                                                          'single'
                                                          ? SizedBox()
                                                          : Center(
                                                          child: InkWell(
                                                            child: Text(
                                                              Strings.addPeople,
                                                              style: Styles.baseTextTheme
                                                                  .headline2.copyWith(
                                                                color: widget.controller
                                                                    .displayColor,
                                                                fontSize: 14,
                                                                fontWeight: FontWeight
                                                                    .bold,
                                                              ),),
                                                            onTap: () {
                                                              showDialog(
                                                                context:
                                                                context,
                                                                builder:
                                                                    (BuildContext
                                                                context) {
                                                                  return AlertDialog(
                                                                    contentPadding:
                                                                    EdgeInsets
                                                                        .zero,
                                                                    insetPadding:
                                                                    EdgeInsets
                                                                        .zero,
                                                                    shape:
                                                                    RoundedRectangleBorder(
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          20),
                                                                    ),
                                                                    content:
                                                                    NewMessageDialogBox(
                                                                      isAddingMembersToChat:
                                                                      true,
                                                                      conversationId: widget
                                                                          .controller
                                                                          .chatName
                                                                          .conversationId,
                                                                    ),
                                                                  );
                                                                },
                                                              );
                                                            },
                                                          )),
                                                      notificationSettings(context, setState),
                                                      Container(
                                                        margin: EdgeInsets.only(
                                                            top: 5, bottom: 5),
                                                        height: 1,
                                                        color: Colors.grey
                                                            .withOpacity(0.4),
                                                        width: Get.width,
                                                      ),
                                                      widget.controller.chatName
                                                          .conversationType == 'single'
                                                          ? Column(
                                                            children: [
                                                              Center(
                                                                  child: InkWell(
                                                                    child: Padding(
                                                                      padding: const EdgeInsets.all(16.0),
                                                                      child: Text(
                                                                          "${Strings.block} @${widget.controller.chatName.username ?? ""}",
                                                                          style: Styles.baseTextTheme.headline2.copyWith(
                                                                            color: MyColors.blue,
                                                                            fontSize: 14,
                                                                            fontWeight: FontWeight.w500,)),
                                                                    ),
                                                                    onTap: () async {
                                                                      Navigator.of(context).pop();
                                                                      widget.controller.isDeletingConversation = true;
                                                                      widget.controller.update();
                                                                      String userID = widget.controller.chatName.memberId.toString();
                                                                      bool isSuccess = await widget.controller.blockUserFromChat(userID);
                                                                      if (isSuccess){
                                                                        await ChatUtils.deleteConversation(widget.controller);
                                                                        debugPrint("user blocked chat_screen_mobile");


                                                                        Navigator.pop(this.context);

                                                                      } else {

                                                                      }
                                                                      widget.controller.isDeletingConversation = false;
                                                                      widget.controller.update();
                                                                    },
                                                                  )),
                                                              Center(
                                                                  child: InkWell(
                                                                    child: Padding(
                                                                      padding: const EdgeInsets.all(16.0),
                                                                      child: Text(
                                                                          "${Strings.report} @${widget.controller.chatName.username ?? ""}",
                                                                          style: Styles.baseTextTheme.headline2.copyWith(
                                                                            color: MyColors.blue,
                                                                            fontSize: 14,
                                                                            fontWeight: FontWeight.w500,
                                                                          )),
                                                                    ),
                                                                    onTap: () async {
                                                                      String userID = widget.controller.chatName.memberId.toString();
                                                                      ChatUtils.showReportUserDialog(context, userID, widget.controller);
                                                                      widget.controller.update();
                                                                    },
                                                                  )),
                                                              Center(
                                                              child: InkWell(
                                                                child: Padding(
                                                                  padding: const EdgeInsets.all(16.0),
                                                                  child: Text(
                                                                      Strings.deleteConversation,
                                                                      // style: TextStyle(
                                                                      //     color: Colors
                                                                      //         .red
                                                                      //         .withOpacity(
                                                                      //             0.5),
                                                                      //     fontSize: 18),
                                                                      style: Styles
                                                                          .baseTextTheme
                                                                          .headline2.copyWith(
                                                                        color: Colors.red,
                                                                        fontSize: 14,
                                                                        fontWeight: FontWeight
                                                                            .w500,
                                                                      )),
                                                                ),
                                                                onTap: () async {
                                                                  Navigator.of(context).pop();
                                                                  widget.controller.isDeletingConversation = true;
                                                                  widget.controller.update();
                                                                  await widget.controller.deleteConversation(widget.controller.chatName.conversationId);
                                                                  widget.controller.chatUserList = await widget.controller.getChat();
                                                                  Navigator.pop(this.context);
                                                                  widget.controller.isDeletingConversation = false;
                                                                  widget.controller.update();
                                                                },
                                                              )),
                                                              const SizedBox(height: 10)
                                                            ],
                                                          )
                                                          : Center(
                                                          child: InkWell(
                                                            child: Text(
                                                                Strings
                                                                    .leaveConversation,
                                                                // style: TextStyle(
                                                                //     color: Colors
                                                                //         .red
                                                                //         .withOpacity(
                                                                //             0.5),
                                                                //     fontSize: 18),
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2.copyWith(
                                                                  color: Colors.red,
                                                                  fontSize: 14,
                                                                  fontWeight: FontWeight
                                                                      .bold,
                                                                )),
                                                            onTap: () async {
                                                              await widget
                                                                  .controller
                                                                  .leaveConversation(
                                                                  widget
                                                                      .controller
                                                                      .chatName
                                                                      .conversationId);
                                                              Navigator.of(
                                                                  context)
                                                                  .pop();
                                                              Navigator.of(
                                                                  context)
                                                                  .pop();
                                                              widget.controller
                                                                  .chatUserList =
                                                              await widget
                                                                  .controller
                                                                  .getChat();

                                                              widget.controller
                                                                  .update();
                                                            },
                                                          )),
                                                      SizedBox(height: 10,),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                });
                            // widget.controller.showOverlay = false;
                            // widget.controller.update();
                            // showModalBottomSheet(
                            //     isDismissible: false,
                            //     isScrollControlled: true,
                            //     backgroundColor: Colors.white,
                            //     shape: RoundedRectangleBorder(
                            //         borderRadius: BorderRadius.only(
                            //             topLeft:
                            //             Radius.circular(20),
                            //             topRight:
                            //             Radius.circular(20))),
                            //     context: context,
                            //     builder: (context) {
                            //       return StatefulBuilder(
                            //           builder: (context, setState) {
                            //             return Container(
                            //               height: widget
                            //                   .controller
                            //                   .chatName
                            //                   .conversationType ==
                            //                   'single'
                            //                   ? Get.height / 1.9
                            //                   : Get.height / 1.5,
                            //               child: SingleChildScrollView(
                            //                 child: Column(
                            //                   children: [
                            //                     Container(
                            //                       // height: Get.height/9,
                            //
                            //                       child: Column(
                            //                         crossAxisAlignment:
                            //                         CrossAxisAlignment
                            //                             .start,
                            //                         children: [
                            //                           Row(
                            //                             children: [
                            //                               IconButton(
                            //                                   onPressed:
                            //                                       () {
                            //                                     Navigator.of(context)
                            //                                         .pop();
                            //                                     widget
                            //                                         .controller
                            //                                         .showOverlay =
                            //                                     true;
                            //                                     widget
                            //                                         .controller
                            //                                         .update();
                            //                                   },
                            //                                   icon: Icon(
                            //                                     Icons.close,
                            //                                     color: Theme
                            //                                         .of(context)
                            //                                         .brightness ==
                            //                                         Brightness
                            //                                         ? Colors.white
                            //                                         : Colors.black,
                            //                                   )),
                            //                               SizedBox(
                            //                                 width: 20,
                            //                               ),
                            //                               Text(
                            //                                 widget.controller.chatName
                            //                                     .conversationType ==
                            //                                     "group"
                            //                                     ? "Group Info"
                            //                                     : "Chat Info",
                            //                                 style: Styles
                            //                                     .baseTextTheme
                            //                                     .headline2.copyWith(
                            //                                   color: Theme
                            //                                       .of(context)
                            //                                       .brightness ==
                            //                                       Brightness.dark
                            //                                       ? Colors.white
                            //                                       : Colors.black,
                            //                                   fontWeight: FontWeight
                            //                                       .bold,
                            //                                 ),)
                            //                             ],
                            //                           ),
                            //                           Container(
                            //                             margin: EdgeInsets
                            //                                 .only(
                            //                                 top: 10,
                            //                                 bottom:
                            //                                 10),
                            //                             height: 1,
                            //                             color: Colors.grey
                            //                                 .withOpacity(
                            //                                 0.4),
                            //                             width:
                            //                             Get.width,
                            //                           ),
                            //                           ListTile(
                            //                             leading:
                            //                             CircleAvatar(
                            //                               backgroundImage:
                            //                               widget.controller.chatName
                            //                                   .groupImage != null &&
                            //                                   widget.controller
                            //                                       .chatName
                            //                                       .groupImage !=
                            //                                       "null" ?
                            //
                            //                               NetworkImage(
                            //                                   widget.controller
                            //                                       .chatName
                            //                                       .profileImage
                            //                                 // 'assets/images/person_placeholder.png'
                            //
                            //                               ) : AssetImage(
                            //                                   'assets/images/person_placeholder.png'
                            //
                            //                               ),
                            //                             ),
                            //                             trailing: widget.controller
                            //                                 .chatName
                            //                                 .conversationType !=
                            //                                 "group"
                            //                                 ? SizedBox()
                            //                                 : InkWell(
                            //                               child: Text(
                            //                                 Strings.edit,
                            //                                 style: Styles
                            //                                     .baseTextTheme
                            //                                     .headline2.copyWith(
                            //                                   color: widget.controller
                            //                                       .displayColor,
                            //                                   fontWeight: FontWeight
                            //                                       .bold,
                            //                                   fontSize: 14,
                            //
                            //                                 ),),
                            //                               onTap:
                            //                                   () {
                            //                                 showDialog(
                            //                                   context:
                            //                                   context,
                            //                                   builder:
                            //                                       (
                            //                                       BuildContext context) {
                            //                                     return StatefulBuilder(
                            //                                         builder: (context,
                            //                                             setState) {
                            //                                           return AlertDialog(
                            //                                             contentPadding: EdgeInsets
                            //                                                 .zero,
                            //                                             insetPadding: EdgeInsets
                            //                                                 .zero,
                            //                                             shape: RoundedRectangleBorder(
                            //                                               borderRadius: BorderRadius
                            //                                                   .circular(
                            //                                                   20),
                            //                                             ),
                            //                                             content: Container(
                            //                                               height: 300,
                            //                                               width: 400,
                            //                                               child: Form(
                            //                                                 key: _formKey,
                            //                                                 child: Column(
                            //                                                   crossAxisAlignment: CrossAxisAlignment
                            //                                                       .center,
                            //                                                   mainAxisAlignment: MainAxisAlignment
                            //                                                       .spaceBetween,
                            //                                                   children: [
                            //                                                     Column(
                            //                                                       children: [
                            //                                                         ListTile(
                            //                                                           title: Text(
                            //                                                             Strings.editGroup,
                            //                                                             style: Styles
                            //                                                                 .baseTextTheme
                            //                                                                 .headline2
                            //                                                                 .copyWith(
                            //                                                               color: widget
                            //                                                                   .controller
                            //                                                                   .displayColor,
                            //                                                               fontWeight: FontWeight
                            //                                                                   .bold,
                            //                                                               fontSize: 14,
                            //
                            //                                                             ),),
                            //                                                           leading: IconButton(
                            //                                                             icon: Icon(
                            //                                                                 Icons
                            //                                                                     .close),
                            //                                                             onPressed: () {
                            //                                                               Navigator
                            //                                                                   .of(
                            //                                                                   context)
                            //                                                                   .pop();
                            //                                                             },
                            //                                                           ),
                            //                                                           trailing: MaterialButton(
                            //                                                             child: Text(
                            //                                                                 Strings
                            //                                                                     .save,
                            //                                                                 style: Theme
                            //                                                                     .of(
                            //                                                                     context)
                            //                                                                     .brightness ==
                            //                                                                     Brightness
                            //                                                                         .dark
                            //                                                                     ? TextStyle(
                            //                                                                   color: Colors
                            //                                                                       .white,
                            //                                                                 )
                            //                                                                     : TextStyle(
                            //                                                                     color: Colors
                            //                                                                         .black)),
                            //                                                             onPressed: widget
                            //                                                                 .controller
                            //                                                                 .groupName ==
                            //                                                                 null &&
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .profileImageGroupChat ==
                            //                                                                     null
                            //                                                                 ? null
                            //                                                                 : () {
                            //                                                               if (widget
                            //                                                                   .controller
                            //                                                                   .groupName !=
                            //                                                                   null &&
                            //                                                                   widget
                            //                                                                       .controller
                            //                                                                       .profileImageGroupChat !=
                            //                                                                       null) {
                            //                                                                 _formKey
                            //                                                                     .currentState
                            //                                                                     .save();
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .updateGroupName(
                            //                                                                     context,
                            //                                                                     groupName: widget
                            //                                                                         .controller
                            //                                                                         .groupName,
                            //                                                                     conversationId: widget
                            //                                                                         .controller
                            //                                                                         .chatName
                            //                                                                         .conversationId);
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .update();
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .updateGroupImage(
                            //                                                                   conversationId: widget
                            //                                                                       .controller
                            //                                                                       .chatName
                            //                                                                       .conversationId,
                            //                                                                   groupProfileImage: widget
                            //                                                                       .controller
                            //                                                                       .profileImageGroupChat,
                            //                                                                 );
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .update();
                            //                                                               } else
                            //                                                               if (widget
                            //                                                                   .controller
                            //                                                                   .groupName !=
                            //                                                                   null) {
                            //                                                                 _formKey
                            //                                                                     .currentState
                            //                                                                     .save();
                            //
                            //                                                                 print(
                            //                                                                     widget
                            //                                                                         .controller
                            //                                                                         .groupName);
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .updateGroupName(
                            //                                                                     context,
                            //                                                                     groupName: widget
                            //                                                                         .controller
                            //                                                                         .groupName,
                            //                                                                     conversationId: widget
                            //                                                                         .controller
                            //                                                                         .chatName
                            //                                                                         .conversationId);
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .update();
                            //                                                               } else
                            //                                                               if (widget
                            //                                                                   .controller
                            //                                                                   .profileImageGroupChat !=
                            //                                                                   null) {
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .updateGroupImage(
                            //                                                                   conversationId: widget
                            //                                                                       .controller
                            //                                                                       .chatName
                            //                                                                       .conversationId,
                            //                                                                   groupProfileImage: widget
                            //                                                                       .controller
                            //                                                                       .profileImageGroupChat,
                            //                                                                 );
                            //                                                                 widget
                            //                                                                     .controller
                            //                                                                     .update();
                            //                                                               }
                            //                                                             },
                            //                                                             color: widget
                            //                                                                 .controller
                            //                                                                 .displayColor,
                            //                                                             shape: RoundedRectangleBorder(
                            //                                                                 borderRadius: BorderRadius
                            //                                                                     .circular(
                            //                                                                     20.0)),
                            //                                                           ),
                            //                                                         ),
                            //                                                         Container(
                            //                                                           color: Colors
                            //                                                               .grey
                            //                                                               .withOpacity(
                            //                                                               0.1),
                            //                                                           height: 1,
                            //                                                           width: Get
                            //                                                               .width,
                            //                                                           margin: EdgeInsets
                            //                                                               .only(
                            //                                                               top: 5,
                            //                                                               bottom: 20),
                            //                                                         ),
                            //                                                       ],
                            //                                                     ),
                            //                                                     Stack(
                            //                                                       alignment: Alignment
                            //                                                           .center,
                            //                                                       children: [
                            //                                                         widget
                            //                                                             .controller
                            //                                                             .profileImageGroupChat !=
                            //                                                             null
                            //                                                             ? CircleAvatar(
                            //                                                           maxRadius: 60,
                            //                                                           minRadius: 60,
                            //                                                           backgroundImage: MemoryImage(
                            //                                                               widget
                            //                                                                   .controller
                            //                                                                   .profileImageGroupChat),
                            //                                                           backgroundColor: Colors
                            //                                                               .white,
                            //                                                         )
                            //                                                             : CircleAvatar(
                            //                                                           backgroundImage: AssetImage(
                            //                                                               'assets/images/person_placeholder.png'),
                            //                                                           minRadius: 60,
                            //                                                           maxRadius: 60,
                            //                                                         ),
                            //                                                         IconButton(
                            //                                                             onPressed: () async {
                            //                                                               widget
                            //                                                                   .controller
                            //                                                                   .profileImageGroupChat =
                            //                                                               await widget
                            //                                                                   .controller
                            //                                                                   .callGetImage();
                            //                                                               setState(() {});
                            //                                                             },
                            //                                                             icon: Icon(
                            //                                                               Icons
                            //                                                                   .camera_alt_outlined,
                            //                                                               size: 25,
                            //                                                               color: Colors
                            //                                                                   .black,
                            //                                                             )),
                            //                                                       ],
                            //                                                     ),
                            //                                                     Padding(
                            //                                                       padding: const EdgeInsets
                            //                                                           .all(
                            //                                                           8.0),
                            //                                                       child: TextFormField(
                            //                                                         initialValue: widget
                            //                                                             .controller
                            //                                                             .groupName,
                            //                                                         onSaved: (
                            //                                                             val) {
                            //                                                           widget
                            //                                                               .controller
                            //                                                               .groupName =
                            //                                                               val;
                            //                                                         },
                            //                                                         decoration: new InputDecoration(
                            //                                                           label: Text(
                            //                                                             'Enter group chat title',
                            //                                                             style: Theme
                            //                                                                 .of(
                            //                                                                 context)
                            //                                                                 .brightness ==
                            //                                                                 Brightness
                            //                                                                     .dark
                            //                                                                 ? TextStyle(
                            //                                                               color: Colors
                            //                                                                   .white,
                            //                                                             )
                            //                                                                 : TextStyle(
                            //                                                               color: Colors
                            //                                                                   .black,
                            //                                                             ),
                            //                                                           ),
                            //                                                           focusedBorder: OutlineInputBorder(
                            //                                                             borderRadius: BorderRadius
                            //                                                                 .circular(
                            //                                                                 5),
                            //                                                             borderSide: BorderSide(
                            //                                                                 color: Theme
                            //                                                                     .of(
                            //                                                                     context)
                            //                                                                     .colorScheme
                            //                                                                     .secondary,
                            //                                                                 width: 1.0),
                            //                                                           ),
                            //                                                           enabledBorder: OutlineInputBorder(
                            //                                                             borderRadius: BorderRadius
                            //                                                                 .circular(
                            //                                                                 5),
                            //                                                             borderSide: BorderSide(
                            //                                                               color: Colors
                            //                                                                   .grey
                            //                                                                   .withOpacity(
                            //                                                                   0.6),
                            //                                                               width: 1.0,
                            //                                                             ),
                            //                                                           ),
                            //                                                         ),
                            //                                                       ),
                            //                                                     ),
                            //                                                   ],
                            //                                                 ),
                            //                                               ),
                            //                                             ),
                            //                                           );
                            //                                         });
                            //                                   },
                            //                                 );
                            //                               },
                            //                             ),
                            //                             title: Text(
                            //                               "${widget.controller
                            //                                   .groupName != null
                            //                                   ? widget.controller
                            //                                   .groupName
                            //                                   : widget.controller
                            //                                   .chatName.name}",
                            //                               style: Styles.baseTextTheme
                            //                                   .headline2.copyWith(
                            //                                 color: Theme
                            //                                     .of(context)
                            //                                     .brightness ==
                            //                                     Brightness.dark
                            //                                     ? Colors.white
                            //                                     : Colors.black,
                            //                                 fontWeight: FontWeight
                            //                                     .w500,
                            //                                 fontSize: 14,
                            //                               ),
                            //                             ),
                            //                             subtitle: Text(
                            //                               "${widget.controller
                            //                                   .chatName.username ==
                            //                                   null ? "Group" : widget
                            //                                   .controller.chatName
                            //                                   .username}",
                            //                               style: Styles.baseTextTheme
                            //                                   .headline2.copyWith(
                            //                                 fontWeight: FontWeight
                            //                                     .w400,
                            //                                 fontSize: kIsWeb
                            //                                     ? 14
                            //                                     : 12,
                            //                               ),),
                            //                           ),
                            //                           Container(
                            //                             margin: EdgeInsets
                            //                                 .only(
                            //                                 top: 10,
                            //                                 bottom:
                            //                                 10),
                            //                             height: 1,
                            //                             color: Colors
                            //                                 .grey
                            //                                 .withOpacity(
                            //                                 0.4),
                            //                             width:
                            //                             Get.width,
                            //                           ),
                            //                           Padding(
                            //                             padding:
                            //                             const EdgeInsets
                            //                                 .only(
                            //                                 top:
                            //                                 8.0,
                            //                                 bottom:
                            //                                 8.0,
                            //                                 left:
                            //                                 15),
                            //                             child: Text(
                            //                               Strings
                            //                                   .peopleInThisChat,
                            //                               // style: TextStyle(
                            //                               //     color: Colors
                            //                               //         .blueAccent,
                            //                               //     fontSize:
                            //                               //         18),
                            //                               style: Styles.baseTextTheme
                            //                                   .headline2.copyWith(
                            //                                 color: widget.controller
                            //                                     .displayColor,
                            //                                 fontWeight: FontWeight
                            //                                     .bold,
                            //                               ),
                            //                             ),
                            //                           ),
                            //                           widget.controller.chatName
                            //                               .conversationType !=
                            //                               "group"
                            //                               ? GestureDetector(
                            //                             onTap: kIsWeb ? () {
                            //                               Get
                            //                                   .find<
                            //                                   NewsfeedController>()
                            //                                   .userInfo =
                            //                                   UserProfile();
                            //                               Get.find<
                            //                                   NewsfeedController>()
                            //                                   .update();
                            //                               _clickChatUser(widget
                            //                                   .controller
                            //                                   .chatName
                            //                               );
                            //                             }
                            //                                 : () async {
                            //                               _clickChatUser(widget
                            //                                   .controller.chatName
                            //                               );
                            //                               Navigator.push(context,
                            //                                   MaterialPageRoute(
                            //                                       builder: (
                            //                                           BuildContext context) =>
                            //                                           OtherUsersProfile(
                            //                                               controller: widget
                            //                                                   .controller)));
                            //                             },
                            //                             child: ListTile(
                            //                               leading:
                            //                               CircleAvatar(
                            //                                 backgroundImage:
                            //                                 AssetImage(
                            //                                     'assets/images/person_placeholder.png'),
                            //                               ),
                            //                               // trailing:
                            //                               //     MaterialButton(
                            //                               //   shape: RoundedRectangleBorder(
                            //                               //       borderRadius:
                            //                               //           BorderRadius.circular(
                            //                               //               20.0)),
                            //                               //   child: Text(
                            //                               //     controller
                            //                               //             .chatName
                            //                               //             .singlePersonFollow
                            //                               //         ? Strings
                            //                               //             .unFollow
                            //                               //         : Strings
                            //                               //             .follow,
                            //                               //     style: TextStyle(
                            //                               //         color: Colors
                            //                               //             .white),
                            //                               //   ),
                            //                               //   onPressed:
                            //                               //       () {
                            //                               //     controller
                            //                               //             .chatName
                            //                               //             .singlePersonFollow
                            //                               //         ? {
                            //                               //             controller.chatName.singlePersonFollow =
                            //                               //                 false,
                            //                               //             setState(() {}),
                            //                               //             controller.update(),
                            //                               //             controller.addFollowing(controller.chatName.memberId,
                            //                               //                 "unfollow")
                            //                               //           }
                            //                               //         : {
                            //                               //             controller.chatName.singlePersonFollow =
                            //                               //                 true,
                            //                               //             setState(() {}),
                            //                               //             controller.update(),
                            //                               //             controller.addFollowing(controller.chatName.memberId,
                            //                               //                 "follow"),
                            //                               //           };
                            //                               //   },
                            //                               //   color: Theme.of(
                            //                               //           context)
                            //                               //       .colorScheme
                            //                               //       .secondary,
                            //                               // ),
                            //                               title:
                            //                               Text(
                            //                                 "${widget.controller
                            //                                     .chatName.name}",
                            //                                 style: Styles
                            //                                     .baseTextTheme
                            //                                     .headline2.copyWith(
                            //                                   color: Theme
                            //                                       .of(context)
                            //                                       .brightness ==
                            //                                       Brightness.dark
                            //                                       ? Colors.white
                            //                                       : Colors.black,
                            //                                   fontWeight: FontWeight
                            //                                       .w500,
                            //                                   fontSize: 14,
                            //                                 ),
                            //                               ),
                            //                               subtitle:
                            //                               Text(
                            //                                 "${widget.controller
                            //                                     .chatName.username ==
                            //                                     null
                            //                                     ? "Group"
                            //                                     : widget
                            //                                     .controller.chatName
                            //                                     .username}",
                            //                                 style: Styles
                            //                                     .baseTextTheme
                            //                                     .headline2.copyWith(
                            //                                   fontWeight: FontWeight
                            //                                       .w500,
                            //                                   fontSize: kIsWeb
                            //                                       ? 14
                            //                                       : 12,
                            //                                 ),
                            //                               ),
                            //                             ),
                            //                           )
                            //                               : Column(
                            //
                            //                             ///1st list
                            //                             children: List.generate(
                            //                                 widget
                            //                                     .controller
                            //                                     .chatName
                            //                                     .members
                            //                                     .length,
                            //                                     (ind) {
                            //                                   return GestureDetector(
                            //                                     onTap: kIsWeb
                            //                                         ? () async {
                            //                                       if (widget
                            //                                           .controller
                            //                                           .userProfile
                            //                                           .userId !=
                            //                                           widget
                            //                                               .controller
                            //                                               .chatName
                            //                                               .members[ind]
                            //                                               .id) {
                            //                                         Get
                            //                                             .find<
                            //                                             NewsfeedController>()
                            //                                             .userInfo =
                            //                                             UserProfile();
                            //                                         Get.find<
                            //                                             NewsfeedController>()
                            //                                             .update();
                            //                                         _clickWho(widget
                            //                                             .controller
                            //                                             .chatName
                            //                                             .members[ind]);
                            //                                       }
                            //                                     }
                            //                                         : () async {
                            //                                       if (widget
                            //                                           .controller
                            //                                           .userProfile
                            //                                           .userId !=
                            //                                           widget
                            //                                               .controller
                            //                                               .chatName
                            //                                               .members[ind]
                            //                                               .id) {
                            //                                         _clickWho(widget
                            //                                             .controller
                            //                                             .chatName
                            //                                             .members[ind]);
                            //                                         Navigator.push(
                            //                                             context,
                            //                                             MaterialPageRoute(
                            //                                                 builder: (
                            //                                                     BuildContext context) =>
                            //                                                     OtherUsersProfile(
                            //                                                         controller: widget
                            //                                                             .controller)));
                            //                                       }
                            //                                     },
                            //                                     child: ListTile(
                            //                                       leading:
                            //                                       CircleAvatar(
                            //                                         backgroundImage:
                            //                                         AssetImage(
                            //                                             'assets/images/person_placeholder.png'),
                            //                                       ),
                            //                                       // trailing: controller.chatName.members[ind].id.toString() ==
                            //                                       //         controller.storage.read('id').toString()
                            //                                       //     ? SizedBox()
                            //                                       //     : MaterialButton(
                            //                                       //         shape:
                            //                                       //             RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
                            //                                       //         child:
                            //                                       //             Text(
                            //                                       //           controller.chatName.members[ind].follow ? "Unfollow" : "Follow",
                            //                                       //           style: TextStyle(color: Colors.white),
                            //                                       //         ),
                            //                                       //         onPressed:
                            //                                       //             () async {
                            //                                       //           if (controller.chatName.members[ind].follow == false) {
                            //                                       //             // controller.followSuggestionsList[index].isFollow =
                            //                                       //             //     true;
                            //                                       //             controller.update();
                            //                                       //             await controller.addFollowing(controller.chatName.members[ind].id, "follow");
                            //                                       //           } else if (controller.chatName.members[ind].follow == true) {
                            //                                       //             // controller.followSuggestionsList[index].isFollow =
                            //                                       //             //     false;
                            //                                       //             await controller.addFollowing(controller.chatName.members[ind].id, "unFollow");
                            //                                       //             controller.update();
                            //                                       //           }
                            //                                       //           print("Followed Id yahha");
                            //                                       //           // print(
                            //                                       //           //     "${controller.followSuggestionsList[index].id}");
                            //                                       //         },
                            //                                       //         color:
                            //                                       //             Theme.of(context).colorScheme.secondary,
                            //                                       //       ),
                            //                                       title:
                            //                                       Text(
                            //                                         "${widget
                            //                                             .controller
                            //                                             .chatName
                            //                                             .members[ind]
                            //                                             .firstname} ${widget
                            //                                             .controller
                            //                                             .chatName
                            //                                             .members[ind]
                            //                                             .lastname}",
                            //                                         style: Styles
                            //                                             .baseTextTheme
                            //                                             .headline2
                            //                                             .copyWith(
                            //                                           color: Theme
                            //                                               .of(context)
                            //                                               .brightness ==
                            //                                               Brightness
                            //                                                   .dark
                            //                                               ? Colors
                            //                                               .white
                            //                                               : Colors
                            //                                               .black,
                            //                                           fontWeight: FontWeight
                            //                                               .w500,
                            //                                           fontSize: 14,
                            //                                         ),
                            //                                       ),
                            //                                       subtitle:
                            //                                       Text(
                            //                                         "${widget
                            //                                             .controller
                            //                                             .chatName
                            //                                             .members[ind]
                            //                                             .username}",
                            //                                         style: Styles
                            //                                             .baseTextTheme
                            //                                             .headline2
                            //                                             .copyWith(
                            //                                           fontWeight: FontWeight
                            //                                               .w400,
                            //                                           fontSize: kIsWeb
                            //                                               ? 14
                            //                                               : 12,
                            //                                         ),
                            //                                       ),
                            //                                     ),
                            //                                   );
                            //                                 }),
                            //                           ),
                            //                           SizedBox(
                            //                             height: 10,
                            //                           ),
                            //                           widget.controller.chatName
                            //                               .conversationType ==
                            //                               'single'
                            //                               ? SizedBox()
                            //                               : Center(
                            //                               child:
                            //                               InkWell(
                            //                                 child:
                            //                                 Text(
                            //                                     Strings
                            //                                         .addPeople,
                            //                                     // style: TextStyle(
                            //                                     //     color:
                            //                                     //         Colors.blueAccent,
                            //                                     //     fontSize: 18),
                            //                                     style: Styles
                            //                                         .baseTextTheme
                            //                                         .headline2
                            //                                         .copyWith(
                            //                                       color: widget
                            //                                           .controller
                            //                                           .displayColor,
                            //                                       fontSize: 20,
                            //                                       // fontWeight: kIsWeb ? FontWeight.bold,
                            //                                     )
                            //                                 ),
                            //                                 onTap:
                            //                                     () {
                            //                                   showDialog(
                            //                                     context:
                            //                                     context,
                            //                                     builder:
                            //                                         (
                            //                                         BuildContext context) {
                            //                                       return AlertDialog(
                            //                                         contentPadding: EdgeInsets
                            //                                             .zero,
                            //                                         insetPadding: EdgeInsets
                            //                                             .zero,
                            //                                         shape: RoundedRectangleBorder(
                            //                                           borderRadius: BorderRadius
                            //                                               .circular(
                            //                                               20),
                            //                                         ),
                            //                                         content: NewMessageDialogBox(
                            //                                           isAddingMembersToChat: true,
                            //                                           conversationId: widget
                            //                                               .controller
                            //                                               .chatName
                            //                                               .conversationId,
                            //                                         ),
                            //                                       );
                            //                                     },
                            //                                   );
                            //                                 },
                            //                               )),
                            //                           Container(
                            //                             margin: EdgeInsets
                            //                                 .only(
                            //                                 top: 10,
                            //                                 bottom:
                            //                                 10),
                            //                             height: 1,
                            //                             color: Colors
                            //                                 .grey
                            //                                 .withOpacity(
                            //                                 0.4),
                            //                             width:
                            //                             Get.width,
                            //                           ),
                            //                           widget.controller.chatName
                            //                               .conversationType ==
                            //                               'single'
                            //                               ? Center(
                            //                               child:
                            //                               InkWell(
                            //                                 child:
                            //                                 Text(
                            //                                   'Delete Conversation',
                            //                                   style: Theme
                            //                                       .of(context)
                            //                                       .brightness ==
                            //                                       Brightness.dark
                            //                                       ? TextStyle(
                            //                                     color: Colors.white,
                            //                                     fontSize: 18,
                            //                                   )
                            //                                       : TextStyle(
                            //                                     color: Colors.red
                            //                                         .withOpacity(0.5),
                            //                                     fontSize: 18,
                            //                                   ),
                            //                                   // style: TextStyle(
                            //                                   //     color:
                            //                                   //         Colors.red.withOpacity(0.5),
                            //                                   //     fontSize: 18),
                            //                                 ),
                            //                                 onTap:
                            //                                     () async {
                            //                                   print(
                            //                                       'RAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANa');
                            //                                   print(
                            //                                       'RAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANa');
                            //                                   print(
                            //                                       'RAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANaRAAAANANNANANa');
                            //                                   await widget.controller
                            //                                       .deleteConversation(
                            //                                       widget
                            //                                           .controller
                            //                                           .chatName
                            //                                           .conversationId);
                            //                                   Navigator.of(context)
                            //                                       .pop();
                            //                                   Navigator.of(context)
                            //                                       .pop();
                            //                                   widget.controller
                            //                                       .chatUserList =
                            //                                   await widget
                            //                                       .controller
                            //                                       .getChat();
                            //                                   // await widget.controller.getMessageRequest();
                            //
                            //                                   widget
                            //                                       .controller
                            //                                       .update();
                            //                                 },
                            //                               ))
                            //                               : Center(
                            //                               child:
                            //                               InkWell(
                            //                                 child:
                            //                                 Text(
                            //                                     Strings
                            //                                         .leaveConversation,
                            //                                     style: Styles
                            //                                         .baseTextTheme
                            //                                         .headline2
                            //                                         .copyWith(
                            //                                       color: Colors.red,
                            //                                       fontSize: 14,
                            //                                       fontWeight: FontWeight
                            //                                           .bold,
                            //                                     )
                            //                                 ),
                            //                                 onTap:
                            //                                     () async {
                            //                                   await widget.controller
                            //                                       .leaveConversation(
                            //                                       widget
                            //                                           .controller
                            //                                           .chatName
                            //                                           .conversationId);
                            //                                   Navigator.of(context)
                            //                                       .pop();
                            //                                   Navigator.of(context)
                            //                                       .pop();
                            //                                   widget.controller
                            //                                       .chatUserList =
                            //                                   await widget
                            //                                       .controller
                            //                                       .getChat();
                            //                                   // await widget.controller.getMessageRequest();
                            //
                            //                                   widget
                            //                                       .controller
                            //                                       .update();
                            //                                 },
                            //                               )),
                            //                         ],
                            //                       ),
                            //                     ),
                            //                   ],
                            //                 ),
                            //               ),
                            //             );
                            //           });
                            //     });
                          },
                          icon: Icon(
                            Icons.info_outline_rounded,
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark ? Colors.white : Colors
                                .black,
                          ),
                        ),
                      ],
                    ),
                    // subtitle: Text(
                    //   "${widget.controller.chatName.username == null
                    //       ? "Group"
                    //       : widget.controller.chatName.username}",
                    //   style: Styles.baseTextTheme.headline2.copyWith(
                    //     fontWeight: FontWeight.w400,
                    //     fontSize: kIsWeb ? 14 : 14,
                    //   ),
                    // ),
                  ),
                ),
              ) : SizedBox(),
            ),


  /// this is the main middle view of chat window where we can see all messages
            widget.controller.messageLoader
                && (widget.controller.messages.isEmpty
                || widget.controller.messages.first.conversationId != widget.controller.chatName.conversationId)
                ? const Expanded(
                  child: Center(
              child: Padding(
                  padding: EdgeInsets.only(top: 100),
                  child: CircularProgressIndicator(color: MyColors.BlueColor,),
              ),
            ),
                )
                : widget.controller.messages.isEmpty ||
                widget.controller.messages.length == 0
                ? Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 100),
                child: Text(
                  Strings.noMessagesYet,
                  style: Styles.baseTextTheme.headline4.copyWith(
                    color: Theme
                        .of(context)
                        .brightness == Brightness.dark ? Colors.white : Colors
                        .black,
                    fontSize: kIsWeb ? 16 : 14,
                  ),
                ),
              ),
            )
                : Expanded(
              child: Container(
                  alignment: kIsWeb ? Alignment.topCenter : Alignment
                      .bottomCenter,
                  // color:Colors.grey,
                  padding: EdgeInsets.only(bottom: 10, top: 0, right: 10),
                  child: PagedL(
                    emptyStateWidget: Text(
                      Strings.noPosts,
                      style: Styles.baseTextTheme.headline4.copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors.white : Colors
                            .black,
                        fontSize: kIsWeb ? 16 : 14,
                      ),
                    ),
                    itemBuilder: msgSample,
                    padding: EdgeInsets.only(
                        top: 16.00, left: 4.00, right: 4.00),
                    loadingIndicator: Padding(
                      padding: EdgeInsets.all(16.00),
                      child: Center(
                        child: CircularProgressIndicator(),
                      ),
                    ),
                    itemDataProvider: _fetchData,
                    list: widget.controller.messages,
                    listSize: _checkPage(widget.controller.messages.length),
                    controller: widget.controller,
                    isRequested: widget.isRequested,
                  )

              ),
            ),
            replyPreviewWidgetAtBottom(),
            widget.controller.isVideoUpload ||
                widget.controller.isDocUpload ||
                widget.controller.isImageUpload
                ? Row(
              children: [
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            "${widget.controller.userProfile != null ? widget
                                .controller.userProfile.firstname : ""}  ",
                            style: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            Strings.justNow,
                            // "${msg.createdAt}".split(" ")[1].split(":")[0] +
                            //     ":" +
                            //     "${msg.createdAt}".split(" ")[1].split(":")[1],
                            style: Styles.baseTextTheme.headline2.copyWith(
                              fontWeight: FontWeight.w400,
                              fontSize: kIsWeb ? 14 : 12,
                            ),
                          ),
                        ],
                      ),
                      Container(
                        color: Colors.transparent,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            DecoratedBox(
                              // chat bubble decoration
                              decoration: BoxDecoration(
                                // color:
                                // msg.messageFiles.isNotEmpty
                                //     ? Colors.transparent
                                //     : msg.userId == controller.storage.read("id")
                                //     ? controller.urlOrNot(msg.body.toString())
                                //     ? Colors.transparent
                                //     : Colorss.blue
                                //     : controller.urlOrNot(msg.body.toString())
                                //     ? Colors.transparent
                                //     : Colors.grey[300],
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: 10,
                                  right: 10,
                                  // top: msg.body.length < 10 ? 1 : 5,
                                  // bottom: msg.body.length < 10 ? 1 : 5,
                                ),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    // controller.videoThumbnail != null
                                    //   ?
                                    widget.controller.isVideoUpload
                                        ? kIsWeb
                                        ? Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(15)),
                                      ),
                                      height: 200,
                                      child: widget.controller.videoController,
                                    )
                                    // Image.asset(
                                    //   "assets/images/mp4.png",
                                    //   fit: BoxFit.contain,
                                    //   height: 200,
                                    //   width: 250,
                                    // )
                                        : Image.memory(
                                      widget.controller
                                          .videoThumbnail,
                                      fit: BoxFit.contain,
                                      height: 200,
                                      width: 250,
                                    )
                                        : widget.controller.isDocUpload
                                        ? Image.asset(
                                      "assets/images/document.png",
                                      fit: BoxFit.contain,
                                      height: 200,
                                      width: 250,
                                    )
                                        : widget.controller.isImageUpload
                                        ? Image.memory(
                                      widget.controller
                                          .ImageThumbnail,
                                      fit: BoxFit.contain,
                                      height: 200,
                                      width: 250,
                                    )
                                        : SizedBox(),
                                    //     : Container(
                                    //   color: Colors.red,
                                    //   height: 100,
                                    // ),
                                    CircularProgressIndicator()
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // controller.messages[index].userId !=
                //     controller.storage.read("id")
                //     ?
                widget.controller.userProfile == null
                    ? Container(
                    width: 24,
                    child: Center(
                      child: SpinKitCircle(
                        color: Colors.grey,
                        size: 40,
                      ),
                    ))
                    : Padding(
                  padding: const EdgeInsets.only(bottom: 15, left: 7),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: FadeInImage(
                      fit: BoxFit.cover,
                      width: 24,
                      height: 24,
                      placeholder: AssetImage(
                          'assets/images/person_placeholder.png'),
                      image: widget.controller.userProfile
                          .profileImage !=
                          null
                          ? NetworkImage(widget
                          .controller.userProfile.profileImage)
                          : AssetImage(
                          'assets/images/person_placeholder.png'),
                      // NetworkImage(
                      //     controller.userProfile.profileImage != null
                      //         ? controller.userProfile.profileImage
                      //         : "assets/images/person_placeholder.png")
                    ),
                  ),
                )
              ],
            )
                : SizedBox(),
            widget.controller.messages.isEmpty ||
                widget.controller.messages.length == 0
                ? Spacer()
                : SizedBox(),
            Padding(
              child: Container(
                decoration: BoxDecoration(
                  border: Border(
                    top: BorderSide(color: Colors.grey[200], width: 1),
                  ),
                ),
                padding: EdgeInsets.only(top: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // widget.controller.isVideoUpload
                    //     ? SizedBox()
                    //     : AnimatedSwitcher(
                    //   child: widget.controller.showOverlay
                    //       ? Container(
                    //     height: 50,
                    //     width: Get.width,
                    //     color: Colors.white,
                    //     child: Row(
                    //       mainAxisAlignment:
                    //       MainAxisAlignment.spaceEvenly,
                    //       children: [
                    //         IconButton(
                    //             onPressed: () async {
                    //               widget.controller.showOverlay = false;
                    //               widget.controller.isSendMsg = false;
                    //               widget.controller.update();
                    //               await widget.controller.uploadImage(
                    //                   Get
                    //                       .find<NewsfeedController>()
                    //                       .chatName
                    //                       .conversationId);
                    //               // controller.update();
                    //             },
                    //             icon: Icon(Icons.image_outlined,
                    //               color: widget.controller.displayColor,
                    //             )),
                    //         IconButton(
                    //             onPressed: () async {
                    //               widget.controller.showOverlay = false;
                    //               widget.controller.isSendMsg = false;
                    //               widget.controller.update();
                    //               await Get.find<NewsfeedController>()
                    //                   .uploadVideo(
                    //                   Get
                    //                       .find<NewsfeedController>()
                    //                       .chatName
                    //                       .conversationId);
                    //             },
                    //             icon: Icon(
                    //               Icons.video_collection_outlined,
                    //               color: widget.controller.displayColor,
                    //             )),
                    //         IconButton(
                    //             onPressed: () async {
                    //               widget.controller.showOverlay = false;
                    //               widget.controller.isSendMsg = false;
                    //               widget.controller.update();
                    //               await Get.find<NewsfeedController>()
                    //                   .uploadDocument(
                    //                   Get
                    //                       .find<NewsfeedController>()
                    //                       .chatName
                    //                       .conversationId);
                    //             },
                    //             icon: Icon(Icons.attach_file_outlined,
                    //               color: widget.controller.displayColor,
                    //             )),
                    //       ],
                    //     ),
                    //   )
                    //       : SizedBox(),
                    //   switchInCurve: Curves.easeInToLinear,
                    //   duration: Duration(milliseconds: 500),
                    // ),
                    widget.controller.isVideoPickedChat
                        ? Padding(
                      padding: EdgeInsets.only(left: 40.0),
                      child: Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(
                                    15))
                            ),
                            height: 200,
                            child: kIsWeb
                                ? widget.controller.videoController
                                : widget.controller.videoThumbnail != null
                                ? Image.memory(
                              widget.controller.videoThumbnail,
                            )
                                : const SizedBox(),
                            /*Image.asset(
                              "assets/images/mp4.png",
                            )*/
                          ),
                          Positioned(
                            right: 6,
                            top: 10,
                            child: CircleAvatar(
                              radius: 14,
                              backgroundColor: Colors.black54,
                              child: IconButton(
                                padding: EdgeInsets.zero,
                                icon: Icon(
                                  Icons.close_rounded,
                                  size: 16,
                                  color: Colors.white,
                                ),
                                onPressed: () {
                                  widget.controller.isVideoPickedChat = false;
                                  widget.controller.videoThumbnail = null;
                                  widget.controller.videoBytesChat
                                      .toList()
                                      .clear();
                                  widget.controller.update();
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                        : SizedBox(),
                    widget.controller.isImagePickedChat
                        ? Padding(
                      padding: EdgeInsets.only(left: 40.0),
                      child: Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(15)),
                            ),
                            height: 200,
                            child: ClipRRect(
                              borderRadius: BorderRadius.all(Radius.circular(15)),
                              child: Image.memory(
                                widget.controller.imageBytesChat,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 6,
                            top: 10,
                            child: CircleAvatar(
                              radius: 14,
                              backgroundColor: Colors.black54,
                              child: IconButton(
                                padding: EdgeInsets.zero,
                                icon: Icon(
                                  Icons.close_rounded,
                                  size: 16,
                                  color: Colors.white,
                                ),
                                onPressed: () {
                                  widget.controller.isImagePickedChat = false;
                                  widget.controller.imageBytesChat
                                      .toList()
                                      .clear();
                                  widget.controller.update();
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                        : widget.controller.isDocumentPickedChat
                        ? Padding(
                      padding: EdgeInsets.only(left: 40.0),
                      child: Stack(
                        children: [
                          Container(
                            height: 200,
                            child: Image.asset(
                              'assets/images/document.png',
                            ),
                          ),
                          Positioned(
                            right: 6,
                            top: 10,
                            child: CircleAvatar(
                              radius: 14,
                              backgroundColor: Colors.grey,
                              child: IconButton(
                                padding: EdgeInsets.zero,
                                icon: Icon(
                                  Icons.close_rounded,
                                  size: 16,
                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                                onPressed: () {
                                  widget.controller.isDocumentPickedChat =
                                  false;
                                  widget.controller.documentBytesChat
                                      .toList()
                                      .clear();
                                  widget.controller.update();
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                        : SizedBox(),
                    widget.controller.chatName == null ? Container() :
                    (widget.controller.chatName.messageAllowed == null ||
                        !widget.controller.chatName.messageAllowed)
                        && widget.controller.chatUserList[widget.controller.chatIndex].conversationType != "group" ?
                    Text(
                      widget.controller.chatName.name != null ?
                      "${widget.controller.chatName.name} ${Strings.doNotAllowMessages}" : Strings.notAllowedToMessage,
                      style: Styles.baseTextTheme.headline4.copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors.white : Colors
                            .black,
                        fontSize: kIsWeb ? 16 : 14,
                      ),
                    )
                        :
                    !widget.controller.chatName.isBlocked
                        ? Text(
                      Strings.youHaveBlockedThisUser,
                      style: Styles.baseTextTheme.headline4.copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors.white : Colors
                            .black,
                        fontSize: kIsWeb ? 16 : 14,
                      ),
                    )
                        : Padding(
                      padding: EdgeInsets.only(bottom: kIsWeb ? 0 : MediaQuery
                          .of(context)
                          .viewInsets
                          .bottom, left: 10, right: 10),
                      child: widget.isRequested? Container(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(Strings.doYouWantToLet + "${widget.controller.chatName
                                .user.firstname} ${widget.controller.chatName.user
                                .lastname}"+Strings.toMessageYou,
                              style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.black54
                              ),
                            ),
                            widget.controller.chatAcceptLoading? Center(child: CircularProgressIndicator(),):
                            Column(
                              children: [
                                Container(
                                  width: double.infinity,
                                  height: 50,
                                  margin: EdgeInsets.all(5.0),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      widget.controller.AcceptRejectMessageRequest(widget.controller.chatName.conversationId, 0.toString());
                                      if(!kIsWeb){
                                        Navigator.of(context)..pop()..pop();
                                      }else{
                                        Get.toNamed(FluroRouters.mainScreen + '/chats');
                                      }
                                    },
                                    child: Text(Strings.reportBlock,
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.black87
                                      ),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(25.0),
                                            side: BorderSide(
                                                color: Colors.black87, width: 2)
                                        ),
                                        backgroundColor: Colors.white
                                    ),
                                  ),
                                ),
                                Container(
                                  width: double.infinity,
                                  height: 50,
                                  margin: EdgeInsets.all(5.0),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      widget.controller.AcceptRejectMessageRequest(widget.controller.chatName.conversationId, 0.toString());
                                      if(!kIsWeb){
                                        Navigator.of(context)..pop()..pop();
                                      }else{
                                        Get.toNamed(FluroRouters.mainScreen + '/chats');
                                      }
                                    },
                                    child: Text(Strings.delete,
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.red
                                      ),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(25.0),
                                            side: BorderSide(
                                                color: Colors.red, width: 2)
                                        ),
                                        backgroundColor: Colors.white
                                    ),
                                  ),
                                ),
                                Container(
                                  width: double.infinity,
                                  height: 50,
                                  margin: EdgeInsets.all(5.0),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      widget.controller.AcceptRejectMessageRequest(widget.controller.chatName.conversationId, 1.toString());
                                      if(!kIsWeb){
                                        Navigator.of(context)..pop()..pop();
                                      }else{
                                        Get.toNamed(FluroRouters.mainScreen + '/chats');
                                      }
                                    },
                                    child: Text(Strings.accept,
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.blue
                                      ),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(25.0),
                                            side: BorderSide(
                                                color: Colors.blue, width: 2)
                                        ),
                                        backgroundColor: Colors.white
                                    ),
                                  ),
                                ),
                              ],
                            )

                          ],
                        ),
                        //when regular message,
                      )
                      :Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(
                                Radius.circular(kIsWeb ? 40 : 20)),
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.grey[900]
                                : Colors.grey[200]
                        ),

                        /// This column is bottom bar of chat view where you can find start a message textfield and add attatchment, send button, and emoji button
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                // SizedBox(
                                //   width: 10,
                                // ),
                                // // controller.showOverlay
                                // //     ?
                                // widget.controller.isVideoPickedChat || widget.controller.isDocumentPickedChat || widget.controller.isImagePickedChat
                                //     ? SizedBox()
                                //     : Container(
                                //     width: 40,
                                //     child: FloatingActionButton(
                                //       backgroundColor: widget.controller.displayColor,
                                //       mini: true,
                                //       child: Icon(
                                //         Icons.add,
                                //         color: Colors.white,
                                //       ),
                                //       onPressed: () {
                                //         if (widget.controller.showOverlay) {
                                //           widget.controller.showOverlay = false;
                                //           widget.controller.update();
                                //         }
                                //         else {
                                //           widget.controller.showOverlay = true;
                                //           widget.controller.update();
                                //         }
                                //       },
                                //     )
                                //   // _buildFab(context),
                                // ),
                                // // : SizedBox(),
                                // SizedBox(width: 5),
                                SizedBox(width: kIsWeb ? 10 : widget.controller
                                    .showOverlay == true ? 15 : 8,),
                                widget.controller.showOverlay == true
                                    ? SizedBox()
                                    : InkWell(
                                  onTap: () async {
                                    widget.controller.showOverlay = false;
                                    widget.controller.isSendMsg = false;
                                    widget.controller.update();
                                    await widget.controller.uploadImage(
                                        Get
                                            .find<NewsfeedController>()
                                            .chatName
                                            .conversationId);
                                    // controller.update();
                                  },
                                  child: Image.asset(
                                    'assets/chaticons/image_icon.png', width: 20,
                                    height: 20,
                                    color: widget.controller.displayColor,),
                                  // Icon(Icons.image_outlined,
                                  //   color: widget.controller.displayColor,
                                  //   size: kIsWeb ? 20 : 18,
                                  // )
                                ),
                                SizedBox(width: kIsWeb ? 15 : widget.controller
                                    .showOverlay == true ? 0 : 10,),
                                widget.controller.showOverlay == true
                                    ? SizedBox()
                                    : InkWell(
                                  onTap: () async {
                                    widget.controller.showOverlay = false;
                                    widget.controller.isSendMsg = false;
                                    widget.controller.update();
                                    await Get.find<NewsfeedController>()
                                        .uploadVideo(
                                        Get
                                            .find<NewsfeedController>()
                                            .chatName
                                            .conversationId);
                                  },
                                  child: Image.asset(
                                    'assets/chaticons/video_icon.png', width: 20,
                                    height: 20,
                                    color: widget.controller.displayColor,),
                                  // Icon(
                                  //   Icons.video_collection_outlined,
                                  //   color: widget.controller.displayColor,
                                  //   size: kIsWeb ? 20 : 18,
                                  // )
                                ),
                                SizedBox(width: kIsWeb ? 15 : widget.controller
                                    .showOverlay == true ? 0 : 10,),
                                widget.controller.showOverlay == true
                                    ? SizedBox()
                                    : InkWell(
                                  onTap: () async {
                                    widget.controller.showOverlay = false;
                                    widget.controller.isSendMsg = false;
                                    widget.controller.update();
                                    await Get.find<NewsfeedController>()
                                        .uploadDocument(
                                        Get
                                            .find<NewsfeedController>()
                                            .chatName
                                            .conversationId);
                                  },
                                  child: Image.asset(
                                    'assets/chaticons/file_attach.png', width: 20,
                                    height: 20,
                                    color: widget.controller.displayColor,),
                                  // Icon(Icons.attach_file_outlined,
                                  //   color: widget.controller.displayColor,
                                  //   size: kIsWeb ? 20 : 18,
                                  // )
                                ),
                                SizedBox(width: kIsWeb ? 15 : widget.controller
                                    .showOverlay == true ? 0 : 10,),
                                Expanded(
                                  child: Builder(builder: (context) {
                                    return

                                      widget.controller
                                          .showOverlay == false && !kIsWeb ?
                                      GestureDetector(
                                          onTap: (){
                                            widget.controller.showOverlay = true;
                                            widget.controller.update();
                                          },
                                          child: Container(
                                              padding: EdgeInsets.symmetric(vertical: 12.0),
                                              alignment: Alignment.centerLeft,
                                              child: Text(Strings.startAMessage,
                                                style: TextStyle(color: Colors.black54, fontWeight: FontWeight.w500),)))
                                      : RawKeyboardListener(
                                        onKey: !widget.controller
                                            .isDocumentPickedChat &&
                                            !widget.controller
                                                .isImagePickedChat &&
                                            !widget.controller
                                                .isVideoPickedChat &&
                                            widget.controller.isChatTextEmpty
                                            ? null
                                            : widget.controller.isSendMsg
                                            ? null :

                                            (event) async {
                                          if (widget.controller
                                              .chatScrapLoading == false) {
                                            if (!event.isShiftPressed &&
                                                event.isKeyPressed(
                                                    LogicalKeyboardKey.enter)) {
                                              showCursor = false;
                                              setState(() {});
                                              print("jjjj");
                                              widget.controller.isSendMsg = true;
                                              widget.controller.update();
                                              final String messageText = widget
                                                  .controller.messageController
                                                  .text.trim();

                                              !widget.controller
                                                  .isDocumentPickedChat &&
                                                  !widget.controller
                                                      .isImagePickedChat &&
                                                  !widget.controller
                                                      .isVideoPickedChat ?
                                              widget.controller.sendMessage(
                                                  scrappingData: widget.controller
                                                      .chatScrappingData,
                                                  chatData: widget.controller
                                                      .chatName,
                                                  FileData: {

                                                    // "name": "KjlLoSp82NUzxX9T.mp4",
                                                    // "path": "https://storage.googleapis.com/buzznbees/33Ft3ZefpBJYkgB.mp4",
                                                    // "thumbnail_url": "https://storage.googleapis.com/buzznbees/temp/19907351150.sltjaenyldf.png"

                                                  },
                                                  messageId: widget.controller
                                                      .messageId ==
                                                      null ? null : widget
                                                      .controller
                                                      .messageId
                                              )
                                                  : widget.controller
                                                  .imageBytesChat !=
                                                  null ?
                                              await widget.controller
                                                  .uploadFileChat(
                                                  widget.controller
                                                      .imageBytesChat,
                                                  widget.controller.chatName
                                                      .conversationId,
                                                  widget.controller.imageFileName,
                                                  textMessage: messageText
                                              )
                                                  : widget.controller
                                                  .videoBytesChat !=
                                                  null
                                                  ? await widget.controller
                                                  .uploadFileChat(
                                                  widget.controller
                                                      .videoBytesChat,
                                                  widget.controller.chatName
                                                      .conversationId,
                                                  widget.controller.videoFileName,
                                                  textMessage: messageText
                                              )
                                                  : widget.controller
                                                  .documentBytesChat !=
                                                  null
                                                  ? await widget.controller
                                                  .uploadFileChat(
                                                  widget.controller
                                                      .documentBytesChat,
                                                  widget.controller.chatName
                                                      .conversationId,
                                                  widget.controller.pdfFileName,
                                                  textMessage: messageText
                                              )
                                                  : null;
                                              Future.delayed(
                                                  Duration(milliseconds: 10),
                                                      () async {
                                                    // Clearing the text without this delay is leaving a blank line in the text field on web.
                                                    // After 'Enter' key pressed, new line is added in the text field only after this listener fires.
                                                    // Giving this delay is solving the problem. - K
                                                    widget.controller
                                                        .messageController
                                                        .clear();
                                                  });
                                              widget.controller.messageController
                                                  .clear();
                                              Future.delayed(Duration(seconds: 2),
                                                      () async {
                                                    // 5s over, navigate to a new page

                                                    // controller.getChatForMessageScreen() is moved to 'new_message' socket listener in new_feed_controller.dart
                                                    // While sending message this is helpful here but the user receiving the message should also have
                                                    // updated conversation list. So, moving this to 'new_message' will update to both sender and receiver.
                                                    // Below is the link to one of the bug related to this on Asana:  - K
                                                    // https://app.asana.com/0/1203291929645086/1204450039764493/f
                                                    //
                                                    // await widget.controller
                                                    //     .getChatForMessageScreen();

                                                    widget.controller.chatIndex =
                                                    0;
                                                    widget.controller.update();

                                                    // await  widget.controller.getChat();
                                                  });

                                              // await    widget.controller.getChatForMessageScreen();

                                              // if(!kIsWeb)
                                              //   {
                                              //
                                              //     widget.controller.getChatForMessageScreen();
                                              //
                                              //   }

                                              // widget.controller.getChat();


                                              widget.controller.update();
                                              showCursor = true;
                                              setState(() {

                                              });

                                              // if (fileUrl == null) {
                                              //   await controller.sendMessage(
                                              //       controller.chatName, fileUrl);
                                              // }
                                              // await Get.find<NewsfeedController>().

                                            }
                                          }
                                        },
                                        focusNode: focusNode,
                                        child: TextFormField(
                                          inputFormatters: [
                                            // Removed the below code, this code is restricting even 'Shift + Enter' to create a new line in the chat.
                                            // In the RawKeyboardListener itself handled both 'Enter' to send message on web and 'Shift + Enter' to create new line on web. - K

                                            // kIsWeb ?  FilteringTextInputFormatter.deny('\n') : FilteringTextInputFormatter.allow('\n'), // Remove the Enter key behavior
                                          ],
                                          showCursor: showCursor,
                                          onTap: () {
                                            if (kIsWeb) {
                                              if (isEmojiVisible) {
                                                isEmojiVisible = !isEmojiVisible;
                                                FocusScope.of(context).unfocus();
                                              }
                                              if (this.mounted) {
                                                // check whether the state object is in tree
                                                setState(() {
                                                  // make changes here
                                                });
                                              }
                                            } else {
                                              debugPrint("hello xxx");
                                              widget.controller.showOverlay = true;
                                              widget.controller.update();
                                            }
                                          },
                                          controller: widget.controller
                                              .messageController,
                                          focusNode: widget.controller.focusNode,
                                          autofocus: kIsWeb ? false : true,
                                          onChanged: (val) {
                                            print("emoji : $val");
                                            if (val
                                                .trim()
                                                .length > 0) {
                                              if (widget.controller.urlOrNot(
                                                  widget.controller
                                                      .messageController.text) ==
                                                  true) {
                                                // if (widget.controller.scrapUrl.contains('.com')) {

                                                widget.controller.chatUrlScraping(
                                                    widget.controller.scrapUrl);


                                                // widget.controller.scrappingDat = widget.controller.scrappingData as ScrappingData;
                                                // }
                                              }
                                              else {
                                                print("dasfasdadsadasdasdasd");

                                                widget.controller
                                                    .chatScrappingData = null;
                                                widget.controller.update();
                                              }


                                              print(val
                                                  .trim()
                                                  .length);
                                              widget.controller.isSendMsg = false;
                                              widget.controller.isChatTextEmpty =
                                              false;
                                              widget.controller.update();
                                            } else {
                                              widget.controller.isChatTextEmpty =
                                              true;
                                              widget.controller.update();
                                            }
                                          },

                                          maxLines: 7,
                                          minLines: 1,
                                          style: TextStyle(
                                            color: Theme
                                                .of(context)
                                                .brightness == Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14,
                                          ),
                                          validator: (_) {
                                            return null;
                                          },
                                          cursorColor: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.grey[300]
                                              : Theme
                                              .of(context)
                                              .textSelectionTheme
                                              .cursorColor,

                                          decoration: InputDecoration(
                                            contentPadding: EdgeInsets.only(
                                              left: kIsWeb ? 0 : widget.controller
                                                  .showOverlay == true ? 0 : 5,
                                              top: kIsWeb ? 18 : widget.controller
                                                  .showOverlay == true ? 15 : 12,
                                              bottom: kIsWeb ? 18 : widget
                                                  .controller.showOverlay == true
                                                  ? 15
                                                  : 12,
                                            ),
                                            isDense: true,
                                            // suffixIcon: widget.controller.showOverlay == true ? SizedBox():IconButton(
                                            //   onPressed: () async {
                                            //     print("hello");
                                            //     if (isEmojiVisible) {
                                            //       print("in");
                                            //
                                            //       widget.controller.focusNode
                                            //           .requestFocus();
                                            //     } else if (!isEmojiVisible) {
                                            //       // await SystemChannels.textInput.invokeMethod('TextInput.hide');
                                            //       // await Future.delayed(
                                            //       //     const Duration(milliseconds: 100));
                                            //       FocusScope.of(context).unfocus();
                                            //
                                            //       // widget.controller.focusNode.unfocus();
                                            //     }
                                            //     isEmojiVisible = !isEmojiVisible;
                                            //     if (this.mounted) {
                                            //       // check whether the state object is in tree
                                            //       setState(() {
                                            //         // make changes here
                                            //       });
                                            //     }
                                            //
                                            //     kIsWeb
                                            //         ? showAlignedDialog(
                                            //         context: context,
                                            //         builder: (BuildContext context) {
                                            //           return Offstage(
                                            //               offstage: !isEmojiVisible,
                                            //               child: Container(
                                            //                   height: 300,
                                            //                   width: 300,
                                            //                   margin: const EdgeInsets.all(5),
                                            //                   padding: const EdgeInsets.all(2),
                                            //                   decoration: BoxDecoration(
                                            //                       color: Colors.white,
                                            //                       border: Border.all(
                                            //                         color: Colors.white,
                                            //                       ),
                                            //                       borderRadius:
                                            //                       BorderRadius.circular(10)
                                            //                   ),
                                            //                   child: DefaultTabController(
                                            //                       length: emojis.length,
                                            //                       child: isPortrait
                                            //                           ? Column(children: [
                                            //                         Container(
                                            //                             margin: const EdgeInsets
                                            //                                 .symmetric(
                                            //                                 horizontal:
                                            //                                 2),
                                            //                             child: EmojiTabBar(
                                            //                                 tabController:
                                            //                                 _tabController)),
                                            //                         const Divider(
                                            //                             color: Colors
                                            //                                 .black45,
                                            //                             height:
                                            //                             5,
                                            //                             thickness:
                                            //                             .5),
                                            //                         EmojisList(
                                            //                             cross:
                                            //                             cross,
                                            //                             textController: widget
                                            //                                 .controller
                                            //                                 .messageController,
                                            //                             tabController:
                                            //                             _tabController)
                                            //                       ])
                                            //                           : Row(children: [
                                            //                         emojiSideBar(),
                                            //                         EmojisList(
                                            //                             cross:
                                            //                             cross,
                                            //                             textController: widget
                                            //                                 .controller
                                            //                                 .messageController,
                                            //                             tabController:
                                            //                             _tabController)
                                            //                       ]))));
                                            //         },
                                            //         followerAnchor:
                                            //         Alignment.bottomRight,
                                            //         targetAnchor:
                                            //         Alignment.bottomRight,
                                            //         avoidOverflow: true,
                                            //         barrierColor: Colors.transparent)
                                            //         : null;
                                            //
                                            //     // setState(() {});
                                            //   },
                                            //   icon: Icon(
                                            //     kIsWeb
                                            //         ? Icons.emoji_emotions
                                            //         : isEmojiVisible
                                            //         ? Icons.keyboard
                                            //         : Icons.emoji_emotions,
                                            //     color: widget.controller.displayColor,
                                            //     size: 20,
                                            //   ),
                                            // ),
                                            border: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(
                                                      kIsWeb ? 0 : 20)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(
                                                      kIsWeb ? 0 : 20)),
                                              borderSide: BorderSide(
                                                width: 0,
                                                style: BorderStyle.none,
                                                color: Theme
                                                    .of(context)
                                                    .primaryColor,
                                              ),
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(
                                                      kIsWeb ? 0 : 20)),
                                              borderSide: BorderSide(
                                                width: 0,
                                                style: BorderStyle.none,
                                              ),
                                            ),
                                            hintText: Strings.enterYourMessage,
                                            // hintStyle: TextStyle(),
                                            hintStyle: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : MyColors.lightColor,
                                              fontWeight: FontWeight.w500,
                                              fontSize: 14,
                                            ),
                                            fillColor: Theme
                                                .of(context)
                                                .brightness == Brightness.dark
                                                ? Colors.grey[900]
                                                : Colors.grey[200],
                                            filled: true,

                                          ),
                                        ),
                                        // InputField(
                                        //   contextPadding: EdgeInsets.only(
                                        //       left: kIsWeb ? 20 : 20,
                                        //       top: kIsWeb ? 30 : 20,
                                        //       bottom: kIsWeb ? 20 : 15),
                                        //   showCursor: showCursor,
                                        //   onTap: () {
                                        //     if (kIsWeb) {
                                        //       if (isEmojiVisible) {
                                        //         isEmojiVisible = !isEmojiVisible;
                                        //         FocusScope.of(context).unfocus();
                                        //       }
                                        //       if (this.mounted) {
                                        //         // check whether the state object is in tree
                                        //         setState(() {
                                        //           // make changes here
                                        //         });
                                        //       }
                                        //     }
                                        //   },
                                        //   onPress: () async {
                                        //     print("hello");
                                        //     if (isEmojiVisible) {
                                        //       print("in");
                                        //
                                        //       widget.controller.focusNode
                                        //           .requestFocus();
                                        //     } else if (!isEmojiVisible) {
                                        //       // await SystemChannels.textInput.invokeMethod('TextInput.hide');
                                        //       // await Future.delayed(
                                        //       //     const Duration(milliseconds: 100));
                                        //       FocusScope.of(context).unfocus();
                                        //
                                        //       // widget.controller.focusNode.unfocus();
                                        //     }
                                        //     isEmojiVisible = !isEmojiVisible;
                                        //     if (this.mounted) {
                                        //       // check whether the state object is in tree
                                        //       setState(() {
                                        //         // make changes here
                                        //       });
                                        //     }
                                        //
                                        //     kIsWeb
                                        //         ? showAlignedDialog(
                                        //         context: context,
                                        //         builder: (BuildContext context) {
                                        //           return Offstage(
                                        //               offstage: !isEmojiVisible,
                                        //               child: Container(
                                        //                   height: 300,
                                        //                   width: 300,
                                        //                   margin: const EdgeInsets.all(5),
                                        //                   padding: const EdgeInsets.all(2),
                                        //                   decoration: BoxDecoration(
                                        //                       color: Colors.white,
                                        //                       border: Border.all(
                                        //                         color: Colors.white,
                                        //                       ),
                                        //                       borderRadius:
                                        //                       BorderRadius.circular(10)
                                        //                   ),
                                        //                   child: DefaultTabController(
                                        //                       length: emojis.length,
                                        //                       child: isPortrait
                                        //                           ? Column(children: [
                                        //                         Container(
                                        //                             margin: const EdgeInsets
                                        //                                 .symmetric(
                                        //                                 horizontal:
                                        //                                 2),
                                        //                             child: EmojiTabBar(
                                        //                                 tabController:
                                        //                                 _tabController)),
                                        //                         const Divider(
                                        //                             color: Colors
                                        //                                 .black45,
                                        //                             height:
                                        //                             5,
                                        //                             thickness:
                                        //                             .5),
                                        //                         EmojisList(
                                        //                             cross:
                                        //                             cross,
                                        //                             textController: widget
                                        //                                 .controller
                                        //                                 .messageController,
                                        //                             tabController:
                                        //                             _tabController)
                                        //                       ])
                                        //                           : Row(children: [
                                        //                         emojiSideBar(),
                                        //                         EmojisList(
                                        //                             cross:
                                        //                             cross,
                                        //                             textController: widget
                                        //                                 .controller
                                        //                                 .messageController,
                                        //                             tabController:
                                        //                             _tabController)
                                        //                       ]))));
                                        //         },
                                        //         followerAnchor:
                                        //         Alignment.bottomRight,
                                        //         targetAnchor:
                                        //         Alignment.bottomRight,
                                        //         avoidOverflow: true,
                                        //         barrierColor: Colors.transparent)
                                        //         : null;
                                        //
                                        //     // setState(() {});
                                        //   },
                                        //   suffixIcon: kIsWeb
                                        //       ? Icons.emoji_emotions
                                        //       : isEmojiVisible
                                        //       ? Icons.keyboard
                                        //       : Icons.emoji_emotions,
                                        //   suffixIconColor: widget.controller.displayColor,
                                        //   controller:
                                        //   widget.controller.messageController,
                                        //   focusNode: widget.controller.focusNode,
                                        //   onChanged: (val) {
                                        //
                                        //
                                        //
                                        //
                                        //     print("emoji : $val");
                                        //     if (val.trim().length > 0) {
                                        //
                                        //
                                        //
                                        //       if( widget.controller.urlOrNot(widget.controller.messageController.text) == true)
                                        //       {
                                        //        // if (widget.controller.scrapUrl.contains('.com')) {
                                        //
                                        //            widget.controller.chatUrlScraping(widget.controller.scrapUrl);
                                        //
                                        //
                                        //           // widget.controller.scrappingDat = widget.controller.scrappingData as ScrappingData;
                                        //        // }
                                        //       }
                                        //       else{
                                        //
                                        //
                                        //         print("dasfasdadsadasdasdasd");
                                        //
                                        //         widget.controller.chatScrappingData = null;
                                        //         widget.controller.update();
                                        //
                                        //       }
                                        //
                                        //
                                        //
                                        //
                                        //
                                        //
                                        //
                                        //
                                        //
                                        //       print(val.trim().length);
                                        //       widget.controller.isSendMsg = false;
                                        //       widget.controller.isChatTextEmpty =
                                        //       false;
                                        //       widget.controller.update();
                                        //     } else {
                                        //       widget.controller.isChatTextEmpty =
                                        //       true;
                                        //       widget.controller.update();
                                        //     }
                                        //   },
                                        //
                                        //   maxLine: 7,
                                        //   minLine: 1,
                                        //
                                        //   validator: (_) {
                                        //     return null;
                                        //   },
                                        //
                                        //   // hint: 'Enter your message',
                                        //   hint: Strings.enterYourMessage,
                                        //   // suffixIcon: Icons.emoji_emotions_outlined,
                                        // ),
                                      );
                                  }),
                                ),
                                widget.controller.showOverlay == true
                                    ? SizedBox()
                                    : InkWell(
                                  onTap: () async {
                                    print("hello");
                                    if (isEmojiVisible) {
                                      print("in");

                                      widget.controller.focusNode
                                          .requestFocus();
                                    } else if (!isEmojiVisible) {
                                      // await SystemChannels.textInput.invokeMethod('TextInput.hide');
                                      // await Future.delayed(
                                      //     const Duration(milliseconds: 100));
                                      FocusScope.of(context).unfocus();

                                      // widget.controller.focusNode.unfocus();
                                    }
                                    isEmojiVisible = !isEmojiVisible;
                                    if (this.mounted) {
                                      // check whether the state object is in tree
                                      setState(() {
                                        // make changes here
                                      });
                                    }

                                    kIsWeb
                                        ? showAlignedDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return Offstage(
                                              offstage: !isEmojiVisible,
                                              child: Container(
                                                  height: 300,
                                                  width: 300,
                                                  margin: const EdgeInsets.all(5),
                                                  padding: const EdgeInsets.all(
                                                      2),
                                                  decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      border: Border.all(
                                                        color: Colors.white,
                                                      ),
                                                      borderRadius:
                                                      BorderRadius.circular(10)
                                                  ),
                                                  child: DefaultTabController(
                                                      length: emojis.length,
                                                      child: isPortrait
                                                          ? Column(children: [
                                                        Container(
                                                            margin: const EdgeInsets
                                                                .symmetric(
                                                                horizontal:
                                                                2),
                                                            child: EmojiTabBar(
                                                                tabController:
                                                                _tabController)),
                                                        const Divider(
                                                            color: Colors
                                                                .black45,
                                                            height:
                                                            5,
                                                            thickness:
                                                            .5),
                                                        EmojisList(
                                                            cross:
                                                            cross,
                                                            textController: widget
                                                                .controller
                                                                .messageController,
                                                            tabController:
                                                            _tabController)
                                                      ])
                                                          : Row(children: [
                                                        emojiSideBar(),
                                                        EmojisList(
                                                            cross:
                                                            cross,
                                                            textController: widget
                                                                .controller
                                                                .messageController,
                                                            tabController:
                                                            _tabController)
                                                      ]))));
                                        },
                                        followerAnchor:
                                        Alignment.bottomRight,
                                        targetAnchor:
                                        Alignment.bottomRight,
                                        avoidOverflow: true,
                                        barrierColor: Colors.transparent)
                                        : null;

                                    // setState(() {});
                                  },
                                  child: Image.asset(
                                    'assets/chaticons/emojii_icon.png', width: 20,
                                    height: 20,
                                    color: widget.controller.displayColor,),
                                  // Icon(
                                  //   kIsWeb
                                  //       ? Icons.emoji_emotions
                                  //       : isEmojiVisible
                                  //       ? Icons.keyboard
                                  //       : Icons.emoji_emotions,
                                  //   color: widget.controller.displayColor,
                                  //   size: kIsWeb ? 22 : 18,
                                  // ),
                                ),
                                SizedBox(width: kIsWeb ? 15 : widget.controller
                                    .showOverlay == true ? 0 : 10,),
                                widget.controller.chatScrapLoading == true
                                    ? CircularProgressIndicator() : widget
                                    .controller.showOverlay == true
                                    ? SizedBox()
                                    : InkWell(
                                  onTap:

                                  !widget.controller.isDocumentPickedChat &&
                                      !widget.controller.isImagePickedChat &&
                                      !widget.controller.isVideoPickedChat &&
                                      widget.controller.isChatTextEmpty
                                      ? null
                                      : widget.controller.isSendMsg
                                      ? null
                                      : () async {
                                    widget.controller.isSendMsg = true;
                                    widget.controller.update();
                                    final String messageText = widget.controller
                                        .messageController.text.trim();

                                    !widget.controller.isDocumentPickedChat &&
                                        !widget.controller.isImagePickedChat &&
                                        !widget.controller.isVideoPickedChat ?
                                    widget.controller.sendMessage(
                                        scrappingData: widget.controller
                                            .chatScrappingData,
                                        chatData: widget.controller.chatName,
                                        FileData: {

                                          // "name": "KjlLoSp82NUzxX9T.mp4",
                                          // "path": "https://storage.googleapis.com/buzznbees/33Ft3ZefpBJYkgB.mp4",
                                          // "thumbnail_url": "https://storage.googleapis.com/buzznbees/temp/19907351150.sltjaenyldf.png"

                                        },

                                        messageId: widget.controller.messageId ==
                                            null
                                            ? null
                                            : widget.controller.messageId
                                    )
                                        : widget.controller.imageBytesChat != null
                                        ?
                                    await widget.controller.uploadFileChat(
                                        widget.controller.imageBytesChat,
                                        widget.controller.chatName.conversationId,
                                        widget.controller.imageFileName,
                                        textMessage: messageText
                                    )
                                        : widget.controller.videoBytesChat !=
                                        null
                                        ? await widget.controller
                                        .uploadFileChat(
                                        widget.controller.videoBytesChat,
                                        widget.controller.chatName.conversationId,
                                        widget.controller.videoFileName,
                                        textMessage: messageText
                                    )
                                        : widget.controller.documentBytesChat !=
                                        null
                                        ? await widget.controller.uploadFileChat(
                                        widget.controller.documentBytesChat,
                                        widget.controller.chatName.conversationId,
                                        widget.controller.pdfFileName,
                                        textMessage: messageText
                                    )
                                        : null;

                                    widget.controller.messageController.clear();
                                    Future.delayed(Duration(seconds: 2),
                                            () async {
                                          // 5s over, navigate to a new page
                                          // controller.getChatForMessageScreen() is moved to 'new_message' socket listener in new_feed_controller.dart
                                          // While sending message this is helpful here but the user receiving the message should also have
                                          // updated conversation list. So, moving this to 'new_message' will update to both sender and receiver.
                                          // Below is the link to one of the bug related to this on Asana:  - K
                                          // https://app.asana.com/0/1203291929645086/1204450039764493/f
                                          // await widget.controller.getChatForMessageScreen();

                                          widget.controller.chatIndex = 0;
                                          widget.controller.update();

                                          // await  widget.controller.getChat();
                                        });

                                    // await    widget.controller.getChatForMessageScreen();

                                    // if(!kIsWeb)
                                    //   {
                                    //
                                    //     widget.controller.getChatForMessageScreen();
                                    //
                                    //   }

                                    // widget.controller.getChat();

                                    widget.controller.update();

                                    // if (fileUrl == null) {
                                    //   await controller.sendMessage(
                                    //       controller.chatName, fileUrl);
                                    // }
                                    // await Get.find<NewsfeedController>().createMessagePaged(controller.chatName.conversationId);
                                  },
                                  child: Image.asset(
                                    'assets/chaticons/send_icon.png', width: 20,
                                    height: 20,
                                    color: widget.controller.displayColor,),
                                  // Icon(
                                  //   Icons.send_outlined,
                                  //   color: widget.controller.displayColor,
                                  //   size: kIsWeb ? 22 : 18,
                                  // ),
                                ),
                                SizedBox(width: kIsWeb ? 10 : 8,),
                              ],
                            ),
                            widget.controller.showOverlay ? Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    SizedBox(width: 15,),
                                    InkWell(
                                      onTap: () async {
                                        widget.controller.showOverlay = false;
                                        widget.controller.isSendMsg = false;
                                        widget.controller.update();
                                        await widget.controller.uploadImage(
                                            Get
                                                .find<NewsfeedController>()
                                                .chatName
                                                .conversationId);
                                        // controller.update();
                                      },
                                      child: Image.asset(
                                        'assets/chaticons/image_icon.png',
                                        width: 20,
                                        height: 20,
                                        color: widget.controller.displayColor,),
                                      // Icon(Icons.image_outlined,
                                      //   color: widget.controller.displayColor,
                                      //   size: 20,
                                      // )
                                    ),
                                    SizedBox(width: 15,),
                                    InkWell(
                                      onTap: () async {
                                        widget.controller.showOverlay = false;
                                        widget.controller.isSendMsg = false;
                                        widget.controller.update();
                                        await Get.find<NewsfeedController>()
                                            .uploadVideo(
                                            Get
                                                .find<NewsfeedController>()
                                                .chatName
                                                .conversationId);
                                      },
                                      child: Image.asset(
                                        'assets/chaticons/video_icon.png',
                                        width: 20,
                                        height: 20,
                                        color: widget.controller.displayColor,),
                                      // Icon(
                                      //   Icons.video_collection_outlined,
                                      //   color: widget.controller.displayColor,
                                      //   size: 20,
                                      // )
                                    ),
                                    SizedBox(width: 15,),
                                    InkWell(
                                      onTap: () async {
                                        widget.controller.showOverlay = false;
                                        widget.controller.isSendMsg = false;
                                        widget.controller.update();
                                        await Get.find<NewsfeedController>()
                                            .uploadDocument(
                                            Get
                                                .find<NewsfeedController>()
                                                .chatName
                                                .conversationId);
                                      },
                                      child: Image.asset(
                                        'assets/chaticons/file_attach.png',
                                        width: 20,
                                        height: 20,
                                        color: widget.controller.displayColor,),
                                      // Icon(Icons.attach_file_outlined,
                                      //   color: widget.controller.displayColor,
                                      //   size: 20,
                                      // )
                                    ),
                                    SizedBox(width: 15,),
                                  ],
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        print("hello");
                                        if (isEmojiVisible) {
                                          print("in");

                                          widget.controller.focusNode
                                              .requestFocus();
                                        } else if (!isEmojiVisible) {
                                          // await SystemChannels.textInput.invokeMethod('TextInput.hide');
                                          // await Future.delayed(
                                          //     const Duration(milliseconds: 100));
                                          FocusScope.of(context).unfocus();

                                          // widget.controller.focusNode.unfocus();
                                        }
                                        isEmojiVisible = !isEmojiVisible;
                                        if (this.mounted) {
                                          // check whether the state object is in tree
                                          setState(() {
                                            // make changes here
                                          });
                                        }

                                        kIsWeb
                                            ? showAlignedDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return Offstage(
                                                  offstage: !isEmojiVisible,
                                                  child: Container(
                                                      height: 300,
                                                      width: 300,
                                                      margin: const EdgeInsets
                                                          .all(5),
                                                      padding: const EdgeInsets
                                                          .all(2),
                                                      decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          border: Border.all(
                                                            color: Colors.white,
                                                          ),
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              10)
                                                      ),
                                                      child: DefaultTabController(
                                                          length: emojis.length,
                                                          child: isPortrait
                                                              ? Column(children: [
                                                            Container(
                                                                margin: const EdgeInsets
                                                                    .symmetric(
                                                                    horizontal:
                                                                    2),
                                                                child: EmojiTabBar(
                                                                    tabController:
                                                                    _tabController)),
                                                            const Divider(
                                                                color: Colors
                                                                    .black45,
                                                                height:
                                                                5,
                                                                thickness:
                                                                .5),
                                                            EmojisList(
                                                                cross:
                                                                cross,
                                                                textController: widget
                                                                    .controller
                                                                    .messageController,
                                                                tabController:
                                                                _tabController)
                                                          ])
                                                              : Row(children: [
                                                            emojiSideBar(),
                                                            EmojisList(
                                                                cross:
                                                                cross,
                                                                textController: widget
                                                                    .controller
                                                                    .messageController,
                                                                tabController:
                                                                _tabController)
                                                          ]))));
                                            },
                                            followerAnchor:
                                            Alignment.bottomRight,
                                            targetAnchor:
                                            Alignment.bottomRight,
                                            avoidOverflow: true,
                                            barrierColor: Colors.transparent)
                                            : null;

                                        // setState(() {});
                                      },
                                      child: Image.asset(
                                        'assets/chaticons/emojii_icon.png',
                                        width: 20,
                                        height: 20,
                                        color: widget.controller.displayColor,),
                                      // Icon(
                                      //   kIsWeb
                                      //       ? Icons.emoji_emotions
                                      //       : isEmojiVisible
                                      //       ? Icons.keyboard
                                      //       : Icons.emoji_emotions,
                                      //   color: widget.controller.displayColor,
                                      //     size: 20,
                                      // ),
                                    ),
                                    SizedBox(width: 15,),
                                    widget.controller.chatScrapLoading == true ?
                                    CircularProgressIndicator() : InkWell(
                                      onTap:

                                      !widget.controller.isDocumentPickedChat &&
                                          !widget.controller.isImagePickedChat &&
                                          !widget.controller.isVideoPickedChat &&
                                          widget.controller.isChatTextEmpty
                                          ? null
                                          : widget.controller.isSendMsg
                                          ? null
                                          : () async {
                                        widget.controller.isSendMsg = true;
                                        widget.controller.update();
                                        final String messageText = widget
                                            .controller.messageController.text
                                            .trim();

                                        !widget.controller.isDocumentPickedChat &&
                                            !widget.controller
                                                .isImagePickedChat &&
                                            !widget.controller.isVideoPickedChat ?
                                        widget.controller.sendMessage(
                                            scrappingData: widget.controller
                                                .chatScrappingData,
                                            chatData: widget.controller.chatName,
                                            FileData: {

                                              // "name": "KjlLoSp82NUzxX9T.mp4",
                                              // "path": "https://storage.googleapis.com/buzznbees/33Ft3ZefpBJYkgB.mp4",
                                              // "thumbnail_url": "https://storage.googleapis.com/buzznbees/temp/19907351150.sltjaenyldf.png"

                                            },

                                            messageId: widget.controller
                                                .messageId == null
                                                ? null
                                                : widget.controller.messageId
                                        )
                                            : widget.controller.imageBytesChat !=
                                            null ?
                                        await widget.controller.uploadFileChat(
                                            widget.controller.imageBytesChat,
                                            widget.controller.chatName
                                                .conversationId,
                                            widget.controller.imageFileName,
                                            textMessage: messageText
                                        )
                                            : widget.controller.videoBytesChat !=
                                            null
                                            ? await widget.controller
                                            .uploadFileChat(
                                            widget.controller.videoBytesChat,
                                            widget.controller.chatName
                                                .conversationId,
                                            widget.controller.videoFileName,
                                            textMessage: messageText
                                        )
                                            : widget.controller
                                            .documentBytesChat != null
                                            ? await widget.controller
                                            .uploadFileChat(
                                            widget.controller.documentBytesChat,
                                            widget.controller.chatName
                                                .conversationId,
                                            widget.controller.pdfFileName,
                                            textMessage: messageText
                                        )
                                            : null;

                                        widget.controller.messageController
                                            .clear();
                                        Future.delayed(Duration(seconds: 2),
                                                () async {
                                              // 5s over, navigate to a new page
                                              // controller.getChatForMessageScreen() is moved to 'new_message' socket listener in new_feed_controller.dart
                                              // While sending message this is helpful here but the user receiving the message should also have
                                              // updated conversation list. So, moving this to 'new_message' will update to both sender and receiver.
                                              // Below is the link to one of the bug related to this on Asana:  - K
                                              // https://app.asana.com/0/1203291929645086/1204450039764493/f
                                              // await widget.controller.getChatForMessageScreen();

                                              widget.controller.chatIndex = 0;
                                              widget.controller.update();

                                              // await  widget.controller.getChat();
                                            });

                                        // await    widget.controller.getChatForMessageScreen();

                                        // if(!kIsWeb)
                                        //   {
                                        //
                                        //     widget.controller.getChatForMessageScreen();
                                        //
                                        //   }

                                        // widget.controller.getChat();

                                        widget.controller.update();

                                        // if (fileUrl == null) {
                                        //   await controller.sendMessage(
                                        //       controller.chatName, fileUrl);
                                        // }
                                        // await Get.find<NewsfeedController>().createMessagePaged(controller.chatName.conversationId);
                                      },
                                      child: Image.asset(
                                        'assets/chaticons/send_icon.png',
                                        width: 20,
                                        height: 20,
                                        color: widget.controller.displayColor,),
                                      // Icon(
                                      //   Icons.send_outlined,
                                      //   color: widget.controller.displayColor,
                                      //   size: 20,
                                      // ),
                                    ),
                                    SizedBox(width: 15,),
                                  ],
                                ),
                              ],
                            ) : SizedBox(),
                            SizedBox(height: widget.controller.showOverlay == true
                                ? 10
                                : 0,),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              padding: EdgeInsets.only(bottom: 10),
            ),
            !kIsWeb
                ? Offstage(
                offstage: !isEmojiVisible,
                child: Container(
                    height: height * .4,
                    width: double.infinity,
                    margin: const EdgeInsets.all(5),
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.black54, width: .5),
                        borderRadius: BorderRadius.circular(10)),
                    child: DefaultTabController(
                        length: emojis.length,
                        child: isPortrait
                            ? Column(children: [
                          Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 2),
                              child: EmojiTabBar(
                                  tabController: _tabController)),
                          const Divider(
                              color: Colors.black45,
                              height: 5,
                              thickness: .5),
                          EmojisList(
                              cross: cross,
                              textController:
                              widget.controller.messageController,
                              tabController: _tabController)
                        ])
                            : Row(children: [
                          emojiSideBar(),
                          EmojisList(
                              cross: cross,
                              textController:
                              widget.controller.messageController,
                              tabController: _tabController)
                        ]))))
                : SizedBox(),
          ],

    ));
    // ),
    // );
  }

  Widget chatTitle() {

    int chatIndex = widget.controller.chatIndex ?? 0;
    if (chatIndex < 0) chatIndex = 0;

    String conversationTitle = "";
    if (widget.controller.chatUserList[chatIndex].conversationType == "group"){
      conversationTitle = ChatUtils.getGroupChatName(widget.controller.chatUserList[chatIndex].members);
    } else {
      conversationTitle = widget.controller.chatUserList[chatIndex].name ?? Strings.werfieUser;
    }

    return Row(
      children: [
        widget.controller.tempGroupName != ""
            ? Expanded(
          child: Container(
            width: widget.controller.tempGroupName.length > 15
                ? kIsWeb ? 120 : 80
                : null,
            child: Text(
              "${widget.controller.tempGroupName}",
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: Styles.baseTextTheme.headline2.copyWith(
                color: Theme
                    .of(context)
                    .brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        )
            : widget.isRequested
            ? Expanded(
          child: Container(
            child: widget.controller.chatRequestUserList[chatIndex].conversationType == "group" ?
            widget.controller.chatRequestUserList[chatIndex].name != null
                ? Container(
              width: widget.controller.chatRequestUserList[chatIndex].name.length > 15
                  ? kIsWeb ? 120 : 80
                  : null,
              child: Text(
                "${widget.controller.chatRequestUserList[chatIndex].name}",
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme
                      .of(context)
                      .brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
            )
                : widget.controller.chatRequestUserList[chatIndex].members.length == 1
                ? FittedBox(
                child: Row(
                  children: [
                    Container(
                      width: widget.controller.chatRequestUserList[chatIndex].members[0].firstname
                          .length > 15 ? kIsWeb ? 120 : 80 : null,
                      child: Text(
                        "${widget.controller.chatRequestUserList[chatIndex].members[0]
                            .firstname}",
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: Styles.baseTextTheme.headline4
                            .copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark ? Colors
                              .white : Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),


                  ],
                )
            )
                : widget.controller.chatRequestUserList[chatIndex].members.length == 2
                ? FittedBox(
                child: Row(
                  children: [
                    Container(
                      width: widget.controller.chatRequestUserList[chatIndex].members[0].firstname
                          .length > 15 ? kIsWeb ? 120 : 80 : null,
                      child: Text(
                        "${widget.controller.chatRequestUserList[chatIndex].members[0]
                            .firstname}, ",
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: Styles.baseTextTheme.headline4
                            .copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark ? Colors
                              .white : Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      width: widget.controller.chatRequestUserList[chatIndex].members[1].firstname
                          .length > 15 ? kIsWeb ? 120 : 80 : null,
                      child: Text(
                        "${widget.controller.chatRequestUserList[chatIndex].members[1]
                            .firstname}",
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: Styles.baseTextTheme.headline4
                            .copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark ? Colors
                              .white : Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),

                  ],
                )
            )
                : widget.controller.chatRequestUserList[chatIndex].members.length == 3
                ? FittedBox(
              child: Row(
                children: [
                  Container(
                    width: widget.controller.chatRequestUserList[chatIndex].members[0].firstname
                        .length > 15 ? kIsWeb ? 120 : 80 : null,
                    child: Text(
                      "${widget.controller.chatRequestUserList[chatIndex].members[0]
                          .firstname}, ",
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: Styles.baseTextTheme.headline4.copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors
                            .white : Colors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Text(
                    "${widget.controller.chatRequestUserList[widget
                        .controller.chatIndex].members.length -
                        1} ${Strings.otherChat}",
                    style: Styles.baseTextTheme.headline4.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors
                          .white : Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            )
                : widget.controller.chatRequestUserList[chatIndex].members.length >= 4
                ? FittedBox(
                child: Row(
                  children: [

                    Container(
                      width: widget.controller.chatRequestUserList[chatIndex].members[0].firstname
                          .length > 15 ? kIsWeb ? 120 : 60 : null,
                      child: Text(
                        "${widget.controller.chatRequestUserList[chatIndex].members[0]
                            .firstname}, ",
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: Styles.baseTextTheme.headline4
                            .copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark ? Colors
                              .white : Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Container(
                      width: widget.controller.chatRequestUserList[chatIndex].members[1].firstname
                          .length > 15 ? kIsWeb ? 120 : 60 : null,
                      child: Text(
                        "${widget.controller.chatRequestUserList[chatIndex].members[1]
                            .firstname}, ",
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: Styles.baseTextTheme.headline4
                            .copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark ? Colors
                              .white : Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    // Text(
                    //   "${controller.chatUserList[index].members[2].firstname} and ",
                    //   style: Theme.of(context).brightness == Brightness.dark ?
                    //   TextStyle(color: Colors.white,
                    //       fontWeight: FontWeight.w600,overflow:
                    //       TextOverflow.ellipsis
                    //   )
                    //       : TextStyle(color: Colors.black,
                    //       fontWeight: FontWeight.w600,overflow:
                    //       TextOverflow.ellipsis
                    //   ),
                    // ),
                    Text(
                      "${widget.controller.chatRequestUserList[widget
                          .controller.chatIndex].members.length -
                          2} ${Strings.otherChat}",
                      style: Styles.baseTextTheme.headline4.copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors
                            .white : Colors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                )
            )


                : SizedBox() : SizedBox(),
          ),
        )
            : widget.controller.chatUserList[chatIndex].conversationType == "group"
/*            ? widget.controller.chatUserList[chatIndex].name != null
            ? Expanded(
          child: Container(
            width: widget.controller.chatUserList[chatIndex].name.length > 15
                ? kIsWeb ? 120 : 80
                : null,
            child: Text(
              "${widget.controller.chatUserList[chatIndex].name}",
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: Styles.baseTextTheme.headline4.copyWith(
                color: Theme
                    .of(context)
                    .brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        )
            : widget.controller.chatUserList[chatIndex].members.length == 1
            ? Expanded(
            child: Row(
              children: [
                Container(
                  width: widget.controller.chatUserList[chatIndex].members[0].firstname
                      .length > 15 ? kIsWeb ? 120 : 80 : null,
                  child: Text(
                    "${widget.controller.chatUserList[chatIndex].members[0]
                        .firstname}",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: Styles.baseTextTheme.headline4
                        .copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors
                          .white : Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),


              ],
            )
        )
            : widget.controller.chatUserList[chatIndex].members.length == 2
            ? Expanded(
            child: Row(
              children: [
                Container(
                  width: widget.controller.chatUserList[chatIndex].members[0].firstname
                      .length > 15 ? kIsWeb ? 120 : 80 : null,
                  child: Text(
                    "${widget.controller.chatUserList[chatIndex].members[0]
                        .firstname}, ",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: Styles.baseTextTheme.headline4
                        .copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors
                          .white : Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    width: widget.controller.chatUserList[chatIndex].members[1].firstname
                        .length > 15 ? kIsWeb ? 120 : 80 : null,
                    child: Text(
                      "${widget.controller.chatUserList[chatIndex].members[1]
                          .firstname}",
                      softWrap: false,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: Styles.baseTextTheme.headline4
                          .copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors
                            .white : Colors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            )
        )
            : widget.controller.chatUserList[chatIndex].members.length == 3
            ? Expanded(
          child: Row(
            children: [
              Container(
                width: widget.controller.chatUserList[chatIndex].members[0].firstname
                    .length > 15 ? kIsWeb ? 120 : 80 : null,
                child: Text(
                  "${widget.controller.chatUserList[chatIndex].members[0]
                      .firstname}, ",
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: Styles.baseTextTheme.headline4.copyWith(
                    color: Theme
                        .of(context)
                        .brightness == Brightness.dark ? Colors
                        .white : Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  "${widget.controller.chatUserList[widget
                      .controller.chatIndex].members.length -
                      1} ${Strings.otherChat}",
                  softWrap: false,
                  overflow: TextOverflow.ellipsis,
                  style: Styles.baseTextTheme.headline4.copyWith(
                    color: Theme
                        .of(context)
                        .brightness == Brightness.dark ? Colors
                        .white : Colors.black,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        )
            : widget.controller.chatUserList[chatIndex].members.length >= 4
            ? Expanded(
            child: Row(
              children: [
                Container(
                  width: widget.controller.chatUserList[chatIndex].members[0].firstname
                      .length > 15 ? kIsWeb ? 120 : 60 : null,
                  child: Text(
                    "${widget.controller.chatUserList[chatIndex].members[0]
                        .firstname}, ",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: Styles.baseTextTheme.headline4
                        .copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors
                          .white : Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
               *//* Container(
                  width: widget.controller.chatUserList[widget
                      .controller.chatIndex].members[1].firstname
                      .length > 15 ? kIsWeb ? 120 : 60 : null,
                  child: Text(
                    "${widget.controller.chatUserList[widget
                        .controller.chatIndex].members[1]
                        .firstname}, ",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: Styles.baseTextTheme.headline4
                        .copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors
                          .white : Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),*//*
                // Text(
                //   "${controller.chatUserList[index].members[2].firstname} and ",
                //   style: Theme.of(context).brightness == Brightness.dark ?
                //   TextStyle(color: Colors.white,
                //       fontWeight: FontWeight.w600,overflow:
                //       TextOverflow.ellipsis
                //   )
                //       : TextStyle(color: Colors.black,
                //       fontWeight: FontWeight.w600,overflow:
                //       TextOverflow.ellipsis
                //   ),
                // ),
                Expanded(
                  child: Text(
                    "${widget.controller.chatUserList[widget
                        .controller.chatIndex].members.length -
                        1} ${Strings.otherChat}",
                    softWrap: false,
                    overflow: TextOverflow.ellipsis,
                    style: Styles.baseTextTheme.headline4.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors
                          .white : Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            )
        )*/
            ? Expanded(
          child: SizedBox(
            // width: widget.controller.chatUserList[chatIndex].name.length > 15 ? 120 : null,
            child: Text(
              conversationTitle,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: Styles.baseTextTheme.headline2.copyWith(
                color: Theme
                    .of(context)
                    .brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        )
            : const SizedBox(),

        widget.isRequested ? widget.controller.chatRequestUserList[chatIndex].conversationType == "single" ?
        Expanded(
          child: Container(
            width: widget.controller.chatRequestUserList[chatIndex].name.length > 15 ? 120 : null,
            child: Text(
              "${widget.controller.chatRequestUserList[chatIndex].name}",
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: Styles.baseTextTheme.headline2.copyWith(
                color: Theme
                    .of(context)
                    .brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ) : SizedBox() :
        widget.controller.chatUserList[chatIndex].conversationType == "single" ?
        Expanded(
          child: SizedBox(
            width: widget.controller.chatUserList[chatIndex].name.length > 15 ? 120 : null,
            child: Text(
              conversationTitle,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: Styles.baseTextTheme.headline2.copyWith(
                color: Theme
                    .of(context)
                    .brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ) : const SizedBox(),

        // Text(
        //   "${widget.controller.groupName != null ? widget.controller.groupName : widget.controller.chatName.name != null ? widget.controller.chatName.name : ""}",
        //   maxLines: 1,
        //   style: Theme.of(context).textTheme.bodyText1.copyWith(
        //       color: Colors.black,
        //       overflow: TextOverflow.ellipsis),
        // ),

        widget.controller.chatName == null ? Container() :
        widget.controller.chatName.accountVerified == null ? SizedBox() :
        widget.controller.chatName.accountVerified ==
            "verified"
            ? Row(
          children: [
            SizedBox(
              width: 5,
            ),
            BlueTick(
              height: 15,
              width: 15,
              iconSize: 10,
            ),
          ],
        )
            : SizedBox()
      ],
    );
  }

  Widget popUpMenuItem(IconData icon, String s, int value, Function function) {
    return PopupMenuItem(
      padding: EdgeInsets.zero,
      value: value,
      child: ListTile(
        dense: true,
        focusColor: Colors.white,
        hoverColor: Colors.white30,
        minVerticalPadding: 0,
        horizontalTitleGap: 0,
        // contentPadding: EdgeInsets.only(
        //   left: 8,
        //   right: 0,
        //   top: 0,
        //   bottom: 0,
        // ),
        leading: Icon(
          icon,
          color: Theme
              .of(context)
              .brightness == Brightness.dark
              ? Colors.white
              : Colors.black,
          size: 18,
        ),
        title: Text(
          s,
          style: TextStyle(
            color: Theme
                .of(context)
                .brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 15,
            height: 0
          ),
        ),
        onTap: function,
      ),
    );
  }

  // Widget urlFetch(NewsfeedController controller) {
  //   // if(widget.controller.scrapUrl.contains('.com')){
  //   //   return
  //   return FutureBuilder<ScrappingData>(
  //     future: controller.urlScraping(controller.scrapUrl),
  //     builder: (context, snapshot) {
  //       if (snapshot.hasData) {
  //         return cardScrap(context, snapshot.data);
  //       } else if (snapshot.hasError) {
  //         print(snapshot.error.toString());
  //         return Container();
  //       }
  //       return Container(
  //         child: Center(
  //           child: CircularProgressIndicator(),
  //         ),
  //       );
  //     },
  //   );
  //
  //   // }else{
  //   //   return Container();
  //   // }
  // }
  parseTimestamp(var timestamp) {
    if (timestamp == null || timestamp == "") return "";
    var result = "";

    var onlyDateFormat = DateFormat('d MMM y');
    var todayDate = new DateTime.now();
    var timestampTemp;
    timestampTemp = DateTime.tryParse(timestamp.toString()).toLocal();
    if (timestampTemp != null) {
      var todaysDateStr = onlyDateFormat.format(todayDate);
      var timestampStr = onlyDateFormat.format(timestampTemp);
      if (todaysDateStr == timestampStr) {
        // This is today's date
        var timeFormat = DateFormat('hh:mm a');
        result = timeFormat.format(timestampTemp).toString();
      } else {
        var dateTimeFormat = DateFormat('MMM d, y, hh:mm a');
        result = dateTimeFormat.format(timestampTemp).toString();
      }
    }
    return result.toString();
  }

  Widget msgSample(BuildContext context, MessageModel msg) {
    String dateLocal = parseTimestamp(msg.createdAt);
    bool isReply = true;

    return Container(
        child:
        Padding(
          // add some padding
          padding: EdgeInsets.only(
              left: msg.messageFiles == null
                  ? msg.messageFiles.isEmpty
                  ? 0
                  : 16
                  : 0,
              right: msg.messageFiles == null
                  ? msg.messageFiles.isEmpty
                  ? 0
                  : 16
                  : 0,
              bottom: 0),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment:
            msg.userId == widget.controller.storage.read("id")
                ? MainAxisAlignment.end
                : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              msg.userId != widget.controller.storage.read("id") ? msg == null
                  ? Container(
                  width: 24,
                  child: Center(
                    child: SpinKitCircle(
                      color: Colors.grey,
                      size: 40,
                    ),
                  ))
                  : SizedBox(
                width: 10,
              )
              // Padding(
              //   padding:
              //   const EdgeInsets.only(left: 0, bottom: 4, right: 7),
              //   child: ClipRRect(
              //     borderRadius: BorderRadius.circular(30),
              //     child: FadeInImage(
              //         fit: BoxFit.cover,
              //         width: 24,
              //         height: 24,
              //         placeholder: AssetImage(
              //             'assets/images/person_placeholder.png'),
              //         image: msg.profileImage != null
              //             ? NetworkImage(msg.profileImage)
              //             : AssetImage(
              //             "assets/images/person_placeholder.png")),
              //   ),
              // )
                  : SizedBox(
                width: 10,
              ),
              Flexible(
                child: Column(
                  crossAxisAlignment:
                  msg.userId == widget.controller.storage.read("id")
                      ? CrossAxisAlignment.end
                      : CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment:
                      msg.userId == widget.controller.storage.read("id")
                          ? MainAxisAlignment.end
                          : MainAxisAlignment.start,
                      children: [
                        // Text(
                        //   "${msg.firstname}  ",
                        //   style: Styles.baseTextTheme.headline2.copyWith(
                        //     color: Theme
                        //         .of(context)
                        //         .brightness == Brightness.dark
                        //         ? Colors.white
                        //         : Colors.black,
                        //     fontWeight: FontWeight.w500,
                        //     fontSize: 13,
                        //   ),
                        // ),
                        // Text(
                        //   dateLocal,
                        //   // "${msg.createdAt}".split(" ")[1].split(":")[0] +
                        //   //     ":" +
                        //   //     "${msg.createdAt}".split(" ")[1].split(":")[1],
                        //   style: Styles.baseTextTheme.headline2.copyWith(
                        //     // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                        //     fontWeight: FontWeight.w400,
                        //     fontSize: 12,
                        //   ),
                        // ),
                      ],
                    ),
                    SizedBox(height: 2),
                    Stack(
                      children: [
                        repliedMsgInfoWidgetWithMsg(msg),
                        Positioned(
                          bottom: msg.replyMsgModel != null ? 0 : null,
                          right: msg.replyMsgModel != null && msg.userId == widget.controller.storage.read("id") ? 0 : null,
                          left: msg.replyMsgModel != null && msg.userId != widget.controller.storage.read("id") ? 0 : null,
                          child: Container(
                            color: msg.isMessageSelected
                                ? Colors.grey[200]
                                : Colors.transparent,
                            child: Row(
                              mainAxisAlignment: msg.userId == widget.controller
                                  .storage.read("id")
                                  ? MainAxisAlignment.end
                                  : MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                msg.userId == widget.controller.storage.read("id") ? reactWidget(msg) : SizedBox(),
                                msg.userId == widget.controller.storage.read("id")
                                    ? Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(20)),
                                  ),
                                  child: PopupMenuButton(
                                    onOpened: (){
                                      FocusScope.of(context).unfocus();
                                    },
                                    splashRadius: 20.0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(20)),
                                    ),
                                    // initialValue: 1,
                                    icon: Icon(
                                      Icons.more_horiz,
                                      color: Theme
                                          .of(context)
                                          .brightness ==
                                          Brightness.dark
                                          ? Colors.white
                                          : Colors.grey[400],
                                    ),
                                    padding: EdgeInsets.zero,
                                    offset: Offset(120, 10),
                                    color: Theme
                                        .of(context)
                                        .brightness ==
                                        Brightness.dark
                                        ? Colors.black
                                        : Colors.white,
                                    // onSelected: (value) {
                                    //   print(
                                    //       'MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM');
                                    // },
                                    // child: IconButton(
                                    //   onPressed: () {},
                                    //   icon: Icon(Icons.more_vert),
                                    // ),
                                    itemBuilder: (BuildContext context) =>
                                    <PopupMenuEntry>[
                                      // popUpMenuItem(
                                      //
                                      //     Icons.edit, Strings.editChat, 1,
                                      //         () {
                                      //       print('MESSAGE BODY  ' + msg.body);
                                      //       Navigator.of(context).pop();
                                      //
                                      //       widget.controller.messageController
                                      //           .value =
                                      //           TextEditingValue(
                                      //             text: msg.body,
                                      //             selection: TextSelection
                                      //                 .fromPosition(
                                      //               TextPosition(
                                      //                   offset: msg.body.length),
                                      //             ),
                                      //           );
                                      //       widget.controller.isChatTextEmpty = false;
                                      //       widget.controller.messageId = msg.id;
                                      //       widget.controller.focusNode
                                      //           .requestFocus();
                                      //       widget.controller.update();
                                      //     }),

                                      popUpMenuItem(
                                          Icons.reply,
                                          Strings.reply,
                                          5,
                                              () {
                                            Navigator.pop(context);
                                            widget.controller.replyToMsgModel = msg;
                                            widget.controller.update();
                                          }
                                      ),

                                      popUpMenuItem(
                                          Icons.delete,
                                          Strings.messageDelete,
                                          1,
                                              () {
                                            Navigator.pop(context);
                                            widget.controller.deleteMessageForYou(msg.id);
                                          }
                                      ),

                                      popUpMenuItem(
                                          Icons.delete,
                                          Strings.deleteForEveryOne,
                                          2,
                                              () {
                                            Navigator.pop(context);
                                            print(msg.id.toString() + 'MSGID');
                                            widget.controller.deleteMsg(
                                                msg.id, false);
                                          }
                                      ),
                                      // If there no text in the message we hide the copy option. This case happens when user sends an image or file without any text
                                      msg.body != null && msg.body != ""
                                          ? popUpMenuItem(
                                          Icons.copy,
                                          Strings.copy, 3,
                                              () {
                                            Navigator.pop(context);
                                            Clipboard.setData(
                                                ClipboardData(text: msg.body));
                                          }
                                      )
                                          : PopupMenuItem(
                                        height: 0.0,
                                        padding: EdgeInsets.zero,
                                        child: Container(),
                                      ),


                                      popUpMenuItem(
                                          Icons.forward,
                                          Strings.forwardMessage,
                                          4,
                                              () {
                                            Navigator.pop(context);


                                            widget.controller.selecteMessagesId
                                                .clear();
                                            widget.controller.selectedMessages
                                                .clear();

                                            widget.controller.isMessageSelected =
                                            false;
                                            widget.controller.selecteMessagesId.add(
                                                msg.id);


                                            print("sdfsdf");

                                            if (msg.messageFiles.isNotEmpty) {
                                              widget.controller.uploadMedia_ = {

                                                "name": msg.messageFiles[0]["name"]
                                                    .toString(),
                                                "path": msg.messageFiles[0]["url"]
                                                    .toString(),
                                                "thumbnail_url": msg
                                                    .messageFiles[0]["thumbnail_url"]
                                                    .toString(),
                                                "size": msg.messageFiles[0]["size"]
                                                    .toString(),


                                              };

                                              print(
                                                  "  widget.controller.uploadMedia ${ widget
                                                      .controller.uploadMedia_}");

                                              widget.controller.update();
                                            }
                                            else {
                                              widget.controller.uploadMedia_ = null;
                                              widget.controller.update();
                                            }


                                            if (msg.link != null) {
                                              print("sd ${msg.linkTitle}");

                                              widget.controller.chatScrappingData =
                                                  ChatScrappingData();
                                              widget.controller.chatScrappingData
                                                  .title = msg.linkTitle;
                                              widget.controller.chatScrappingData
                                                  .link = msg.link;
                                              widget.controller.chatScrappingData
                                                  .images = [msg.linkImage];
                                              widget.controller.chatScrappingData
                                                  .meta = msg.linkMeta;
                                              widget.controller.update();
                                            }
                                            else {
                                              widget.controller.chatScrappingData =
                                              null;
                                              widget.controller.update();
                                            }


                                            widget.controller.selectedMessages.add(
                                                msg);
                                            for (int i = 0; i <
                                                widget.controller.messages
                                                    .length; i++) {
                                              widget.controller.messages[i]
                                                  .isMessageSelected = false;


                                              // print("  widget.controller.uploadMedia ${ msg.messageFiles[0]["name"]}");


                                              widget.controller.update();
                                            }
                                            showDialog(
                                              context: context,
                                              builder: (BuildContext context) {
                                                return AlertDialog(
                                                  contentPadding: EdgeInsets.zero,
                                                  insetPadding: EdgeInsets.zero,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(20),
                                                  ),
                                                  content: ForwardMessageDialogBox(),
                                                );
                                              },
                                            );
                                          }),
                                    ],
                                  ),
                                )
                                    : SizedBox(),
                                Column(
                                  crossAxisAlignment: msg.userId == widget.controller
                                      .storage.read("id")
                                      ? CrossAxisAlignment.end
                                      : CrossAxisAlignment.start,
                                  children: [
                                    msg.link != null ?
                                    Padding(
                                      padding: const EdgeInsets.only(bottom: 4.0),
                                      child: cardScrap(context: context,
                                          link: msg.link,
                                          title: msg.linkTitle,
                                          images: msg.linkImage,
                                          meta: msg.linkMeta),
                                    ) : Container(),

                                    chatBubble(msg),
                                    // translateChatWidget(msg),
                                  ],
                                ),
                                msg.userId != widget.controller.storage.read("id")
                                    ? Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(20)),
                                  ),
                                  child: PopupMenuButton(
                                    onOpened: (){
                                      FocusScope.of(context).unfocus();
                                    },
                                    splashRadius: 20.0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(20)),
                                    ),
                                    icon: Icon(
                                      Icons.more_horiz,
                                      color: Theme
                                          .of(context)
                                          .brightness ==
                                          Brightness.dark
                                          ? Colors.white
                                          : Colors.grey[400],
                                    ),
                                    padding: EdgeInsets.zero,
                                    offset: Offset(190, 5),
                                    itemBuilder: (BuildContext context) =>
                                    <PopupMenuEntry>[
                                      // popUpMenuItem(Icons.delete, Strings.delete, 2,
                                      //         () {
                                      //       Navigator.of(context).pop();
                                      //       print(msg.id.toString() + 'MSGID');
                                      //       widget.controller.deleteMsg(msg.id, false);
                                      //     }),
                                      // If there no text in the message we hide the copy option. This case happens when user sends an image or file without any text

                                      popUpMenuItem(
                                          Icons.reply,
                                          Strings.reply,
                                          1,
                                              () {
                                            Navigator.pop(context);
                                            widget.controller.replyToMsgModel = msg;
                                            widget.controller.update();
                                          }
                                      ),
                                popUpMenuItem(
                                    Icons.flag_outlined,
                                    Strings.report,
                                    1,
                                        () async{
                                      Navigator.pop(context);
                                      Post post = Post(userInfo: UserProfile(firstname: msg.firstname,));
                                      // Navigator.of(context).pop();
                                      // widget.controller.update();
                                      String userID = widget.controller.chatName.memberId.toString();

                                      await ReportUserAndWerfDialog().showReportUserDialog(context,post, () async{
                                        widget.controller.isDeletingConversation = true;
                                        bool isSuccess = await widget.controller.blockUserFromChat(userID);
                                        if (isSuccess){
                                        await ChatUtils.deleteConversation(widget.controller);
                                        debugPrint("user blocked chat_screen_mobile");
                                        }
                                        widget.controller.isDeletingConversation = false;
                                      },(){
                                      }, ReportType.message, msg.id);
                                      widget.controller.deleteMessageForYou(msg.id);

                                      widget.controller.update();

                                    }
                                ),
                                popUpMenuItem(
                                    Icons.delete,
                                    Strings.messageDelete,
                                    2,
                                        () {
                                      Navigator.pop(context);
                                      widget.controller.deleteMessageForYou(msg.id);
                                    }
                                ),
                                msg.body != null && msg.body != "" ?
                                popUpMenuItem(Icons.copy, Strings.copy, 3, () {
                                  Navigator.pop(context);
                                  Clipboard.setData(
                                      ClipboardData(text: msg.body));
                                }) : PopupMenuItem(
                                  height: 0.0,
                                  padding: EdgeInsets.zero,
                                  child: Container(),),

                                      popUpMenuItem(
                                        Icons.forward,
                                        Strings.forward,
                                        4,
                                            () {
                                          Navigator.pop(context);
                                          widget.controller.selecteMessagesId.clear();
                                          widget.controller.selectedMessages.clear();

                                          print("sdfsdf");

                                          if (msg.messageFiles.isNotEmpty) {
                                            widget.controller.uploadMedia_ = {

                                              "name": msg.messageFiles[0]["name"]
                                                  .toString(),
                                              "path": msg.messageFiles[0]["url"]
                                                  .toString(),
                                              "thumbnail_url": msg
                                                  .messageFiles[0]["thumbnail_url"]
                                                  .toString(),
                                              "size": msg.messageFiles[0]["size"]
                                                  .toString(),


                                            };

                                            print(
                                                "  widget.controller.uploadMedia ${ widget
                                                    .controller.uploadMedia_}");

                                            widget.controller.update();
                                          }
                                          else {
                                            widget.controller.uploadMedia_ = null;
                                            widget.controller.update();
                                          }

                                          if (msg.link != null) {
                                            widget.controller.chatScrappingData =
                                                ChatScrappingData();
                                            widget.controller.chatScrappingData
                                                .title = msg.linkTitle;
                                            widget.controller.chatScrappingData.link =
                                                msg.link;
                                            widget.controller.chatScrappingData
                                                .images = [msg.linkImage];
                                            widget.controller.chatScrappingData
                                                .meta = msg.linkMeta;
                                            widget.controller.update();
                                          }
                                          else {
                                            widget.controller.chatScrappingData =
                                            null;
                                            widget.controller.update();
                                          }


                                          widget.controller.isMessageSelected = false;
                                          widget.controller.selecteMessagesId
                                              .add(msg.id);


                                          widget.controller.selectedMessages.add(msg);
                                          for (int i = 0; i <
                                              widget.controller.messages
                                                  .length; i++) {
                                            widget.controller.messages[i]
                                                .isMessageSelected = false;
                                            widget.controller.update();
                                          }
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                contentPadding: EdgeInsets.zero,
                                                insetPadding: EdgeInsets.zero,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                  BorderRadius.circular(20),
                                                ),
                                                content: ForwardMessageDialogBox(),
                                              );
                                            },
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                )
                                    : SizedBox(),
                                msg.userId != widget.controller.storage.read("id") ? reactWidget(msg) : SizedBox(),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    msg.reactionInfo != null && msg.reactionInfo.isNotEmpty ? likedReactions(msg) : Container(),
                    msg.userId == widget.controller.storage.read("id")
                        ? Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          dateLocal + " . ",
                          // "${msg.createdAt}".split(" ")[1].split(":")[0] +
                          //     ":" +
                          //     "${msg.createdAt}".split(" ")[1].split(":")[1],
                          style: Styles.baseTextTheme.headline2.copyWith(
                            // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                            fontWeight: FontWeight.w400,
                            fontSize: 12,
                          ),
                        ),
                        Container(
                          child: Image.asset(
                              !msg.deliverByAll
                                  ? 'assets/chaticons/single_tick.png'
                                  : 'assets/chaticons/double_tick.png',
                              fit: BoxFit.fill,
                              height: 15,
                              width: 15,
                              color: msg.deliverByAll && msg.seenByAll
                                  ? MyColors.blue
                                  : MyColors.blue),
                        ),
                        // Icon(
                        // !msg.deliverByAll
                        //     ? Icons.check
                        //     : FontAwesomeIcons.checkDouble,
                        // color: msg.deliverByAll && msg.seenByAll
                        //     ? MyColors.blue
                        //     : widget.controller.displayColor,
                        // size: 12),
                      ],
                    )
                        : Container(
                      child: Text(
                        dateLocal,
                        // "${msg.createdAt}".split(" ")[1].split(":")[0] +
                        //     ":" +
                        //     "${msg.createdAt}".split(" ")[1].split(":")[1],
                        style: Styles.baseTextTheme.headline2.copyWith(
                          // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    SizedBox(height: 5),
                  ],
                ),
              ),
              // msg.userId == widget.controller.storage.read("id")
              //     ?
              // // controller.messages[index].userId !=
              // //     controller.storage.read("id")
              // //     ?
              // widget.controller.userProfile == null
              //     ? Container(
              //     width: 24,
              //     child: Center(
              //       child: SpinKitCircle(
              //         color: Colors.grey,
              //         size: 40,
              //       ),
              //     ))
              //     : Padding(
              //   padding: const EdgeInsets.only(bottom: 15, left: 7),
              //   child: ClipRRect(
              //     borderRadius: BorderRadius.circular(30),
              //     child: FadeInImage(
              //       fit: BoxFit.cover,
              //       width: 24,
              //       height: 24,
              //       placeholder: AssetImage(
              //           'assets/images/person_placeholder.png'),
              //       image: widget.controller.userProfile.profileImage !=
              //           null
              //           ? NetworkImage(
              //           widget.controller.userProfile.profileImage)
              //           : AssetImage(
              //           'assets/images/person_placeholder.png'),
              //       // NetworkImage(
              //       //     controller.userProfile.profileImage != null
              //       //         ? controller.userProfile.profileImage
              //       //         : "assets/images/person_placeholder.png")
              //     ),
              //   ),
              // )
              //     : SizedBox(
              //   width: 10,
              // ),
            ],
          ),
        )

    );
  }

  Widget chatBubble(MessageModel msg){
    return GestureDetector(
      onLongPress: () {
        msg.isMessageSelected = true;
        widget.controller.isMessageSelected = true;
        widget.controller.selecteMessagesId.add(msg.id);
        widget.controller.selectedMessages.add(msg);
        widget.controller.update();
      },
      child: DecoratedBox(
        // chat bubble decoration

        decoration: BoxDecoration(
          color: msg.messageFiles.isNotEmpty ||
              msg.post != null ? Colors.transparent
              : msg.userId ==
              widget.controller.storage.read("id")
              ? widget.controller.displayColor
              : Colors.grey[200],
          // color:  Colors.red,
          // color: msg.messageFiles.isNotEmpty ? Colors.grey[200] : msg.userId == widget.controller.storage.read("id") ? msg.link!=null ?  Colors.transparent : widget.controller.displayColor : msg.link!=null ? Colors.transparent : Colors.grey[200],
          // color: msg.messageFiles.isNotEmpty ? Colors.grey[200] : msg.userId == widget.controller.storage.read("id") ? widget.controller.displayColor : Colors.grey[200],
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(msg.userId ==
                widget.controller.storage.read("id")
                ? 20
                : 3),
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
            bottomRight: Radius.circular(msg.userId ==
                widget.controller.storage.read("id")
                ? 3
                : 20),
          ),
        ),
        child: Padding(
          padding: EdgeInsets.only(
            left: msg.userId ==
                widget.controller.storage.read("id")
                ? 15
                : 15,
            right: msg.userId ==
                widget.controller.storage.read("id")
                ? 15
                : 15,
            top: msg.body.length < 10 ? 8 : 8,
            bottom: msg.body.length < 10 ? 8 : 8,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              msg.post != null && msg.postTypes == "post"
                  ?
              postTypeWidget(msg)
                  :
              msg.messageFiles.isEmpty
                  ? SizedBox()
                  : msg.messageFiles[0]['url'] != null
                  ? msg.messageFiles[0]['post_type'] ==
                  'image' ||
                  msg.messageFiles[0]['post_type'] ==
                      'post'
                  ? InkWell(
                onTap: () {
                  print("sdfsdf");
                  print(
                      "${msg.messageFiles[0]['url']
                          .toString()}");
                  showDialog(
                    barrierDismissible: false,
                    context: context,
                    builder:
                        (BuildContext context) {
                      /// bug
                      return NewsFeedCarousel(
                        chatCheck: 1,

                        imagesListForCarousel: [
                          msg.messageFiles[0]
                          ['url']
                              .toString()
                        ],
                        mediaIndex: 0,
                      );
                    },
                  );
                },
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: kIsWeb ?
                    MediaQuery
                        .of(context)
                        .size
                        .width >= 680
                        ? 408
                        : MediaQuery
                        .of(context)
                        .size
                        .width >= 530 ? 308 : 280
                        : 180,
                    maxHeight: kIsWeb ? 550 : 400,
                    minHeight: kIsWeb ? 250 : 200,
                    minWidth: kIsWeb ? MediaQuery
                        .of(context)
                        .size
                        .width >= 530
                        ? 308
                        : 260
                        : 100,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(
                        Radius.circular(20)),
                    child: Image.network(
                      msg.messageFiles[0]['url']
                          .toString(),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              )
                  : msg.messageFiles[0]['post_type'] ==
                  'video'
                  ? Container(
                height: 230,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(
                      Radius.circular(20)),
                ),
                child: ChewieVideoPlayer(
                  thumbnailUrl: msg
                      .messageFiles[0]['thumbnail_url'],
                  videoUrl: msg.messageFiles[0]['url'],
                  isFullScreenOnMobile:
                  kIsWeb ? false : true,
                  fromChat: true,
                  newsfeedController: widget.controller,
                ),
              )
                  : msg.messageFiles[0]['post_type'] ==
                  'attachment'
                  ? Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 200,
                  decoration:
                  BoxDecoration(
                    borderRadius:
                    BorderRadius
                        .circular(30),
                    color:
                    Colors.grey[100],
                  ),
                  child: Padding(
                    padding:
                    const EdgeInsets
                        .all(5.0),
                    child: InkWell(
                      onTap: () {
                        launch(
                            msg.messageFiles[0]['url']);
                      },
                      child: Row(
                        children: [
                          SizedBox(
                            height: 28,
                            width: 28,
                            child: Image
                                .asset(
                                'assets/images/document.png'),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment
                                .start,
                            children: [
                              msg
                                  .messageFiles[0]['name'] !=
                                  null ? Container(
                                width: 150,
                                child: Text(
                                  msg
                                      .messageFiles[0]['name'],
                                  overflow:
                                  TextOverflow.ellipsis,
                                  style: Styles
                                      .baseTextTheme
                                      .headline2.copyWith(
                                    color: Colors.black,
                                    fontSize: 15,
                                  ),
                                ),
                              ) : Text(""),

                              msg
                                  .messageFiles[0]['size'] !=
                                  null ? Text(

                                "Size:${msg
                                    .messageFiles[0]['size']}",
                                maxLines: 2,
                                overflow: TextOverflow
                                    .ellipsis,
                                style: Styles
                                    .baseTextTheme
                                    .headline2.copyWith(
                                  color: Colors.black,
                                  fontSize: 15,
                                ),
                              ) : Text(""),
                            ],
                          )


                        ],
                      ),
                    ),
                  ),
                ),
              )
              // ListTile(
              //   onTap: () {
              //     launch(controller
              //         .messages[
              //     index]
              //         .messageFiles[0]['url']);
              //   },
              //   shape: RoundedRectangleBorder(
              //       borderRadius:
              //       BorderRadius.circular(10)),
              //   tileColor:
              //   Colors.grey[
              //   100],
              //   leading:
              //   SizedBox(
              //     height:
              //     28,
              //     width: 28,
              //     child: Image
              //         .asset(
              //         'assets/images/document.png'),
              //   ),
              //   title: Text(controller
              //       .messages[
              //   index]
              //       .messageFiles[0]['url']),
              // )
                  : Container()
                  : Container(),

              // msg.link != null ?
              //
              // cardScrap(context: context,
              //     link: msg.link,
              //     title: msg.linkTitle,
              //     images: msg.linkImage) : Container(),

              msg.body != null ?
              // widget.controller.urlOrNot(msg.body.toString()) ?
              // urlFetch(widget.controller) :

              ChatContainer(
                msg: msg,
                controller: widget.controller,
                isFromMessagePopup: widget.isFromMessagePopup,
              )

                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  Widget translateChatWidget(MessageModel msg) {
    return Text("");
    var controller = widget.controller;
    var post;
    bool containHashTag;
    return
      //   controller.languageData != null &&
      // controller.languageData.myLang.id != post.languageId ?
      GestureDetector(
        onTap: () async {
          post.translationLoadere.value = true;
          bool success = false;
          post.translationData = await controller.newsFeedTranslation(post.postId, controller.languageData.myLang.code);


          if (post.translationData != null) {
            post.translationLoadere.value = false;

            if (post.translation.value == false) {
              post.translation.value = true;
              controller.update(['translate']);
            } else if (post.translation.value == true) {
              post.translation.value = false;
              controller.update(['translate']);
            }
          }
          else {
            post.translationLoadere.value = false;
            controller.update();
          }
        },

        child: post.translation.value == true
            ? Padding(
          padding: EdgeInsets.only(bottom: 10),
          child: Text("View Original",
              style: TextStyle(
                  decoration: TextDecoration.underline,
                  color: controller.displayColor
              )
          ),
        )
            : Padding(
          padding: EdgeInsets.only(bottom: 10, top: 5),
          child: containHashTag ? SizedBox() : Text(
              controller.languageData.appLang.id == 2
                  ? "عرض الترجمة" : Strings.viewTranslated,

              style: TextStyle(
                  decoration: TextDecoration.underline,
                  color: controller.displayColor
              )
          ),
        ),
      );
    // : SizedBox();
  }

  Widget replyPreviewWidgetAtBottom(){
    MessageModel msgModel = widget.controller.replyToMsgModel;
    return msgModel == null ? const SizedBox() : Container(
      height: 50,
      width: double.infinity,
      color: Colors.grey.shade200,
      // decoration: BoxDecoration(
      //     color: Colors.grey.shade200,
      //     borderRadius: BorderRadius.circular(4)),
      child: Row(children: [
        Container(width: 5, height: double.infinity, color: Colors.blueGrey.shade700,),
        const SizedBox(width: 10,),
        Expanded(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children:[
            Text(msgModel.firstname, style: TextStyle(fontSize: 13, color: Colors.black, fontWeight: FontWeight.w500)),
            Text(msgModel.body, softWrap: false, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12)),
          ]),
        ),
        IconButton(onPressed: (){
          widget.controller.replyToMsgModel = null;
          widget.controller.update();
        }, icon: const Icon(Icons.close, size: 20,)),
      ],)
    );
  }

  repliedMsgInfoWidgetWithMsg(msg){
    MessageModel replyMessageModel = msg.replyMsgModel;
    Color textColor = Theme.of(context).brightness == Brightness.dark
        ? Colors.white
        : Colors.grey[800];
    return  replyMessageModel == null || replyMessageModel.body == null ? const SizedBox()
        : Column(
      crossAxisAlignment: msg.userId == widget.controller.storage.read("id") ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Row(
                mainAxisAlignment: msg.userId == widget.controller.storage.read("id") ? MainAxisAlignment.end : MainAxisAlignment.start,
                children:[
              Icon(Icons.reply, size: 13, color: textColor),
              Text("  Replying to  ", style: TextStyle(fontSize: 11, color: textColor)),
            ]),
            const SizedBox(height: 4.0),
            // Image, Videos and Attachement
            replyMessageModel.post != null && replyMessageModel.postTypes == "post" ? postTypeWidget(replyMessageModel)
                : replyMessageModel.messageFiles.isEmpty ? const SizedBox() : replyMessageModel.messageFiles[0]['url'] != null
                ? replyMessageModel.messageFiles[0]['post_type'] == 'image' || replyMessageModel.messageFiles[0]['post_type'] == 'post'
                ? InkWell(
              onTap: () {
                showDialog(
                  barrierDismissible: false,
                  context: context,
                  builder: (BuildContext context) {
                    return NewsFeedCarousel(
                      chatCheck: 1,
                      imagesListForCarousel: [
                        replyMessageModel.messageFiles[0]['url'].toString()
                      ],
                      mediaIndex: 0,
                    );
                  },
                );
              },
              child: ConstrainedBox(
                constraints: const BoxConstraints(
                  maxWidth: 70,
                  maxHeight: 70,
                  minHeight: 70,
                  minWidth: 70,
                  // maxWidth: kIsWeb ? MediaQuery.of(context).size.width >= 680 ? 408 : MediaQuery.of(context).size.width >= 530 ? 308 : 280 : 180,
                  // maxHeight: kIsWeb ? 550 : 400,
                  // minHeight: kIsWeb ? 250 : 200,
                  // minWidth: kIsWeb ? MediaQuery.of(context).size.width >= 530 ? 308 : 260 : 100,
                ),
                child: ClipRRect(
                  borderRadius: const BorderRadius.all(Radius.circular(5)),
                  child: Image.network(
                    replyMessageModel.messageFiles[0]['url'].toString(),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            )
                : replyMessageModel.messageFiles[0]['post_type'] == 'video'
                ? Container(
                  height: 150,
                  decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(20)),),
                  child: ChewieVideoPlayer(
                  thumbnailUrl: replyMessageModel.messageFiles[0]['thumbnail_url'],
                  videoUrl: replyMessageModel.messageFiles[0]['url'],
                  isFullScreenOnMobile:
                  kIsWeb ? false : true,
                  fromChat: true,
                  newsfeedController: widget.controller,
              ),
            )
                : replyMessageModel.messageFiles[0]['post_type'] == 'attachment'
                ? Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 200,
                decoration: BoxDecoration(
                  borderRadius:
                  BorderRadius
                      .circular(30),
                  color:
                  Colors.grey[100],
                ),
                child: Padding(
                  padding:
                  const EdgeInsets.all(5.0),
                  child: InkWell(
                    onTap: () {
                      launch(replyMessageModel.messageFiles[0]['url']);
                    },
                    child: Row(
                      children: [
                        SizedBox(
                          height: 28,
                          width: 28,
                          child: Image
                              .asset(
                              'assets/images/document.png'),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment
                              .start,
                          children: [
                            replyMessageModel.messageFiles[0]['name'] != null ? Container(
                              width: 150,
                              child: Text(
                                replyMessageModel.messageFiles[0]['name'],
                                overflow: TextOverflow.ellipsis,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  color: Colors.black,
                                  fontSize: 15,
                                ),
                              ),
                            ) : Text(""),

                            replyMessageModel.messageFiles[0]['size'] != null ? Text(
                              "Size:${replyMessageModel.messageFiles[0]['size']}",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Colors.black,
                                fontSize: 15,
                              ),
                            ) : Text(""),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            )
                : Container()
                : Container(),
            // Chat Bubble
            Row(
              mainAxisAlignment: msg.userId == widget.controller.storage.read("id") ? MainAxisAlignment.end : MainAxisAlignment.start,
              children: [
                replyMessageModel.body.isEmpty? const SizedBox(height: 50) : Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                    margin: const EdgeInsets.only(bottom: 40, right: 0),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.grey[100],
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(20), //Radius.circular(msg.userId == widget.controller.storage.read("id") ? 20 : 3),
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                        bottomRight: Radius.circular(20), //Radius.circular(msg.userId == widget.controller.storage.read("id") ? 3 : 20),
                      ),
                    ),
                    child: Text(replyMessageModel.body, maxLines: 2, softWrap: true, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, color: textColor)),),
                ),
              ],
            ),
          ],
        );
  }

  Widget reactWidget(MessageModel msg){

    return Container(
      width: 30.0,
      child: PopupMenuButton(
        onOpened: (){
          FocusScope.of(context).unfocus();
        },
        tooltip: Strings.react,
        constraints: const BoxConstraints(
          // minWidth: 2.0 * 56.0,
          maxWidth: 8.0 * 56.0,
        ),
        splashRadius: 20.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
              Radius.circular(20)),
        ),
        initialValue: 1,
        icon: Icon(
          Icons.favorite_border_outlined,
          size: 15.0,
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white : Colors.grey[400],
        ),
        padding: EdgeInsets.zero,
        // offset: Offset(120, 10),
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.black : Colors.white,
        itemBuilder: (BuildContext context) =>
        <PopupMenuEntry>[

          PopupMenuItem(
            enabled: false,
            padding: EdgeInsets.zero,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(width: 2.0),
                IconButton(
                  splashRadius: 20.0,
                  icon: Image.asset(
                    AppImages.like,
                    height: 30.0,
                    width: 30.0,
                  ),
                  onPressed: () {
                    widget.controller.chatReactionsEmit(reactionType: "like", messageId: msg.id, conversationId: msg.conversationId);
                    Navigator.pop(context);
                  },
                ),
                IconButton(
                  splashRadius: 20.0,
                  icon: Image.asset(
                    AppImages.love,
                    height: 30.0,
                    width: 30.0,
                  ),
                  onPressed: () {
                    widget.controller.chatReactionsEmit(reactionType: "love", messageId: msg.id, conversationId: msg.conversationId);
                    Navigator.pop(context);
                  },
                ),
                IconButton(
                  splashRadius: 20.0,
                  icon: Image.asset(
                    AppImages.lough,
                    height: 30.0,
                    width: 30.0,
                  ),
                  onPressed: () {
                    widget.controller.chatReactionsEmit(reactionType: "laugh", messageId: msg.id, conversationId: msg.conversationId);
                    Navigator.pop(context);
                  },
                ),
                IconButton(
                  splashRadius: 20.0,
                  icon: Image.asset(
                    AppImages.excited,
                    height: 30.0,
                    width: 30.0,
                  ),
                  onPressed: () {
                    widget.controller.chatReactionsEmit(reactionType: "celebrate", messageId: msg.id, conversationId: msg.conversationId);
                    Navigator.pop(context);
                  },
                ),
                IconButton(
                  splashRadius: 20.0,
                  icon: Image.asset(
                    AppImages.thanks,
                    height: 30.0,
                    width: 30.0,
                  ),
                  onPressed: () {
                    widget.controller.chatReactionsEmit(reactionType: "thanks", messageId: msg.id, conversationId: msg.conversationId);
                    Navigator.pop(context);
                  },
                ),
                IconButton(
                  splashRadius: 20.0,
                  icon: Image.asset(
                    AppImages.cry,
                    height: 30.0,
                    width: 30.0,
                  ),
                  onPressed: () {
                    widget.controller.chatReactionsEmit(reactionType: "cry", messageId: msg.id, conversationId: msg.conversationId);
                    Navigator.pop(context);
                  },
                ),
                IconButton(
                  splashRadius: 20.0,
                  icon: Image.asset(
                    AppImages.smile,
                    height: 30.0,
                    width: 30.0,
                  ),
                  onPressed: () {
                    widget.controller.chatReactionsEmit(reactionType: "smile", messageId: msg.id, conversationId: msg.conversationId);
                    Navigator.pop(context);
                  },
                ),
                SizedBox(width: 2.0),
              ],),
          )
        ],
      ),
    );
  }

  Widget likedReactions(MessageModel msg){
    bool showLike = false, showLove = false, showLaugh = false, showCelebrate = false, showThanks = false, showCry = false, showSmile = false;
    var like, love, laugh, celebrate, thanks, cry, smile;
    if (msg.reactionInfo != null && msg.reactionInfo.isNotEmpty){
      like = msg.reactionInfo.where((element) => element.reactionType == "like");
      love = msg.reactionInfo.where((element) => element.reactionType == "love");
      laugh = msg.reactionInfo.where((element) => element.reactionType == "laugh");
      celebrate = msg.reactionInfo.where((element) => element.reactionType == "celebrate");
      thanks = msg.reactionInfo.where((element) => element.reactionType == "thanks");
      cry = msg.reactionInfo.where((element) => element.reactionType == "cry");
      smile = msg.reactionInfo.where((element) => element.reactionType == "smile");
      if (like.isNotEmpty) showLike = true;
      if (love.isNotEmpty) showLove = true;
      if (laugh.isNotEmpty) showLaugh = true;
      if (celebrate.isNotEmpty) showCelebrate = true;
      if (thanks.isNotEmpty) showThanks = true;
      if (cry.isNotEmpty) showCry = true;
      if (smile.isNotEmpty) showSmile = true;
    }

    return GestureDetector(
      onTapDown: (details) => showReactedUsers(details, msg),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 3.0),
        child: Row(
          mainAxisAlignment: msg.userId == widget.controller.storage.read("id")
              ? MainAxisAlignment.end
              : MainAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(width: 2.0),
                showLike ? Row(
                  children: [
                    Image.asset(
                      AppImages.like,
                      height: 20.0,
                      width: 20.0,
                    ),
                    like.length > 1 ? Padding(
                      padding: const EdgeInsets.only(left:4.0),
                      child: Text(like.length.toString(),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),),
                    ) : SizedBox(),
                    SizedBox(width: 5.0),
                  ],
                ) : SizedBox(),
                showLove ? Row(
                  children: [
                    Image.asset(
                      AppImages.love,
                      height: 20.0,
                      width: 20.0,
                    ),
                    love.length > 1 ? Padding(
                      padding: const EdgeInsets.only(left:4.0),
                      child: Text(love.length.toString(),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),),
                    ) : SizedBox(),
                    SizedBox(width: 5.0),
                  ],
                ) : SizedBox(),
                showLaugh ? Row(
                  children: [
                    Image.asset(
                      AppImages.lough,
                      height: 20.0,
                      width: 20.0,
                    ),
                    laugh.length > 1 ? Padding(
                      padding: const EdgeInsets.only(left:4.0),
                      child: Text(laugh.length.toString(),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),),
                    ) : SizedBox(),
                    SizedBox(width: 5.0),
                  ],
                ) : SizedBox(),
                showCelebrate ? Row(
                  children: [
                    Image.asset(
                      AppImages.excited,
                      height: 20.0,
                      width: 20.0,
                    ),
                    celebrate.length > 1 ? Padding(
                      padding: const EdgeInsets.only(left:4.0),
                      child: Text(celebrate.length.toString(),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),),
                    ) : SizedBox(),
                    SizedBox(width: 5.0),
                  ],
                ) : SizedBox(),
                showThanks ? Row(
                  children: [
                    Image.asset(
                      AppImages.thanks,
                      height: 20.0,
                      width: 20.0,
                    ),
                    thanks.length > 1 ? Padding(
                      padding: const EdgeInsets.only(left:4.0),
                      child: Text(thanks.length.toString(),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),),
                    ) : SizedBox(),
                    SizedBox(width: 5.0),
                  ],
                ) : SizedBox(),
                showCry ? Row(
                  children: [
                    Image.asset(
                      AppImages.cry,
                      height: 20.0,
                      width: 20.0,
                    ),
                    cry.length > 1 ? Padding(
                      padding: const EdgeInsets.only(left:4.0),
                      child: Text(cry.length.toString(),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),),
                    ) : SizedBox(),
                    SizedBox(width: 5.0),
                  ],
                ) : SizedBox(),
                showSmile ? Row(
                  children: [
                    Image.asset(
                      AppImages.smile,
                      height: 20.0,
                      width: 20.0,
                    ),
                    smile.length > 1 ? Padding(
                      padding: const EdgeInsets.only(left:4.0),
                      child: Text(smile.length.toString(),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),),
                    ) : SizedBox(),
                    SizedBox(width: 5.0),
                  ],
                ) : SizedBox(),
                SizedBox(width: 2.0),
              ],
            ),

          ],),
      ),
    );
  }

  void showReactedUsers(TapDownDetails details, MessageModel msg)  {
    if (kIsWeb){
      showMenu(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
              Radius.circular(20)),
        ),
        context: context,
        position: RelativeRect.fromLTRB(
          details.globalPosition.dx,
          details.globalPosition.dy,
          details.globalPosition.dx,
          details.globalPosition.dy,
        ),
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.black : Colors.white,
        items: List.generate(
          msg.reactionInfo.length,
              (index) =>
              PopupMenuItem(
                padding: EdgeInsets.zero,
                value: 1,
                child: InkWell(
                  onTap: kIsWeb ? () {
                    if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                      Get.find<NewsfeedController>().userInfo = UserProfile();
                      Get.find<NewsfeedController>().update();
                      _clickWho(msg.reactionInfo[index]);
                      Get.toNamed(FluroRouters.mainScreen + "/profile/" + widget.controller.otherUserId.toString());
                    }
                  }
                      : () async {
                    if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                      _clickWho(msg.reactionInfo[index]);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (
                                  BuildContext context) =>
                                  OtherUsersProfile(
                                      controller: widget
                                          .controller)));
                    }
                  },
                  child: Row(
                    children: [
                      const SizedBox(width:20.0),
                      SizedBox(
                        width: 80.0,
                        child: Row(
                          children: [
                            msg.reactionInfo[index].reactionType == "like" ? Image.asset(
                              AppImages.like,
                              height: 30.0,
                              width: 30.0,
                            ) : SizedBox(),
                            msg.reactionInfo[index].reactionType == "love" ? Image.asset(
                              AppImages.love,
                              height: 30.0,
                              width: 30.0,
                            ) : SizedBox(),

                            msg.reactionInfo[index].reactionType == "laugh" ? Image.asset(
                              AppImages.lough,
                              height: 30.0,
                              width: 30.0,
                            ) : SizedBox(),
                            msg.reactionInfo[index].reactionType == "celebrate" ? Image.asset(
                              AppImages.excited,
                              height: 30.0,
                              width: 30.0,
                            ) : SizedBox(),
                            msg.reactionInfo[index].reactionType == "thanks" ? Image.asset(
                              AppImages.thanks,
                              height: 30.0,
                              width: 30.0,
                            ) : SizedBox(),
                            msg.reactionInfo[index].reactionType == "cry" ? Image.asset(
                              AppImages.cry,
                              height: 30.0,
                              width: 30.0,
                            ) : SizedBox(),
                            msg.reactionInfo[index].reactionType == "smile" ? Image.asset(
                              AppImages.smile,
                              height: 30.0,
                              width: 30.0,
                            ) : SizedBox(),
                            SizedBox(width: 10.0),
                            CircleAvatar(
                              backgroundImage:
                              msg.reactionInfo[index].profileImage !=
                                  null && msg.reactionInfo[index].profileImage != "null" ?
                              NetworkImage(msg.reactionInfo[index].profileImage
                                // 'assets/images/person_placeholder.png'

                              ) : AssetImage(
                                  'assets/images/person_placeholder.png'),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width:10.0),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "${msg.reactionInfo[index].firstname} ${msg.reactionInfo[index].lastname}",
                              overflow: TextOverflow.ellipsis,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),),
                            msg.reactionInfo[index].username ==null ||msg.reactionInfo[index].username =="" ||msg.reactionInfo[index].username =="null"?
                            Text("",
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                  fontSize: kIsWeb ? 14 : 12,
                                  fontWeight: FontWeight.w400,
                                )):
                            Text(
                              "${msg.reactionInfo[index].username}",
                              overflow: TextOverflow.ellipsis,
                              style: Styles.baseTextTheme.headline2
                                  .copyWith(
                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                fontSize: kIsWeb ? 14 : 12,
                                fontWeight: FontWeight.w400,
                              ),),
                          ],),
                      ),
                      const SizedBox(width:10.0),
                      msg.reactionInfo[index].id.toString() ==
                          widget.controller.storage.read('id').toString()
                          ? InkWell(
                          onTap: (){
                            print("trailing");
                            widget.controller.chatReactionsEmit(reactionType: "dislike", messageId: msg.id, conversationId: msg.conversationId);
                            Navigator.pop(context);
                          },
                          child: Text(Strings.undo, style: TextStyle(color: Colors.blue))) : SizedBox(),
                      const SizedBox(width:20.0),
                      // ListTile(
                      //   trailing: msg.reactionInfo[index].id.toString() ==
                      //           widget.controller.storage.read('id').toString()
                      //       ? InkWell(
                      //       onTap: (){
                      //         print("trailing");
                      //         widget.controller.chatReactionsEmit(reactionType: "dislike", messageId: msg.id, conversationId: msg.conversationId);
                      //       },
                      //       child: Text("Undo", style: TextStyle(color: Colors.blue))) : SizedBox(),
                      //   leading: SizedBox(
                      //     width: 85.0,
                      //     child: Row(
                      //       children: [
                      //         msg.reactionInfo[index].reactionType == "like" ? Image.asset(
                      //           AppImages.like,
                      //           height: 30.0,
                      //           width: 30.0,
                      //         ) : SizedBox(),
                      //         msg.reactionInfo[index].reactionType == "love" ? Image.asset(
                      //           AppImages.love,
                      //           height: 30.0,
                      //           width: 30.0,
                      //         ) : SizedBox(),
                      //
                      //         msg.reactionInfo[index].reactionType == "laugh" ? Image.asset(
                      //           AppImages.lough,
                      //           height: 30.0,
                      //           width: 30.0,
                      //         ) : SizedBox(),
                      //         msg.reactionInfo[index].reactionType == "celebrate" ? Image.asset(
                      //           AppImages.excited,
                      //           height: 30.0,
                      //           width: 30.0,
                      //         ) : SizedBox(),
                      //         msg.reactionInfo[index].reactionType == "thanks" ? Image.asset(
                      //           AppImages.thanks,
                      //           height: 30.0,
                      //           width: 30.0,
                      //         ) : SizedBox(),
                      //         msg.reactionInfo[index].reactionType == "cry" ? Image.asset(
                      //           AppImages.cry,
                      //           height: 30.0,
                      //           width: 30.0,
                      //         ) : SizedBox(),
                      //         msg.reactionInfo[index].reactionType == "smile" ? Image.asset(
                      //           AppImages.smile,
                      //           height: 30.0,
                      //           width: 30.0,
                      //         ) : SizedBox(),
                      //         SizedBox(width: 10.0),
                      //         CircleAvatar(
                      //           backgroundImage:
                      //           msg.reactionInfo[index].profileImage !=
                      //               null && msg.reactionInfo[index].profileImage != "null" ?
                      //           NetworkImage(msg.reactionInfo[index].profileImage
                      //             // 'assets/images/person_placeholder.png'
                      //
                      //           ) : AssetImage(
                      //               'assets/images/person_placeholder.png'),
                      //         ),
                      //       ],
                      //     ),
                      //   ),
                      //   // trailing: controller
                      //   //             .chatName
                      //   //             .members[
                      //   //                 ind]
                      //   //             .id
                      //   //             .toString() ==
                      //   //         controller
                      //   //             .storage
                      //   //             .read('id')
                      //   //             .toString()
                      //   //     ? SizedBox()
                      //   //     : MaterialButton(
                      //   //         shape: RoundedRectangleBorder(
                      //   //             borderRadius:
                      //   //                 BorderRadius.circular(20.0)),
                      //   //         child:
                      //   //             Text(
                      //   //           controller.chatName.members[ind].follow
                      //   //               ? "Unfollow"
                      //   //               : "Follow",
                      //   //           style:
                      //   //               TextStyle(color: Colors.white),
                      //   //         ),
                      //   //         onPressed:
                      //   //             () async {
                      //   //           if (controller.chatName.members[ind].follow ==
                      //   //               false) {
                      //   //             // controller.followSuggestionsList[index].isFollow =
                      //   //             //     true;
                      //   //             controller.update();
                      //   //             await controller.addFollowing(controller.chatName.members[ind].id,
                      //   //                 "follow");
                      //   //           } else if (controller.chatName.members[ind].follow ==
                      //   //               true) {
                      //   //             // controller.followSuggestionsList[index].isFollow =
                      //   //             //     false;
                      //   //             await controller.addFollowing(controller.chatName.members[ind].id,
                      //   //                 "unFollow");
                      //   //             controller.update();
                      //   //           }
                      //   //           print(
                      //   //               "Followed Id yahha");
                      //   //           // print(
                      //   //           //     "${controller.followSuggestionsList[index].id}");
                      //   //         },
                      //   //         color: Theme.of(context)
                      //   //             .colorScheme
                      //   //             .secondary,
                      //   //       ),
                      //   title: Text(
                      //     "${msg.reactionInfo[index].firstname} ${msg.reactionInfo[index].lastname}",
                      //     style: Styles.baseTextTheme.headline2.copyWith(
                      //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //       fontSize: 14,
                      //       fontWeight: FontWeight.bold,
                      //     ),),
                      //   subtitle: msg.reactionInfo[index].username ==null ||msg.reactionInfo[index].username =="" ||msg.reactionInfo[index].username =="null"?
                      //   Text("",
                      //       style: Styles.baseTextTheme.headline2.copyWith(
                      //         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //         fontSize: kIsWeb ? 14 : 12,
                      //         fontWeight: FontWeight.w400,
                      //       )):
                      //   Text(
                      //     "${msg.reactionInfo[index].username}",
                      //     style: Styles.baseTextTheme.headline2
                      //         .copyWith(
                      //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //       fontSize: kIsWeb ? 14 : 12,
                      //       fontWeight: FontWeight.w400,
                      //     ),),
                      //   onTap: kIsWeb ? () {
                      //     if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                      //       Get.find<NewsfeedController>().userInfo = UserProfile();
                      //       Get.find<NewsfeedController>().update();
                      //       _clickWho(msg.reactionInfo[index]);
                      //       Get.toNamed(FluroRouters.mainScreen + "/profile/" + widget.controller.otherUserId.toString());
                      //     }
                      //   }
                      //       : () async {
                      //     if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                      //       _clickWho(msg.reactionInfo[index]);
                      //       Navigator.push(
                      //           context,
                      //           MaterialPageRoute(
                      //               builder: (
                      //                   BuildContext context) =>
                      //                   OtherUsersProfile(
                      //                       controller: widget
                      //                           .controller)));
                      //     }
                      //   },
                      // ),
                    ],
                  ),
                ),
              ),
        ),
        elevation: 8.0,
      ).then((value) {
        if (value != null) print(value);
      });
    } else {
      widget.controller.showOverlay = false;
      widget.controller.update();

      showModalBottomSheet(
          // isDismissible: false,
          isScrollControlled: true,
          backgroundColor: Theme
              .of(context)
              .brightness == Brightness.dark ? Colors.black : Colors
              .white,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20))),
          context: context,
          builder: (context) {
            return StatefulBuilder(
                builder: (context, setState) {

                  return Container(
                    height: Get.height / 1.8,

                    child: Column(
                      children: [
                        Row(
                          children: [
                            IconButton(
                                onPressed: () {
                                  Navigator.of(
                                      context)
                                      .pop();
                                  widget.controller
                                      .showOverlay =
                                  true;
                                  widget.controller
                                      .update();
                                },
                                icon: Icon(
                                    Icons.close)),
                            SizedBox(
                              width: 20,
                            ),
                            Text(
                              Strings.reactions,
                              style: Styles.baseTextTheme
                                  .headline2.copyWith(
                                color: Theme
                                    .of(context)
                                    .brightness ==
                                    Brightness.dark ? Colors
                                    .white : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Container(
                          margin: EdgeInsets.only(
                              top: 10, bottom: 10),
                          height: 1,
                          color: Colors.grey.withOpacity(
                              0.4),
                          width: Get.width,
                        ),
                        Expanded(
                          child: ListView.builder(
                              itemCount: msg.reactionInfo.length,
                              itemBuilder: (context, index) {
                                return InkWell(
                                  onTap: kIsWeb ? () {
                                    if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                                      Get.find<NewsfeedController>().userInfo = UserProfile();
                                      Get.find<NewsfeedController>().update();
                                      _clickWho(msg.reactionInfo[index]);
                                      Get.toNamed(FluroRouters.mainScreen + "/profile/" + widget.controller.otherUserId.toString());
                                    }
                                  }
                                      : () async {
                                    if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                                      _clickWho(msg.reactionInfo[index]);
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (
                                                  BuildContext context) =>
                                                  OtherUsersProfile(
                                                      controller: widget
                                                          .controller)));
                                    }
                                  },
                                  child: Row(
                                    children: [
                                      const SizedBox(width:20.0),
                                      SizedBox(
                                        width: 80.0,
                                        child: Row(
                                          children: [
                                            msg.reactionInfo[index].reactionType == "like" ? Image.asset(
                                              AppImages.like,
                                              height: 30.0,
                                              width: 30.0,
                                            ) : SizedBox(),
                                            msg.reactionInfo[index].reactionType == "love" ? Image.asset(
                                              AppImages.love,
                                              height: 30.0,
                                              width: 30.0,
                                            ) : SizedBox(),

                                            msg.reactionInfo[index].reactionType == "laugh" ? Image.asset(
                                              AppImages.lough,
                                              height: 30.0,
                                              width: 30.0,
                                            ) : SizedBox(),
                                            msg.reactionInfo[index].reactionType == "celebrate" ? Image.asset(
                                              AppImages.excited,
                                              height: 30.0,
                                              width: 30.0,
                                            ) : SizedBox(),
                                            msg.reactionInfo[index].reactionType == "thanks" ? Image.asset(
                                              AppImages.thanks,
                                              height: 30.0,
                                              width: 30.0,
                                            ) : SizedBox(),
                                            msg.reactionInfo[index].reactionType == "cry" ? Image.asset(
                                              AppImages.cry,
                                              height: 30.0,
                                              width: 30.0,
                                            ) : SizedBox(),
                                            msg.reactionInfo[index].reactionType == "smile" ? Image.asset(
                                              AppImages.smile,
                                              height: 30.0,
                                              width: 30.0,
                                            ) : SizedBox(),
                                            SizedBox(width: 10.0),
                                            CircleAvatar(
                                              backgroundImage:
                                              msg.reactionInfo[index].profileImage !=
                                                  null && msg.reactionInfo[index].profileImage != "null" ?
                                              NetworkImage(msg.reactionInfo[index].profileImage
                                                // 'assets/images/person_placeholder.png'

                                              ) : AssetImage(
                                                  'assets/images/person_placeholder.png'),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(width:10.0),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                          Text(
                                            "${msg.reactionInfo[index].firstname} ${msg.reactionInfo[index].lastname}",
                                            overflow: TextOverflow.ellipsis,
                                            style: Styles.baseTextTheme.headline2.copyWith(
                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                            ),),
                                          msg.reactionInfo[index].username ==null ||msg.reactionInfo[index].username =="" ||msg.reactionInfo[index].username =="null"?
                                          Text("",
                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                fontSize: kIsWeb ? 14 : 12,
                                                fontWeight: FontWeight.w400,
                                              )):
                                          Text(
                                            "${msg.reactionInfo[index].username}",
                                            overflow: TextOverflow.ellipsis,
                                            style: Styles.baseTextTheme.headline2
                                                .copyWith(
                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                              fontSize: kIsWeb ? 14 : 12,
                                              fontWeight: FontWeight.w400,
                                            ),),
                                        ],),
                                      ),
                                      const SizedBox(width:10.0),
                                      msg.reactionInfo[index].id.toString() ==
                                          widget.controller.storage.read('id').toString()
                                          ? InkWell(
                                          onTap: (){
                                            widget.controller.chatReactionsEmit(reactionType: "dislike", messageId: msg.id, conversationId: msg.conversationId);
                                            Navigator.pop(context);
                                          },
                                          child: Text(Strings.undo, style: TextStyle(color: Colors.blue))) : SizedBox(),
                                      const SizedBox(width:20.0),
                                      // ListTile(
                                      //   trailing: msg.reactionInfo[index].id.toString() ==
                                      //           widget.controller.storage.read('id').toString()
                                      //       ? InkWell(
                                      //       onTap: (){
                                      //         print("trailing");
                                      //         widget.controller.chatReactionsEmit(reactionType: "dislike", messageId: msg.id, conversationId: msg.conversationId);
                                      //       },
                                      //       child: Text("Undo", style: TextStyle(color: Colors.blue))) : SizedBox(),
                                      //   leading: SizedBox(
                                      //     width: 85.0,
                                      //     child: Row(
                                      //       children: [
                                      //         msg.reactionInfo[index].reactionType == "like" ? Image.asset(
                                      //           AppImages.like,
                                      //           height: 30.0,
                                      //           width: 30.0,
                                      //         ) : SizedBox(),
                                      //         msg.reactionInfo[index].reactionType == "love" ? Image.asset(
                                      //           AppImages.love,
                                      //           height: 30.0,
                                      //           width: 30.0,
                                      //         ) : SizedBox(),
                                      //
                                      //         msg.reactionInfo[index].reactionType == "laugh" ? Image.asset(
                                      //           AppImages.lough,
                                      //           height: 30.0,
                                      //           width: 30.0,
                                      //         ) : SizedBox(),
                                      //         msg.reactionInfo[index].reactionType == "celebrate" ? Image.asset(
                                      //           AppImages.excited,
                                      //           height: 30.0,
                                      //           width: 30.0,
                                      //         ) : SizedBox(),
                                      //         msg.reactionInfo[index].reactionType == "thanks" ? Image.asset(
                                      //           AppImages.thanks,
                                      //           height: 30.0,
                                      //           width: 30.0,
                                      //         ) : SizedBox(),
                                      //         msg.reactionInfo[index].reactionType == "cry" ? Image.asset(
                                      //           AppImages.cry,
                                      //           height: 30.0,
                                      //           width: 30.0,
                                      //         ) : SizedBox(),
                                      //         msg.reactionInfo[index].reactionType == "smile" ? Image.asset(
                                      //           AppImages.smile,
                                      //           height: 30.0,
                                      //           width: 30.0,
                                      //         ) : SizedBox(),
                                      //         SizedBox(width: 10.0),
                                      //         CircleAvatar(
                                      //           backgroundImage:
                                      //           msg.reactionInfo[index].profileImage !=
                                      //               null && msg.reactionInfo[index].profileImage != "null" ?
                                      //           NetworkImage(msg.reactionInfo[index].profileImage
                                      //             // 'assets/images/person_placeholder.png'
                                      //
                                      //           ) : AssetImage(
                                      //               'assets/images/person_placeholder.png'),
                                      //         ),
                                      //       ],
                                      //     ),
                                      //   ),
                                      //   // trailing: controller
                                      //   //             .chatName
                                      //   //             .members[
                                      //   //                 ind]
                                      //   //             .id
                                      //   //             .toString() ==
                                      //   //         controller
                                      //   //             .storage
                                      //   //             .read('id')
                                      //   //             .toString()
                                      //   //     ? SizedBox()
                                      //   //     : MaterialButton(
                                      //   //         shape: RoundedRectangleBorder(
                                      //   //             borderRadius:
                                      //   //                 BorderRadius.circular(20.0)),
                                      //   //         child:
                                      //   //             Text(
                                      //   //           controller.chatName.members[ind].follow
                                      //   //               ? "Unfollow"
                                      //   //               : "Follow",
                                      //   //           style:
                                      //   //               TextStyle(color: Colors.white),
                                      //   //         ),
                                      //   //         onPressed:
                                      //   //             () async {
                                      //   //           if (controller.chatName.members[ind].follow ==
                                      //   //               false) {
                                      //   //             // controller.followSuggestionsList[index].isFollow =
                                      //   //             //     true;
                                      //   //             controller.update();
                                      //   //             await controller.addFollowing(controller.chatName.members[ind].id,
                                      //   //                 "follow");
                                      //   //           } else if (controller.chatName.members[ind].follow ==
                                      //   //               true) {
                                      //   //             // controller.followSuggestionsList[index].isFollow =
                                      //   //             //     false;
                                      //   //             await controller.addFollowing(controller.chatName.members[ind].id,
                                      //   //                 "unFollow");
                                      //   //             controller.update();
                                      //   //           }
                                      //   //           print(
                                      //   //               "Followed Id yahha");
                                      //   //           // print(
                                      //   //           //     "${controller.followSuggestionsList[index].id}");
                                      //   //         },
                                      //   //         color: Theme.of(context)
                                      //   //             .colorScheme
                                      //   //             .secondary,
                                      //   //       ),
                                      //   title: Text(
                                      //     "${msg.reactionInfo[index].firstname} ${msg.reactionInfo[index].lastname}",
                                      //     style: Styles.baseTextTheme.headline2.copyWith(
                                      //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      //       fontSize: 14,
                                      //       fontWeight: FontWeight.bold,
                                      //     ),),
                                      //   subtitle: msg.reactionInfo[index].username ==null ||msg.reactionInfo[index].username =="" ||msg.reactionInfo[index].username =="null"?
                                      //   Text("",
                                      //       style: Styles.baseTextTheme.headline2.copyWith(
                                      //         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      //         fontSize: kIsWeb ? 14 : 12,
                                      //         fontWeight: FontWeight.w400,
                                      //       )):
                                      //   Text(
                                      //     "${msg.reactionInfo[index].username}",
                                      //     style: Styles.baseTextTheme.headline2
                                      //         .copyWith(
                                      //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      //       fontSize: kIsWeb ? 14 : 12,
                                      //       fontWeight: FontWeight.w400,
                                      //     ),),
                                      //   onTap: kIsWeb ? () {
                                      //     if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                                      //       Get.find<NewsfeedController>().userInfo = UserProfile();
                                      //       Get.find<NewsfeedController>().update();
                                      //       _clickWho(msg.reactionInfo[index]);
                                      //       Get.toNamed(FluroRouters.mainScreen + "/profile/" + widget.controller.otherUserId.toString());
                                      //     }
                                      //   }
                                      //       : () async {
                                      //     if (widget.controller.userProfile.userId != msg.reactionInfo[index].id) {
                                      //       _clickWho(msg.reactionInfo[index]);
                                      //       Navigator.push(
                                      //           context,
                                      //           MaterialPageRoute(
                                      //               builder: (
                                      //                   BuildContext context) =>
                                      //                   OtherUsersProfile(
                                      //                       controller: widget
                                      //                           .controller)));
                                      //     }
                                      //   },
                                      // ),
                                    ],
                                  ),
                                );
                              }),
                        ),
                      ],
                    ),
                  );
                });
          });
    }

  }


  Widget postTypeWidget(MessageModel msg) {
    // print(LoggingUtils.printValue("message object", jsonEncode(msg)));
    return
      msg.post.files == null ? Container() :
      msg.post.files[0].fileType == 'image' ||
          msg.post.files[0].fileType == 'post'
          ? InkWell(
        onTap: () {
          print("sdfsdf");
          print(
              "${msg.post.files[0].filePath
                  .toString()}");
          Get.toNamed(FluroRouters.mainScreen + "/postDetail/" +
              msg.post.id.toString());

          /*  showDialog(
          barrierDismissible: false,
          context: context,
          builder:
              (BuildContext context) {
            /// bug
            return NewsFeedCarousel(
              chatCheck: 1,

              imagesListForCarousel: [
                msg.post.files[0].filePath
                    .toString()
              ],
              mediaIndex: 0,
            );
          },
        );*/
        },
        child: Container(
          width: 200,
          height: 140,
          child: Image.network(
            msg.post.files[0].filePath
                .toString(),
            fit: BoxFit.contain,
          ),
        ),
      )
          : msg.post.files[0].fileType ==
          'video'
          ? InkWell(
        onTap: () {
          Get.toNamed(FluroRouters.mainScreen + "/postDetail/" +
              msg.post.id.toString());
        },
        child: SizedBox(
            height: 200,
            width: kIsWeb ? 330 : 250,
            child: ChewieVideoPlayer(
              thumbnailUrl:
              msg.post.files[0].thumbnailPath,
              videoUrl:
              msg.post.files[0].filePath,
              isFullScreenOnMobile:
              kIsWeb ? false : true,
            )),
      )
          : msg.post.files[0].fileType ==
          'attachment'
          ? InkWell(
        onTap: () {
          Get.toNamed(FluroRouters.mainScreen + "/postDetail/" +
              msg.post.id.toString());
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            width: 200,
            decoration:
            BoxDecoration(
              borderRadius:
              BorderRadius
                  .circular(30),
              color:
              Colors.grey[100],
            ),
            child: Padding(
              padding:
              const EdgeInsets
                  .all(5.0),
              child: InkWell(
                onTap: () {
                  launch(
                      msg.post.files[0].filePath);
                },
                child: Row(
                  children: [
                    SizedBox(
                      height: 28,
                      width: 28,
                      child: Image
                          .asset(
                          'assets/images/document.png'),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment
                          .start,
                      children: [
                        msg
                            .messageFiles[0]['name'] !=
                            null ? Container(
                          width: 150,
                          child: Text(
                            msg
                                .messageFiles[0]['name'],
                            overflow:
                            TextOverflow.ellipsis,
                            style: Styles
                                .baseTextTheme
                                .headline2.copyWith(
                              color: Colors.black,
                              fontSize: 15,
                            ),
                          ),
                        ) : Text(""),

                        msg
                            .messageFiles[0]['size'] !=
                            null ? Text(

                          "Size:${msg
                              .messageFiles[0]['size']}",
                          maxLines: 2,
                          overflow: TextOverflow
                              .ellipsis,
                          style: Styles
                              .baseTextTheme
                              .headline2.copyWith(
                            color: Colors.black,
                            fontSize: 15,
                          ),
                        ) : Text(""),
                      ],
                    )


                  ],
                ),
              ),
            ),
          ),
        ),
      )
      // ListTile(
      //   onTap: () {
      //     launch(controller
      //         .messages[
      //     index]
      //         .messageFiles[0]['url']);
      //   },
      //   shape: RoundedRectangleBorder(
      //       borderRadius:
      //       BorderRadius.circular(10)),
      //   tileColor:
      //   Colors.grey[
      //   100],
      //   leading:
      //   SizedBox(
      //     height:
      //     28,
      //     width: 28,
      //     child: Image
      //         .asset(
      //         'assets/images/document.png'),
      //   ),
      //   title: Text(controller
      //       .messages[
      //   index]
      //       .messageFiles[0]['url']),
      // )
          : Container();
  }

  Widget cardScrap({BuildContext context, String link, String title, String images, String meta}) {
    // _validURL = true;

    return Container(
      height: 100,
      width: widget.isFromMessagePopup ? 200.0 : kIsWeb ? Get.width / 4.5 : Get.width / 1.5,
      child: Align(
        alignment: Alignment.center,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 0.0),
          child: InkWell(
            onTap: () async {
              if (!kIsWeb) {
                if (!link.contains('https') || !link.contains('http')) {
                  String url = "https://";
                  link = url + link;
                }
                else if (!link.contains('https') && !link.contains('www.') ||
                    !link.contains('http') && !link.contains('www.')) {
                  String url = "https://www.";
                  link = url + link;
                }
                print("url+string ${ link}");

                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => WebViewScreen(webUrl: link)),
                );
              }
              else {
                if (await canLaunchUrl(Uri.parse(link.toString()))) {
                  print("launch");
                  print(link.toString());
                  print("launch");
                  if (await canLaunchUrl(Uri.parse(link.toString().trim()))) {
                    await launchUrl(Uri.parse(link.toString().trim(),),
                        mode: LaunchMode.externalApplication);
                  }
                  // await launchUrl(Uri.parse(string.trim(),),
                  // );
                } else {
                  print("not launch");
                  print(link.toString());
                  print("not launch");
                  await launchUrl(
                      Uri.parse('https://www.${link.toString().trim()}',),
                      mode: LaunchMode.externalApplication);
                }
              }


              // print("lunch not wewq  ${link.toString()}");
              // await canLaunchUrl(Uri.parse(link));


              // // await canLaunch(link.toString())
              //     ? await launch(link.toString())
              //     : throw 'Could not launch ${link}';
            },
            child: Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(15.0)),
                side: BorderSide(
                  color: Colors.blue.withOpacity(0.5),
                  width: 1,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.all(
                  Radius.circular(15.0),
                ),
                child: Container(
                  height: 100,
                  child: Row(
                    children: [

                      images.contains('.svg') ?
                      Padding(
                        padding: const EdgeInsets.only(left: 0),
                        child: Container(
                            height: 100,
                            width: 100,
                            child: SvgPicture.network(
                                images,
                                fit: BoxFit.cover
                            )
                        ),
                      ) :
                      Padding(
                        padding: const EdgeInsets.only(left: 0),
                        child: Container(
                          height: 100,
                          width: 100,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(0.0),
                              image: DecorationImage(
                                  image: images.isNotEmpty
                                      ? NetworkImage(
                                      images.toString())
                                      : AssetImage(
                                      "assets/images/person_placeholder.png"),
                                  fit: BoxFit.cover)),
                        ),
                      ),


                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // Padding(
                              //   padding:
                              //   const EdgeInsets.only(right: 8.0, top: 8.0),
                              //   child: InkWell(
                              //     onTap: () {},
                              //     child: SizedBox(
                              //       height: 4,
                              //       child: Align(
                              //           alignment: Alignment.topRight,
                              //           child: Icon(Icons.cancel)),
                              //     ),
                              //   ),
                              // ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: Text(link.toString(),
                                    textAlign: TextAlign.left,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Colors.grey[500],
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                    )),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: Text(title.toString(),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 2,
                                  style: Styles.baseTextTheme.headline2
                                      .copyWith(
                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w400,
                                  )
                                    // style: TextStyle(
                                    //   color: Colors.black,
                                    //   fontSize: 15,
                                    //   fontWeight: FontWeight.w500,
                                    // )
                              ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: Text(meta == null ? "" : meta.toString(),
                                    textAlign: TextAlign.left,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Colors.grey[500],
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                    )),
                              ),

                              // Padding(
                              //   padding: const EdgeInsets.only(right: 8.00),
                              //   child: meta != null ?
                              //   Text(
                              //     data.meta.toString(),
                              //     maxLines: 1,
                              //     overflow: TextOverflow.ellipsis,
                              //     style: TextStyle(
                              //       color: Colors.black,
                              //       fontFamily: 'Cairo',
                              //       fontSize: 16,
                              //       fontWeight: FontWeight.w500,
                              //     ),
                              //   ) : SizedBox(),
                              // ),

                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ignore: missing_return
  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 20;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 20).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Future<List<MessageModel>> _fetchData(int page) {
    return Get.find<NewsfeedController>().createMessagePaged(page);
  }

  SizedBox emojiSideBar() {
    return SizedBox(
        width: 50,
        child: ListView.builder(
            controller: _scrollController,
            itemCount: emojis.length,
            itemBuilder: (context, index) {
              final x = emojis[index].split(' ');
              return GestureDetector(
                  onTap: () {
                    _selectedTab = index;
                    _tabController.animateTo(index);
                    setState(() {});
                  },
                  child: Container(
                      padding: const EdgeInsets.all(2),
                      margin: const EdgeInsets.all(2),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: _selectedTab == index
                              ? Colors.grey.shade300
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(x[0], style: const TextStyle(fontSize: 25))));
            }));
  }

  Widget notificationSettings(context, setState){
    return widget.controller.chatName.conversationType ==
        'single'
        ? Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin:
          EdgeInsets.only(top: 10, bottom: 10),
          height: 1,
          color: Colors.grey.withOpacity(0.4),
          width: Get.width,
        ),
        Padding(
          padding: const EdgeInsets.only(
              top: 8.0, bottom: 8.0, left: 15),
          child: Text(
            Strings.notifications,
            style: Styles.baseTextTheme.headline2
                .copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).brightness ==
                  Brightness.dark
                  ? Colors.white
                  : Colors.black,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 10),
          child: Column(

            children: [
              Padding(
                padding: EdgeInsets.only(
                    right: widget.controller.languageData.appLang.id == 2
                        ? 15.0
                        : 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        "${Strings.snoozeNotificationsFrom} ${widget.controller.chatName.username}",//Strings.pushNotifications,
                        style:
                        Styles.baseTextTheme.headline1.copyWith(
                          color: Theme
                              .of(context)
                              .brightness ==
                              Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Switch(
                        value: widget.controller.isChatSnoozeNotification,
                        activeColor: widget.controller.displayColor,
                        onChanged: (value) async {
                          int snoozeValue = value ? 1 : 0;
                          await widget.controller.setSnoozeNotification("message", snoozeValue);
                          setState(() {
                          });
                        }),
                  ],
                ),
              ),

              SizedBox(
                height: 10,
              ),

            ],
          ),
        )
      ],
    )
        : Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin:
          EdgeInsets.only(top: 10, bottom: 10),
          height: 1,
          color: Colors.grey.withOpacity(0.4),
          width: Get.width,
        ),
        Padding(
          padding: const EdgeInsets.only(
              top: 8.0, bottom: 8.0, left: 15),
          child: Text(
            Strings.notifications,
            style: Styles.baseTextTheme.headline2
                .copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).brightness ==
                  Brightness.dark
                  ? Colors.white
                  : Colors.black,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    right: widget.controller.languageData.appLang.id == 2
                        ? 15.0
                        : 0),
                child: Row(
                  children: [
                    Text(
                      Strings.snoozeNotificationsFromTheGroup,//Strings.pushNotifications,
                      style:
                      Styles.baseTextTheme.headline1.copyWith(
                        color: Theme
                            .of(context)
                            .brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 16 : 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Spacer(),
                    Switch(
                        value: widget.controller.isChatSnoozeNotification,
                        activeColor: widget.controller.displayColor,
                        onChanged: (value) async {
                          int snoozeValue = value ? 1 : 0;
                          await widget.controller.setSnoozeNotification("message", snoozeValue);
                          setState(() {
                          });
                        }),
                  ],
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Padding(
                padding: EdgeInsets.only(
                    right: widget.controller.languageData.appLang.id == 2
                        ? 15.0
                        : 0),
                child: Row(
                  children: [
                    Text(
                      Strings.snoozeMentions,//Strings.pushNotifications,
                      style:
                      Styles.baseTextTheme.headline1.copyWith(
                        color: Theme
                            .of(context)
                            .brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 16 : 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Spacer(),
                    Switch(
                        value: widget.controller.isChatSnoozeMention,
                        activeColor: widget.controller.displayColor,
                        onChanged: (value) async {
                          int snoozeValue = value ? 1 : 0;
                          await widget.controller.setSnoozeNotification("mention", snoozeValue);
                          setState(() {
                          });
                        }),
                  ],
                ),
              ),
              Text(
               Strings.disableNotificationsWhenPeoplemention,
                style: TextStyle(
                    fontSize: 12, color: Colors.grey[500]),
              ),
              SizedBox(
                height: 10,
              ),

            ],
          ),
        )
      ],
    );

  }

  videoCallButton(){
    return CallButtons(context: context, conversationId: widget.controller.chatName.conversationId.toString(),);
  }
}

class PagedL extends StatefulWidget {
  final Widget emptyStateWidget;
  final Widget Function(BuildContext, MessageModel) _itemBuilder;
  final Widget _loadingIndicator;
  final Future<List<MessageModel>> Function(int) _itemDataProvider;
  final NewsfeedController controller;
  final EdgeInsets _padding;
  List<MessageModel> list = [];
  int listSize;
  bool isRequested;

  PagedL({
    @required Widget Function(BuildContext context, MessageModel value) itemBuilder,
    @required Widget loadingIndicator,
    @required Future<List<MessageModel>> Function(int page) itemDataProvider,
    List<MessageModel> list,
    int listSize,
    this.emptyStateWidget = const SizedBox(),
    EdgeInsets padding = EdgeInsets.zero,
    Key key, this.controller, this.isRequested,
  })
      : assert(itemBuilder != null &&
      loadingIndicator != null &&
      itemDataProvider != null),
        _itemBuilder = itemBuilder,
        _loadingIndicator = loadingIndicator,
        _itemDataProvider = itemDataProvider,
        list = list,
        listSize = listSize,
        _padding = padding,
        super(key: key);

  @override
  _PagedLState createState() => _PagedLState();
}

class _PagedLState extends State<PagedL> {
  // ignore: deprecated_member_use, unused_field
  final List<MessageModel> _loadedData = List<MessageModel>();

  int _pgCount = 2;
  bool _end = false;
  bool _loading = false;
  bool _noData = false;

  // ignore: unused_field
  bool _finalEnd = false;
  int i = 0;

  @override
  Widget build(BuildContext context) {
    // if (_loadedData.isEmpty) {
    //   if (widget.list.isEmpty) {
    //     _noData = true;
    //   } else
    //     _loadedData.addAll(widget.list);
    //   widget.list = [];
    // } else{
    //     _loadedData.removeWhere((item) => item.id == widget.list[0].id);
    //     _loadedData.insert(0, widget.list[0]);
    // }
    // one extra item when loading to include indicator widget
    final itemCount = _loading ? widget.list.length + 1 : widget.list.length;
    final maxIndex = itemCount - 1;
    return
      // Column(
      // children: [
      // _finalEnd ? Text('No More') : SizedBox(),
      _noData
          ? Center(
        child: widget.emptyStateWidget,
      )
          :
      // Expanded(
      //             child:
      ListView.builder(
        key: widget.key,
        // controller: controller.scrollController,
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        padding: widget._padding,
        reverse: true,
        cacheExtent: 1000,
        itemCount: itemCount,
        itemBuilder: (context, index) {
          final isLastItem = index == maxIndex;
          if (isLastItem && maxIndex >= 19) {
            _loadMoreData();
            if (_loading) {
              return widget._loadingIndicator;
            }
          }
          return isLastItem == true ?
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              widget.controller.chatName.conversationType == 'group'
                  ? SizedBox()
                  :
              Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                    ),
                    width: 64,
                    child: widget.controller.chatName
                        // != null ? controller.chatName.profileImage
                        ==
                        null
                        ? Container(
                        width: 24,
                        child: Center(
                          child: SpinKitCircle(
                            color: Colors.grey,
                            size: 40,
                          ),
                        ))
                        : ClipRRect(
                      borderRadius: BorderRadius.circular(64),
                      child: FadeInImage(
                        // fit: BoxFit.fill,
                        fit: BoxFit.fitWidth,
                        width: 64,
                        height: 64,
                        placeholder: AssetImage(
                            'assets/images/person_placeholder.png'),
                        image: widget.controller.chatName.conversationType ==
                            'single'
                            ? widget.controller.chatName.profileImage != null
                            ? NetworkImage(widget.controller.chatName
                            .profileImage)
                            : AssetImage('assets/images/person_placeholder.png')
                            : widget.controller.chatName.conversationType ==
                            'group'
                            ? widget.controller.tempProfileImageGroupChat !=
                            null
                            ? MemoryImage(widget.controller
                            .tempProfileImageGroupChat)
                            : widget.controller.chatName.groupImage != null
                            ? NetworkImage(
                            widget.controller.chatName.groupImage)
                            : AssetImage('assets/images/person_placeholder.png')
                            : AssetImage(
                            'assets/images/person_placeholder.png'),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      // /// bugs
                      //
                      // widget.controller.tempGroupName != "" ? Text(
                      //   "${widget.controller.tempGroupName}",
                      //   style: Styles.baseTextTheme.headline2.copyWith(
                      //     color: Theme
                      //         .of(context)
                      //         .brightness == Brightness.dark
                      //         ? Colors.white
                      //         : Colors.black,
                      //     fontWeight: FontWeight.bold,
                      //     fontSize: kIsWeb ? 18 : 15,
                      //   ),
                      // ) :
                      // widget. controller.chatUserList[widget.controller.chatIndex].conversationType =="group" ?
                      // widget. controller.chatUserList[widget.controller.chatIndex].name != null
                      //     ? Text(
                      //   "${widget.controller.chatUserList[widget.controller.chatIndex].name}",
                      //   style: Styles.baseTextTheme.headline4.copyWith(
                      //     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //     fontSize: kIsWeb ? 18 : 15,
                      //     fontWeight: FontWeight.bold,
                      //   ),
                      // )
                      //     :   widget.controller.chatUserList[widget.controller.chatIndex].members.length ==1
                      //     ? FittedBox(
                      //     child : Row(
                      //       children: [
                      //         Text(
                      //           "${widget.controller.chatUserList[widget.controller.chatIndex].members[0].firstname}",
                      //           style: Styles.baseTextTheme.headline4.copyWith(
                      //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //             fontSize: kIsWeb ? 18 : 15,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //
                      //
                      //       ],
                      //     )
                      // )
                      //     : widget.controller.chatUserList[widget.controller.chatIndex].members.length ==2
                      //     ? FittedBox(
                      //     child : Row(
                      //       children: [
                      //         Text(
                      //           "${widget.controller.chatUserList[widget.controller.chatIndex].members[0].firstname}, ",
                      //           style: Styles.baseTextTheme.headline4.copyWith(
                      //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //             fontSize: kIsWeb ? 18 : 15,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //         Text(
                      //           "${widget.controller.chatUserList[widget.controller.chatIndex].members[1].firstname}",
                      //           style: Styles.baseTextTheme.headline4.copyWith(
                      //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //             fontSize: 15,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //
                      //       ],
                      //     )
                      // )
                      //     : widget.controller.chatUserList[widget.controller.chatIndex].members.length==3
                      //     ? FittedBox(
                      //   child: Row(
                      //     children: [
                      //       Text(
                      //         "${widget.controller.chatUserList[widget.controller.chatIndex].members[0].firstname}, ",
                      //         style: Styles.baseTextTheme.headline4.copyWith(
                      //           color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //           fontSize: kIsWeb ? 18 : 15,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //       ),
                      //       Text(
                      //         "${widget.controller.chatUserList[widget.controller.chatIndex].members.length - 1} other...",
                      //         style: Styles.baseTextTheme.headline4.copyWith(
                      //           color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //           fontSize: 15,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //       ),
                      //     ],
                      //   ),
                      // )
                      //     : widget.controller.chatUserList[widget.controller.chatIndex].members.length>=4
                      //     ? FittedBox(
                      //     child : Row(
                      //       children: [
                      //
                      //         Text(
                      //           "${widget.controller.chatUserList[widget.controller.chatIndex].members[0].firstname}, ",
                      //           style: Styles.baseTextTheme.headline4.copyWith(
                      //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //             fontSize: kIsWeb ? 18 : 15,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //         Text(
                      //           "${widget.controller.chatUserList[widget.controller.chatIndex].members[1].firstname}, ",
                      //           style: Styles.baseTextTheme.headline4.copyWith(
                      //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //             fontSize: 15,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //         // Text(
                      //         //   "${controller.chatUserList[index].members[2].firstname} and ",
                      //         //   style: Theme.of(context).brightness == Brightness.dark ?
                      //         //   TextStyle(color: Colors.white,
                      //         //       fontWeight: FontWeight.w600,overflow:
                      //         //       TextOverflow.ellipsis
                      //         //   )
                      //         //       : TextStyle(color: Colors.black,
                      //         //       fontWeight: FontWeight.w600,overflow:
                      //         //       TextOverflow.ellipsis
                      //         //   ),
                      //         // ),
                      //         Text(
                      //           "${widget.controller.chatUserList[widget.controller.chatIndex].members.length - 2} other...",
                      //           style: Styles.baseTextTheme.headline4.copyWith(
                      //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //             fontSize: 15,
                      //             fontWeight: FontWeight.bold,
                      //           ),
                      //         ),
                      //       ],
                      //     )
                      // )
                      //
                      //
                      //
                      //
                      //     : SizedBox() :SizedBox(),

                      widget.isRequested ? widget.controller
                          .chatRequestUserList[widget.controller
                          .chatIndex].conversationType == "single" ?
                      Text(
                        "${widget.controller.chatRequestUserList[widget
                            .controller
                            .chatIndex].name}",
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: kIsWeb ? 15 : 15,
                        ),
                      ) : SizedBox() :
                      widget.controller.chatUserList[widget.controller
                          .chatIndex].conversationType == "single" ?
                      Text(
                        "${widget.controller.chatUserList[widget.controller
                            .chatIndex].name}",
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: kIsWeb ? 15 : 15,
                        ),
                      ) : SizedBox(),

                      // Text(
                      //   "${widget.controller.groupName != null ? widget.controller.groupName : widget.controller.chatName.name != null ? widget.controller.chatName.name : ""}",
                      //   maxLines: 1,
                      //   style: Theme.of(context).textTheme.bodyText1.copyWith(
                      //       color: Colors.black,
                      //       overflow: TextOverflow.ellipsis),
                      // ),
                      widget.controller.chatName.accountVerified ==
                          "verified"
                          ? Row(
                        children: [
                          SizedBox(
                            width: 5,
                          ),
                          BlueTick(
                            height: 15,
                            width: 15,
                            iconSize: 10,
                          ),
                        ],
                      )
                          : SizedBox()
                    ],
                  ),
                  widget.isRequested?
                  Text(
                    "@${widget.controller.chatRequestUserList[widget.controller
                        .chatIndex].username}",
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : Color(0xff536471),
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 15 : 15,
                    ),
                  ):Text(
                    "@${widget.controller.chatUserList[widget.controller
                        .chatIndex].username}",
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : Color(0xff536471),
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 15 : 15,
                    ),
                  ),
                  widget.isRequested?
                  widget.controller.chatRequestUserList[widget.controller.chatIndex]
                      .participant_bio == null
                      ? SizedBox()
                      : Text(
                    widget.controller.chatRequestUserList[widget.controller.chatIndex]
                        .participant_bio,
                    textAlign: TextAlign.center,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 15 : 15,
                    ),
                  ):widget.controller.chatUserList[widget.controller.chatIndex]
                      .participant_bio == null
                      ? SizedBox()
                      : Text(
                    widget.controller.chatUserList[widget.controller.chatIndex]
                        .participant_bio,
                    textAlign: TextAlign.center,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 15 : 15,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      widget.isRequested?
                      Text(
                        "${widget.controller.chatRequestUserList[widget.controller
                            .chatIndex].participant_followers} ",
                        style: Styles
                            .baseTextTheme.headline1
                            .copyWith(
                          color: Theme
                              .of(context)
                              .brightness ==
                              Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: 14.0,
                        ),
                      )
                          :Text(
                        "${widget.controller.chatUserList[widget.controller
                            .chatIndex].participant_followers} ",
                        style: Styles
                            .baseTextTheme.headline1
                            .copyWith(
                          color: Theme
                              .of(context)
                              .brightness ==
                              Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: 14.0,
                        ),
                      ),
                      Text(
                        Strings.followers,
                        style: Styles
                            .baseTextTheme.headline2
                            .copyWith(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          color: Color(0xff536471),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5,),
                  // Divider(color: Colors.grey[200],thickness: 0.2,),
                ],
              ),
              widget._itemBuilder(context, widget.list[index])
            ],
          ) : widget._itemBuilder(context, widget.list[index]);
        },
        // ),
        //           ),
        //   ],
      );
  }

  void _loadMoreData() async {
    if (!_end) {
      if (!_loading) {
        // making sure setState is called after build method is done
        try {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              setState(() => _loading = true);
            }
          });
        } catch (_) {}
        List<MessageModel> listFor = [];
        await widget._itemDataProvider(_pgCount).then((value) {
          value.forEach((element) {
            widget.list.removeWhere((item) => item.id == element.id);
            // _loadedData.add(element);
          });
          listFor.addAll(value);
          if (listFor != null && listFor.isNotEmpty) {
            try {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) {
                  setState(() {
                    widget.list.addAll(listFor);
                    _pgCount++;
                    _loading = false;
                  });
                }
              });
            } catch (_) {}
            if (listFor.length < 10) {
              try {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (mounted) {
                    setState(() {
                      _end = true;
                    });
                  }
                });
              } catch (_) {}
            }
          } else {
            try {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) {
                  setState(() {
                    _end = true;
                    _loading = false;
                    _finalEnd = true;
                  });
                }
              });
            } catch (_) {}
          }
        });
      }
    } else {
      try {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            setState(() {
              _loading = false;
              _finalEnd = true;
            });
          }
        });
      } catch (_) {}
    }
  }
// }
}

class ChatContainer extends StatefulWidget {
  MessageModel msg;
  NewsfeedController controller;
  bool isFromMessagePopup;

  ChatContainer({this.msg, this.controller, this.isFromMessagePopup = false});

  @override
  _ChatContainerState createState() => _ChatContainerState();
}

class _ChatContainerState extends State<ChatContainer> {
  @override
  Widget build(BuildContext context) {
    int maxTextLength = 30;
    if (widget.isFromMessagePopup) maxTextLength = 25;

    if (widget.msg.body.isEmpty){
      return const SizedBox();
    }

    return widget.msg.body.length > maxTextLength
        ? Row(
      children: [
        Container(
          width: widget.isFromMessagePopup ? 180.0 : kIsWeb ? Get.width / 4.5 : Get.width / 1.9,
          child: textWidget()
          // Text(
          //   "${widget.msg.body}",
          //   // maxLines: 10,
          //   softWrap: true,
          //   textAlign: TextAlign.start,
          //   // textAlign: TextAlign.justify,
          //   style: Theme
          //       .of(context)
          //       .textTheme
          //       .bodyText2
          //       .copyWith(
          //       fontSize: 15,
          //       color: widget.msg.userId ==
          //           widget.controller.storage.read("id")
          //           ? widget.msg.messageFiles.isNotEmpty
          //           ? Colors.black87
          //           : Colors.white
          //           : Colors.black),
          // ),
        ),
        // widget.msg.body == "" || widget.msg.body == null
        //     ? SizedBox()
        //     : Align(
        //   alignment: Alignment.centerLeft,
        //   child: IconButton(
        //     onPressed: () async {
        //       //  widget.post.tts.awaitSpeakCompletion(true).whenComplete(() {
        //       //    widget.post.isPlay = false;
        //       //    setState(() {
        //       //
        //       //    });
        //       //  });
        //       // tts.setSpeechRate(0.001);
        //
        //       // tts.pauseHandler.call();
        //
        //       if (widget.msg.isPlay) {
        //         widget.msg.isPlay = !widget.msg.isPlay;
        //         // widget.post.tts.pauseHandler();
        //         widget.msg.tts.stop();
        //         setState(() {});
        //       } else if (!widget.msg.isPlay) {
        //         widget.msg.tts = FlutterTts();
        //
        //         Get
        //             .find<NewsfeedController>()
        //             .messages
        //             .forEach((element) {
        //           element.tts = FlutterTts();
        //           element.isPlay = false;
        //           element.tts.stop();
        //           setState(() {});
        //         });
        //         widget.msg.isPlay = true;
        //         setState(() {});
        //         widget.msg.tts.awaitSpeakCompletion(true);
        //         widget.msg.tts.speak(widget.msg.body);
        //         widget.msg.tts.setLanguage(
        //             "${Get
        //                 .find<NewsfeedController>()
        //                 .languageData
        //                 .myLang
        //                 .code}");
        //         widget.msg.tts.setCompletionHandler(() {
        //           print("Complete");
        //           setState(() {
        //             widget.msg.isPlay = false;
        //           });
        //         });
        //       }
        //     },
        //     // icon: FaIcon(
        //     //   widget.msg.isPlay
        //     //       ? FontAwesomeIcons.volumeDown
        //     //       : FontAwesomeIcons.volumeDown,
        //     //   color: widget.msg.userId ==
        //     //       widget.controller.storage.read("id")
        //     //       ? Colors.white
        //     //       : Colors.black,
        //     //   // Colors.grey[500],
        //     //   size: 16,
        //     // ),
        //   ),
        // )
      ],
    )
        : Row(
      children: [

        textWidget()
        // Text(
        //   "${widget.msg.body}",
        //   // maxLines: 10,
        //   softWrap: true,
        //   textAlign: TextAlign.start,
        //   style: Theme
        //       .of(context)
        //       .textTheme
        //       .bodyText2
        //       .copyWith(
        //       fontSize: 15,
        //       color: widget.msg.userId == widget.controller.storage.read("id")
        //           ? widget.msg.messageFiles.isNotEmpty
        //           ? Colors.black87
        //           : Colors.white
        //           : Colors.black),
        // ),
        // Align(
        //   alignment: Alignment.centerLeft,
        //   child: IconButton(
        //     onPressed: () async {
        //       //  widget.post.tts.awaitSpeakCompletion(true).whenComplete(() {
        //       //    widget.post.isPlay = false;
        //       //    setState(() {
        //       //
        //       //    });
        //       //  });
        //       // tts.setSpeechRate(0.001);
        //
        //       // tts.pauseHandler.call();
        //
        //       if (widget.msg.isPlay) {
        //         widget.msg.isPlay = !widget.msg.isPlay;
        //         // widget.post.tts.pauseHandler();
        //         widget.msg.tts.stop();
        //         setState(() {});
        //       } else if (!widget.msg.isPlay) {
        //         widget.msg.tts = FlutterTts();
        //
        //         Get
        //             .find<NewsfeedController>()
        //             .messages
        //             .forEach((element) {
        //           element.tts = FlutterTts();
        //           element.isPlay = false;
        //           element.tts.stop();
        //           setState(() {});
        //         });
        //         widget.msg.isPlay = true;
        //         setState(() {});
        //         widget.msg.tts.awaitSpeakCompletion(true);
        //         widget.msg.tts.speak(widget.msg.body);
        //         widget.msg.tts.setLanguage(
        //             "${Get
        //                 .find<NewsfeedController>()
        //                 .languageData
        //                 .myLang
        //                 .code}");
        //         widget.msg.tts.setCompletionHandler(() {
        //           print("Complete");
        //           setState(() {
        //             widget.msg.isPlay = false;
        //           });
        //         });
        //       }
        //     },
        //     // icon: FaIcon(
        //     //   widget.msg.isPlay
        //     //       ? FontAwesomeIcons.volumeDown
        //     //       : FontAwesomeIcons.volumeDown,
        //     //   color: widget.msg.userId ==
        //     //       widget.controller.storage.read("id")
        //     //       ? Colors.white
        //     //       : Colors.grey[500],
        //     //   // Colors.grey[500],
        //     //   size: 16,
        //     // ),
        //   ),
        // )
      ],
    );
  }
  Widget textWidget(){
    return Linkify(
      onOpen: (link) async {
        // if (!kIsWeb) {
        //   Navigator.push(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) => WebViewScreen(String: link)),
        //   );
        // }
        // else {
        //   if (await canLaunchUrl(Uri.parse(link.toString()))) {
        //     if (await canLaunchUrl(Uri.parse(link.toString().trim()))) {
        //       await launchUrl(Uri.parse(link.toString().trim(),),
        //           mode: LaunchMode.externalApplication);
        //     }
        //   } else {
        //     await launchUrl(
        //         Uri.parse('https://www.${link.toString().trim()}',),
        //         mode: LaunchMode.externalApplication);
        //   }
        // }
        if (!await launchUrl(Uri.parse(link.url))) {
          // throw Exception('Could not launch ${link.url}');
        }
      },
      options: LinkifyOptions(
          looseUrl: true),
      text: widget.msg.body,
      softWrap: true,
      style: Theme.of(context).textTheme.bodyText2.copyWith(
          fontSize: 15,
          color: widget.msg.userId ==
              widget.controller.storage.read("id")
              ? widget.msg.messageFiles.isNotEmpty
              ? Colors.black87
              : Colors.white
              : Colors.black),
      linkStyle: Theme.of(context).textTheme.bodyText2.copyWith(
          fontSize: 15,
          decoration: TextDecoration.underline,
          color: widget.msg.userId ==
              widget.controller.storage.read("id")
              ? widget.msg.messageFiles.isNotEmpty
              ? Colors.black87
              : Colors.white
              : Colors.black),
    );
  }
}

class EmojiTabBar extends StatelessWidget {
  EmojiTabBar({
    Key key,
    this.tabController,
  }) : super(key: key);
  final TabController tabController;

  final controller = Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return TabBar(
        controller: tabController,
        isScrollable: true,
        labelColor: controller.displayColor,
        unselectedLabelColor: controller.displayColor,
        labelStyle: const TextStyle(fontSize: 25),
        unselectedLabelStyle: const TextStyle(fontSize: 20),
        labelPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 1),
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: BoxDecoration(
            color: Colors.grey.withOpacity(.3),
            borderRadius: BorderRadius.circular(10)),
        tabs: emojis.map((e) {
          final x = e.split(' ');
          return Tab(
              child: SizedBox(width: 35, child: Center(child: Text(x[0]))));
        }).toList());
  }
}

class EmojisList extends StatelessWidget {
  const EmojisList({Key key,
    this.cross,
    TextEditingController textController,
    this.tabController,
    this.controller})
      : _textController = textController,
        super(key: key);

  final int cross;
  final TextEditingController _textController;
  final TabController tabController;
  final NewsfeedController controller;

  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: TabBarView(
            controller: tabController,
            children: emojis.map((e) {
              final x = e.split(' ');
              return GridView.builder(
                  itemCount: x.length,
                  scrollDirection: Axis.vertical,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: kIsWeb ? 8 : cross,
                      mainAxisSpacing: 2,
                      crossAxisSpacing: 2),
                  itemBuilder: (context, index) =>
                      GestureDetector(
                          onTap: () {
                            _textController.text =
                                _textController.text + x[index];
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: kIsWeb
                                      ? Colors.transparent
                                      : Colors.green.shade50,
                                  borderRadius: BorderRadius.circular(10)),
                              alignment: Alignment.center,
                              child: FittedBox(
                                  child: Text(x[index],
                                      style: const TextStyle(fontSize: 30))))));
            }).toList()));
  }
}
