import 'package:flutter/material.dart';
import 'package:werfieapp/utils/colors.dart';

class BlueTick extends StatelessWidget {
  BlueTick({Key key, this.height, this.width, this.iconSize}) : super(key: key);
  double height;
  double width;
  double iconSize;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(color: MyColors.blue, shape: BoxShape.circle),
      child: Icon(
        Icons.check,
        color: Colors.white,
        size: iconSize,
      ),
    );
  }
}
