import 'package:flutter/foundation.dart';
import 'package:werfieapp/models/notifications.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/comments_screen.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../models/profile.dart';
import '../network/singleTone.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';

// ignore: must_be_immutable
class MentionedNotificationsWidget extends StatelessWidget {
  NotificationController controller = Get.find<NotificationController>();

  MentionedNotificationsWidget({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _refresh,

      child: GetBuilder<NotificationController>(builder: (controller) {
        return
            // Center(
            // child:
            controller.isLoadingMentionedNotifications
                ? const Center(
                    child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(MyColors.blue),
                  ))
                // Container(
                //   color: Colors.grey[200],
                //   margin: EdgeInsets.all(10),
                //   height: 100,
                //   child: buildNotificationShimmer(context)
                // );

                : controller.mentionedNotificationList == null ||
                        controller.mentionedNotificationList.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                            Strings.noNotification,
                            style: Styles.baseTextTheme.headlineMedium.copyWith(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                              //fontWeight: FontWeight.w500,
                            ),
                      ),

                            IconButton(onPressed: _refresh, icon:  Icon(Icons.refresh,color: MyColors.werfieBlue,)),
                            Text(
                                Strings.refresh,
                              style: Styles.baseTextTheme.headlineMedium.copyWith(
                                color: Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : MyColors.werfieBlue,
                                fontSize: kIsWeb ? 14 : 12,
                                //fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ))
                    : PagedList(
                        emptyStateWidget: Text(
                          Strings.noNotification,
                          style: Styles.baseTextTheme.headlineMedium.copyWith(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            //fontWeight: FontWeight.w500,
                          ),
                        ),
                        itemBuilder: _itemRow,
                        padding: const EdgeInsets.only(
                            top: 00.00, left: 00.00, right: 00.00),
                        loadingIndicator: const Padding(
                          padding: EdgeInsets.all(16.00),
                          child: Center(
                            child: CircularProgressIndicator(),
                          ),
                        ),
                        itemDataProvider: _fetchData,

                        list: controller.mentionedNotificationList,
                        // post: controller.postList,
                      );

        // ListView.separated(
        //             separatorBuilder: (context, index) =>
        //                 Divider(height: 1),
        //             padding: EdgeInsets.all(10),
        //             itemCount: controller.notificationList.length,
        //             itemBuilder: (context, index) {
        //               return ListTile(
        //                 horizontalTitleGap: 20,
        //                 contentPadding: EdgeInsets.all(11),
        //                 trailing: Column(
        //                   mainAxisAlignment: MainAxisAlignment.start,
        //                   children: [Icon(Icons.more_horiz)],
        //                 ),
        //                 leading: controller
        //                     .notificationList[index]
        //                     .profileImage ==
        //                     null ? Padding(
        //                       padding: const EdgeInsets.only(top: 5.0),
        //                       child: CircleAvatar(
        //                       radius: 22,
        //                       backgroundImage: AssetImage(
        //                           "assets/images/person_placeholder.png")),
        //                     )
        //                 : Padding(
        //                   padding: const EdgeInsets.only(top: 5.0),
        //                   child: ClipRRect(
        //                     borderRadius: BorderRadius.circular(25),
        //                     child: FadeInImage(
        //                         fit: BoxFit.cover,
        //                         width: 40,
        //                         height: 40,
        //                         placeholder: AssetImage(
        //                             'assets/images/person_placeholder.png'),
        //                         image: NetworkImage(controller
        //                             .notificationList[index]
        //                             .profileImage !=
        //                             null
        //                             ? controller
        //                             .notificationList[index]
        //                             .profileImage
        //                             : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
        //                   ),
        //                 ),
        //                 // CircleAvatar(
        //                 //   radius: 44,
        //                 //   foregroundImage: controller
        //                 //               .notificationList[index]
        //                 //               .profileImage !=
        //                 //           null
        //                 //       ? NetworkImage(controller
        //                 //           .notificationList[index].profileImage)
        //                 //       :  AssetImage('assets/images/person_placeholder.png',),
        //                 // ),
        //                 title: SizedBox(
        //                   height: 24,
        //                   child: Text(
        //                       "${controller.notificationList[index].senderName} ${controller.notificationList[index].text}"),
        //                 ),
        //                 subtitle: SizedBox(
        //                   height: 20,
        //                   child: Text(DateFormat.yMMMMd('en_US')
        //                       .add_jm()
        //                       .format(controller
        //                           .notificationList[index].createdAt)),
        //                 ),
        //               );
        //             },
        //           ),
        // );
      }),
    );
  }
  Future<void> _refresh() async {
    await controller.getMentionedNotifications();

  }
  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page numberPrint1:" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Widget _itemRow(BuildContext context, Notifications post) {
    return ListTile(
      onTap: !kIsWeb
          ? () async {
              // controller.isSingleNewsfeedCalled = true;
              // controller.update();
              // Post singlePost = await Get.find<NewsfeedController>()
              //     .getSingleNewsFeedItem(post.postId);
              // controller.isSingleNewsfeedCalled = false;
              // controller.update();
              if (post.type == 'follow') {
                Get.find<NewsfeedController>().otherUserId = post.userId;
                Get.find<NewsfeedController>().update();
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => OtherUsersProfile(
                            controller: Get.find<NewsfeedController>(),
                          )),
                );
                Get.find<NewsfeedController>().userInfo = UserProfile();
                Get.find<NewsfeedController>().userInfo =
                    await Get.find<NewsfeedController>().getOtherUserProfile(
                        Get.find<NewsfeedController>().otherUserId);

                await Get.find<OtherUserController>()
                    .filterUsersPostPagged("posts", page: 1);
                Get.find<OtherUserController>().userPosts.forEach((element) {
                  element.mute = Get.find<NewsfeedController>().userInfo.muted;
                });
                Get.find<OtherUserController>().update();

                // Get.find<NewsfeedController>().otherUserName = post.senderName;
                //
                // if (Get.isRegistered<OtherUserController>()) {
                //   await Get.delete<OtherUserController>();
                // }
              } else {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => CommentsScreen(
                      thread_no: null,
                      postId: post.postId,
                    ),
                  ),
                );
              }
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (BuildContext context) => PostDetail(
              //       controller: Get.find<NewsfeedController>(),
              //       post: singlePost,
              //     ),
              //   ),
              // );
            }
          : post.type == 'follow'
              ? () async {
                  Get.toNamed("${FluroRouters.mainScreen}/profile/${post.userId}");
                  // Get.find<NewsfeedController>().isPostDetails = false;
                  // Get.find<NewsfeedController>().isTrendsScreen = false;
                  // Get.find<NewsfeedController>().isNewsFeedScreen = false;
                  // Get.find<NewsfeedController>().isBrowseScreen = false;
                  // Get.find<NewsfeedController>().isNotificationScreen = false;
                  // Get.find<NewsfeedController>().isChatScreen = false;
                  // Get.find<NewsfeedController>().isSavedPostScreen = false;
                  // Get.find<NewsfeedController>().isOtherUserProfileScreen =
                  //     true;
                  Get.find<NewsfeedController>().otherUserId = post.userId;

                  Get.find<NewsfeedController>().userInfo = UserProfile();
                  Get.find<NewsfeedController>().userInfo =
                      await Get.find<NewsfeedController>().getOtherUserProfile(
                          Get.find<NewsfeedController>().otherUserId);

                  await Get.find<OtherUserController>()
                      .filterUsersPostPagged("posts", page: 1);
                  Get.find<OtherUserController>().userPosts[0].mute =
                      Get.find<NewsfeedController>().userInfo?.muted ?? false;

                  Get.find<OtherUserController>().userPosts.forEach((element) {
                    element.mute =
                        Get.find<NewsfeedController>().userInfo.muted;
                  });
                  // Get.find<NewsfeedController>().otherUserName = post.senderName;
                  // Get.find<NewsfeedController>().update();
                  if (Get.isRegistered<OtherUserController>()) {
                    await Get.delete<OtherUserController>();
                  }
                  // if (controller.isSavedPostScreen) {
                  //   savedController.update();
                  // }
                  // if (controller.isBrowseScreen) {
                  //   browseController.update();
                  // }
                  // Get.find<NewsfeedController>().postDetail =
                  //     await Get.find<NewsfeedController>()
                  //         .getSingleNewsFeedItem(post.postId);
                  // Get.find<NewsfeedController>().fromNotificationsScreen = true;
                  Get.find<NewsfeedController>().update();
                }
              : () async {
                  // Get.find<NewsfeedController>().isPostDetails = true;
                  // Get.find<NewsfeedController>().isTrendsScreen = false;
                  // Get.find<NewsfeedController>().isNewsFeedScreen = false;
                  // Get.find<NewsfeedController>().isBrowseScreen = false;
                  // Get.find<NewsfeedController>().isNotificationScreen = false;
                  // Get.find<NewsfeedController>().isChatScreen = false;
                  // Get.find<NewsfeedController>().isSavedPostScreen = false;

                  Get.find<NewsfeedController>().postId = post.postId;
                  Get.find<NewsfeedController>().threadNumber = null;
                  SingleTone.instance.post_Id = post.postId;
                  Get.toNamed("${FluroRouters.mainScreen}/postDetail/${post.postId}");

                  //  controller.selectedPost = post;

                  // controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId, isReload: true);
                  // controller.update();

                  // if (controller.isSavedPostScreen) {
                  //   savedController.update();
                  // }
                  // if (controller.isBrowseScreen) {
                  //   browseController.update();
                  // }
                  // Get.find<NewsfeedController>().postDetail2 = await Get.find<NewsfeedController>().getSingleNewsFeedItem(post.postId,threadNumber: null);
                  Get.find<NewsfeedController>().fromNotificationsScreen = true;
                  //goto comment screen

                  Get.find<NewsfeedController>().update();
                },
      horizontalTitleGap: 20,
      contentPadding: const EdgeInsets.all(11),
      // trailing: Column(
      //   mainAxisAlignment: MainAxisAlignment.start,
      //   children: [Icon(Icons.more_horiz)],
      // ),
      leading: post.profileImage == null
          ? const Padding(
              padding: EdgeInsets.only(top: 5.0),
              child: CircleAvatar(
                  radius: 22,
                  backgroundImage:
                      AssetImage("assets/images/person_placeholder.png")),
            )
          : Padding(
              padding: const EdgeInsets.only(top: 0.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(25),
                child: FadeInImage(
                  fit: BoxFit.cover,
                  width: 40,
                  height: 40,
                  placeholder:
                      const AssetImage('assets/images/person_placeholder.png'),
                  image: NetworkImage(post.profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                ),
              ),
            ),
      // CircleAvatar(
      //   radius: 44,
      //   foregroundImage: controller
      //               .notificationList[index]
      //               .profileImage !=
      //           null
      //       ? NetworkImage(controller
      //           .notificationList[index].profileImage)
      //       :  AssetImage('assets/images/person_placeholder.png',),
      // ),
      title: SizedBox(
        // height: 24,
        child: Text(
          "${post.senderName} ${post.text}",
          // style: TextStyle(height: 1.2),
          style: Styles.baseTextTheme.headlineMedium.copyWith(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            fontSize: 15,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      subtitle: SizedBox(
        // height: 20,
        child: Text(
          DateFormat.yMMMMd('en_US').add_jm().format(post.createdAt),
          style: Styles.baseTextTheme.displayMedium.copyWith(
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Future<List<Notifications>> _fetchData(int page) async {
    // print("page____ $page");
    return await controller.getMentionedNotificationsPaged(page: page);
  }

// Widget buildNotificationShimmer(BuildContext context) => ListTile(
//       leading: CustomShimmerWidget.circular(height: 64, width: 64),
//       title: Column(
//         children: [
//           SizedBox(height: 20),
//           Align(
//             alignment: Alignment.centerLeft,
//             child: CustomShimmerWidget.rectangular(
//               height: 16,
//               width: MediaQuery.of(context).size.width * 0.3,
//             ),
//           ),
//           SizedBox(height: 12),
//           Align(
//             alignment: Alignment.centerLeft,
//             child: CustomShimmerWidget.rectangular(
//               height: 14,
//               width: MediaQuery.of(context).size.width * 0.2,
//             ),
//           ),
//         ],
//       ),
//     );
}
