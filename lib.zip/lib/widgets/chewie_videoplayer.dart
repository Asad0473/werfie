import 'dart:io';

import 'package:chewie/chewie.dart';
import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/utils/colors.dart';

import '../network/controller/news_feed_controller.dart';
import 'multi_manager/flick_multi_manager.dart';

class ChewieVideoPlayer extends StatefulWidget {
  ChewieVideoPlayer(
      {Key key,
      this.post,
      this.index,
      this.videoUrl,
      this.isAudio = false,
      this.aspectRatio,
      this.borderRadius = 15,
      this.allowFullScreen = true,
      this.isFullScreenOnMobile = false,
      this.thumbnailUrl,
      this.isQuoteWerfPlayer = false,
      this.quoteWerf,
      this.playPressed,
      this.fromChat = false,
      this.newsfeedController})
      : super(key: key);

  final Post post;
  final QuoteWerf quoteWerf;
  final int index;
  final String videoUrl;
  final bool isAudio;
  final double aspectRatio;
  final double borderRadius;
  final bool isFullScreenOnMobile;
  final bool isQuoteWerfPlayer;
  final allowFullScreen;
  final thumbnailUrl;
  Function() playPressed;
  final bool fromChat;
  final NewsfeedController newsfeedController;

  @override
  State<ChewieVideoPlayer> createState() => _ChewieVideoPlayerState();
}

class _ChewieVideoPlayerState extends State<ChewieVideoPlayer> {
  VideoPlayerController videoPlayerController;
  // ChewieController chewieController;
  FlickManager flickManager;
  FlickMultiManager flickMultiManager;
  FlickControlManager control;
  String videoUrl;
  Duration _currentPosition = Duration.zero;
  bool _isPlaying = false;
  double volumn = 0.0;
  bool isVideoVisible = true;
  double _volumeLevel = 0.5;
  bool showControls = kIsWeb?true:false;
  VideoPlayerController _videoController;
  ChewieController _chewieController;

  @override
  void initState() {
    // TODO: implement initState
    _initControllers();
    ServicesBinding.instance.keyboard.addHandler(_onKey);
    super.initState();
  }

  void _initControllers({double volumn = 0.0, bool isPlaying}) async {
    videoUrl = widget.isQuoteWerfPlayer
        ? widget.videoUrl != null
            ? widget.videoUrl
            : widget.quoteWerf.postFiles[widget.index]['file_path']
        : widget.videoUrl != null
            ? widget.videoUrl
            : widget.post.postFiles[widget.index]['file_path'];
    _videoController = VideoPlayerController.network(
      videoUrl,
    );

    // ..initialize().then((value) {
    //   _videoController.setVolume(volumn);
    //   _videoController.seekTo(_currentPosition);
    //   print("02 Chewie : _videoController initialize");
    //   setState(() {});
    // });
    await _videoController.initialize().then((value) {
      _videoController.setVolume(volumn);

      _videoController.seekTo(_currentPosition);
      setState(() {});
    });
    _chewieController = ChewieController(
      looping: true,
      videoPlayerController: _videoController,
      showControls: showControls,
      deviceOrientationsOnEnterFullScreen: [DeviceOrientation.portraitUp],
      // deviceOrientationsAfterFullScreen: [DeviceOrientation.portraitUp],
      hideControlsTimer: Duration(milliseconds: kIsWeb ? 500 : 3000),
      materialProgressColors: ChewieProgressColors(
          backgroundColor: Colors.grey,
          bufferedColor: Colors.grey,
          playedColor: Colors.white),
      cupertinoProgressColors: ChewieProgressColors(
          backgroundColor: Colors.grey,
          bufferedColor: Colors.grey,
          playedColor: Colors.white),
      placeholder: AspectRatio(
          aspectRatio: kIsWeb ? 16 / 11 : 16 / 18,
          child: Container(decoration: BoxDecoration(color: Colors.black))),
    )..addListener(_reInitListener);

    if (_isPlaying) {
      _chewieController.play();
    }

    // _videoController.addListener(reInitVideoManager);
  }

  void _reInitControllers() {
    _chewieController.removeListener(_reInitListener);
    _currentPosition = _videoController.value.position;
    _isPlaying = _chewieController.isPlaying;

    _initControllers(
        volumn: _videoController.value.volume, isPlaying: _isPlaying);
  }

  void _reInitListener() {
    debugPrint("chewie listener triggered");
    if (!_chewieController.isFullScreen) {
      print("small screen");
      kIsWeb ? _reInitControllers() : null;
    } else {
      print("full screen");
      kIsWeb
          ? Future.delayed(const Duration(milliseconds: 1000), () {
              // Here you can write your code for open new view
              _chewieController.play();
            })
          : Future.delayed(Duration(milliseconds: Platform.isIOS ? 1000 : 2500),
              () {
              // Here you can write your code for open new view
              _chewieController.play();
            });
      // _videoController.play();
    }
  }

  void reInitVideoManager() {
    // flickManager.flickVideoManager.videoPlayerController.seekTo(Duration(seconds: 0));
    // print("reInitVideoManager called");
    if (_videoController.value.position == _videoController.value.duration) {
      // print('video Ended');
      _chewieController.seekTo(Duration(seconds: 0));
      _chewieController.pause();
    }
  }

  @override
  void dispose() {
    // print("dispose called");
    /* flickManager.flickControlManager.pause();
    flickManager.flickVideoManager.videoPlayerController.pause();
    flickManager.flickVideoManager.dispose();*/
    _videoController.dispose();
    if(_chewieController!=null) {
      _chewieController.dispose();
    }
    ServicesBinding.instance.keyboard.removeHandler(_onKey);

    // videoPlayerController.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  //It will work fine in release mode but will through an error in debug mode
  bool _onKey(KeyEvent event) {
    final key = event.logicalKey.keyLabel;

    if (event is KeyDownEvent) {
      print("Key down: $key");
      if (key == "Escape") {
        // Get.back();
        //LoggingUtils.printValue("CHEW CONTROLLER IS FULL SCREE", _chewieController.isFullScreen);

        if (_chewieController.isFullScreen) {
          _chewieController.exitFullScreen();
        }
      }
    }

    return false;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.fromChat) {
      // In chats, when two videos are visible, they both play at the same time.
      // We are pausing the other videos expect the latest visible video.
      String currentURL = widget.newsfeedController != null
          ? widget.newsfeedController.currentlyPlayingVideoURLInChat
          : "";
      if (_chewieController != null &&
          currentURL != "" &&
          currentURL != widget.videoUrl &&
          this.mounted) {
        _chewieController.pause();
        isVideoVisible = false;
      }
    }

    return widget.isAudio
        //audio player
        ? ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: AspectRatio(aspectRatio: 16 / 9, child: Container()),
          )
        : ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: widget.isFullScreenOnMobile
                ? _videoController.value.isInitialized
                    ? VisibilityDetector(
                        key: ObjectKey(_chewieController),
                        onVisibilityChanged: (visibilityInfo) {
                          var visiblePercentage =
                              visibilityInfo.visibleFraction * 100;
                          debugPrint(
                              'Widget ${visibilityInfo.key} is ${visibilityInfo.visibleFraction}% visible');
                          if (visibilityInfo.visibleFraction <= 0.7 &&
                              this.mounted) {
                            // flickManager?.flickControlManager?.pause();//pausing  functionality
                            _chewieController.pause();
                            isVideoVisible = false;
                          } else if (visibilityInfo.visibleFraction == 1) {
                            if (widget.fromChat) {
                              // In chats, when two videos are visible, they both play at the same time.
                              // We are pausing the other videos expect the latest visible video.
                              widget.newsfeedController
                                      .currentlyPlayingVideoURLInChat =
                                  widget.videoUrl;
                              widget.newsfeedController.update();
                            }
                            isVideoVisible = true;
                            _chewieController.play();
                          }
                        },
                        child: AspectRatio(
                            aspectRatio: widget.aspectRatio == null
                                ? 16 / 18
                                : widget.aspectRatio,
                            child: GestureDetector(
                                onTap: () {
                                  if (!kIsWeb) {
                                    setState(() {
                                      _chewieController =
                                          _chewieController.copyWith(
                                        showControls: !showControls,
                                      );
                                    });
                                  }
                                },
                                child: Chewie(controller: _chewieController))))
                    : Center(
                        child: Stack(children: [
                          AspectRatio(
                              aspectRatio: widget.aspectRatio == null
                                  ? 16 / 18
                                  : widget.aspectRatio,
                              child: Container(
                                  decoration: BoxDecoration(
                                      color: Colors.black,
                                      borderRadius:
                                          BorderRadius.circular(15)))),
                          Positioned(
                            top: 0,
                            bottom: 0,
                            left: 0,
                            right: 0,
                            child: SpinKitCircle(
                              color: MyColors.werfieBlue,
                              size: 50.0,
                            ),
                          )
                        ]),
                      )

                // ],)
                : kIsWeb
                    ? VisibilityDetector(
                        key: ObjectKey(_chewieController),
                        onVisibilityChanged: (visibilityInfo) {
                          var visiblePercentage =
                              visibilityInfo.visibleFraction * 100;
                          debugPrint(
                              'Widget ${visibilityInfo.key} is ${visibilityInfo.visibleFraction}% visible');
                          if (visibilityInfo.visibleFraction <= 0.7 &&
                              this.mounted) {
                            // flickManager?.flickControlManager?.pause();//pausing  functionality
                            _chewieController.pause();
                            /*   setState(() {
              isVideoVisible=false;
            });*/
                          } else if (visibilityInfo.visibleFraction == 1) {
                            /*   setState(() {
              isVideoVisible=true;
            });*/
                            _chewieController.play();
                          }
                        },
                        child: Center(
                          child: AspectRatio(
                            aspectRatio: widget.aspectRatio == null
                                ? 16 / 11
                                : widget.aspectRatio,
                            child: _videoController.value.isInitialized
                                ? Chewie(controller: _chewieController)
                                : Center(
                                    child: Stack(children: [
                                      AspectRatio(
                                          aspectRatio:
                                              widget.aspectRatio == null
                                                  ? 16 / 11
                                                  : widget.aspectRatio,
                                          child: Container(
                                              decoration: const BoxDecoration(
                                                  color: Colors.black))),
                                      Positioned(
                                          top: 0,
                                          bottom: 0,
                                          left: 0,
                                          right: 0,
                                          child: SpinKitCircle(
                                            color: MyColors.werfieBlue,
                                            size: 50.0,
                                          ))
                                    ]),
                                  ),
                          ),
                        ),
                      )
                    : SizedBox(),
          );
  }
}

/*isVideoVisible? Chewie(controller: _chewieController)
                :  Center(
              child:
              AspectRatio(
                  aspectRatio: widget.aspectRatio == null
                      ?  16 / 11
                      : widget.aspectRatio,
                  child:Container(
                      decoration: BoxDecoration(color: Colors.black)
                  )
              ),


            )*/
