import 'dart:convert';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/components/input_field.dart';
import 'package:werfieapp/components/input_password_field.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/models/GetCountriesResponse.dart' as cr;
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../dummy_data.dart';
import '../network/controller/news_feed_controller.dart';
import '../network/controller/profile_controller.dart';
import '../network/singleTone.dart';
import '../screens/main_screen.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';

// ignore: must_be_immutable
class SignUpForm extends StatefulWidget {
  LoginController controller;

  SignUpForm({this.controller});

  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  State<SignUpForm> createState() => _SignUpFormState();
}

class _SignUpFormState extends State<SignUpForm> {
  TextEditingController textControllor = TextEditingController();
  TextEditingController confirmPassController = TextEditingController();

  /// controller used in profile picture feature
  // final DummyData dummyDataController = Get.put(DummyData());
  // final profileController = Get.put(ProfileController());
  // final newsFeedController = Get.put(NewsfeedController());

  double _strength = 0;

  RegExp regExpMedium = RegExp(r'^(?=.*[A-Z])(?=.*\d).+$');
  RegExp regExpStrong = RegExp(r'^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=]).+$');
  RegExp emailregExp =
      RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');

  SharedPreferences shared;
  bool isCheckedGlobal = false;
  // String name;
  final storage = GetStorage();
//bool formValidation =false;
  String name = '';
  String werfieHandle = '';
  String email = '';
  String password = '';
  String confirmPassword = '';
  dynamic country = '';
  bool countryCheck = false;
  bool errorText = false;
  String get nameError {
    final text = widget.controller.firstName.text;
    if (text.length == 0) {
      return Strings.nameCannotBeEmpty;
    }
    // else if ( !RegExp('[a-zA-Z]+[ a-zA-Z]*').hasMatch(text)) {
    //        return "Name start with must be Alphabets ";
    //      }
    else if (text.length > 20) {
      return Strings.nameLengthShouldMax20;
    }
    return null;
  }

  String get userNameError {
    final text = widget.controller.username.text;
    if (text.isEmpty) {
      return Strings.werfieHandleIsRequired;
      // } else if (!RegExp('[a-zA-Z]+[ a-zA-Z]*').hasMatch(text)) {
    } else if (!RegExp(r'^[a-zA-Z0-9_]{4,15}$').hasMatch(text)) {
      return Strings.nameStartsWithCharacter;
    }
    return null;
  }

  String get emailError {
    final text = widget.controller.signupEmail.text;
    if (text.isEmpty) {
      return Strings.emailFieldCannotBeEmpty;
    } else if (!RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(text)) {
      return Strings.pleaseProvideAValidEmail;
    } else
      return null;
  }

  String get passwordError {
    final text = widget.controller.signupPassword.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8) {
      return Strings.passwordShouldBeMin8Char;
    } /*else if (emailregExp.hasMatch(password)) {
      return Strings.cantChooseEmailAsApass;
    } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (widget.controller.signupPassword.text !=
        widget.controller.signupPasswordCon.text) {
      return Strings.bothPasswordAndConfirmPassShouldMatch;
    }
    else if(_strength==0.5){
      return Strings.yourPasswordIsWeak;
    }*/
    else
      return null;
  }

  String get confirmPasswordErr {
    final text = widget.controller.signupPasswordCon.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8 ) {
      return Strings.passwordShouldBeMin8Char;
    } /*else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (widget.controller.signupPassword.text !=
        widget.controller.signupPasswordCon.text) {
      return Strings.bothPasswordAndConfirmPassShouldMatch;
    }
    else if(_strength==0.5){
      return Strings.yourPasswordIsWeak;
    }*/
    else
      return null;
  }



  void _checkPassword(String value) {
    password = value.trim();

    if (password.isEmpty) {
      setState(() {
        _strength = 0;
      });
    } else if (password.length > 7 &&
        regExpMedium.hasMatch(password) &&
        !regExpStrong.hasMatch(password)) {
      setState(() {
        _strength = 0.5;
      });
    } else if (password.length > 7 && regExpStrong.hasMatch(password)) {
      setState(() {
        _strength = 1;
      });
    } else {
      setState(() {
        _strength = 0.3;
      });
    }
  }

  /// this function is used to get profile image
  /*
  Future<Uint8List> callGetImage({String imageType}) async {
    Uint8List image;
    var img = await dummyDataController.getImage();

    if(!kIsWeb && imageType != null && imageType == "cover"){
      CroppedFile croppedFile = await ImageCropper().cropImage(
        sourcePath: img.path,
        aspectRatio: const CropAspectRatio(ratioX: 16, ratioY: 9),
        aspectRatioPresets: [
          // CropAspectRatioPreset.square,
          // CropAspectRatioPreset.ratio3x2,
          // CropAspectRatioPreset.original,
          // CropAspectRatioPreset.ratio4x3,
          CropAspectRatioPreset.ratio16x9
        ],
        uiSettings: [
          AndroidUiSettings(
              toolbarTitle: '',
              toolbarColor: Colors.deepOrange,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: true),
          IOSUiSettings(
            title: '',
            aspectRatioLockEnabled: true,
          ),
          // WebUiSettings(
          //   context: context,
          // ),
        ],
      );
      image = await croppedFile?.readAsBytes();
      return image;
    }

    image = await img?.readAsBytes();

    // pickedMedia = await dataController.getImageWeb();
    // _pickedImage.add(imageBytes);
    // print("img ${image}");
    print('NAHI ATA IDHAR');

    // if (_pickedImage != null) {
    //   print('I D H A R A J A T A H A I');
    //   isMediaAttached = true;
    //
    //   setState(() {});
    // }
    return image;
  }

   */


  @override
  void initState() {
    widget.controller.chosenValue = null;
    widget.controller.countryId = null;
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          //SizedBox(height: 15),
          kIsWeb
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      Strings.signUp,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                      // style: Theme.of(context).textTheme.headline4.copyWith(
                      //       fontWeight: FontWeight.normal,
                      //     ),
                    ),
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Container(
                    width: 200,
                    // height: 150,
                    // color: Colors.grey,
                    child: Image.asset(
                      AppImages.logo,
                    ),
                  ),
                ),
          !kIsWeb
              ? Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      Strings.signUp,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22,
                      ),
                      // style: Theme.of(context).textTheme.headline4.copyWith(
                      //       fontWeight: FontWeight.normal,
                      //     ),
                    ),
                  ),
                )
              : SizedBox.shrink(),
          Form(
            key: SignUpForm.formKey,
            // autovalidateMode: formValidation?
            // AutovalidateMode.onUserInteraction:
            // AutovalidateMode.disabled ,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /// profile image
                // _addProfileImageView(),

                ///name
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): EnterYourFirstName(),
                  },
                  child: Actions(
                    actions: {
                      EnterYourFirstName:
                          CallbackAction<EnterYourFirstName>(onInvoke: (_) {
                        widget.controller.focus1.unfocus();
                        FocusScope.of(context)
                            .requestFocus(widget.controller.focus2);
                      }),
                    },
                    child: Container(
                      //  height: 55,
                      child: errorText == false
                          ? InputField(
                              focusNode: widget.controller.focus1,
                              TextInputAction: TextInputAction.next,
                              onChanged: (value) {
                                setState(() {
                                  name = value;
                                });
                              },
                              hint: Strings.enterYourFirstName,
                              validator: (value) {
                                return UtilsMethods.validateField(
                                    value, "Name");
                              },
                              controller: widget.controller.firstName,
                              formatter: [
                                LengthLimitingTextInputFormatter(20),
                                FilteringTextInputFormatter.deny("@"),
                              ],
                              textInputType: TextInputType.name,
                              fieldIcon: Icons.person,
                            )
                          : ValueListenableBuilder(
                              valueListenable: widget.controller.firstName,
                              // builder: ( BuildContext context,TextEditingValue value,__),
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return InputField(
                                  focusNode: widget.controller.focus1,
                                  TextInputAction: TextInputAction.next,
                                  onChanged: (value) {
                                    setState(() {
                                      name = value;
                                    });
                                  },
                                  hint: Strings.enterYourFirstName,
                                  // onValueEntered: (value) {
                                  //   controller.firstName = value;
                                  // },
                                  errorText: nameError,

                                  validator: (value) {
                                    return UtilsMethods.validateField(
                                        value, "Name");
                                  },
                                  controller: widget.controller.firstName,
                                  formatter: [
                                    LengthLimitingTextInputFormatter(20),
                                    // FilteringTextInputFormatter.allow(
                                    //     RegExp('[a-zA-Z]+[ a-zA-Z]*'))
                                    FilteringTextInputFormatter.deny("@"),
                                  ],
                                  textInputType: TextInputType.name,
                                  fieldIcon: Icons.person,
                                );
                              },
                            ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 12.0, top: 4.0),
                  child: const Text(
                    '(e.g. John Smith)',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),

                SizedBox(height: 5),

                /// Werfie hhandel
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab):
                        EnterYourWerifeHandle(),
                  },
                  child: Actions(
                    actions: {
                      EnterYourWerifeHandle:
                          CallbackAction<EnterYourWerifeHandle>(onInvoke: (_) {
                        widget.controller.focus2.unfocus();
                        FocusScope.of(context)
                            .requestFocus(widget.controller.focus3);
                      }),
                    },
                    child: Container(
                      // height: 55,
                      child: errorText == false
                          ? InputField(
                              focusNode: widget.controller.focus2,
                              nextInputField: widget.controller.focus3,
                              TextInputAction: TextInputAction.next,
                              formatter: [
                                LengthLimitingTextInputFormatter(20),
                                // FilteringTextInputFormatter.allow(
                                //     RegExp('[a-zA-Z]+[ a-zA-Z]*')),
                                // FilteringTextInputFormatter.deny(RegExp(r'[0-9]')),
                                FilteringTextInputFormatter.deny('@'),
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[a-z A-Z 0-9_]')),
                                FilteringTextInputFormatter.deny(RegExp(r'\s')),
                              ],
                              hint: Strings.createYourWerfieHandle,
                              controller: widget.controller.username,
                              onChanged: (value) {
                                setState(() {
                                  werfieHandle = value;
                                });
                              },
                              validator: (value) {
                                return UtilsMethods.validateField(
                                    value, 'Username');
                              },
                              textInputType: TextInputType.name,
                              fieldIcon: FontAwesomeIcons.userTag,
                            )
                          : ValueListenableBuilder(
                              valueListenable: widget.controller.username,
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return InputField(
                                  focusNode: widget.controller.focus2,
                                  nextInputField: widget.controller.focus3,
                                  TextInputAction: TextInputAction.next,
                                  formatter: [
                                    LengthLimitingTextInputFormatter(20),
                                    // FilteringTextInputFormatter.allow(
                                    //     RegExp('[a-zA-Z]+[ a-zA-Z]*')),
                                    // FilteringTextInputFormatter.deny(RegExp(r'[0-9]')),
                                    FilteringTextInputFormatter.deny('@'),
                                    FilteringTextInputFormatter.allow(
                                        RegExp('[a-z A-Z 0-9_]')),
                                    FilteringTextInputFormatter.deny(
                                        RegExp(r'\s')),
                                  ],
                                  hint: Strings.createYourWerfieHandle,
                                  controller: widget.controller.username,
                                  onChanged: (value) {
                                    setState(() {
                                      werfieHandle = value;
                                    });
                                  },
                                  errorText: userNameError,
                                  validator: (value) {
                                    return UtilsMethods.validateField(
                                        value, 'Username');
                                  },
                                  textInputType: TextInputType.name,
                                  fieldIcon: FontAwesomeIcons.userTag,
                                );
                              },
                            ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 12.0, top: 4.0),
                  child: const Text(
                    '(e.g. johnsmith123)',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
                SizedBox(height: 5),

                /// Email
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): EnterYourEmail(),
                  },
                  child: Actions(
                    actions: {
                      EnterYourEmail:
                          CallbackAction<EnterYourEmail>(onInvoke: (_) {
                        widget.controller.focus3.unfocus();
                        FocusScope.of(context)
                            .requestFocus(widget.controller.focus4);
                      }),
                    },
                    child: Container(
                      //  height: 55,
                      child: errorText == false
                          ? InputField(
                              focusNode: widget.controller.focus3,
                              nextInputField: widget.controller.focus4,
                              TextInputAction: TextInputAction.next,
                              onChanged: (value) {
                                setState(() {
                                  email = value;
                                });
                              },
                              hint: Strings.enterYourEmail,
                              controller: widget.controller.signupEmail,
                              validator: (value) {
                                return UtilsMethods.validateEmail(value);
                              },
                              textInputType: TextInputType.emailAddress,
                              fieldIcon: Icons.email,
                            )
                          : ValueListenableBuilder(
                              valueListenable: widget.controller.signupEmail,
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return InputField(
                                  focusNode: widget.controller.focus3,
                                  nextInputField: widget.controller.focus4,
                                  TextInputAction: TextInputAction.next,
                                  onChanged: (value) {
                                    setState(() {
                                      email = value;
                                    });
                                  },
                                  hint: Strings.enterYourEmail,
                                  controller: widget.controller.signupEmail,
                                  // onValueEntered: (value) {
                                  //   controller.signupEmail = value;
                                  // },

                                  errorText: emailError,
                                  validator: (value) {
                                    return UtilsMethods.validateEmail(value);
                                  },
                                  textInputType: TextInputType.emailAddress,
                                  fieldIcon: Icons.email,
                                );
                              }),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 12.0, top: 4.0),
                  child: const Text(
                    '(e.g. johnsmith@example.com)',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
                SizedBox(height: 5),

                /// password
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): EnterYourPassword(),
                  },
                  child: Actions(
                    actions: {
                      EnterYourPassword:
                          CallbackAction<EnterYourPassword>(onInvoke: (_) {
                        widget.controller.focus4.unfocus();
                        FocusScope.of(context)
                            .requestFocus(widget.controller.confirmPassNode);
                      }),
                    },
                    child: Container(
                      //  height: 55,
                      child: errorText == false
                          ? InputPasswordField(
                              focusNode: widget.controller.focus4,
                              nextNode: widget.controller.focus9,
                              TextInputAction: TextInputAction.next,
                              text: Strings.createYourPassword,
                              controller: widget.controller.signupPassword,
                              onChanged: (value) {
                                password = value;
                                //_checkPassword(password);
                              },
                              validator: (value) {
                                return UtilsMethods.validatePassword(value);
                              },
                            )
                          : ValueListenableBuilder(
                              valueListenable: widget.controller.signupPassword,
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return InputPasswordField(
                                  focusNode: widget.controller.focus4,
                                  nextNode: widget.controller.focus9,
                                  TextInputAction: TextInputAction.next,
                                  text: Strings.createYourPassword,
                                  controller: widget.controller.signupPassword,
                                  onChanged: (value) {
                                    password = value;
                                    _checkPassword(password);
                                  },
                                  // onPasswordEntered: (value) {
                                  //   controller.signupPassword = value;
                                  // },
                                  errorText: passwordError,
                                  // errorText: errorPassword,
                                  validator: (value) {
                                    return UtilsMethods.validatePassword(value);
                                  },
                                );
                              },
                            ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
               /* Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: SizedBox(
                    // width: 160,
                    child: ClipRRect(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                      child: LinearProgressIndicator(
                        value: _strength,
                        backgroundColor: Colors.white,
                        color: _strength == 0.3
                            ? Colors.red
                            : _strength == 0.5
                                ? Colors.yellow
                                : _strength == 1
                                    ? Colors.green
                                    : Colors.red,
                        minHeight: 5,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 4),

                Padding(
                  padding: const EdgeInsets.only(left: 20.0, bottom: 10.0),
                  child: _strength == 0.3
                      ? Text(
                          Strings.chooseASecurePassword,
                          style: TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                              fontSize: 14),
                        )
                      : _strength == 0.5
                          ? Text(
                              Strings.yourPasswordIsWeakSignUP,
                              style: TextStyle(
                                  color: Colors.amber,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14),
                            )
                          : _strength == 1
                              ? Text(
                                  Strings.yourPasswordIsStrong,
                                  style: TextStyle(
                                      color: Colors.green,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14),
                                )
                              : SizedBox(),
                ),*/

                /// confirm password
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab):
                        ConfirmYourPassword(),
                  },
                  child: Actions(
                    actions: {
                      ConfirmYourPassword:
                          CallbackAction<ConfirmYourPassword>(onInvoke: (_) {
                        widget.controller.confirmPassNode.unfocus();
                        FocusScope.of(context)
                            .requestFocus(widget.controller.focus5);
                      }),
                    },
                    child: Container(
                      //  height: 55,
                      child: errorText == false
                          ? InputPasswordField(
                              focusNode: widget.controller.confirmPassNode,
                              nextNode: widget.controller.focus9,
                              TextInputAction: TextInputAction.next,
                              text: Strings.confirmYourPasswords,
                              controller: widget.controller.signupPasswordCon,
                              onChanged: (value) {
                                confirmPassword = value;
                              },
                              validator: (value) {
                                return UtilsMethods.validatePassword(value);
                              },
                            )
                          : ValueListenableBuilder(
                              valueListenable:
                                  widget.controller.signupPasswordCon,
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return InputPasswordField(
                                  focusNode: widget.controller.confirmPassNode,
                                  nextNode: widget.controller.focus9,
                                  TextInputAction: TextInputAction.next,
                                  text: Strings.confirmYourPasswords,
                                  controller:
                                      widget.controller.signupPasswordCon,
                                  onChanged: (value) {
                                    confirmPassword = value;
                                  },
                                  // onPasswordEntered: (value) {
                                  //   controller.signupPassword = value;
                                  // },
                                  errorText: confirmPasswordErr,
                                  // errorText: errorPassword,
                                  validator: (value) {
                                    return UtilsMethods.validatePassword(value);
                                  },
                                );
                              },
                            ),
                    ),
                  ),
                ),

                const SizedBox(
                  height: 5,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 12.0, top: 4.0),
                  child: const Text(
                    '(Should contain at least 8 characters)',
                    maxLines: 2,
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),

                SizedBox(height: 5),

                /// country code
                Shortcuts(
                    shortcuts: {
                      LogicalKeySet(LogicalKeyboardKey.tab):
                          ChooseYourCountry(),
                    },
                    child: Actions(
                        actions: {
                          ChooseYourCountry:
                              CallbackAction<ChooseYourCountry>(onInvoke: (_) {
                            widget.controller.focus5.unfocus();
                            FocusScope.of(context)
                                .requestFocus(widget.controller.focus6);
                          }),
                        },
                        child: Container(
                          child: CountryDropDown(
                            widget.controller.list,
                            widget.controller.countryId,
                            errorText,
                            context,
                            widget.controller,
                            (p0) => null ? Strings.youMustSelectACountry : null,
                            textControllor,
                          ),
                          // child: CountryDropDown(),
                        ))),
                SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Text(
                    Strings.enterYourBirthDateOptional,
                    style: TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
                  ),
                ),
                SizedBox(height: 10),

                ///date
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Drop Down Button for Month
                    ButtonTheme(
                      materialTapTargetSize: MaterialTapTargetSize.padded,
                      child: Expanded(
                        flex: 2,
                        child: DropdownButtonFormField<String>(
                          icon: Icon(Icons.keyboard_arrow_down),
                          isExpanded: true,
                          // validator: (value) =>
                          //     value == null ? 'field required' : null,

                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[250],
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 16),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            errorBorder: OutlineInputBorder(),
                            labelText: 'Month',
                            labelStyle: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                            ),
                          ),
                          // value: 0.toString(),
                          hint: Text(
                            Strings.mm,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.grey,
                              fontSize: kIsWeb ? 14 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),

                          alignment: Alignment.bottomCenter,
                          items: widget.controller.months.map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                value.toString(),
                                style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                            );
                          }).toList(),
                          onChanged: (month) {
                            widget.controller.selectedMonth = month;
                            widget.controller.update();
                          },
                        ),
                      ),
                    ),
                    SizedBox(width: 12),
                    // Drop Down Button for Day
                    ButtonTheme(
                      materialTapTargetSize: MaterialTapTargetSize.padded,
                      child: Expanded(
                        flex: 1,
                        child: DropdownButtonFormField<String>(
                          icon: Icon(Icons.keyboard_arrow_down),
                          isExpanded: true,
                          // validator: (value) =>
                          //     value == null ? 'field required' : null,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[250],
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 16),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            labelText: 'Day',
                            labelStyle: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                            ),
                          ),
                          // value: 0.toString(),
                          hint: Text(
                            Strings.dd,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.grey,
                              fontSize: kIsWeb ? 12 : 12,
                              fontWeight: FontWeight.w500,
                            ),
                            // DateTime.now().day.toString(),
                            // controller.selectedDay.isEmpty ? controller.DayDob() : " ",
                          ),
                          //hint: Text(controller.selectedDay),
                          alignment: Alignment.bottomCenter,
                          items: List.generate(31, (index) => index + 1)
                              .map((int value) {
                            return DropdownMenuItem<String>(
                              value: value.toString(),
                              child: Text(
                                value.toString(),
                                style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                            );
                          }).toList(),
                          onChanged: (day) {
                            widget.controller.selectedDay = day;

                            widget.controller.update();
                            // }
                            // }
                          },
                        ),
                      ),
                    ),

                    SizedBox(width: 12),

                    // Drop Down Button for Year

                    ButtonTheme(
                      materialTapTargetSize: MaterialTapTargetSize.padded,
                      child: Expanded(
                        flex: 1,
                        child: DropdownButtonFormField<String>(
                          icon: Icon(Icons.keyboard_arrow_down),
                          isExpanded: true,
                          // validator: (value) =>
                          //     value == null ? 'field required' : null,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[250],
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 12),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: Colors.grey),
                            ),
                            labelText: 'Year',
                            labelStyle: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                            ),
                          ),
                          // value: 0.toString(),
                          hint: Text(
                            Strings.yyyy,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.grey,
                              fontSize: kIsWeb ? 14 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                            // DateTime.now().year.toString(),
                            //  ""
                            // controller.selectedYear.isEmpty ?  controller.YearDob() : " ",
                          ),
                          //hint: Text(controller.selectedYear),
                          alignment: Alignment.bottomCenter,
                          items: widget.controller.years.map((int value) {
                            return DropdownMenuItem<String>(
                              value: value.toString(),
                              child: Text(
                                value.toString(),
                                style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                            );
                          }).toList(),
                          onChanged: (year) {
                            // controller.selectedYearValue = year;
                            // controller.scheduleYearValue = year;
                            // controller.selectedDateTime = "$controller.selectedYearValue-$controller.selectedMonthValue-$controller.selectedDayValue" + " $controller.selectedHourValue:$controller.selectedMinutesValue:00";
                            //
                            // print('Scheduled Year ' +       controller.scheduleYearValue.toString());
                            widget.controller.selectedYear = year;
                            widget.controller.update();
                            // pollDays = days;
                            // setState(() {});
                          },
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 20),

                Obx(() {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Shortcuts(
                        shortcuts: {
                          LogicalKeySet(LogicalKeyboardKey.tab):
                              CheckBoxWidget(),
                        },
                        child: Actions(
                          actions: {
                            CheckBoxWidget:
                                CallbackAction<CheckBoxWidget>(onInvoke: (_) {
                              widget.controller.focus6.unfocus();
                              FocusScope.of(context)
                                  .requestFocus(widget.controller.focus7);
                            }),
                          },
                          child: Theme(
                            data: ThemeData(
                              unselectedWidgetColor:
                                  widget.controller.checkBoxColor.value == true
                                      ? Colors.red
                                      : Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                            ),
                            child: RawKeyboardListener(
                              focusNode: widget.controller.CheckBoxFocusNode,
                              onKey: (RawKeyEvent event) {
                                if (event.logicalKey ==
                                    LogicalKeyboardKey.enter) {
                                  if (widget.controller.termAndPrivacyCheck
                                          .value ==
                                      false) {
                                    widget.controller.termAndPrivacyCheck
                                        .value = true;

                                    // print(".....assas1231231");
                                    widget.controller.checkBoxColor.value =
                                        false;
                                  } else if (widget.controller
                                          .termAndPrivacyCheck.value ==
                                      true) {
                                    // print(".....assas1");
                                    widget.controller.termAndPrivacyCheck
                                        .value = false;
                                    widget.controller.update();
                                  }
                                }
                              },
                              child: Checkbox(
                                activeColor: Colors.blue,
                                onChanged: (bool value) {
                                  if (widget.controller.termAndPrivacyCheck
                                          .value ==
                                      false) {
                                    widget.controller.termAndPrivacyCheck
                                        .value = true;

                                    // print(".....assas1231231");
                                    widget.controller.checkBoxColor.value =
                                        false;
                                  } else if (widget.controller
                                          .termAndPrivacyCheck.value ==
                                      true) {
                                    // print(".....assas1");
                                    widget.controller.termAndPrivacyCheck
                                        .value = false;
                                    widget.controller.update();
                                  }
                                },
                                focusNode: widget.controller.focus6,
                                value:
                                    widget.controller.termAndPrivacyCheck.value,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: kIsWeb ? 10 : 0),
                      Flexible(
                        child: RichText(
                          maxLines: 2,
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: '${Strings.bySigningUpYouAgree} ',
                                style: TextStyle(color: Colors.black),
                              ),
                              TextSpan(
                                text: Strings.termsOfService,
                                style: TextStyle(
                                    color: MyColors.black,
                                    fontWeight: FontWeight.bold),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    launchUrl(Uri.parse(
                                        'https://api.werfie.com/terms'));
                                  },
                              ),
                              TextSpan(
                                text: ' ${Strings.and} ',
                                style: TextStyle(color: Colors.black),
                              ),
                              TextSpan(
                                text: Strings.privacyPolicy,
                                style: TextStyle(
                                    color: MyColors.black,
                                    fontWeight: FontWeight.bold),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    launchUrl(Uri.parse(
                                        'https://api.werfie.com/privacy'));
                                  },
                              ),
                            ],
                          ),
                        ),
                      ),
                      // Container(
                      //     // child: RichText(
                      //     //   overflow: TextOverflow.clip,
                      //     //
                      //     //   // Controls how the text should be aligned horizontally
                      //     //   textAlign: TextAlign.end,
                      //     //
                      //     //   // Control the text direction
                      //     //   textDirection: TextDirection.rtl,
                      //     //
                      //     //   // Whether the text should break at soft line breaks
                      //     //   softWrap: true,
                      //     //   text: TextSpan(
                      //     //     text: 'By signing up, you agree our ',
                      //     //     style: TextStyle(
                      //     //       fontSize: 14,
                      //     //       fontWeight: FontWeight.w500,
                      //     //       color: controller.checkBoxColor == true
                      //     //           ? Colors.red
                      //     //           : Theme
                      //     //           .of(context)
                      //     //           .brightness == Brightness.dark
                      //     //           ? Colors.white
                      //     //           : Colors.black,
                      //     //
                      //     //     ),
                      //     //     // style: DefaultTextStyle.of(context).style,
                      //     //     children: <TextSpan>[
                      //     //       TextSpan(
                      //     //           text: 'Terms of Service ',
                      //     //           style: TextStyle(
                      //     //             fontWeight: FontWeight.bold,
                      //     //             // decoration: TextDecoration.underline,
                      //     //             fontSize: 14,
                      //     //             color: controller.checkBoxColor == true
                      //     //                 ? Colors.red
                      //     //                 : Theme
                      //     //                 .of(context)
                      //     //                 .brightness == Brightness.dark
                      //     //                 ? Colors.white
                      //     //                 : Colors.black,
                      //     //
                      //     //           ),
                      //     //           recognizer: TapGestureRecognizer()
                      //     //             ..onTap = () async {
                      //     //               var url = "https://api.werfie.com/terms";
                      //     //               // if (await canLaunch(url))
                      //     //               await launch(url);
                      //     //             }
                      //     //       ),
                      //     //       TextSpan(
                      //     //           text: ' and ',
                      //     //           style: TextStyle(
                      //     //             fontSize: 14,
                      //     //             fontWeight: FontWeight.w500,
                      //     //             color: controller.checkBoxColor == true
                      //     //                 ? Colors.red
                      //     //                 : Theme
                      //     //                 .of(context)
                      //     //                 .brightness == Brightness.dark
                      //     //                 ? Colors.white
                      //     //                 : Colors.black,
                      //     //             // fontWeight: FontWeight.bold
                      //     //           )),
                      //     //       TextSpan(
                      //     //           text: ' Privacy Policy',
                      //     //           style: TextStyle(
                      //     //             fontWeight: FontWeight.bold,
                      //     //             // decoration: TextDecoration.underline,
                      //     //             fontSize: 14,
                      //     //             color: controller.checkBoxColor == true
                      //     //                 ? Colors.red
                      //     //                 : Theme
                      //     //                 .of(context)
                      //     //                 .brightness == Brightness.dark
                      //     //                 ? Colors.white
                      //     //                 : Colors.black,
                      //     //           ),
                      //     //           recognizer: TapGestureRecognizer()
                      //     //             ..onTap = () async {
                      //     //               var url = "https://api.werfie.com/privacy";
                      //     //               // if (await canLaunch(url))
                      //     //               await launch(url);
                      //     //             }
                      //     //       ),
                      //     //     ],
                      //     //   ),
                      //     // )
                      //   child: Column(
                      //     children: [
                      //       Row(
                      //         children: [
                      //
                      //         ],
                      //       ),
                      //     ],
                      //   ),
                      //
                      //
                      // ),
                      // // Text("By signing up, you agree to the,"),
                      // // Text("Terms of Service"),
                      // // Text("and"),
                      // // Text("Privacy Policy,"),
                    ],
                  );
                }),
                SizedBox(
                  height: 15,
                ),
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): SignUPButton(),
                  },
                  child: Actions(
                    actions: {
                      SignUPButton: CallbackAction<SignUPButton>(onInvoke: (_) {
                        widget.controller.focus9.unfocus();
                        FocusScope.of(context)
                            .requestFocus(widget.controller.focus1);
                      }),
                    },
                    child: Container(
                      width: Get.width,
                      child: RawKeyboardListener(
                        focusNode: widget.controller.SignUpFocusNode,
                        onKey: (RawKeyEvent event) async {
                          if (event.logicalKey == LogicalKeyboardKey.enter) {
                            if (widget.controller.termAndPrivacyCheck.value ==
                                false) {
                              widget.controller.checkBoxColor.value = true;
                              widget.controller.update();
                            }
                            if (name.isNotEmpty &&
                                werfieHandle.isNotEmpty &&
                                email.isNotEmpty &&
                                password.isNotEmpty &&
                                confirmPassword.isNotEmpty &&
                                countryCheck == true) {
                              if (SignUpForm.formKey.currentState.validate() &&
                                  widget.controller.chosenValue != null &&
                                  widget.controller.termAndPrivacyCheck ==
                                      true) {
                                SignUpForm.formKey.currentState.save();

                                // if (widget.controller.selectedMonth.isNotEmpty && widget.controller.selectedYear.isNotEmpty && widget.controller.selectedDay.isNotEmpty) {
                                //
                                //
                                // }
                                //
                                //   DateTime noDate = DateTime.now();
                                //   int newYear = noDate.year;
                                //   int selectedYear =
                                //   int.parse(widget.controller.selectedYear);
                                //   int difference = newYear - selectedYear;
                                //   print('dateDifference:${difference}');
                                //if (difference >= 13)
                                //{

                                showDialog(
                                    barrierDismissible: false,
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        backgroundColor:
                                            Color(0xFFFFFFFF).withOpacity(0.2),
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(10.0))),
                                        insetPadding: EdgeInsets.symmetric(
                                            horizontal: 0, vertical: 0),
                                        contentPadding: EdgeInsets.zero,
                                        content: Container(
                                          height: 100,
                                          width: 80,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              SpinKitCircle(
                                                color: Theme.of(context)
                                                    .primaryColor,
                                                size: 50.0,
                                              ),
                                              Text(
                                                Strings.pleaseWait,
                                                style: TextStyle(
                                                    color: Colors.white),
                                              )
                                            ],
                                          ),
                                        ),
                                      );
                                    });

                                var response = await widget.controller
                                    .register(queryParameters: {
                                  "firstname": widget.controller.firstName.text,
                                  "lastname": '',
                                  "username": widget.controller.username.text,
                                  "password":
                                      widget.controller.signupPassword.text,
                                  "password_confirmation":
                                      widget.controller.signupPassword.text,
                                  "email": widget.controller.signupEmail.text,
                                  "country_id":
                                      widget.controller.countryId.toString(),
                                  "dob":
                                      widget.controller.selectedMonth
                                                  .isNotEmpty &&
                                              widget.controller.selectedYear
                                                  .isNotEmpty &&
                                              widget.controller.selectedDay
                                                  .isNotEmpty
                                          ? widget.controller
                                              .functionStoreDate()
                                          : "",
                                }, token: {
                                  "Authorization": "Bearer ${Url.webAPIKey}",
                                  "X-Requested-With": "XMLHttpRequest"
                                });
                                // print("responseeeeee  ${response.toString()}");
                                var jsonResponse =
                                    jsonDecode(response.toString());

                                // print("jsonResponse $jsonResponse");

                                if (jsonResponse['errors'] != null &&
                                    jsonResponse['errors']['email'][0] ==
                                        "The email has already been taken.") {
                                  Navigator.pop(context);
                                  showDialog(
                                      barrierDismissible: false,
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(10.0))),
                                          insetPadding: EdgeInsets.symmetric(
                                              horizontal: 0, vertical: 0),
                                          contentPadding: EdgeInsets.zero,
                                          content: Container(
                                            height: 200,
                                            width: 300,
                                            padding: EdgeInsets.symmetric(
                                              horizontal: 20,
                                              vertical: 10,
                                            ),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Text(Strings
                                                    .snAccountHasAlreadyBeenCreatedWithThisEmail),
                                                TextButton(
                                                  onPressed: () {
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    Strings.goBack,
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                } else {
                                  var responseCode =
                                      jsonResponse['meta']['code'];
                                  var userName =
                                      jsonResponse['data']['username'];
                                  var token = jsonResponse['data']['token'];
                                  // print("token : $token");
                                  var userId = jsonResponse['data']['id'];

                                  var email = jsonResponse['data']['email'];

                                  shared =
                                      await SharedPreferences.getInstance();
                                  // DialogBuilder(context).hideOpenDialog();

                                  if (responseCode == 200) {
                                    shared.setString("token", token.toString());
                                    shared.setString(
                                        "userName", userName.toString());

                                    shared.setString("email", email.toString());

                                    storage.write("email", email.toString());

                                    shared.setBool('guestUser', true);
                                    shared.setBool('socialLogin', false);
                                    storage.write('id', userId);
                                    storage.write("token", token.toString());

                                    storage.write("CurrentEmail",
                                        widget.controller.signupEmail.text);
                                    storage.write(
                                        "userName", userName.toString());

                                    storage.write("remember", isCheckedGlobal);

                                    widget.controller.signupEmail.clear();
                                    widget.controller.signupPassword.clear();
                                    widget.controller.generateFCMToken(context);
                                    Get.put(NewsfeedController(
                                        // linkId: controller.postId != null ? controller.postId : null,
                                        // profileId: controller.profileId != null ? controller.profileId : null,
                                        ));

                                    Get.find<NewsfeedController>()
                                            .languageData =
                                        await Get.find<NewsfeedController>()
                                            .getLanguages();
                                    int index = Get.find<NewsfeedController>()
                                        .languagesList
                                        .indexWhere((element) {
                                      return kIsWeb
                                          ? shared.getInt('languageId')
                                          : Get.find<NewsfeedController>()
                                                  .languageData
                                                  .appLang
                                                  .id ==
                                              element.id;
                                    });

                                    int index2 = Get.find<NewsfeedController>()
                                        .translationLanguage
                                        .indexWhere((element) {
                                      return kIsWeb
                                          ? shared.getInt('languageId')
                                          : Get.find<NewsfeedController>()
                                                  .languageData
                                                  .myLang
                                                  .id ==
                                              element.id;
                                    });

                                    Get.find<NewsfeedController>()
                                            .dropdownValue =
                                        Get.find<NewsfeedController>()
                                            .languagesList[index];

                                    Get.find<NewsfeedController>()
                                            .dropdownValue1 =
                                        Get.find<NewsfeedController>()
                                            .translationLanguage[index2];

                                    // print("idhr sdfsdf");

                                    // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                    //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                    //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                    //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                    // );
                                    //
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                    Get.find<NewsfeedController>()
                                            .selectedAppLanguageInfoId =
                                        kIsWeb
                                            ? shared.getInt('languageId')
                                            : Get.find<NewsfeedController>()
                                                .languageData
                                                .appLang
                                                .id;

                                    Get.find<NewsfeedController>().upDateLocale(
                                        kIsWeb
                                            ? shared.getInt('languageCode')
                                            : Get.find<NewsfeedController>()
                                                .languageData
                                                .appLang
                                                .code);
                                    Get.find<NewsfeedController>().update();

                                    if (kIsWeb) {
                                      SingleTone.instance.socialLogin = false;
                                      widget.controller
                                          .showRegistrationSuccessful = true;
                                      widget.controller.showSignUpForm = false;
                                      widget.controller.update();
                                      // Routemaster.of(context).pop();
                                      Navigator.pop(context);

                                      String userName =
                                          shared.getString("userName");
                                      // print({
                                      //   "userName on mainScreen :  $userName"
                                      // });

                                      Get.offNamed(FluroRouters.mainScreen);

                                      // Routemaster.of(context).replace(
                                      //     AppRoute.mainScreen, queryParameters: {
                                      //
                                      //
                                      //   "userName": shared.getString("userName"),
                                      //   "postId": controller.postId != null
                                      //       ? controller.postId
                                      //       : null,
                                      //   "profileId": controller.profileId != null
                                      //       ? controller.profileId
                                      //       : null
                                      // });
                                    } else {
                                      SingleTone.instance.socialLogin = false;
                                      Get.back();
                                      Get.offAll(MainScreen(), arguments: {
                                        "userName":
                                            shared.getString("userName"),
                                      });
                                    }

                                    // Get.offAll(MainScreen(
                                    //   userName: shared.getString("userName"),
                                    //   postId: controller.postId != null
                                    //       ? controller.postId
                                    //       : null,
                                    //   profileId: controller.profileId != null
                                    //       ? controller.profileId
                                    //       : null,
                                    // ));
                                    // Navigator.of(context).pushAndRemoveUntil(
                                    //     MaterialPageRoute(
                                    //         builder: (context) => MainScreen(
                                    //               userName: userName,
                                    //               postId: controller.postId != null
                                    //                   ? controller.postId
                                    //                   : null,
                                    //               profileId: controller.profileId != null
                                    //                   ? controller.profileId
                                    //                   : null,
                                    //             )),
                                    //     (Route<dynamic> route) => false);
                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (BuildContext context) =>
                                    //         MainScreen(userName: userName),
                                    // ),
                                    // );
                                  }

/*
                              if (responseCode.toString() == "200") {
                                print("register");
                                Navigator.pop(context);
                                if(kIsWeb) {
                                  Navigator.pop(context);
                                }
                                // controller.showSignUpForm = false;
                                // controller.showRegistrationSuccessful = true;
                                // controller.update();
                                //
                                Future.delayed(
                                    const Duration(milliseconds:1 ), () {
                                  UtilsMethods.toastMessageShow(
                                      MyColors.werfieBlue,
                                      MyColors.werfieBlue,
                                      MyColors.werfieBlue,
                                      message:
                                      'An email has been sent to your provided email address to verify your account.Or you can now login');

                                  widget.controller.showRegistrationSuccessful =
                                  true;
                                  widget.controller.showSignUpForm = false;
                                  widget.controller.update();
                                });

                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (BuildContext context) => LoginScreen(),
                                //   ),
                                // );
                                // showDialog(
                                //     barrierDismissible: false,
                                //     context: context,
                                //     builder: (BuildContext context) {
                                //       return AlertDialog(
                                //         shape: RoundedRectangleBorder(
                                //             borderRadius: BorderRadius.all(
                                //                 Radius.circular(10.0))),
                                //         insetPadding: EdgeInsets.symmetric(
                                //             horizontal: 0, vertical: 0),
                                //         contentPadding: EdgeInsets.zero,
                                //         content: Container(
                                //           height: 100,
                                //           width: 80,
                                //           child: Column(
                                //             mainAxisAlignment:
                                //                 MainAxisAlignment.spaceAround,
                                //             children: [
                                //               Text(
                                //                   'You have been registered successfully'),
                                //               TextButton(
                                //                 onPressed: () {
                                //                   Navigator.pop(context);
                                //                   Get.find<LoginController>()
                                //                       .showSignUpForm = false;
                                //                   Get.find<LoginController>().update();
                                //                   controller.update();
                                //                 },
                                //                 child: Text(
                                //                   'Return to Login',
                                //                 ),
                                //               )
                                //             ],
                                //           ),
                                //         ),
                                //       );
                                //     });

                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (BuildContext context) =>
                                //         LoginScreen(),
                                //   ),
                                // );
                              }
*/
                                  // IF USER NAME IS TAKEN
                                  else if (responseCode.toString() == "423") {
                                    // print("423 ${responseCode.toString()}");
                                    // print("HITTING ANOTHER API");
                                    // print(widget
                                    //     .controller.isSuggestedUsername.value
                                    //     .toString());
                                    // print("VALUE CHANGED OF OBX");
                                    // widget.controller.list = await widget.controller
                                    String error = await widget.controller
                                        .usernameSuggestion(queryParameters: {
                                      "username":
                                          widget.controller.username.text
                                    }, token: {
                                      "Authorization":
                                          "Bearer ${Url.webAPIKey}",
                                      "X-Requested-With": "XMLHttpRequest"
                                    });
                                    LoggingUtils.printValue(
                                        "username_suggestion",
                                        error.toString());
                                    Navigator.of(context).pop();

                                    widget.controller.isSuggested = true;

                                    widget.controller.update();
                                    showDialog(
                                        barrierDismissible: false,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(10.0))),
                                            insetPadding: EdgeInsets.symmetric(
                                                horizontal: 0, vertical: 0),
                                            contentPadding: EdgeInsets.zero,
                                            content: Container(
                                              height: 100,
                                              width: 80,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceAround,
                                                children: [
                                                  Text(Strings
                                                      .usernameIsAlreadyTaken),
                                                  TextButton(
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text(
                                                      Strings.goBack,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          );
                                        });
                                  }
                                  // IF EMAIL IS TAKEN
                                  else {
                                    // print("pop${responseCode.toString()}");
                                    Navigator.of(context).pop();
                                    // print(responseCode);
                                  }
                                }
                                // }///

                                // else {
                                //   UtilsMethods.toastMessageShow(
                                //     Colors.blue,
                                //     Colors.blue,
                                //     Colors.blue,
                                //     message: 'You should be at least 14 years old',
                                //   );
                                // }

                                // else {
                                //   UtilsMethods.toastMessageShow(
                                //     Colors.blue,
                                //     Colors.blue,
                                //     Colors.blue,
                                //     message: 'Please Enter your Date of Birth',
                                //   );
                                // }
                              }
                            } else {
                              setState(() {
                                errorText = true;
                              });
                            }
                          }
                        },
                        child: RoundedButton(
                          Strings.signUp,
                          () async {
                            // debugPrint('Ok--->> ${widget.controller.chosenValue.name}');

                            if (widget.controller.termAndPrivacyCheck.value ==
                                false) {
                              widget.controller.checkBoxColor.value = true;
                              widget.controller.update();
                            }

                            if (name.isNotEmpty &&
                                werfieHandle.isNotEmpty &&
                                email.isNotEmpty &&
                                password.isNotEmpty &&
                                confirmPassword.isNotEmpty &&
                                countryCheck == true && _strength==1) {
                              if (SignUpForm.formKey.currentState.validate() &&
                                  widget.controller.chosenValue != null &&
                                  widget.controller.termAndPrivacyCheck ==
                                      true) {
                                SignUpForm.formKey.currentState.save();

                                debugPrint('Ok--->>');

                                // if (widget.controller.selectedMonth.isNotEmpty && widget.controller.selectedYear.isNotEmpty && widget.controller.selectedDay.isNotEmpty) {
                                //
                                //
                                // }

                                // DateTime noDate = DateTime.now();
                                // int newYear = noDate.year;
                                // int selectedYear =
                                // int.parse(widget.controller.selectedYear);
                                // int difference = newYear - selectedYear;
                                // print('dateDifference:${difference}');
                                //if (difference >= 13)
                                //{

                                showDialog(
                                    barrierDismissible: false,
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        backgroundColor:
                                            Color(0xFFFFFFFF).withOpacity(0.2),
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(10.0))),
                                        insetPadding: EdgeInsets.symmetric(
                                            horizontal: 0, vertical: 0),
                                        contentPadding: EdgeInsets.zero,
                                        content: Container(
                                          height: 100,
                                          width: 80,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              SpinKitCircle(
                                                color: Theme.of(context)
                                                    .primaryColor,
                                                size: 50.0,
                                              ),
                                              Text(
                                                Strings.pleaseWait,
                                                style: TextStyle(
                                                    color: Colors.white),
                                              )
                                            ],
                                          ),
                                        ),
                                      );
                                    });
                                var response = await widget.controller
                                    .register(queryParameters: {
                                  "firstname": widget.controller.firstName.text,
                                  "lastname": '',
                                  "username": widget.controller.username.text,
                                  "password":
                                      widget.controller.signupPassword.text,
                                  "password_confirmation":
                                      widget.controller.signupPassword.text,
                                  "email": widget.controller.signupEmail.text,
                                  "country_id":
                                      widget.controller.countryId.toString(),
                                  "dob": '',
                                  //123213 "dob":widget.controller.selectedMonth.isNotEmpty && widget.controller.selectedYear.isNotEmpty && widget.controller.selectedDay.isNotEmpty? widget.controller.functionStoreDate():'',
                                }, token: {
                                  "Authorization": "Bearer ${Url.webAPIKey}",
                                  "X-Requested-With": "XMLHttpRequest"
                                });

                                //print("responseeeeee  ${response.toString()}");
                                var jsonResponse =
                                    jsonDecode(response.toString());

                                // print("jsonResponse $jsonResponse");

                                if (jsonResponse['errors'] != null &&
                                    jsonResponse['errors']['email'][0] ==
                                        "The email has already been taken.") {
                                  Navigator.pop(context);
                                  showDialog(
                                      barrierDismissible: false,
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(10.0))),
                                          insetPadding: EdgeInsets.symmetric(
                                              horizontal: 0, vertical: 0),
                                          contentPadding: EdgeInsets.zero,
                                          content: Container(
                                            height: 200,
                                            width: 300,
                                            padding: EdgeInsets.symmetric(
                                              horizontal: 20,
                                              vertical: 10,
                                            ),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Text(Strings
                                                    .snAccountHasAlreadyBeenCreatedWithThisEmail),
                                                TextButton(
                                                  onPressed: () {
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    Strings.goBack,
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                } else {
                                  var responseCode =
                                      jsonResponse['meta']['code'];
                                  var userName =
                                      jsonResponse['data']['username'];
                                  var token = jsonResponse['data']['token'];
                                  //print("token : $token");
                                  var userId = jsonResponse['data']['id'];

                                  var email = jsonResponse['data']['email'];

                                  shared =
                                      await SharedPreferences.getInstance();
                                  // DialogBuilder(context).hideOpenDialog();

                                  if (responseCode == 200) {
                                    shared.setString("token", token.toString());
                                    shared.setString(
                                        "userName", userName.toString());

                                    shared.setString("email", email.toString());

                                    storage.write("email", email.toString());

                                    shared.setBool('guestUser', true);
                                    shared.setBool('socialLogin', false);
                                    storage.write('id', userId);
                                    storage.write("token", token.toString());

                                    storage.write("CurrentEmail",
                                        widget.controller.signupEmail.text);
                                    storage.write(
                                        "userName", userName.toString());

                                    storage.write("remember", isCheckedGlobal);

                                    widget.controller.signupEmail.clear();
                                    widget.controller.signupPassword.clear();
                                    widget.controller.generateFCMToken(context);
                                    widget.controller
                                        .updateInitialWelcomeMsg(true);

                                    Get.put(NewsfeedController(
                                        // linkId: controller.postId != null ? controller.postId : null,
                                        // profileId: controller.profileId != null ? controller.profileId : null,
                                        ));

                                    Get.find<NewsfeedController>()
                                            .languageData =
                                        await Get.find<NewsfeedController>()
                                            .getLanguages();
                                    int index = Get.find<NewsfeedController>()
                                        .languagesList
                                        .indexWhere((element) {
                                      return Get.find<NewsfeedController>()
                                              .languageData
                                              .appLang
                                              .id ==
                                          element.id;
                                    });

                                    int index2 = Get.find<NewsfeedController>()
                                        .translationLanguage
                                        .indexWhere((element) {
                                      return Get.find<NewsfeedController>()
                                              .languageData
                                              .myLang
                                              .id ==
                                          element.id;
                                    });

                                    Get.find<NewsfeedController>()
                                            .dropdownValue =
                                        Get.find<NewsfeedController>()
                                            .languagesList[index];

                                    Get.find<NewsfeedController>()
                                            .dropdownValue1 =
                                        Get.find<NewsfeedController>()
                                            .translationLanguage[index2];

                                    // print("idhr sdfsdf");

                                    // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                    //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                    //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                    //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                    // );
                                    //
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                    Get.find<NewsfeedController>()
                                            .selectedAppLanguageInfoId =
                                        Get.find<NewsfeedController>()
                                            .languageData
                                            .appLang
                                            .id;

                                    Get.find<NewsfeedController>().upDateLocale(
                                        Get.find<NewsfeedController>()
                                            .languageData
                                            .appLang
                                            .code);
                                    Get.find<NewsfeedController>().update();

                                    if (kIsWeb) {
                                      SingleTone.instance.socialLogin = false;
                                      widget.controller
                                          .showRegistrationSuccessful = true;
                                      widget.controller.showSignUpForm = false;
                                      widget.controller.update();
                                      // Routemaster.of(context).pop();
                                      Navigator.pop(context);

                                      String userName =
                                          shared.getString("userName");
                                      // print({
                                      //   "userName on mainScreen :  $userName"
                                      // });

                                      Get.offNamed(FluroRouters.mainScreen);

                                      // Routemaster.of(context).replace(

                                      //     AppRoute.mainScreen, queryParameters: {
                                      //
                                      //
                                      //   "userName": shared.getString("userName"),
                                      //   "postId": controller.postId != null
                                      //       ? controller.postId
                                      //       : null,
                                      //   "profileId": controller.profileId != null
                                      //       ? controller.profileId
                                      //       : null
                                      // });
                                    } else {
                                      SingleTone.instance.socialLogin = false;
                                      Get.back();
                                      Get.offAll(MainScreen(), arguments: {
                                        "userName":
                                            shared.getString("userName"),
                                      });
                                    }

                                    // Get.offAll(MainScreen(
                                    //   userName: shared.getString("userName"),
                                    //   postId: controller.postId != null
                                    //       ? controller.postId
                                    //       : null,
                                    //   profileId: controller.profileId != null
                                    //       ? controller.profileId
                                    //       : null,
                                    // ));
                                    // Navigator.of(context).pushAndRemoveUntil(
                                    //     MaterialPageRoute(
                                    //         builder: (context) => MainScreen(
                                    //               userName: userName,
                                    //               postId: controller.postId != null
                                    //                   ? controller.postId
                                    //                   : null,
                                    //               profileId: controller.profileId != null
                                    //                   ? controller.profileId
                                    //                   : null,
                                    //             )),
                                    //     (Route<dynamic> route) => false);
                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (BuildContext context) =>
                                    //         MainScreen(userName: userName),
                                    // ),
                                    // );
                                  }

/*
                              if (responseCode.toString() == "200") {
                                print("register");
                                Navigator.pop(context);
                                if(kIsWeb) {
                                  Navigator.pop(context);
                                }
                                // controller.showSignUpForm = false;
                                // controller.showRegistrationSuccessful = true;
                                // controller.update();
                                //
                                Future.delayed(
                                    const Duration(milliseconds:1 ), () {
                                  UtilsMethods.toastMessageShow(
                                      MyColors.werfieBlue,
                                      MyColors.werfieBlue,
                                      MyColors.werfieBlue,
                                      message:
                                      'An email has been sent to your provided email address to verify your account.Or you can now login');

                                  widget.controller.showRegistrationSuccessful =
                                  true;
                                  widget.controller.showSignUpForm = false;
                                  widget.controller.update();
                                });

                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (BuildContext context) => LoginScreen(),
                                //   ),
                                // );
                                // showDialog(
                                //     barrierDismissible: false,
                                //     context: context,
                                //     builder: (BuildContext context) {
                                //       return AlertDialog(
                                //         shape: RoundedRectangleBorder(
                                //             borderRadius: BorderRadius.all(
                                //                 Radius.circular(10.0))),
                                //         insetPadding: EdgeInsets.symmetric(
                                //             horizontal: 0, vertical: 0),
                                //         contentPadding: EdgeInsets.zero,
                                //         content: Container(
                                //           height: 100,
                                //           width: 80,
                                //           child: Column(
                                //             mainAxisAlignment:
                                //                 MainAxisAlignment.spaceAround,
                                //             children: [
                                //               Text(
                                //                   'You have been registered successfully'),
                                //               TextButton(
                                //                 onPressed: () {
                                //                   Navigator.pop(context);
                                //                   Get.find<LoginController>()
                                //                       .showSignUpForm = false;
                                //                   Get.find<LoginController>().update();
                                //                   controller.update();
                                //                 },
                                //                 child: Text(
                                //                   'Return to Login',
                                //                 ),
                                //               )
                                //             ],
                                //           ),
                                //         ),
                                //       );
                                //     });

                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (BuildContext context) =>
                                //         LoginScreen(),
                                //   ),
                                // );
                              }
*/
                                  // IF USER NAME IS TAKEN
                                  else if (responseCode.toString() == "423") {
                                    print("423 ${responseCode.toString()}");
                                    print("HITTING ANOTHER API");
                                    print(widget
                                        .controller.isSuggestedUsername.value
                                        .toString());
                                    print("VALUE CHANGED OF OBX");
                                    // widget.controller.list = await widget.controller
                                    String error = await widget.controller
                                        .usernameSuggestion(queryParameters: {
                                      "username":
                                          widget.controller.username.text
                                    }, token: {
                                      "Authorization":
                                          "Bearer ${Url.webAPIKey}",
                                      "X-Requested-With": "XMLHttpRequest"
                                    });
                                    LoggingUtils.printValue(
                                        "username_suggestion",
                                        error.toString());
                                    Navigator.of(context).pop();

                                    widget.controller.isSuggested = true;

                                    widget.controller.update();
                                    showDialog(
                                        barrierDismissible: false,
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(10.0))),
                                            insetPadding: EdgeInsets.symmetric(
                                                horizontal: 0, vertical: 0),
                                            contentPadding: EdgeInsets.zero,
                                            content: Container(
                                              height: 100,
                                              width: 80,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceAround,
                                                children: [
                                                  Text(Strings
                                                      .usernameIsAlreadyTaken),
                                                  TextButton(
                                                    onPressed: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text(
                                                      Strings.goBack,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          );
                                        });
                                  }
                                  // IF EMAIL IS TAKEN
                                  else {
                                    print("pop${responseCode.toString()}");
                                    Navigator.of(context).pop();
                                    print(responseCode);
                                  }
                                }
                                // }///

                                // else {
                                //   UtilsMethods.toastMessageShow(
                                //     Colors.blue,
                                //     Colors.blue,
                                //     Colors.blue,
                                //     message: 'You should be at least 14 years old',
                                //   );
                                // }

                                // else {
                                //   UtilsMethods.toastMessageShow(
                                //     Colors.blue,
                                //     Colors.blue,
                                //     Colors.blue,
                                //     message: 'Please Enter your Date of Birth',
                                //   );
                                // }
                              }
                            } else {
                              setState(() {
                                errorText = true;
                              });
                            }
                          },
                          focusNode: widget.controller.focus9,
                          horizontalPadding: !kIsWeb ? 20.0 : 150.0,
                          verticalPadding: kIsWeb ? 20.0 : 15.0,
                          roundedButtonColor: MyColors.werfieBlue,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  CountryDropDown(
      List<cr.Data> list,
      int countryId,
      bool error,
      BuildContext context,
      LoginController controller,
      String Function(dynamic) onValidate,
      TextEditingController textControllor) {
    return list == null
        ? Padding(
            padding: const EdgeInsets.symmetric(vertical: 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  Strings.pleaseChooseACountry,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    // fontWeight: FontWeight.normal
                  ),
                  // TextStyle(
                  //
                  //     fontSize: 14,
                  //     fontWeight: FontWeight.w500),
                ),
                Icon(
                  Icons.arrow_drop_down,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                )
              ],
            ),
          )
        : Column(
            children: [
              Container(
                child: DropdownButtonHideUnderline(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                      color: Colors.grey[300].withOpacity(0.3),
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: CircleAvatar(
                            backgroundColor: Colors.white,
                            child: SvgPicture.asset(
                              "assets/images/world.svg",
                              height: 25.0,
                              width: 25.0,
                              allowDrawingOutsideViewBox: true,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        Expanded(
                            child: Container(
                          width: kIsWeb ? 350 : 300,
                          child: DropdownButtonFormField2<cr.Data>(
                            isExpanded: true,
                            hint: Text(Strings.pleaseChooseACountry,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500)),
                            items: list
                                .map((item) => DropdownMenuItem<cr.Data>(
                                      value: item,
                                      child: Text(
                                        item.name,
                                        style: TextStyle(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        ),
                                      ),
                                    ))
                                .toList(),
                            value: controller.chosenValue,
                            validator: (value) {
                              return UtilsMethods.validateCountryField(
                                  value, 'Country');
                            },

                            onChanged: (value) {
                              setState(() {
                                country = value;

                                widget.controller.chosenValue = value;
                                widget.controller.countryId = value.id;
                                if (widget.controller.chosenValue != null) {
                                  countryCheck = true;
                                }
                              });
                            },
                            decoration: InputDecoration(
                              enabledBorder: InputBorder.none,
                            ),
                            buttonStyleData: ButtonStyleData(
                              decoration: BoxDecoration(
                                color: Colors.transparent,
                              ),
                              height: 35,
                              width: MediaQuery.of(context).size.width * 0.28,
                            ),
                            dropdownStyleData: const DropdownStyleData(
                              maxHeight: 200,
                            ),
                            menuItemStyleData: const MenuItemStyleData(
                              height: 40,
                            ),
                            dropdownSearchData: DropdownSearchData(
                              searchController: textControllor,
                              searchInnerWidgetHeight: 50,
                              searchInnerWidget: Container(
                                height: 50,
                                padding: const EdgeInsets.only(
                                  top: 8,
                                  bottom: 4,
                                  right: 8,
                                  left: 8,
                                ),
                                child: TextFormField(
                                  expands: true,
                                  maxLines: null,
                                  controller: textControllor,
                                  decoration: InputDecoration(
                                    isDense: true,
                                    hoverColor: Colors.transparent,
                                    contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 8,
                                    ),
                                    hintText: Strings.searchForAnItem,
                                    hintStyle: const TextStyle(fontSize: 12),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                ),
                              ),
                              searchMatchFn: (item, searchValue) {
                                return (item.value.name
                                    .toLowerCase()
                                    .toString()
                                    .contains(searchValue.toLowerCase()));
                              },
                            ),
                            //This to clear the search value when you close the menu
                            onMenuStateChange: (isOpen) {
                              if (!isOpen) {
                                textControllor.clear();
                              }
                            },
                          ),
                        ))
                      ],
                    ),
                  ),
                ),
                //  height: 55,
              ),
              error == true && countryCheck == false
                  ? Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            Strings.pleaseChooseACountry,
                            style:
                                TextStyle(color: Colors.red[800], fontSize: 10),
                          )),
                    )
                  : SizedBox()
            ],
          );
  }
}

/// this is the profile picture view UI in sign up form top
Widget _addProfileImageView()=>GetBuilder<ProfileController>(builder: (controller) {
  debugPrint('profile image data ${controller.profileImage}');
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 20.0),
    child: Align(
      alignment: Alignment.center,
      child: Stack(
        children: [
          CircleAvatar(
              radius: 65,
              backgroundColor: Colors.white,
              child: controller.profileImage != null
                  ? CircleAvatar(
                radius: 100,
                backgroundImage: MemoryImage(
                    controller.profileImage),
                backgroundColor: Colors.white,
              )
                  : controller.userProfile == null
                  ? Container(decoration:BoxDecoration(shape: BoxShape.circle),child: CircleAvatar(radius: 100,backgroundImage:  AssetImage('assets/images/person_placeholder.png'),))
                  : ClipRRect(
                borderRadius:
                BorderRadius.circular(60),
                child: FadeInImage(
                    fit: BoxFit.cover,
                    width: 120,
                    height: 120,
                    placeholder: AssetImage(
                        'assets/images/person_placeholder.png'),
                    image: NetworkImage(controller
                        .userProfile
                        .profileImage !=
                        null
                        ? controller
                        .profileImageDelete
                        ? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                        : controller
                        .userProfile
                        .profileImage
                        : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
              )),
          Positioned(
            bottom: 2,
            right: 2,
            // top: 70,
            // right: 0,
            // left: 80,
            child: PopupMenuButton(
              constraints: BoxConstraints.expand(
                  height: 100, width: 170),
              position: PopupMenuPosition.under,
              onSelected: (value) async {
                if (value == 1) {
                  controller.profileImage =
                  await controller.callGetImage();
                  controller.profileImageDelete = false;
                  controller.update();
                } else if (value == 2) {
                  controller.profileImage = null;
                  controller.profileImageDelete = true;
                  controller.update();
                }
              },
              offset: Offset(10, 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              itemBuilder: (BuildContext context) => [
                PopupMenuItem(
                    value: 1,
                    child: Row(
                      children: [
                        Icon(Icons.add),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          "Add photo${controller.userName}",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: Theme.of(context)
                                .brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                      ],
                    )),
                PopupMenuItem(
                    value: 2,
                    child: Row(
                      children: [
                        Icon(
                          Icons.delete,
                          color: Colors.red,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          "Delete photo${controller.userName}",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: Theme.of(context)
                                .brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                      ],
                    )),
              ],
              child: Tooltip(
                message: "Add photo",
                decoration:
                BoxDecoration(color: Colors.black54),
                child: Container(
                  height: 40,
                  width: 40,
                  alignment: Alignment.center,
                  // padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.camera_alt_outlined,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
            ),
            // Tooltip(
            //   message : "Add photo",
            //   decoration: BoxDecoration(
            //       color: Colors.black54
            //   ),
            //   child: Container(
            //     height: 40,
            //     width: 40,
            //     alignment: Alignment.center,
            //     // padding: const EdgeInsets.all(13),
            //     decoration: BoxDecoration(
            //       color: Colors.black54,
            //       shape: BoxShape.circle,
            //     ),
            //     child: IconButton(
            //       icon: Icon(
            //         Icons.camera_alt_outlined,
            //         color: Colors.white,
            //         size: 20,
            //       ),
            //       onPressed: () async {
            //         controller.profileImage = await controller.callGetImage();
            //         controller.update();
            //       },
            //     ),
            //   ),
            // ),
          )
        ],
      ),
    ),
  );
});

class PrivacyPolicy extends Intent {}

class TermsOfService extends Intent {}

class SignUPButton extends Intent {}

class CheckBoxWidget extends Intent {}

class ChooseYourCountry extends Intent {}

class EnterYourPassword extends Intent {}

class ConfirmYourPassword extends Intent {}

class EnterYourEmail extends Intent {}

class EnterYourWerifeHandle extends Intent {}

class EnterYourFirstName extends Intent {}

class SlectCountry extends Intent {}

extension exString on String {}
