import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:routemaster/routemaster.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../components/input_password_field.dart';
import '../constants/responsive.dart';
import '../network/controller/login_controller.dart';
import '../network/controller/news_feed_controller.dart';
import '../screens/login_screen.dart';
import '../screens/session.dart';
import '../utils/colors.dart';
import '../utils/font.dart';
import '../utils/routes.dart';
import '../utils/strings.dart';
import '../utils/utils_methods.dart';

class Deactivation extends StatelessWidget {
  BuildContext context2;

  Deactivation({Key key, this.context2}) : super(key: key);

  final loginController = Get.put(LoginController());
  final newFeedController = Get.put(NewsfeedController());

  @override
  Widget build(context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? Colors.black
            : Colors.white,
        iconTheme: IconThemeData(
          color: Color(0xFF4f515b),
        ),
        title: Text(
          Strings.deactivationAndDeletion,
          textAlign: TextAlign.center,
          style: Theme.of(context2).textTheme.headline6.copyWith(
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
        ),
        centerTitle: true,
        automaticallyImplyLeading:
            !Responsive.isDesktop(context2) ? true : false,
      ),
      body: GetBuilder<LoginController>(
        builder: (controller) {
          return Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: Container(
              child: newFeedController.checkDeactivate == false
                  ? Center(
                      child: CircularProgressIndicator(
                      color: MyColors.BlueColor,
                    ))
                  : Form(
                      key: LoginController.formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 30),
                          Text(
                            Strings.confirmPassMsg,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 20),
                          Container(
                            // height: 55,
                            child: InputPasswordField(
                              // formKey: LoginController.formKey,
                              TextInputAction: TextInputAction.next,
                              // onPasswordEntered: (value) {
                              //   value = password.text;
                              // },
                              text: Strings.enterYourPassword,
                              controller: loginController.password,
                              validator: (value) {
                                return UtilsMethods.validatePassword(value);
                              },
                            ),
                          ),
                          SizedBox(height: 10),

                          // Align(
                          //   alignment: Alignment.centerRight,
                          //   child: Padding(
                          //     padding: const EdgeInsets.only(right: 15.0),
                          //     child: TextButton(
                          //       onPressed: () {
                          //         if (!kIsWeb) {
                          //           Get.to(
                          //             // MaterialPageRoute(
                          //             //   builder: (context) =>
                          //             ResetPasswordScreen(),
                          //             // ),
                          //           );
                          //         } else {
                          //
                          //           Get.toNamed(FluroRouters.resetPasswordScreen);
                          //           // context.push(AppRoute.resetPasswordScreen);
                          //
                          //         }
                          //       },
                          //       child: Text(
                          //         Strings.lostPassword,
                          //         style: TextStyle(
                          //           color: Colors.black,
                          //           fontSize: 13,
                          //         ),
                          //       ),
                          //     ),
                          //   ),
                          // ),
                          SizedBox(
                            height: 40,
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton(
                                  // key: LoginController.formKey,
                                  onPressed: () async {
                                    // print("hello login");

                                    if (LoginController.formKey.currentState
                                        .validate()) {
                                      newFeedController.checkDeactivate.value =
                                          false;
                                      int code;
                                      code = await newFeedController
                                          .deactivateProfile(
                                              Password: loginController
                                                  .password.text);
                                      loginController.password.clear();
                                      loginController.update();

                                      newFeedController.checkDeactivate.value =
                                          true;

                                      // print("code $code");

                                      if (code != null) {
                                        SharedPreferences preferences =
                                            await SharedPreferences
                                                .getInstance();
                                        await preferences.clear();
                                        await newFeedController.storage.erase();
                                        Get.delete<SessionController>();
                                        Get.delete<NewsfeedController>();
                                        if (kIsWeb) {
                                          Routemaster.of(context2).replace(
                                              AppRoute.loginScreen,
                                              queryParameters: {
                                                "postId": null,
                                                "profileId": null
                                              });
                                        } else {
                                          Get.offUntil(
                                              MaterialPageRoute(
                                                  builder: (context2) =>
                                                      LoginScreen()),
                                              (route) => false);
                                          UtilsMethods.toastMessageShow(
                                              newFeedController.displayColor,
                                              newFeedController.displayColor,
                                              newFeedController.displayColor,
                                              message:
                                                  "You're about to permanently delete your account.you have 30 days to reactivate your account.After 30 days, the deletion process will begin and you won't be able to retrieve any of the content or information you have added.");
                                          // Get.snackbar(
                                          //   "",
                                          //   "You're about to permanently delete your account.you have 30 days to reactivate your account.After 30 days, the deletion process will begin and you won't be able to retrieve any of the content or information you have added.",
                                          //   snackPosition: SnackPosition.TOP,
                                          //   duration: const Duration(seconds: 8),
                                          //   colorText: Colors.black,
                                          // );
                                        }
                                      }
                                    }
                                  },
                                  child: Text(
                                    Strings.deactivateAccount,
                                    style: Theme.of(context2)
                                        .textTheme
                                        .headline6
                                        .copyWith(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14),
                                  ),

                                  style: ElevatedButton.styleFrom(
                                    shadowColor: Colors.transparent,
                                    primary: Colors.blue,
                                    padding: EdgeInsets.symmetric(
                                        vertical: 12, horizontal: 25),
                                    elevation: 0.0,
                                    shape: StadiumBorder(),
                                    // minimumSize: Size(100, 40),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Center(
                            child: Text(
                              "OR",
                              style: Styles.baseTextTheme.headline1.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: kIsWeb ? 16 : 14,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),

                          ///delete account
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton(
                                  // key: LoginController.formKey,
                                  onPressed: () async {
                                    if (LoginController.formKey.currentState
                                        .validate()) {
                                      showDialog<String>(
                                        context: context,
                                        builder: (BuildContext context) =>
                                            AlertDialog(
                                          title: Text(
                                            'Permanently delete account',
                                            style: Styles
                                                .baseTextTheme.headline2
                                                .copyWith(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          content: Container(
                                              width: 100,
                                              child: Text(
                                                "If you want to permanently delete your Werfie account,Once you Click the ok button,you won't be able to reactivate your account or retrieve any of the content or information you have added.",
                                                textAlign: TextAlign.justify,
                                                style: Styles
                                                    .baseTextTheme.headline2
                                                    .copyWith(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontSize: 14,
                                                ),
                                              )),
                                          actions: <Widget>[
                                            ElevatedButton(
                                              onPressed: () => Navigator.pop(
                                                  context, 'Cancel'),
                                              child: Text(
                                                Strings.cancel,
                                                style: Styles
                                                    .baseTextTheme.headline2
                                                    .copyWith(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.white,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              style: ElevatedButton.styleFrom(
                                                shadowColor: Colors.transparent,
                                                primary: Colors.blue,
                                                elevation: 0.0,
                                                // minimumSize: Size(100, 40),
                                              ),
                                            ),
                                            ElevatedButton(
                                              onPressed: () async {
                                                Navigator.pop(context, 'OK');

                                                /// idhr ann

                                                newFeedController
                                                    .checkDeactivate
                                                    .value = false;
                                                int code;
                                                code = await newFeedController
                                                    .deletedProfile(
                                                        Password:
                                                            loginController
                                                                .password.text);
                                                loginController.password
                                                    .clear();
                                                loginController.update();
                                                newFeedController
                                                    .checkDeactivate
                                                    .value = true;
                                                // print("code $code");
                                                if (code != null) {
                                                  SharedPreferences
                                                      preferences =
                                                      await SharedPreferences
                                                          .getInstance();
                                                  await preferences.clear();
                                                  await newFeedController
                                                      .storage
                                                      .erase();
                                                  Get.delete<
                                                      SessionController>();
                                                  Get.delete<
                                                      NewsfeedController>();

                                                  Get.offUntil(
                                                      MaterialPageRoute(
                                                          builder: (context2) =>
                                                              LoginScreen()),
                                                      (route) => false);
                                                  UtilsMethods.toastMessageShow(
                                                    newFeedController
                                                        .displayColor,
                                                    newFeedController
                                                        .displayColor,
                                                    newFeedController
                                                        .displayColor,
                                                    message:
                                                        'Your account has been permanently deleted.',
                                                  );
                                                  // Get.snackbar(
                                                  //   "",
                                                  //   "Your account has been permanently deleted.",
                                                  //   snackPosition: SnackPosition.TOP,
                                                  //   duration: const Duration(seconds: 8),
                                                  //   colorText: Colors.black,
                                                  // );
                                                }
                                              },
                                              child: Text(
                                                'OK',
                                                style: Styles
                                                    .baseTextTheme.headline2
                                                    .copyWith(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.white,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              style: ElevatedButton.styleFrom(
                                                shadowColor: Colors.transparent,
                                                primary: Colors.red,
                                                elevation: 0.0,
                                                // minimumSize: Size(100, 40),
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    }
                                  },
                                  child: Text(
                                    Strings.deleteAccount,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    shadowColor: Colors.transparent,
                                    primary: Colors.red,
                                    padding: EdgeInsets.symmetric(
                                        vertical: 12, horizontal: 25),
                                    elevation: 0.0,
                                    shape: StadiumBorder(),
                                    // minimumSize: Size(100, 40),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
            ),
          );
          // return Obx(() {
          //
          // });
        },
      ),
    );
  }
}
