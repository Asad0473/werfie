import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../utils/colors.dart';

class InputPasswordField extends StatefulWidget {
  @override
  _InputPasswordFieldState createState() => _InputPasswordFieldState();

  final Function(String) onPasswordEntered;
  final String Function(String) validator;
  final TextEditingController controller;
  final String text;
  final TextInputAction;
  final String errorText;
  final Function onChanged;
  var focusNode;
  var nextNode;
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  InputPasswordField(
      {this.onPasswordEntered,
      this.controller,
      this.validator,
      this.text,
      this.focusNode,
      this.TextInputAction,
      this.nextNode,
        this.errorText,
        this.onChanged,
      this.formKey});
}

class _InputPasswordFieldState extends State<InputPasswordField>
    with UtilsMethods {
  var _isObsecure = true;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      key: widget.formKey,
      // textAlignVertical: TextAlignVertical.bottom,
      focusNode: widget.focusNode != null ? widget.focusNode : null,
      controller: widget.controller,
      onChanged: widget.onChanged,
      textInputAction: widget.TextInputAction,
      onFieldSubmitted: (_) =>
          FocusScope.of(context).requestFocus(widget.nextNode),
      obscuringCharacter: '.',

      inputFormatters: [
        LengthLimitingTextInputFormatter(20),
      ],
      decoration: InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
            width: 0,
            style: BorderStyle.none,
            color: Theme.of(context).primaryColor,
          ),
        ),
        errorText:widget.errorText ,
        errorBorder:OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
            width: 0,
            style: BorderStyle.none,
            color:Colors.red,
          ),
        ),
        filled: true,
        fillColor: Colors.white,

        suffixIcon: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: IconButton(
            icon: Icon(
              _isObsecure ? Icons.visibility_off : Icons.visibility,
            ),
            onPressed: () {
              setState(() {
                _isObsecure = !_isObsecure;
              });
            },
          ),
        ),
        hintText: widget.text,
        hintStyle: TextStyle(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : MyColors.lightColor,
          fontWeight: FontWeight.w500,
          fontSize: 14,
        ),
      ),
      obscureText: _isObsecure,
      style: TextStyle(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white
            : Colors.black,
        fontWeight: FontWeight.w500,
        fontSize: 14,
      ),
      cursorColor: Theme.of(context).brightness == Brightness.dark
          ? Colors.white
          : Colors.black,
      // style: TextStyle(
      //   fontSize: 14.0,
      // ),

      keyboardType: TextInputType.visiblePassword,
      // textInputAction: TextInputAction.done,
      validator: widget.validator,
      // onChanged: (String val) => widget.onPasswordEntered(val),
    );
  }
}
