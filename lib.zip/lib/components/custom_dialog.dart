import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:werfieapp/utils/strings.dart';

// ignore: missing_return
Widget customDialog(context, {isSuccess = false, message}) {
  showDialog(
      // barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: isSuccess
              ? Color(0xFFFFFFFF)
              : Color(0xFFFFFFFF).withOpacity(0.2),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          insetPadding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
          contentPadding: EdgeInsets.zero,
          content: Container(
            height: 100,
            width: 80,
            child: isSuccess
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "$message",
                            style: TextStyle(color: Colors.black),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      MaterialButton(
                        // onFocusChange: (bool value){
                        //   print("buttom  ${value}");
                        //   if(value == true)
                        //   {
                        //     onPressed();
                        //
                        //   }
                        //   else if (value == false)
                        //   {
                        //     focusNode = null;
                        //
                        //   }
                        //
                        // },

                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(60.0)),
                        color: Color(0xFF0157d3),
                        child: Text(
                          "Okay",
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () {
                          FocusScope.of(context).unfocus();
                          // print('hello pr aya hai ');

                          Navigator.pop(context);

                          isSuccess = false;
                        },
                      )
                    ],
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      SpinKitCircle(
                        color: Theme.of(context).primaryColor,
                        size: 50.0,
                      ),
                      Text(
                        Strings.pleaseWait,
                        style: TextStyle(color: Colors.white),
                      )
                    ],
                  ),
          ),
        );
      });
}
