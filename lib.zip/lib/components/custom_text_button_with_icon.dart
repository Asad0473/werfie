import 'package:flutter/material.dart';

class CustomTextButtonWIthIcon extends StatelessWidget {
  final IconData icon;
  final String buttonText;
  final Function onPressed;
  final Color color;

  CustomTextButtonWIthIcon(this.icon, this.buttonText, this.onPressed,
      {this.color});

  @override
  Widget build(BuildContext context) {
    return TextButton.icon(
      icon: Icon(icon),
      onPressed: onPressed,
      label: Text(buttonText),
      style: TextButton.styleFrom(
        backgroundColor: color,
        padding: EdgeInsets.only(
          right: 20,
          top: 12,
          bottom: 12,
          left: 12,
        ),
      ),
    );
  }
}
