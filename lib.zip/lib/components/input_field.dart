import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/colors.dart';

// ignore: must_be_immutable
class InputField extends StatefulWidget {
  @override
  _InputFieldState createState() => _InputFieldState();

  final Function(String) onValueEntered;
  final Function(String) onChanged;
  final String errorText;
  var nextInputField;
  final Function (String) onSaved;
  final String hint;
  final String Function(String) validator;
  final TextInputType textInputType;
  final IconData fieldIcon;
  final TextEditingController controller;
  final IconData suffixIcon;
  final Color suffixIconColor;
  final List<TextInputFormatter> formatter;
  final int maxLine;
  final int minLine;
  final TextInputAction;
  final EdgeInsetsGeometry contextPadding;
  var focusNode;
  final showCursor;

  Function onPress;
  Function onTap;

  InputField({
    this.hint,
    this.maxLine = 1,
    this.minLine,
    this.controller,
    this.onValueEntered,
    @required this.validator,
    this.textInputType,
    this.fieldIcon,
    this.suffixIcon,
    this.formatter,
    this.focusNode,
    this.onChanged,
    this.TextInputAction,
    this.onPress,
    this.onTap,
    this.nextInputField,
    this.showCursor,
    this.suffixIconColor,
    this.contextPadding,
    this.errorText,
    this.onSaved
  });
}

class _InputFieldState extends State<InputField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      cursorColor: Colors.blue,
      cursorHeight: 30,
      // textAlignVertical: TextAlignVertical.bottom,
      autofocus: true,
      autocorrect: false,
      showCursor: widget.showCursor,
      onSaved: widget.onSaved,
      onFieldSubmitted: (_) =>
          FocusScope.of(context).requestFocus(widget.nextInputField),
      focusNode: widget.focusNode != null ? widget.focusNode : null,
      inputFormatters: widget.formatter,
      controller: widget.controller,
      maxLines: widget.maxLine,
      minLines: widget.minLine,

      textInputAction: widget.TextInputAction,

      decoration: InputDecoration(
        errorText:widget.errorText ,
        errorBorder:OutlineInputBorder(
          borderRadius: BorderRadius.circular(40),
          borderSide: BorderSide(
            width: 0,
            style: BorderStyle.none,
            color:Colors.red,
          ),
        ),

        contentPadding: widget.contextPadding,
        // contentPadding: const EdgeInsets.only(left: 20,top: kIsWeb ? 30 : 40 , bottom: kIsWeb ? 20 : 5),
        isDense: true,
        prefixIcon: widget.fieldIcon != null

            ? Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: 12, vertical: kIsWeb ? 5 : 10),
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(
                    widget.fieldIcon,
                    color: Colors.black,
                  ),
                ),
              )
            : null,
        suffixIcon: widget.suffixIcon != null
            ? IconButton(
                onPressed: widget.onPress,
                icon: Icon(
                  widget.suffixIcon,
                  color: widget.suffixIconColor,
                  size: 20,
                ),
              )
            : SizedBox(
                height: 0,
                width: 0,
              ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
            width: 0,
            style: BorderStyle.none,
            color: Theme.of(context).primaryColor,
          ),
        ),
        hintText: widget.hint,
        // hintStyle: TextStyle(),
        hintStyle: TextStyle(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : MyColors.lightColor,
          fontWeight: FontWeight.w500,
          fontSize: 14,
        ),
        fillColor: Colors.white,
        filled: true,
      ),
      style: TextStyle(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white
            : Colors.black,
        fontWeight: FontWeight.w500,
        fontSize: 14,
      ),
      // style: TextStyle(
      //   fontSize: 14.0,
      //   fontWeight: FontWeight.w300,
      // ),
      keyboardType: widget.textInputType,
      // textInputAction: TextInputAction.done,
      validator: widget.validator,
      onTap: widget.onTap,

      onChanged: (String val) => widget.onChanged(val),
    );
  }
}
