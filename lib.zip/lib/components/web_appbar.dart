import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/fluro_router.dart';
import 'package:werfieapp/utils/strings.dart';

import '../network/controller/add_moment_controller.dart';
import '../network/controller/get_moment_list_controller.dart';
import '../utils/app_languages.dart';
import '../utils/font.dart';
import '../web_views/web_main_screen.dart';

class WebAppBar extends StatelessWidget {
  final userName;
  final NewsfeedController controller;
  final profileImageUrl;

  WebAppBar({this.userName, this.controller, this.profileImageUrl});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          MouseRegion(
            cursor: SystemMouseCursors.click,
            child: Align(
              alignment: Alignment.centerLeft,
              child: GestureDetector(
                onTap: () async {
                  onProfileChange = false;
                  onChatsChange = false;
                  onBookMarksChange = false;
                  onTrendsChange = false;
                  onHomeChange = true;
                  onBrowsChange = false;
                  onMoreChange = false;
                  onNotificationChange = false;
                  onListChange = false;
                  onSettingChange = false;

                  controller.drawerLeftMoment = false;
                  controller.isSearch = false;
                  controller.isFilter = false;
                  controller.isFilterScreen = false;
                  controller.isTrendsScreen = false;
                  controller.isNewsFeedScreen = true;
                  controller.isWhoToFollowScreen = false;
                  controller.isBrowseScreen = false;
                  controller.isNotificationScreen = false;
                  controller.isChatScreen = false;
                  controller.isSavedPostScreen = false;
                  controller.isPostDetails = false;
                  controller.isProfileScreen = false;
                  controller.isFollwerScreen = false;
                  controller.isSettingsScreen = false;

                  // controller.i = false;
                  controller.navRoute = "isNewsFeedScreen";
                  controller.searchText.text = '';

                  controller.postList = await controller.getNewsFeed(
                      reload: true, shouldUpdate: true);
                  controller.postList.forEach((element) {
                    // print('first screen1');
                    controller.threadNumber = element.thread_no;
                    // print('thread number:${controller.threadNumber}');
                    element.rebuzz.value = element.isRetweeted;
                    element.likeCount.value = element.simpleLikeCount;
                    element.rebuzzCount.value = element.retweetCount;
                    element.commentCount.value = element.commentsCount;

                    element.reactionType.value = element.isLiked;

                    // element.comments.forEach((element) {
                    //   element.reactionType.value = element.isLiked;
                    //   element.commentCount.value = element.simpleLikeCount;
                    // });

                    element.reactionCheck.refresh();

                    controller.update();

                    // element.reactionCheck.value = false;
                    // if (element.isLiked == true) {
                    //   element.like.value = true;
                    //   element.like.refresh();
                    // }
                  });

                  if (Get.isRegistered<MomentsListController>()) {
                    Get.delete<MomentsListController>();
                  }
                  if (Get.isRegistered<AddMomentsController>()) {
                    Get.delete<AddMomentsController>();
                  }
                },
                child: Container(
                    alignment: Alignment.centerLeft,
                    padding: EdgeInsets.only(
                      left:
                          MediaQuery.of(context).size.width >= 1100 ? 120 : 15,
                    ),
                    width: MediaQuery.of(context).size.width * 0.275,
                    height: MediaQuery.of(context).size.height / 38,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Image.asset(
                        AppImages.logoPng,
                        alignment: Alignment.centerLeft,
                        // color: Color((0xFF47b867)),
                      ),
                    )),
              ),
            ),
          ),

          controller.isBrowseScreen
              ? SizedBox()
              : Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                        child: TextField(
                          style: LightStyles.baseTextTheme.headline4.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            //fontWeight: FontWeight.w500,
                            // fontSize: 14,
                          ),
                          cursorColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                          onTap: () {
                            // print("search tap called");
                            if (controller.isFilterScreen) {
                              // print("search tap called if");

                              controller.isProfileScreen = false;
                              controller.isSettingsScreen = false;
                              controller.isSavedPostScreen = false;
                              controller.isNewsFeedScreen = false;
                              controller.isOtherUserProfileScreen = false;
                              controller.isChatScreen = false;
                              controller.isChatScreenWeb = false;
                              controller.isBrowseScreen = false;
                              controller.isClickWhoToFollow = false;
                              controller.isFollwerScreen = false;
                              controller.isPostDetails = false;
                              controller.isFilterScreen = true;

                              controller.isSearch = true;
                              controller.isFilter = false;

                              controller.update();
                            } else {
                              // print("search tap called else");

                              controller.isSearch = true;
                              controller.isPostDetails = false;
                              controller.isFilter = true;
                              controller.isFilterScreen = false;
                              controller.update();
                            }
                          },
                          controller: controller.searchText,
                          onChanged: (val) async {
                            await controller.onSearchTextChanged(val);

                            if (controller.isFilterScreen) {
                              controller.isFilterScreen = true;

                              controller.isSearch = true;
                              controller.isFilter = false;

                              controller.update();
                            } else {
                              controller.update();
                            }
                          },
                          textAlignVertical: TextAlignVertical.bottom,
                          decoration: InputDecoration(
                            hintText: Strings.search,
                            border: InputBorder.none,

                            hintStyle: LightStyles.baseTextTheme.headline3,
                            prefixIcon: Icon(
                              Icons.search,
                              size: 20,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                            // border: OutlineInputBorder(
                            //   borderRadius: BorderRadius.circular(40),
                            //   borderSide: BorderSide(color: Colors.grey, width: 1),
                            // ),
                            //
                            // enabledBorder: OutlineInputBorder(
                            //   borderRadius: BorderRadius.circular(40),
                            //   borderSide: BorderSide(color: Colors.grey, width: 1),
                            // ),
                            fillColor: Colors.grey[250],
                          ),
                        ),
                      ),
                      PopupMenuButton(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(10.0),
                            ),
                          ),
                          tooltip: "Select Language",
                          position: PopupMenuPosition.under,
                          padding: EdgeInsets.zero,
                          icon: SvgPicture.asset(
                            AppImages.languageIcon,
                            height: 30,
                            width: 30,
                            color: controller.displayColor,
                          ),
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.black
                              : Colors.white,
                          // Callback that sets the selected popup menu item.
                          onSelected: (value) async {},
                          itemBuilder: (BuildContext context) => [
                                PopupMenuItem(
                                  padding: EdgeInsets.all(0),
                                  value: 1,
                                  child: GetBuilder<NewsfeedController>(
                                      builder: (controller) {
                                    return Container(
                                      height: 250,
                                      width: 350,
                                      color: Colors.white,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "App Language",
                                              style: TextStyle(
                                                color: controller.displayColor,
                                                fontSize: 15,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            SizedBox(
                                              height: 40,
                                              child: FormField<String>(
                                                builder: (FormFieldState<String>
                                                    state) {
                                                  return InputDecorator(
                                                    decoration: InputDecoration(
                                                      fillColor:
                                                          Colors.transparent,
                                                      focusColor:
                                                          Colors.transparent,
                                                      contentPadding:
                                                          EdgeInsets.only(
                                                              bottom: 5,
                                                              top: 2,
                                                              left: 15,
                                                              right: 2),
                                                      // labelText: "hi",
                                                      // labelStyle: textStyle,
                                                      // labelText: _dropdownValue == null
                                                      //     ? 'Where are you from'
                                                      //     : 'From',
                                                      hintText:
                                                          "Community Name",

                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            width: 1,
                                                            color: Colors.grey),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(60),
                                                      ),

                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            width: 1,
                                                            color: Colors
                                                                .blue), //<-- SEE HERE
                                                      ),
                                                    ),
                                                    child:
                                                        DropdownButtonHideUnderline(
                                                      child: DropdownButton<
                                                          AppLanguage>(
                                                        // borderRadius: BorderRadius.circular(20),
                                                        focusColor:
                                                            Colors.transparent,

                                                        iconEnabledColor:
                                                            controller
                                                                .displayColor,
                                                        menuMaxHeight: 200,

                                                        value: controller
                                                            .dropdownValue,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                        ),
                                                        // hint: Text(
                                                        //   "Select Bank",
                                                        //   style: TextStyle(
                                                        //     color: Colors.grey,
                                                        //     fontSize: 16,
                                                        //     fontFamily: "verdana_regular",
                                                        //   ),
                                                        // ),
                                                        onChanged: (AppLanguage
                                                            value) {
                                                          // print(
                                                          //     "controller.languageData ${controller.languageData.myLang.name}");

                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .dropdownValue =
                                                              value;

                                                          controller.languagesRequest(
                                                              languageId: controller.selectedLanguage != null
                                                                  ? controller
                                                                      .selectedLanguage
                                                                      .id
                                                                      .toString()
                                                                  : 1
                                                                      .toString(),
                                                              autoTranslate:
                                                                  1.toString(),
                                                              appLanguageId:
                                                                  controller
                                                                      .dropdownValue
                                                                      .id,
                                                              appLanguage:
                                                                  controller
                                                                      .dropdownValue
                                                                      .name,
                                                              appLanguageCode:
                                                                  controller
                                                                      .dropdownValue
                                                                      .code);


                                                          Get.delete<
                                                              NewsfeedController>();
                                                          if (kIsWeb) {
                                                            /*Routemaster.of(context)
                                                      .replace(
                                                      AppRoute.postScreen,
                                                      queryParameters: {
                                                        "postId": null,
                                                        "profileId": null
                                                      });*/
                                                            Get.offAllNamed(
                                                                FluroRouters
                                                                    .mainScreen);
                                                          } else {
                                                            Get.offUntil(
                                                                MaterialPageRoute(
                                                                  builder:
                                                                      (context) =>
                                                                          Session(),
                                                                ),
                                                                (route) =>
                                                                    false);
                                                          }

                                                          // print(controller
                                                          //     .dropdownValue
                                                          //     .name);
                                                          controller.update();
                                                        },
                                                        items: controller
                                                            .languagesList
                                                            .map((AppLanguage
                                                                language) {
                                                          return new DropdownMenuItem<
                                                              AppLanguage>(
                                                            value: language,
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                new Text(
                                                                  language.name,
                                                                  style: new TextStyle(
                                                                      color: Colors
                                                                          .black),
                                                                ),
                                                                // controller.languageData.appLang.id == language.id?
                                                                // Icon(
                                                                //     Icons.check
                                                                // ):SizedBox(),
                                                              ],
                                                            ),
                                                          );
                                                        }).toList(),
                                                        isExpanded: false,
                                                        isDense: true,
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Divider(),
                                            ),
                                            Text(
                                              "Translation Language",
                                              style: TextStyle(
                                                color: controller.displayColor,
                                                fontSize: 15,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            SizedBox(
                                              height: 40,
                                              child: FormField<String>(
                                                builder: (FormFieldState<String>
                                                    state) {
                                                  return InputDecorator(
                                                    decoration: InputDecoration(
                                                      fillColor:
                                                          Colors.transparent,
                                                      focusColor:
                                                          Colors.transparent,
                                                      contentPadding:
                                                          EdgeInsets.only(
                                                              bottom: 5,
                                                              top: 2,
                                                              left: 15,
                                                              right: 2),
                                                      // labelText: "hi",
                                                      // labelStyle: textStyle,
                                                      // labelText: _dropdownValue == null
                                                      //     ? 'Where are you from'
                                                      //     : 'From',
                                                      hintText:
                                                          "Community Name",

                                                      enabledBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            width: 1,
                                                            color: Colors.grey),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(60),
                                                      ),

                                                      focusedBorder:
                                                          OutlineInputBorder(
                                                        borderSide: BorderSide(
                                                            width: 1,
                                                            color: Colors
                                                                .blue), //<-- SEE HERE
                                                      ),
                                                    ),
                                                    child:
                                                        DropdownButtonHideUnderline(
                                                      child: DropdownButton<
                                                          AppLanguage>(
                                                        // borderRadius: BorderRadius.circular(20),
                                                        focusColor:
                                                            Colors.transparent,

                                                        iconEnabledColor:
                                                            controller
                                                                .displayColor,
                                                        menuMaxHeight: 200,

                                                        value: controller
                                                            .dropdownValue1,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                        ),
                                                        // hint: Text(
                                                        //   "Select Bank",
                                                        //   style: TextStyle(
                                                        //     color: Colors.grey,
                                                        //     fontSize: 16,
                                                        //     fontFamily: "verdana_regular",
                                                        //   ),
                                                        // ),
                                                        onChanged: (AppLanguage
                                                            value) {
                                                          // print("hello");
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .dropdownValue1 =
                                                              value;

                                                          // print(
                                                          //     " controller.dropdownValue1 ${controller.dropdownValue1.code}");

                                                          // controller.selectedLanguage =  controller.dropdownValue1.id;

                                                          controller.languagesRequest(
                                                              languageId: controller
                                                                          .dropdownValue1 !=
                                                                      null
                                                                  ? controller
                                                                      .dropdownValue1
                                                                      .id
                                                                      .toString()
                                                                  : 1
                                                                      .toString(),
                                                              autoTranslate:
                                                                  1.toString());
                                                          // controller.postList =await controller.getNewsFeed(reload: true);
                                                          // controller.languageData =await controller.getLanguages();
                                                          // // await controller.get
                                                          // controller.isLanguageSettings =false;
                                                          //     controller.isProfileLanguagetype = false;
                                                          //     controller.isNewsFeedScreen =true;
                                                          //     controller.isSettingsScreen =false;

                                                          // MyApp.rebirth(context);
                                                          // controller.update();

                                                          // Future.delayed(
                                                          //     Duration(seconds: 2), () {

                                                          // print("dsfsfdsdfsdf");

                                                          Get.delete<
                                                              NewsfeedController>();
                                                          if (kIsWeb) {
                                                            /*     Routemaster.of(context)
                                                      .replace(
                                                      AppRoute.postScreen,
                                                      queryParameters: {
                                                        "postId": null,
                                                        "profileId": null
                                                      });*/
                                                            // Get.(FluroRouters.sessionScreen);
                                                            // Get.(FluroRouters.sessionScreen);
                                                            Get.offAllNamed(
                                                                FluroRouters
                                                                    .mainScreen);

                                                            // Get.Named(FluroRouters.sessionScreen);
                                                          } else {
                                                            Get.offUntil(
                                                                MaterialPageRoute(
                                                                  builder:
                                                                      (context) =>
                                                                          Session(),
                                                                ),
                                                                (route) =>
                                                                    false);
                                                          }
                                                          // Navigator.of(context)
                                                          //     .pushAndRemoveUntil(
                                                          //         MaterialPageRoute(
                                                          //             builder:
                                                          //                 (context) =>
                                                          //                     Session()),
                                                          //         (Route<dynamic>
                                                          //                 route) =>
                                                          //             false);
                                                          // });
                                                          // Phoenix.rebirth(context);

                                                          // print(controller
                                                          //     .dropdownValue1
                                                          //     .name);

                                                          controller.update();
                                                        },
                                                        items: controller
                                                            .translationLanguage
                                                            .map((AppLanguage
                                                                language) {
                                                          return new DropdownMenuItem<
                                                              AppLanguage>(
                                                            value: language,
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                new Text(
                                                                  language.name,
                                                                  style: new TextStyle(
                                                                      color: Colors
                                                                          .black),
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                        }).toList(),
                                                        isExpanded: false,
                                                        isDense: true,
                                                      ),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  }),
                                ),
                              ]),
                    ],
                  ),
                ),
          Padding(
            padding: const EdgeInsets.only(right: 40, left: 40),
            child: Row(children: [
              TextButton.icon(
                onPressed: () async {
                  // print("Singleton value${SingleTone.instance.socialLogin}");
                  Get.toNamed(FluroRouters.root + "/logout");

                  /*    onHomeChange = true;
                      onBrowsChange = false;
                      onTrendsChange = false;
                      onBookMarksChange = false;
                      onChatsChange = false;
                      onProfileChange = false;
                      onSettingChange = false;
                      onListChange = false;
                      onNotificationChange = false;
                      onMoreChange = false;
                      onMomentChange = false;
                      SharedPreferences preferences =
                      await SharedPreferences.getInstance();

                      if( preferences.getBool('socialLogin')==true){
                        print('social logout');
                        UtilsMethods utils=UtilsMethods();
                        utils.signOutGoogle();

                        await preferences.clear();
                        // await preferences.remove("userName");
                        // await preferences.remove("id");
                        await controller.storage.erase();
                        Get.delete<SessionController>();
                        Get.delete<ProfileController>();
                        Get.delete<NewsfeedController>();
                        controller.update();
                        preferences.setBool('guestUser', true);
                     */ /*   Routemaster.of(context).replace(
                            AppRoute.guestUserMainScreen);*/ /*
                        Get.offNamed(FluroRouters.guestUserMainScreen);
                      }
                      else{

                        await preferences.clear();
                        // await preferences.remove("userName");
                        // await preferences.remove("id");
                        await controller.storage.erase();
                        Get.delete<SessionController>();
                        Get.delete<ProfileController>();
                        Get.delete<NewsfeedController>();
                        controller.update();
                        preferences.setBool('guestUser', true);
                */ /*        Routemaster.of(context).replace(
                            AppRoute.guestUserMainScreen);*/ /*
                        Get.offNamed(FluroRouters.guestUserMainScreen);

                      }*/
                },
                icon: Icon(
                  Icons.logout,
                ),
                label: Text(
                  Strings.logout,
                  style: Theme.of(context).brightness == Brightness.dark
                      ? TextStyle(
                          color: Colors.white,
                        )
                      : TextStyle(
                          color: Colors.black,
                        ),
                ),
              ),
            ]),
          ),
          // Container(
          //   padding: EdgeInsets.only(
          //     right: 24,
          //   ),
          //   width: MediaQuery.of(context).size.width * 0.275,
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.end,
          //     children: [
          //       Text(
          //         userName != null ? userName : 'Alexa',
          //         style: Theme.of(context).textTheme.bodyText1,
          //       ),
          //       SizedBox(
          //         width: 8,
          //       ),
          //       CircleAvatar(
          //         radius: 20,
          //         foregroundImage: controller.userProfile != null && controller.userProfile.profileImage != null
          //             ? NetworkImage(controller.userProfile.profileImage)
          //             : AssetImage('assets/images/image.jpg'),
          //       ),
          //     ],
          //   ),
          // ),
        ],
      ),
    );
  }
}
