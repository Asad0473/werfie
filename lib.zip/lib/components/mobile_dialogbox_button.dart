import 'package:flutter/material.dart';

class MobileDialogboxButton extends StatelessWidget {
  final Color color;
  final Function onPressed;
  final IconData prefixIcon;
  final IconData suffixIcon;
  final String buttonText;

  MobileDialogboxButton({
    @required this.color,
    @required this.onPressed,
    @required this.prefixIcon,
    @required this.suffixIcon,
    @required this.buttonText,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ElevatedButton.icon(
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all(
            color,
          ),
        ),
        onPressed: onPressed,
        icon: Icon(prefixIcon),
        label: Row(
          children: [
            Text(buttonText),
            Icon(
              suffixIcon,
            )
          ],
        ),
      ),
    );
  }
}
