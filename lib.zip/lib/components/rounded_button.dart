import 'package:flutter/material.dart';

class RoundedButton extends StatelessWidget {
  final String buttonText;
  final Function onPressed;
  final horizontalPadding;
  final verticalPadding;
  var focusNode;
  final Color roundedButtonColor;

  RoundedButton(this.buttonText, this.onPressed,
      {Key key, this.horizontalPadding = 100.0,
      this.verticalPadding = 14.0,
      this.focusNode,
      this.roundedButtonColor}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      focusNode: focusNode,
      // focusNode: focusNode != null ? focusNode : null,
      // onFocusChange: (bool value){
      //   print("buttom  ${value}");
      //   if(value == true)
      //     {
      //       onPressed();
      //
      //     }
      //   else if (value == false)
      //   {
      //     focusNode = null;
      //
      //   }
      //
      // },
      style: ButtonStyle(
        padding: MaterialStateProperty.all(
          EdgeInsets.symmetric(
            horizontal: horizontalPadding,
            vertical: verticalPadding,
          ),
        ),
        shape: MaterialStateProperty.all(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(40.0),
          ),
        ),
        backgroundColor: MaterialStateProperty.all(roundedButtonColor),
      ),
      onPressed: onPressed,
      child: Text(
        buttonText,
        style: const TextStyle(
          fontSize: 16,
          color: Colors.white,
        ),
      ),
    );
  }
}
