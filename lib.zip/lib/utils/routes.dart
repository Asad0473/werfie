import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/screens/dicover_list_post_screen.dart';
import 'package:werfieapp/screens/login_screen.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/screens/suggested_list_screen.dart';
import 'package:werfieapp/web_views/ExampleRoute.dart';

import '../screens/re_new_password.dart';
import '../screens/reset_password_screen.dart';
import '../web_views/web_guest_user/web_guest_user_main.dart';

class AppRoute {
  static const routeMain = '/';

  // static const mobileCommentRoute = "/mobileComment";
  static const loginScreen = '/login';
  static const mainScreen = '/mainScreen';
  static const resetPasswordScreen = '/resetPassword';
  static const newPasswordScreen = '/newPassword';
  static const exampleScreen = '/exampleScreen';

  // static const mainScreen = '/main';
  static const postScreen = '/post';
  static const profileScreen = '/profile';
  static const suggestedscreen = '/suggested';
  static const discoverListScreen = '/discoverListScreen';
  static const guestUserMainScreen = '/guestUserScreen';

  // static home([CurrentTab? type]) => '/${type?.name ?? ':type'}';
  static home() => routeMain;

  // static const singleArticleWithParams = '/article/:id';
  /// get route name with parameters, here [id] is optional because we need [:id] to define path on [_singleArticleWithParams]
  static sessionWithParams([String id]) => '/article/${id ?? ':id'}';

  /// private static methods that are accessible only in this class and not from outside
/*  static Widget _homePageRouteBuilder(
          BuildContext context, GoRouterState state) =>
      HomePage(
          currentTab: state.params['type']! == CurrentTab.blogs.name
              ? CurrentTab.blogs
              : CurrentTab.favorite);

  static Widget _singleBlog(BuildContext context, GoRouterState state) =>
      SingleArticle(blog: state.extra as Blog);

  static Widget _singleArticleWithParams(
          BuildContext context, GoRouterState state) =>
      SingleArticleWithParams(id: state.params["id"]);*/

  /*static Widget errorWidget(BuildContext context, GoRouterState state) =>
      const NotFoundPage();
*/

  static SharedPreferences prefs;

  static Future<String> getSharePreference() async {
    prefs = await SharedPreferences.getInstance();
    // print('the token is ${prefs.getString("token")}');
  }

  static GoRouter returnRouter(SharedPreferences prefs) {
    // getSharePreference();
// Future.delayed(Duration(seconds: 1));
    final GoRouter router = GoRouter(
      initialLocation: routeMain,
      // debugLogDiagnostics: true,
      redirect: (context, state) {
        // if(Storage.getJWT() == null ||Storage.getJWT().isEmpty){
        // 1
        // final loginLoc = state.location.contains("loginScreen");
        // 2
        final loggingIn = state.subloc == loginScreen;
        if (prefs == null || prefs.getString("token") == null) {
          // if(!pref){
          return loginScreen;
        } else if (prefs.getString("token") != null && loggingIn) {
          return routeMain;
        } else
          return null;
      },
      routes: <GoRoute>[
        GoRoute(
          path: routeMain,
          builder: (BuildContext context, GoRouterState state) => MainScreen(
              // postId: state.params["id"],
              // profileId: state.params["profileId"],
              ),
        ),
        GoRoute(
            path: loginScreen,
            builder: (BuildContext context, GoRouterState state) => LoginScreen(
                  postId: null,
                  profileId: null,
                )),
        GoRoute(
            path: mainScreen,
            builder: (BuildContext context, GoRouterState state) =>
                MainScreen()),
        GoRoute(
            path: resetPasswordScreen,
            builder: (BuildContext context, GoRouterState state) =>
                ResetPasswordScreen()),
        GoRoute(
            path: newPasswordScreen,
            builder: (BuildContext context, GoRouterState state) =>
                NewPasswordScreen())
      ],
      // errorBuilder: errorWidget,
    );
    return router;
  }

  /// use this in [MaterialApp.router]

  // GoRouter get router => returnRouter(pref);

  static List<GetPage> get navMain {
    return [
      GetPage(
        name: routeMain,
        page: () => Session(
          postId: Get.parameters['postId'],
          profileId: Get.parameters['profileId'],
        ),
      ),
      GetPage(
        name: discoverListScreen,
        page: () => DiscoverListScreen(),
      ),
      GetPage(
        name: suggestedscreen,
        page: () => SuggestedListScreen(),
      ),

      GetPage(
        name: postScreen,
        page: () => Session(
          postId: Get.parameters['postId'],
          profileId: null,
        ),
      ),
      GetPage(
        name: profileScreen,
        page: () => Session(
          postId: null,
          profileId: Get.parameters['profileId'],
        ),
      ),
      GetPage(
        name: guestUserMainScreen,
        page: () => GuestUserMainScreen(
            /* postId: null,
          profileId: Get.parameters['profileId'],*/
            ),
      ),
      // GetPage(
      //   name: mobileCommentRoute,
      //   page: () => CommentsScreen(),
      // ),
      GetPage(
        name: loginScreen,
        page: () => LoginScreen(),
      ),
      GetPage(
        name: exampleScreen,
        page: () => ExampleRoute(),
      ),
      GetPage(
        name: mainScreen,
        page: () => MainScreen(),
      ),
    ];
  }
}
