import 'package:get/get.dart';

class Strings extends Translations {
  static const String mgsLocation = 'Allow Location Permission';
  static const String sContinue = 'Continue';
  static const String momentsScreen = 'Moments';
  static const String permissionRequired = 'Permission Required';
  static const String permissionText =
      'For the best experience, Werfie needs to use your current location to find closest provider for you. Do you want to share your location?';
  static String locationPermission = 'null';
  static String locationTag = "Location Tag";
  static String streetAddress = "Street Address";
  // static String pinnedList = "Pinned List";
  // static String private = "Make Private";
  static String account = "Accounts";

  static String someThingWentWrong = "Something went wrong! Please try again.";

  static get noResponseFromServerMsg => 'We are experiencing some difficulties. Please try again later'.tr;
  static get topic => 'Topics'.tr;
  static get moments => 'Moments'.tr;

  static get displaySettings => 'Display Setting'.tr;

  static get newsSocial => 'News'.tr;

  static get filmTV => 'Entertainment'.tr;

  static get music => 'Music'.tr;

  static get travelAdventure => 'Travel'.tr;

  static get privacyAndSafety => 'Privacy and Safety'.tr;

  static get yourWerfieActivity => 'Your Werfie activity'.tr;

  static get theseAreThePlacesWerfieUsesToShowYouMoreRelevantContentYouWontSeePlacesListedHereIfYouTurnedOffPersonalizeBasedOnPlacesYouHaveBeen =>
      "These are the places Werfie uses to show you more relevant content.You won't see places listed here if you turned off \"Personalize based on places you have been\" "
          .tr;

  static get manageTheLocationInformationWerfieUsesToPersonalizeYourExperience =>
      'Manage the location information Werfie uses to personalize your experience.'
          .tr;

  static get dataSharingAndPersonalization =>
      'Data sharing and personalization'.tr;

  static get manageWhatInformationYouSeeAndShareOnWerfie =>
      'Manage what information you see and share on Werfie.'.tr;

  static get ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked =>
      'Manage the accounts,word,and notification that you have muted or blocked.'
          .tr;

  static get manageWhatInformationYouAllowOtherPeopleOnWerfie =>
      'Manage what information you allow other people on Werfie.'.tr;

  static get manageTheInformationAssociatedWithYourWerfs =>
      'Manage the information associated with your Werfs.'.tr;

  static get decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics =>
      'Decide what you see on werfie based on your preferences like Topics'.tr;

  static get whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem =>
      "When you block someone,that person won't be able to follow or message you.and you won't see notification from them."
          .tr;

  static get ifEnabledYouWillBeAbleToAttachLocationToYourWerfs =>
      'if enabled,you will be able to attach location to your Werfs.'.tr;

  static get notificationsSettings => 'Notifications Settings'.tr;

  static get HereEveryoneYouMutedYouCanAddRemoveThemFromThisList =>
      "Here's everyone you muted.You can add remove them from this list.".tr;

  static get accountInformation => 'Account information'.tr;

  static get youCanMuteOneWordUsernameOrHashtagAtATime =>
      'You can mute one word,@username,or hashtag at a time.'.tr;

  static get whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline =>
      "when you mute words,you won't get any new notification for Werfs that include them or see Werfs with those words in your Home timeline."
          .tr;

  static get audienceAndTagging => 'Audience and tagging'.tr;

  static get photoTagging => 'Photo tagging'.tr;

  static get addLocationInformationToYourWerfs =>
      'Add location information to your Werfs'.tr;
  static get protectYourTweets => 'Protect your Werfs'.tr;

  static get controlWhoCanMessageYou => 'Control who can message you'.tr;

  static get werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen =>
      'Werfie always uses some information,like where you signed up and and your current location,to help show you more relevant content.when this setting is enabled,Werfie may also personalize your experience based on other places you have been.'
          .tr;
  static get markMediaYouWerfAsHavingMaterialThatMayBeSensitive =>
      'Mark media you Werf as having material that may be sensitive'.tr;

  static get AnyoneCanTagYou => 'Anyone can tag you'.tr;

  static get personalizeBasedOnPlacesYouHaveBeen =>
      'Personalize based on places you have been'.tr;

  static get displayMediaThatMayContainSensitiveContent =>
      'Display media that may contain sensitive content'.tr;

  static get showContentInThisLocation => 'Show content in this location'.tr;

  static get onlyPeopleYouFollowCanTagYou =>
      'Only people you follow can tag you'.tr;

  static get whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou =>
      'When selected, your werfie and account information are only visible to people who follow you'
          .tr;

  static get WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent =>
      "When enabled,picture and videos you Werf will be marked as sensitive for people who don't want to see sensitive content."
          .tr;

  static get allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo =>
      'Allow people to tag you in their photos and receive notifications when they do so'
          .tr;

  static get LearnMoreAboutPrivacyOnWerfie =>
      'Learn more about privacy on Werfie'.tr;

  static get privacyCenter => 'Privacy center'.tr;
  static get contactUs => 'Contact us'.tr;

  static get personalization => 'Personalization'.tr;

  static get muteFrom => 'Mute from'.tr;

  static get duration => 'Duration'.tr;
  static get untilYouUnmuteTheWord => 'Until you unmute the word'.tr;
  static get hours24 => '24 hours'.tr;
  static get days7 => '7 days'.tr;
  static get days30 => '30 days'.tr;

  static get fromPeopleYouDontFollow => "From people you don't follow".tr;

  static get hideSensitiveContent => 'Hide sensitive content'.tr;

  static get useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted =>
      'Use this to eliminate search results from account you have blocked or muted'
          .tr;
  static get removeBlockedAndMutedAccounts =>
      'Remove blocked and muted accounts'.tr;

  static get WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow =>
      'When this is on, you will see what is happening around you right now.'
          .tr;

  static get youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow =>
      'you can personalize trends based on your location and who you follow'.tr;
  static get locationInformation => 'Location information'.tr;

  static get thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults =>
      'This prevents Werfs with potentially sensitive content displaying in your search results.'
          .tr;

  static get optional => 'Optional'.tr;

  static get mm => 'MM'.tr;

  static get dd => 'DD'.tr;

  static get yyyy => 'YYYY'.tr;

  static get ChangeYourPassword => 'Change your password'.tr;

  static get yourWerfs => 'Your Werfs'.tr;

  static get mutedAccounts => 'Muted accounts'.tr;
  static get mutedWords => 'Muted words'.tr;

  static get mutedWord => 'Muted word'.tr;

  static get addMutedWords => 'Add muted words'.tr;

  static get mutedNotification => 'Muted notifications'.tr;

  static get directMessages => 'Direct Messages'.tr;

  static get muteAndBlock => 'Mute and block'.tr;

  static get contentYouSee => 'Content you see'.tr;

  static get ChangePasswordSettings => 'Change password'.tr;

  static get username => 'Username'.tr;

  static get enterWordOrPhrase => 'Enter word or phrase'.tr;

  static get Age => 'Age'.tr;

  static get accountCreation => 'Account creation'.tr;

  static get gender => 'Gender'.tr;

  static get werf => 'Werf'.tr;

  static get enterYourEmail => 'Enter your email'.tr;

  static get verificationCode => 'Verification code'.tr;

  static get enterYourPassword => 'Enter your password'.tr;
  static get enterYourNewPasswordHint => 'Enter your new password'.tr;


  static get createYourPassword => 'Create your password'.tr;

  static get languageSettings => 'Language Settings'.tr;

  static get blockedAccountsSettings => 'Blocked Accounts'.tr;

  static get ChangeUsernameSettings => 'Change username'.tr;

  static get ChangeGenderSettings => 'Gender'.tr;

  static get changeCountrySettings => 'Change country'.tr;

  static get selectYourPreferredLanguage => 'Select your preferred language'.tr;

  static get home => 'Home'.tr;

  static get browse => 'Browse'.tr;

  static get explore => 'Explore'.tr;

  static get exploreLocation => 'Explore location'.tr;

  static get exploreSettings => 'Explore settings'.tr;

  static get location => 'Location'.tr;

  static get searchSettings => 'Search settings'.tr;

  static get hotTrends => 'Trending'.tr;
  static get filteredResult => 'Filtered Result'.tr;

  static get list => 'Lists'.tr;
  static get listYouAre => "Lists you're on".tr;
  static get listYouHave=>"You haven't been added to any Lists yet".tr;
  static get listAddedSomeOne=>"When someone adds you to a List, it'll show up here".tr;

  static get birthDate => 'Birth date'.tr;

  static get saved => 'Saved'.tr;

  static get bookmarks => 'Bookmarks'.tr;

  static get removeWerfFromBookMark => 'Remove werf from Bookmark'.tr;
  static get bookmark => 'Bookmark'.tr;

  static get communities => 'Communities'.tr;


  static get lists => 'Lists'.tr;

  static get topics => 'Topics'.tr;

  static get seePlacesYouHaveBeen => 'See places you have been'.tr;

  static get messages => 'Messages'.tr;

  static get chat => 'Chat'.tr;

  static get chats => 'Chats'.tr;

  static get myProfile => 'My profile'.tr;

  static get settings => 'Settings'.tr;

  static get notifications => 'Notifications'.tr;

  static get pushNotifications => 'Push Notifications'.tr;

  static get settingsType => 'Settings Type'.tr;

  static get manageHowBuzzNBeeContentIsDisplayedToYou =>
      'Manage how Werfie content is displayed to you'.tr;

  static get selectYourProfileLanguage => 'Select your translation language'.tr;

  static get selectYourAppLanguage => 'Select your app language'.tr;

  static get enableDisableAutoTranslation =>
      'Enable / disable auto translation'.tr;

  ///  unreadable text
  static get language => 'Language'.tr;

  // static get yourAccount => 'Your account'.tr;

  static get YourAccount => 'Your Account'.tr;

  static get snoozeNotification => 'Snooze Notification'.tr;

  static get verificationAccount => 'Account Verification'.tr;
  static get verification => 'verification'.tr;

  static get version => 'Version'.tr;

  static get appVersion => 'App Version'.tr;

  static get copylinkToWerf => 'Copy link to werf'.tr;
  static get creatAsWerf => 'Create as werf'.tr;

  static get sendViaDirectMessage => 'Send via Direct Message'.tr;

  static get shareWerf => 'Share werf'.tr;

  static get deactivationAndDeletion => 'Deactivation and Deletion'.tr;



  static get removeAllLocationInformationAttachedToYourWerfs =>
      'Remove all location information attached to your Werfs'.tr;

  static get confirmYourPasswords => 'Confirm Your Password'.tr;

  static get views => 'Views'.tr;

  static get deactivateAccount => 'Deactivate account'.tr;

  static get dismiss => 'Dismiss'.tr;

  static get or => 'OR'.tr;

  static get deleteAccount => 'Delete account'.tr;

  static get updateYourLanguageAndTranslation =>
      'Update your language and translation settings'.tr;

  static get youHaveNotBlockedAnyPersonYet =>
      'You have not blocked any person yet'.tr;

  static get youHaveNotMutedAnyPersonYet =>
      'You have not muted any person yet'.tr;

  static get youHaveNotMutedAnyWordYet => 'You have not muted any word yet'.tr;

  static get whoCanMessageYou => 'Who can message you'.tr;

  static get manageYourPrivacySettings => 'Manage your privacy settings'.tr;

  static get privacySettings => 'Privacy Settings'.tr;

  static get setYourPrivacySettings => 'Set Your Privacy Settings'.tr;

  static get messageSettings => 'Message Settings'.tr;

  static get noOne => 'No One'.tr;

  static get daily => 'Daily'.tr;



  static get off => 'Off'.tr;

  static get biweekly => 'Biweekly'.tr;

  static get male => 'Male'.tr;

  static get female => 'Female'.tr;

  static get other => 'Other'.tr;

  static get everyOne => 'EveryOne'.tr;

  static get permanentlyDeleteAccount => 'Permanently delete account'.tr;

  static get IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount =>
      "If you want to permanently delete your Werfie account,Once you Click the ok button,you won't be able to reactivate your account or retrieve any of the content or information you have added."
          .tr;

  static get viewEditHistory => 'View Edit History'.tr;

  static get mute => 'Mute'.tr;

  static get unMute => 'UnMute'.tr;

  static get copyProfileLink => 'Copy profile link'.tr;
  static get werfReportedSuccssfully => 'Werf reported successfully!'.tr;

  static get deleteWerf => 'Delete Werf'.tr;

  static get addDescriptions => 'Add descriptions'.tr;

  static get viewWerfAnalytics => 'View Werf Analytics'.tr;

  static get pintoYourProfile => 'Pin to your profile'.tr;

  static get editWerf => 'Edit Werf'.tr;

  static get thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers =>
      'This will make them visible only to your werfie followers'.tr;

  static get ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults =>
      'This can’t be undone and it will be removed from your profile, the timeline of any accounts that follow you, and from Werfie search results.'
          .tr;
  static get unFollowDetailsStrings=>'Their Werfs will no longer show up in your home timeline. You can still view their profile, unless their Werfs are protected '.tr;

  static get locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect =>
      'Location labels you have added to your Werfs will no longer be visible on Werfie.com, Werfie for IOS, and Werfie for Android. These updates may take some time to go into effect.'
          .tr;

  static get YouCanAddADescriptionSometimesCalledAltTextToYourPhotosSoTheyreAccessibleToEvenMorePeopleIncludingPeopleWhoAreBlindOrHaveLowVisionGoodDescriptionsAreConciseButPresentWhatsInYourPhotosAccuratelyEnoughToUnderstandTheirContext =>
      "You can add a description, sometimes called alt-text, to your photos so they’re accessible to even more people, including people who are blind or have low vision. Good descriptions are concise, but present what’s in your photos accurately enough to understand their context."
          .tr;

  static get blockedAccounts => 'Blocked Accounts'.tr;

  static get translations => 'Translations'.tr;

  static get viewListOfBlockedAccounts => 'View list of blocked accounts.'.tr;

  static get realTimePostTranslation => 'Real time post translation'.tr;

  static get selectLanguageTheTimeOfUploadingVideoOrAudio =>
      'Select language at the time of uploading a video or audio'.tr;

  static get originalTranslatedScriptAudioPost =>
      'Original or translated script of audio post'.tr;

  static get listenTranslatedScript => 'Listen to translated script'.tr;

  static get automaticallyTranslateMessagesChatUsersSelectedLanguage =>
      'Automatically translate messages in chat in users selected language'.tr;

  static get postedUpdate => 'created a werf'.tr;

  static get peopleWhoReacted => 'People who reacted'.tr;

  static get comments => 'Comments'.tr;

  static get peopleWhoRetweeted => 'People who rewerfed'.tr;

  static get leaveAComment => 'Leave a comment'.tr;

  static get post => 'Werf'.tr;


  static get allwerf => 'All Werf'.tr;

  static get posts => 'Werfs'.tr;

  static get cancel => 'Cancel'.tr;

  static get noThanks => 'No, thanks'.tr;

  static get savePost => 'Save Werf'.tr;

  static get report => 'Report'.tr;

  static get reportWerf => 'Report Werf'.tr;

  static get unsaveWerf => 'Unsave Werf'.tr;

  static get hide => 'Hide'.tr;
  static get showMenu => 'Show Menu'.tr;


  static get unhideWerf => 'Unhide Werf'.tr;
  static get hideWerf => 'Hide Werf'.tr;

  static get shareLinkVia => 'Share Link via...'.tr;

  static get copyLink => 'Copy Link'.tr;

  static get fieldRequired => 'Field Required'.tr;

  static get enterDescriptionFieldIsRequired =>
      "Enter description field is required".tr;

  static get enterDescription => 'Enter Description'.tr;

  static get selectCategory => 'Select Category'.tr;

  static get okay => 'Okay'.tr;

  static get pleaseWait => 'Please wait...'.tr;

  static get search => 'Search'.tr;

  static get logout => 'Logout'.tr;

  static get writeSomethingHere => 'Write something here...'.tr;

  static get werfYourReply => 'Werf your reply...'.tr;

  static get viewTranslated => 'Translate'.tr;

  static get addMore => 'Add More'.tr;

  static get image => 'Image'.tr;

  static get video => 'Video'.tr;

  static get videos => 'Videos'.tr;

  static get file => 'File'.tr;

  static get gif => 'GIF'.tr;

  static get audio => 'Audio'.tr;

  static get live => 'Live'.tr;

  static get doNotHaveAnAccount => "Don't have an account?".tr;

  static get register => 'Register'.tr;

  static get haveAnAccount => "Have an account?".tr;

  static get login => 'Login'.tr;

  static get whoToFollow => 'Who to follow'.tr;

  static get noSuggestion => 'No Suggestion'.tr;

  static get follow => 'follow'.tr;

  static get unFollow => 'Unfollow'.tr;

  static get seeMore => 'See More'.tr;

  static get searchFilter => 'Search Filter'.tr;

  static get people => 'People'.tr;

  static get peopleInThisChat => 'People in this chat'.tr;

  static get fromAnyone => 'From Anyone'.tr;

  static get peopleYouFollow => 'People You Follow'.tr;

  static get anywhere => 'Anywhere'.tr;

  static get nearYou => 'Near You'.tr;

  static get advancedSearch => 'Advanced Search'.tr;

  static get trendsForYou => 'Trends For You'.tr;

  static get homeTimeline => 'Home timeline'.tr;

  static get noTrending => 'There are no trends in your region'.tr;

  static get pinnFavouritList =>
      'Nothing to see here yet — pin your favorite Lists to access them quickly.'
          .tr;
  static get trendingIn => 'Trending in'.tr;

  // static get tweets => 'Werfs'.tr;

  static get noNotification => 'There are no notifications for you'.tr;

  static get refresh => 'Refresh'.tr;

  static get edit => 'Edit'.tr;

  static get save => 'Save'.tr;

  static get editImageDescription => 'Edit image description'.tr;

  static get WhatIsAltText => 'What is alt text?'.tr;

  static get alt => 'ALT'.tr;



  static get cFollow => 'Follow'.tr;

  static get addPeople => 'Add People'.tr;

  static get someText => 'some text'.tr;

  static get reportConversation => 'Report Conversation'.tr;

  static get leaveConversation => 'Leave Conversation'.tr;

  static get enterYourMessage => 'Start a message'.tr;

  static get enterYourComment => 'Enter your comment'.tr;

  static get showMoreComments => 'Show more comments'.tr;

  static get reBuzz => 'Rebuzz'.tr;

  static get noPosts => 'No updates for you'.tr;


  static get emailFieldCannotBeEmpty => 'Email / Phone cannot be empty'.tr;

  static get verificationCodeCannotBeEmpty =>
      'Verification Field cannot be empty'.tr;

  static get DidNoTReceiveCode => "Didn't receive code?".tr;



  static get emailFormatIsInvalid => 'Email Format is invalid'.tr;

  static get rememberMe => 'Remember me'.tr;

  static get lostPassword => 'Lost Password?'.tr;

  static get cLOGIN => 'LOGIN'.tr;

  static get emailOrPasswordIsIncorrect => 'Email or password is incorrect'.tr;

  static get newsFeed => 'News Feed'.tr;

  static get trends => 'Trends'.tr;

  static get profile => 'Profile'.tr;

  static get newMessage => 'New Message'.tr;

  static get newChat => 'New Chat'.tr;

  static get forwardMessage => 'Forward Message'.tr;

  static get next => 'Next'.tr;

  static get verify => 'Verify'.tr;

  static get change => 'Change'.tr;

  static get changeEmail => 'Change Email'.tr;

  static get changeEmailSetting => 'Change email'.tr;

  static get current => 'Current'.tr;

  static get emailNotification => 'Email Notifications'.tr;

  static get securityAndAccountAccess => 'Security and account access'.tr;

  static get searchPeople => 'Search People'.tr;

  static get saySomething => 'Say Something'.tr;
  static get noSearchResult => 'No Search Result'.tr;

  static get searchResult => 'Search Result'.tr;

  static get hidePost => 'Hide Post'.tr;

  static get showLess => 'Show Less'.tr;

  static get showMore => 'Show More'.tr;

  static get nothingYet => 'Nothing yet!'.tr;

  static get savedPosts => 'Saved Posts'.tr;

  static get enterYourFirstName => 'Enter your name'.tr;

  static get enterYourLastName => 'Enter your last name'.tr;

  static get enterYourUsername => 'Enter your username'.tr;

  static get enterYourWerfieHandle => 'Enter your werfie handle'.tr;

  static get createYourWerfieHandle => 'Create your werfie handle'.tr;

  static get signUp => 'Sign up'.tr;

  static get pleaseChooseACountry => 'Choose your country'.tr;

  static get replied => 'replied'.tr;

  static get reply => 'Reply'.tr;

  static get delete => 'Delete'.tr;


  static get protect => 'Protect'.tr;

  static get sure => 'Sure'.tr;

  static get messageDelete => 'Delete for me'.tr;

  static get replyToComment => 'Replying to'.tr;
  static get replyingTo => 'Replying to '.tr;

  static get noFollower => 'No Follower'.tr;
  static get following => 'Following'.tr;
  static get forYou => 'For you'.tr;

  static get followings => 'Followings'.tr;

  static get followBack => 'Follow Back'.tr;

  static get followers => 'Followers'.tr;
  static get listMembers =>'List Members'.tr;
  static get listFollowers =>  'List Followers'.tr;
  static get noMembers =>'No Members'.tr;
  static get noResults =>'No results'.tr;
  static get noFollowers =>  'No Followers'.tr;
  ///new Strings add
///
  static get ok => 'OK'.tr;
  static get timesThisWerfWasSeenOnWerfie =>'Times this werf was seen on Werfie'.tr;
  static get totalNumberOfTimesAUserHasInteractedWithAWerf=> "Total number of times a user has interacted with a werf.".tr;
  static get timesPeopleViewedTheDetailsAboutThisWerf => "Times people viewed the details about this werf".tr;
  static get followsGainedDirectlyFromThisWerf => "Follows gained directly from this werf".tr;
  static get numberOfProfileViewsFromThisWerf => "Number of  profile views from this werf".tr;
  static get deleteForEveryOne => 'Delete for everyone'.tr;
  static get photo => 'Photo'.tr;
  static get emojis =>  'Emojis'.tr;
  static get uploadFile => 'Upload File'.tr;
  static get createPoll =>'Create Poll'.tr;
  static get scheduleWerf =>"Schedule Werf".tr;
  static get noVerifiedFollower =>'No Verified Follower'.tr;
  static get verifiedFollowers =>  'Verified Followers'.tr;
  static get signUpToYourAccount => "Sign Up to your account".tr;
  static get pleaseEnterYourName => 'Please enter your name'.tr;
  static get werfieHandleErrorMessage => 'Please enter a handle'.tr;
  static get emailErrorMessage => 'Please enter a valid email'.tr;
  static get werfieHandle => 'Werfie Handle'.tr;
  static get pleaseEnterAValidDOB =>'Please enter a valid DOB'.tr;
  static get pleaseEnterDOB => 'DOB (DD/MM/YYYY)'.tr;
  static get phone =>'Phone'.tr;
  static get suggestions => "Suggestions".tr;
  static get customizeYourExperience => "Customize your experience".tr;
  static get trackWhereYouSeeWerfieContentAcrossTheWeb => "Track where you see Werfie content across the web".tr;
  static get werfieUsesThisDataToPersonalizeYourExperience => "Werfie uses this data to personalize your experience. This web browsing history will never be stored with your name, email, or phone number".tr;
  static get werfieMayUseYourContactInformationIncludingYouEmail => "Werfie may use your contact information, including you email address and phone number for purposes outlined in our Privacy Policy.".tr;
  static get pleaseAgreeToWerfieTermsConditions => "Please agree to Werfie Terms & Conditions".tr;
  static get createYourAccount =>  "Create your account".tr;
  static get weSentYouACode =>  "We sent you a code".tr;
  static get enterItBelowToVerify => "Enter it below to verify ".tr;
  static get didNotReceiveEmail => "Didn't receive email?".tr;
  static get youWillNeedAPassword =>"You will need a password".tr;
  static get passwordMustBeCharactersLong=>"Password must be 8 characters long, including at least one number, one capital letter, and one special character.".tr;
  static get   pleaseEnterAValidEmail => 'Please enter a valid Email / Phone'.tr;
  static get resend => "Resend".tr;
  static get usePhoneInstead =>  "Use Phone Instead".tr;
  static get useEmailInstead => "Use Email Instead".tr;
  static get loginWithEmail => 'Login with Email'.tr;

  static get google =>"Google".tr;
  static get apple =>"Apple".tr;
  static get worldNoor =>"Worldnoor".tr;
  static get doNotMissWhatsHappening =>"Don’t miss what’s happening".tr;
  static get peopleOnWerfieAreTheFirstToKnow =>"People on Werfie are the first to know".tr;
  static get newToWerfie =>  "New to Werfie?".tr;
  static get signUpNowToGetYourOwnPersonalizedTimeline =>'Sign up now to get your own personalized timeline!'.tr;
  static get signUpWithGoogle =>  "Sign Up with Google".tr;
  static get signUpWithApple =>"Sign Up with Apple".tr;
  static get signUpWithEmailOrMobile => "Sign Up with Email or Mobile".tr;
  static get loginWithWorldNoor => "Login with WorldNoor".tr;
  static get bySigningUpYouAgreeOur => 'By signing up, you agree our'.tr;
  static get trending =>'Trending'.tr;
  static get noUserNoTag => 'No user && No tag'.tr;
  static get noTrendsInThisRegion =>'No Trends inThis Region'.tr;
  static get weAreExperiencingSomeDifficulties => "We are experiencing some difficulties. Please try again later".tr;
  static get noPost => 'No Post'.tr;

  static get signInToYourAccount => "Sign In to your account".tr;
  static get enterEmailPhone => "Enter Email / Phone".tr;
  static get forgotPassword => "Forgot Password?".tr;
  static get itSeemsLikeYouAreARobot=> " It seems like you are a robot. please verify again".tr;
  static get signIn=>  "Sign In".tr;
  static get registerHere=> "Register here!".tr;
  static get orContinueWith=> "Or continue with".tr;
  static get somThingWentWrongWithConfiguration=>  "Somthing went wrong with configuration. please try again".tr;
  static get error=>"Error".tr;
  static get pleaseAllowEmailToContinueWithWerfie=> "Please allow email to continue with werfie".tr;
  static get alert=> "Alert".tr;
  static get sorryForTheInconvenience=>"Sorry for the inconvenience. Please try again later.".tr;
  static get enterDigitsVerificationCodeSentToYourRegisteredEmail=> "Enter 6-digits verification code Sent to your registered email".tr;


  static get theUsernameHasAlreadyBeenTaken => 'The username has already been taken.'.tr;
  static get thereWasAnErrorInSavingThisUsername => " There was an error in saving this Username!".tr;
  static get yourPasswordIsWeakSignUP => 'Your password is weak'.tr;
  static get chooseASecurePassword => 'Choose a secure password'.tr;
  static get yourPasswordIsStrong =>'Your password is strong'.tr;
  static get topicsThatYouFollowShownHere =>
      'Topics that you follow are shown here. To see all the things that Werfie thinks you’re interested in, check out Your Werfie data. You can also learn more about following Topics.'
          .tr;
  static get yourPasswordIsWeak => 'Your password is weak, please choose a strong password'.tr;

  static get thisPollHasExpired => 'This poll has expired'.tr;
  static get youCannotVoteOnYourOwnPoll => 'You cannot vote on your own poll!'.tr;
  static get choice => "Choice".tr;
  static get optionalPoll => "(Optional)".tr;

  static get watchPartyLetGo =>  "Watch party, let's go".tr;
  static get createSpace =>'Create Space'.tr;
  static get oopsSomethingWentWrongPleaseTryAgain => 'Oops…Something went wrong! Please try again'.tr;
  static get noSpacesAvailable => 'No spaces available'.tr;
  static get yourSpaceIsReady => "Your space is ready".tr;
  static get spaceLinkCopiedSuccessfully => 'Space link copied successfully'.tr;
  static get instant => 'Instant'.tr;
  static get nameYourSpace => 'Name your space'.tr;
  static get whatDoYouWantToTalkAbout =>'What do you want to talk about?'.tr;
  static get scheduleYourSpace => "Schedule your space".tr;
  static get confirm => 'Confirm'.tr;
  static get selectTopic => 'Select Topic'.tr;
  static get momentDeleteSuccessfully => "Moment Deleted Successfully".tr;
  static get createSpaceSuccessfully => "Create Space Successfully".tr;
  static get pleaseEnterTheSpaceName => "Please enter the space name".tr;
  static get spaces => 'Spaces'.tr;


  static get pleaseChooseEither1VideoOr1Pdf=> "Please choose either 1 video or 1 Pdf at a time or up to 4 photos.".tr;
  static get fileTypeIsNotAllowed=>'File type is not allowed'.tr;
  static get thisPostIsScheduledFor=> "This post is scheduled for".tr;
  static get askAQuestion=> 'Ask a question...'.tr;
  static get pollLength=>'Poll length'.tr;
  static get hours=> 'Hours'.tr;
  static get minutes=>'Minutes'.tr;
  static get removePoll=> 'Remove Poll'.tr;
  static get uploading=> 'Uploading...'.tr;
  static get addDescription=> "Add Description".tr;
  static get willPostOn=>  "Will Post on".tr;
  static get date=>'Date'.tr;
  static get youCannotScheduleAWerfInThePast=> 'You cannot schedule a Werf in the past'.tr;
  static get time=> 'Time'.tr;
  static get timeZone=> 'Time zone'.tr;
  static get youHaveNoScheduledWerfs=> 'You have no scheduled werfs'.tr;
  static get willSendOn=>  "Will send on".tr;
  static get selectAll=> 'Select all'.tr;
  static get schedule=> 'Schedule'.tr;
  static get scheduledWerfs=> 'Scheduled Werfs'.tr;
  static get deselectAll=> 'Deselect all'.tr;
  static get yourImageVideoWillBeAvailableInAMoment=> 'Your image/video will be available in a moment.'.tr;
  static get pleaseEnterValidText=> 'Please enter valid text'.tr;
  static get takeAPhoto=> "Take a Photo".tr;
  static get chooseFromGallery=>  "Choose from Gallery".tr;
  static get makeVideoWithPhoneCamera=> "Make video with phone camera".tr;
  static get unsentWerfs=> 'Unsent Werfs'.tr;



  static get commentsHere=>'comments here'.tr;
  static get ImageDescription => 'Image description'.tr;
  static get viewHiddenReplies=> 'View Hidden Replies'.tr;
  static get undoRewerf=> 'Undo Rewerf'.tr;

  static get share=>  "Share".tr;
  static get view=>  "View".tr;
  static get werfLinkCopiedSuccessfully=> "Werf link copied successfully".tr;
  static get addBookmark=> "Add Bookmark".tr;
  static get removeBookmark=> "Remove Bookmark".tr;
  static get werfSavedSuccessfully=> 'Werf saved successfully!'.tr;
  static get werfUnsavedSuccessfully=>  'Werf unsaved successfully!'.tr;
  static get thereWasAnErrorInUnSavingThisWerf=> 'There was an error in unsaving this werf!'.tr;
  static get thereWasAnErrorInSavingThisWerf=>'There was an error in saving this werf!'.tr;
  static get thereWasAnErrorInBlockingThisUser=>'There was an error in blocking this user!'.tr;
  static get noEditHistory=> 'No edit history'.tr;
  static get unPinFromProfile=> "UnPin from Profile".tr;
  static get saveWerf=> 'Save Werf'.tr;
  static get linkCopiedToClipBoard=>  'Link copied to clipboard!'.tr;
  static get removeFromBookmarks=> 'Remove from bookmarks'.tr;
  static get thereWasAnErrorInReportingThisUser=> 'There was an error in reporting this user!'.tr;
  static get viewOriginal=>  "Original".tr;
  static get showThisThread=>'Show this thread'.tr;
  static get rewerf => 'Rewerf'.tr;


  static get nothingFound=>'Nothing found'.tr;
  static get year=>'Year'.tr;
  static get day => 'Day'.tr;
  static get month => 'Month'.tr;
  static get thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount =>
  "This should be the date of birth of the person using the account. Even if you’re making an account for your business or event.".tr;
  static get editDateOfBirth => 'Edit date of birth?'.tr;
  static get deletePhoto =>"Delete photo".tr;
  static get removePhoto => "Remove photo".tr;
  static get addPhoto =>"Add photo".tr;
  static get discard => "Discard".tr;
  static get removeWerfAlert =>
      "This can't be undone and you'll lose your changes".tr;
  static get discardChanges => "Discard changes?".tr;
  static get youShouldBeAtLeast14YearsOld=> 'You should be at least 14 years old'.tr;
  static get contentOfDialog =>"Content of Dialog".tr;
  static get pinnedWerf => "Pinned Werf".tr;
  static get hiddenPost => "Hidden Werfs".tr;
  static get thisCanBeOnlyChangedAFewTimes =>" This can be only changed a few times. Make sure you enter the age of the person using the account".tr;

  static get aboutHashTag => 'About hashtag'.tr;
  static get werfHashTag => 'Werf hashtag'.tr;

  static get messageRequests => 'Message requests'.tr;
  static get enterGroupChatTitle =>  "Enter group chat title".tr;
  static get chooseOneFromYourExistingChatsOrStartANewOne =>
      'Choose one from your existing chats, or start a new one'.tr;
  static get snoozeNotificationsFrom =>  "Snooze notifications from".tr;
  static get snoozeNotificationsFromTheGroup => "Snooze notifications from the group".tr;
  static get snoozeMentions => "Snooze mentions".tr;
  static get disableNotificationsWhenPeoplemention => "Disable notifications when people mention you in this conversation.".tr;
  static get trySearchingForPeopleGroupsOrMessages => "Try searching for people,groups, or messages".tr;
  static get werfieUser =>  "Werfie User".tr;
  static get otherChat =>"other...".tr;
  static get photoChat => 'Photo'.tr;
  static get videoChat => 'Video'.tr;
  static get fileChat => 'File'.tr;
  static get directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore =>
      'Direct Messages are private conversations between you and other people on Twitter. Share Tweets, media, and more!'
          .tr;
  static get searchChats => "Search Chats".tr;
  static get allTabChat => "All".tr;
  static get peopleTabChat => "People".tr;
  static get groupsTabChat =>"Group".tr;
  static get chatsTabChat =>"Chats".tr;
  static get noResultsFor => "No results for".tr;
  static get theTermYouEnteredDidNotBring => "The term you entered did not bring up any results".tr;
  static get message => "Message".tr;
  static get addMembersToChat => 'Add members to chat'.tr;
  static get noMessagesYet => "No Messages Yet".tr;
  static get doNotAllowMessages => "don't allow messages".tr;
  static get notAllowedToMessage => "Not allowed to message.".tr;
  static get youHaveBlockedThisUser => "You have blocked this user".tr;
  static get startAMessage =>   "Start a message".tr;
  static get react =>  "React".tr;
  static get undo => "Undo".tr;
  static get reactions => 'Reactions'.tr;
  static get messageRequestsFallHere =>
      "Message requests from people you don't follow live here. To reply there message, you need to accept the request."
          .tr;
  static get noMessageRequestAvailable => 'No Message Request Available'.tr;
  static get dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage =>
      'Depending on the setting you select,different people can send you a direct message.'
          .tr;
  static get allowMessagesOnlyFromPeopleYouFollow =>
      'Allow messages only from people you follow'.tr;
  static get youWontReceiveAnyMessageRequests =>
      "You won't receive any message requests".tr;
  static get allowMessageRequestsOnlyFromVerifiedUsers =>
      "Allow message requests only from Verified users".tr;
  static get peopleYouFollowWillStillBeAbleToMessageYou =>
      "People you follow will still be able to message you".tr;
  static get allowMessagesRequestsFromEveryone =>
      'Allow messages requests from everyone'.tr;
  static get otherControls => "Other controls".tr;
  static get filterLowQualityMessages => "Filter low-quality messages".tr;
  static get hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant =>
      "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want"
          .tr;
  static get showReadReceipts => "Show read receipts".tr;
  static get letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests =>
      "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests"
          .tr;



  static get getPushNotificationsToFindOut =>"Get push notifications to find out what’s going on when you’re not on Werfie. You can turn them off anytime.".tr;
  static get relatedToYouAndYourWerfs => "Related to you and your Werfs".tr;
  static get whenYouTurnOnWerfNotificationsFromPeopleYouFollow => "When you turn on Werf notifications from people you follow, you'll get push notifications about their Werfs.".tr;
  static get topWerfs => "Top Werfs".tr;
  static get tailoredForYou=> "Tailored for you".tr;
  static get like => 'Like'.tr;
  static get photoTags => "Photo Tags".tr;
  static get messageReactions => "Message Reactions".tr;
  static get fromWerfie => "From Werfie".tr;
  static get newsSports => "News / Sports".tr;
  static get recommendations => "Recommendations".tr;
  static get turnOnPush => "Turn on push\nnotifications".tr;
  static get toReceiveNotificationsAsTheyHappen =>"To receive notifications as they happen, turn on\npush notification, You'll also receive them when\nyou're not on Werfie. Turn them off anytime.".tr;
  static get turnOn => "Turn on".tr;
  static get newNotifications =>  "New notifications".tr;
  static get werfsEmailedToYou => "Werfs emailed to you".tr;
  static get weekly => 'Weekly'.tr;
  static get newAboutWerfieProduct =>"New about Werfie product and features updates".tr;
  static get tipsOnGettingMoreOut=> "Tips on getting more out of Werfie".tr;
  static get thingsYouMissedSinceYou=> "Things you missed since you last logged into Werfie".tr;
  static get participationInWerfieResearchSurveys=> "Participation in Werfie research surveys".tr;
  static get suggestionsRorRecommendedAccounts=> "Suggestions for recommended accounts".tr;
  static get suggestionsBasedOnYourRecentFollows=> "Suggestions based on your recent follows".tr;


  static get qualityFilters => "Quality filters".tr;
  static get chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs =>"Choose to filter out content such as duplicate and automated Werfs. This doesn't apply to notifications from accounts you follow and have interacted with recently.".tr;

  static get filters => "Filters".tr;
  static get chooseTheNotification => "Choose the notification you'd like to see and those you don't".tr;
  static get preferences => "Preferences".tr;
  static get selectYourPreferencesByNotificationType =>"Select your preferences by notification type.".tr;

  static get forever => " Forever".tr;
  static get muteNotificationsFromPeople =>"Mute notifications from people:".tr;
  static get youDoNotFollow => "You don't follow".tr;
  static get whoDoNotFollowYou =>  "Who don't follow you".tr;
  static get withANewAccount => "With a new account".tr;
  static get whoHaveDefaultProfilePhoto => "Who have default profile photo".tr;
  static get whoHaveNotConfirmedTheirEmail => "Who haven't confirmed their email".tr;
  static get whoHaveNotConfirmedTheirPhoneNumber =>"Who haven't confirmed their phone number".tr;

  static get security => 'Security'.tr;
  static get manageYourAccountsSecurity => "Manage your accounts security".tr;
  static get twoFactorAuthentication => "Two-factor authentication".tr;
  static get manageYourAccountsSecurityKeepTrack => "Manage your accounts security and keep track of your account usage".tr;
  static get helpProtectYourAccountFromUnauthorizedAccess =>  "Help protect your account from unauthorized access by requiring a second authentication method in addition to your X password. You can choose a text message, authentication app, or security key.".tr;
  static get verificationCodeSentToYourRegisteredEmail => "Enter 6-digits verification code Sent to your registered email".tr;
  static get submit =>'Submit'.tr;

      static get genderChangedSuccessfully => "Gender Changed Successfully".tr;
  static get genderSettingTextDescription =>"If you haven’t already specified a gender, this is the one associated with your account based on your profile and activity. This information won’t be displayed publicly.".tr;
  static get updateEmailAddress =>  'Update email address'.tr;
  static get youHaveNotCreatedOrFollowedAnyLists =>  "You haven't created or followed any Lists. When you do, they'll show up here.".tr;
  static get userCanPinnedOnly5  => 'User can pinned  only 5 '.tr;
  static get pleaseEnterTheName  => 'Please enter the name '.tr;
  static get follower => 'Follower'.tr;

  static get noFollowings => 'No Followings'.tr;

  static get sendAMessageGetAMessage => 'Send a message, get a message'.tr;

  static get werfieTagline =>
      'Join Werfie and create your own social network. Stay up to date with latest happenings and hot trends. Share your updates, reply to werfs and stay current!'
          .tr;

  static get startAConversation => 'Start a Conversation'.tr;

  static get groupInfo => 'Group Info'.tr;

  static get chatInfo => 'Chat Info'.tr;
  static get createWerf => 'Create Werf'.tr;
  static get viewWerfs => 'View Werfs'.tr;

  static get youDoNotHaveAMessageSelected =>
      'You don’t have a message selected'.tr;

  static get youDoNotHaveAChatSelected => 'You don’t have a chat selected'.tr;

  static get chooseOneFromYourExistingMessagesOrStartANewOne =>
      'Choose one from your existing messages, or start a new one'.tr;



  static get pleaseEnterVerificationCodeToVerifyYourEmail =>
      'Please enter verification code to verify your email'.tr;

  static get usernameOrEmail => 'Username or Email'.tr;

  static get enterVerificationCode => 'Enter verification code'.tr;

  static get confirmCode => 'Confirm Code'.tr;


  static get top => 'Top'.tr;

  static get latest => 'Latest'.tr;

  static get photos => 'Photos'.tr;

  static get files => 'Files'.tr;

  static get noPeople => 'No People'.tr;

  static get all => 'All'.tr;

  static get mentions => 'Mentions'.tr;

  static get replies => 'Reply'.tr;

  static get tweetsAndReplies => 'Werfs & Replies'.tr;

  static get media => 'Media'.tr;

  static get likes => 'Likes'.tr;

  static get searchPost => 'Search Updates'.tr;

  static get lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail =>
      'Lost your password? Please enter your email address. You will receive a code to create a new password via email.'
          .tr;

  static get resetYourPassword => 'Reset Your Password'.tr;

  static get enterCode => 'Enter Code you have received on your email'.tr;

  static get enterNewPassword => 'Enter New Password'.tr;

  static get enterCurrentPassword => 'Enter Current Password'.tr;

  static get reEnterPassword => 'Re-Enter Password'.tr;

  static get passwordCannotBeEmpty => 'Password cannot be Empty'.tr;

  static get passwordShouldBeCharacter =>
      'Password should be at least 8 character long'.tr;

  static get passwordShouldBeMatched => 'Password should be Matched'.tr;

  static get resetPassword => 'Reset Password'.tr;

  static get email => 'Email'.tr;

  static get country => 'Country'.tr;

  static get blockUser => 'Block user'.tr;

  static get reportUser => 'Report user'.tr;

  static get public => 'Public'.tr;

  static get mentionUsers => 'Mention Users'.tr;

  static get editProfile => 'Edit Profile'.tr;

  static get yourProfileIsUpdated => 'Your Profile is updated'.tr;

  static get seeProfile => 'See Profile'.tr;

  static get skipForNow => 'Skip for now'.tr;

  static get addBio => 'Add Bio'.tr;

  static get profileUpdated => 'Profile Updated'.tr;

  static get upDate => 'Update'.tr;

  static get goToProfile => 'Go to Profile'.tr;

  static get english => 'English'.tr;

  static get arabic => 'عربي'.tr;

  static get french => 'Français'.tr;

  static get german => 'Deutsche'.tr;

  static get spanish => 'Española'.tr;

  static get hindi => 'हिंदी'.tr;

  static get indonesia => 'Bahasa Indonesia'.tr;

  static get portuguese => 'Português'.tr;

  static get turkish => 'Turca'.tr;

  static get somali => 'Shoomaali'.tr;

  static get persian => 'فارسی'.tr;

  static get more => 'More'.tr;

  static get about => 'About'.tr;

  static get help => 'Help'.tr;

  static get privacyPolicy => 'Privacy Policy'.tr;

  static get blog => 'Blog'.tr;

  static get termsOfService => 'Terms of Service'.tr;

  static get youMustSelectACountry => 'You must select a country'.tr;

  static get selectACountry => 'Select a country'.tr;

  static get usernameIsAlreadyTaken => 'Wefie Handle is already taken'.tr;

  static get goBack => 'Go back'.tr;

  static get snAccountHasAlreadyBeenCreatedWithThisEmail =>
      'An account has already been created with this email'.tr;

  static get yourPasswordIsResetSuccessfully =>
      'Your password is reset successfully'.tr;

  static get returnToLogin => 'Return to Login'.tr;

  static get youHaveEnteredAnInvalidCode =>
      'You have entered an invalid code'.tr;

  static get thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe =>
      'Thank you for creating your account with Werfie. Stay Safe!'.tr;

  static get success => 'Success'.tr;
  static get privacy => 'Privacy'.tr;

  static get goBackToHomePage => 'Go back to Home page'.tr;

  static get popularUpdates => 'Popular Updates'.tr;

  static get discoverlist => 'Discover New Lists'.tr;

  static get yourlist => 'Your Lists'.tr;



  static get liked => 'Liked'.tr;

  static get postDetail => 'Werf Detail'.tr;

  static get trendingUpdates => 'Trending Updates'.tr;

  static get forward => 'Forward message'.tr;

  static get copy => 'Copy message'.tr;

  static get textLimitExceeded => 'Text limit exceeded.'.tr;

  static get editChat => 'Edit'.tr;
  static get userBlockedSuccessfully => 'User blocked successfully!'.tr;
  static get werfHideSuccessMsg => 'Werf has been hidden successfully!'.tr;


  static get werfUnHideSuccessMsg => 'Werf has been unhidden successfully!'.tr;


  static get postOnlyCanUpdateIn60minutes => 'Post only can update in 60 minutes'.tr;




  ///static get werfUnHideSuccessMsg => 'Werf has been unhidden successfully!'.tr;

  static get werfHideFailedMsg => 'There was an error in hiding werf!'.tr;

  static get werfUnHideFailedMsg => 'There was an error in unhiding werf!'.tr;

  static get userReportedSuccessfully => 'User reported successfully!'.tr;
  static get muteUser => 'muted successfully'.tr;
  static get profileLinkCopy => 'Profile link copied successfully'.tr;
  static get noReplyComments => 'Be the first one to reply'.tr;
  static get rewerfSuccessfully => 'ReWerf Successfully'.tr;
  static get quoteRewerf => 'Quote Rewerf'.tr;
  static get pinPostMsg => 'Pin post to your profile'.tr;
  static get unPinPostMsg => 'Unpin post to your profile'.tr;
  static get newWerfs => 'New Werfs'.tr;
  static get newWerf => 'New Werf'.tr;
  static get werfSeenCountMsg => 'This werf was seen'.tr;
  static get deleteConversation => 'Delete Conversation'.tr;
  static get loginWithGoogle => 'Login with Google'.tr;
  static get unBlock => 'Unblock'.tr;
  static get wrongPasswordMsg => 'Wrong password'.tr;
  static get confirmPassMsg => 'Confirm Your Password'.tr;
  static get viewTopics => 'View Topics'.tr;
  static get werfs => 'Werfs'.tr;
  static get onlyPeopleYouMention => 'Only people you mention'.tr;
  static get changedTheCountryName =>
      'Changed the country name successfully!'.tr;
  static get everyoneCanReply => 'Everyone can reply'.tr;
  static get whoCanReply => 'Who can reply?'.tr;
  static get pickWhoCanReplyMsg => 'Who can reply?'.tr;
  static get otpSentMsg =>
      "We have just sent a 6-digit code. Enter that code in the place given below and press Confirm button"
          .tr;
  static get getEmailToFindOut =>
      "Get emails to find out what’s going on when you’re not on Werfie. You can turn them off anytime."
          .tr;

  static get userNameSavedSuccessfully => "Username saved successfully".tr;
  static get theTopicsYouFollow =>
      'The Topics you follow are used to personalize the Werfs, events, and ads that you see, and show up publicly on your profile'
          .tr;
  static get addToYourList => 'Add To Your List'.tr;
  static get noMsgsYet => "No Messages Yet".tr;
  static get listYouAreON => "Lists you’re on".tr;
  static get manageMembers => "Manage Members".tr;
  static get editList => "Edit List".tr;
  static get done => "Done".tr;
  static get createNewList => "Create New List".tr;
  static get makePrivate => "Make Private".tr;
  static get whenYouMakeAList =>
      "When you make a List private, only you can see it.".tr;
  static get members => "Members".tr;
  static get remove => "Remove".tr;
  static get add => "Add".tr;
  static get suggested => "Suggested".tr;
  static get notInterested => "Not Interested".tr;
  static get followed => "Followed".tr;
  static get werfAnalytics => "Werf Analytics".tr;
  static get impressions => "Impressions".tr;
  static get engagements => "Engagements".tr;
  static get detailExpands => "Detail Expands".tr;
  static get newFollowers => "New Followers".tr;
  static get profileVisits => "Profile Visits".tr;
  static get tagLocation => "Tag location".tr;
  static get searchLocation => "Search location".tr;
  static get youHaveAlreadyReportedWerf =>
      "You have already reported this werf".tr;
  static get thisWerfSeen => "This werf was seen".tr;
  static get times => "times".tr;
  static get customizeView => "Customize your view".tr;
  static get block => "Block".tr;
  static get colors => "Colors".tr;
  static get dark => "Dark".tr;
  static get light => "Light".tr;
  static get editGroup => "Edit Group".tr;
  static get viewHiddenReply => "View Hidden Reply".tr;
  static get theseSettingsAffect =>
      "These settings affect all the Werfie accounts on this browser.".tr;
  static get nothingToSeeHerePinYour =>
      "Nothing to see here yet — pin your favorite Lists to access them quickly."
          .tr;
  static get nothingToSeeHere => "Nothing to see here yet".tr;
  static get momentsDelete => "Moments Delete?".tr;
  static get createMoment => "Create Moment".tr;
  static get removeMomentAlertMsg =>
      "This can’t be undone and you’ll lose your Moment.".tr;

  static get seizeTheMoment => 'Seize the Moment'.tr;
  static get createNew => 'Create New'.tr;
  static get suggestedTopics => 'Suggested Topics'.tr;
  static get chooseYourLists => 'Choose your Lists'.tr;
  static get createANewWerf => 'Create a new werf'.tr;
  static get clear => 'Clear'.tr;
  static get justNow => 'Just Now'.tr;
  static get noMomentsList => 'No Moments'.tr;
  static get chooseAnExistingMomentOrCreateNew =>
      'Choose and existing moment or create a new one'.tr;
  static get whenYouFollowMsg =>
      "When you follow a List, you'll be able to quickly keep up with the experts on what you care about most."
          .tr;



  static get pendingRequest => 'Pending requests'.tr;

  static get accept => 'Accept'.tr;

  static get reject => 'Delete'.tr;

  static get doYouWantToLet => 'Do you want to let '.tr;

  static get toMessageYou =>
      ' To message you? They wont know that you have seen their message until you accept.'
          .tr;

  static get reportBlock => 'Report/Block'.tr;
  static get allReply => 'All Reply'.tr;
  static get addWerfs => 'Add Werfs'.tr;
  static get werfsILiked => "Werfs I've liked".tr;
  static get werfsByAccount => "Werfs by account".tr;
  static get werfSearch => "Werfs search".tr;
  static get likedBy => 'Liked by '.tr;
  static get publish => 'Publish '.tr;
  static get addATitle => 'Add a title '.tr;
  static get writeAShortDesc => 'Write a short description about moments'.tr;
  static get editOrder => 'Edit Order'.tr;
  static get searchForAnItem => 'Search for an item...'.tr;
  static get signInWithApple => 'Login with Apple'.tr;
  static get pinnedList => 'Pinned List'.tr;
  static get getMoments => 'Get Moments'.tr;
  static get verified => 'Verified'.tr;
  static get noWerfs => 'No Werfs'.tr;
  static get enterYourNewPassword =>
      "Enter your new password and press Next button. We will send you a 6-digit code. You will need to enter that 6-digit code on the next screen to complete the process."
          .tr;
  static get requestVerification => "Request Verification".tr;
  static get youllSeeTopWerfs =>
      "You'll see top Werfs about these right in your Home timeline".tr;
  static get weWontSuggestThisTopic => "We won’t suggest this Topic anymore".tr;
  static get create => "Create".tr;
  static get name => "Name".tr;
  static get bio => "Bio".tr;
  static get private => "Make Private".tr;
  static get werfUnsaved => 'Werf Unsaved successfully!'.tr;
  static get areYouSure => 'Are you sure?'.tr;
  static get doYouWantToExit => 'Do you want to exit the App'.tr;
  static get no => 'No'.tr;
  static get yes => 'Yes'.tr;
  static get privacyUpdated => 'Privacy Updated'.tr;
  static get bySigningUpYouAgree => 'By signing up, you agree our'.tr;
  static get and => 'and'.tr;
  static get nameCannotBeEmpty => "Name is required".tr;
  static get nameLengthShouldMax20 =>
      "Name length should not greater than 20".tr;
  static get nameStartsWithCharacter => "Werfie handle is invalid".tr;
  static get pleaseProvideAValidEmail => "Please provide a valid email".tr;
  static get werfieHandleIsRequired => "Werfie handle is required".tr;
  static get yourAndTagging => "Your and tagging".tr;
  static get welcomeToWerfie => "Welcome to Werfie".tr;
  static get dobAddMsg => 'Add your date of birth to your '.tr;
  static get noInternetAvailable => 'No Internet Available!'.tr;
  static get passwordShouldBeMin8Char =>
      'Password should be at least 8 character long'.tr;
  static get pleaseEnterYourBirthDate => 'Please Enter your Date of Birth'.tr;
  static get cantChooseEmailAsApass =>
      "Your can't choose email as a password please \nchoose a secure password"
          .tr;
  static get passMustContainUpperCaseAndLeeter =>
      'Password must contain at least one uppercase letter \nand one number'.tr;
  static get bothPasswordAndConfirmPassShouldMatch => 'Both password and confirm password should match'.tr;

  static get enterYourBirthDateOptional =>
      'Enter your date of birth (Optional)'.tr;


  @override
  Map<String, Map<String, String>> get keys => {
        'en': {
  ok : 'OK',
 timesThisWerfWasSeenOnWerfie :'Times this werf was seen on Werfie',
  totalNumberOfTimesAUserHasInteractedWithAWerf: "Total number of times a user has interacted with a werf.",
   timesPeopleViewedTheDetailsAboutThisWerf : "Times people viewed the details about this werf",
  followsGainedDirectlyFromThisWerf : "Follows gained directly from this werf",
  numberOfProfileViewsFromThisWerf : "Number of  profile views from this werf",
 deleteForEveryOne : 'Delete for everyone',

 photo : 'Photo',
   emojis : 'Emojis',
   uploadFile: 'Upload File',
   createPoll :'Create Poll',
  scheduleWerf :"Schedule Werf",

   loginWithEmail : 'Login with Email',
   usePhoneInstead :  "Use Phone Instead",
  useEmailInstead : "Use Email Instead",
  noVerifiedFollower :'No Verified Follower',
   verifiedFollowers :  'Verified Followers',
  signUpToYourAccount : "Sign Up to your account",
  pleaseEnterYourName : 'Please enter your name',
  werfieHandleErrorMessage : 'Please enter a handle',
  emailErrorMessage : 'Please enter a valid email',
   werfieHandle : 'Werfie Handle',
 pleaseEnterAValidDOB :'Please enter a valid DOB',
   pleaseEnterDOB : 'DOB (DD/MM/YYYY)',
  phone :'Phone',
 suggestions : "Suggestions",
  customizeYourExperience : "Customize your experience",
 trackWhereYouSeeWerfieContentAcrossTheWeb : "Track where you see Werfie content across the web",
 werfieUsesThisDataToPersonalizeYourExperience : "Werfie uses this data to personalize your experience. This web browsing history will never be stored with your name, email, or phone number",
  werfieMayUseYourContactInformationIncludingYouEmail : "Werfie may use your contact information, including you email address and phone number for purposes outlined in our Privacy Policy.",
   pleaseAgreeToWerfieTermsConditions: "Please agree to Werfie Terms & Conditions",
   createYourAccount :  "Create your account",
  weSentYouACode : "We sent you a code",
   enterItBelowToVerify :"Enter it below to verify ",
  didNotReceiveEmail : "Didn't receive email?",
   youWillNeedAPassword :"You will need a password",
  passwordMustBeCharactersLong:"Password must be 8 characters long, including at least one number, one capital letter, and one special character.",
     pleaseEnterAValidEmail : 'Please enter a valid Email / Phone',
   resend : "Resend",

   google :"Google",
   apple :"Apple",
  worldNoor :"Worldnoor",
   doNotMissWhatsHappening :"Don’t miss what’s happening",
  peopleOnWerfieAreTheFirstToKnow :"People on Werfie are the first to know",
  newToWerfie :  "New to Werfie?",
  signUpNowToGetYourOwnPersonalizedTimeline :'Sign up now to get your own personalized timeline!',
   signUpWithGoogle :  "Sign Up with Google",
   signUpWithApple :"Sign Up with Apple",
  signUpWithEmailOrMobile : "Sign Up with Email or Mobile",
   loginWithWorldNoor : "Login with WorldNoor",
   bySigningUpYouAgreeOur : 'By signing up, you agree our',
   trending :'Trending',
   noUserNoTag : 'No user && No tag',
   noTrendsInThisRegion :'No Trends inThis Region',
    weAreExperiencingSomeDifficulties : "We are experiencing some difficulties. Please try again later",
 noPost : 'No Post',

  signInToYourAccount : "Sign In to your account",
enterEmailPhone : "Enter Email / Phone",
  forgotPassword : "Forgot Password?",
  itSeemsLikeYouAreARobot: " It seems like you are a robot. please verify again",
 signIn:  "Sign In",
  registerHere: "Register here!",
   orContinueWith: "Or continue with",
  somThingWentWrongWithConfiguration: "Somthing went wrong with configuration. please try again",
   error:"Error",
   pleaseAllowEmailToContinueWithWerfie: "Please allow email to continue with werfie",
   alert: "Alert",
   sorryForTheInconvenience:"Sorry for the inconvenience. Please try again later.",
   enterDigitsVerificationCodeSentToYourRegisteredEmail: "Enter 6-digits verification code Sent to your registered email",

  theUsernameHasAlreadyBeenTaken : 'The username has already been taken.',
  thereWasAnErrorInSavingThisUsername : " There was an error in saving this Username!",

   showMenu : 'Show Menu',
   thisPollHasExpired : 'This poll has expired',
   youCannotVoteOnYourOwnPoll : 'You cannot vote on your own poll!',
  choice : "Choice",
   optionalPoll : "(Optional)",

   watchPartyLetGo :  "Watch party, let's go",
  createSpace :'Create Space',
 oopsSomethingWentWrongPleaseTryAgain : 'Oops…Something went wrong! Please try again',
  noSpacesAvailable : 'No spaces available',
  yourSpaceIsReady : "Your space is ready",
  spaceLinkCopiedSuccessfully : 'Space link copied successfully',
 instant : 'Instant',
  nameYourSpace : 'Name your space',
   whatDoYouWantToTalkAbout :'What do you want to talk about?',
 scheduleYourSpace : "Schedule your space",
  confirm : 'Confirm',
 selectTopic : 'Select Topic',
 momentDeleteSuccessfully : "Moment Deleted Successfully",
  createSpaceSuccessfully : "Create Space Successfully",
  pleaseEnterTheSpaceName : "Please enter the space name",
  spaces : 'Spaces',

   pleaseChooseEither1VideoOr1Pdf: "Please choose either 1 video or 1 Pdf at a time or up to 4 photos.",
  fileTypeIsNotAllowed:'File type is not allowed',
   thisPostIsScheduledFor: "This post is scheduled for",
  askAQuestion: 'Ask a question...',
   pollLength:'Poll length',
   hours: 'Hours',
   minutes:'Minutes',
   removePoll: 'Remove Poll',
   uploading: 'Uploading...',
  addDescription: "Add Description",
   willPostOn:  "Will Post on",
   date:'Date',
   youCannotScheduleAWerfInThePast: 'You cannot schedule a Werf in the past',
   time: 'Time',
  timeZone: 'Time zone',
  youHaveNoScheduledWerfs: 'You have no scheduled werfs',
   willSendOn:  "Will send on",
  selectAll: 'Select all',
  schedule: 'Schedule',
   scheduledWerfs: 'Scheduled Werfs',
  deselectAll: 'Deselect all',
   yourImageVideoWillBeAvailableInAMoment: 'Your image/video will be available in a moment.',
   pleaseEnterValidText: 'Please enter valid text',
   takeAPhoto: "Take a Photo",
   chooseFromGallery:  "Choose from Gallery",
   makeVideoWithPhoneCamera: "Make video with phone camera",
   unsentWerfs: 'Unsent Werfs',


  commentsHere:'comments here',
   ImageDescription : 'Image description',
 viewHiddenReplies: 'View Hidden Replies',
  undoRewerf: 'Undo Rewerf',
 share:  "Share",
   view:  "View",
  werfLinkCopiedSuccessfully: "Werf link copied successfully",
 addBookmark: "Add Bookmark",
 removeBookmark: "Remove Bookmark",
 werfSavedSuccessfully: 'Werf saved successfully!',
 werfUnsavedSuccessfully:  'Werf unsaved successfully!',
 thereWasAnErrorInUnSavingThisWerf: 'There was an error in unsaving this werf!',
  thereWasAnErrorInSavingThisWerf:'There was an error in saving this werf!',
   thereWasAnErrorInBlockingThisUser:'There was an error in blocking this user!',
 noEditHistory: 'No edit history',
   unPinFromProfile: "UnPin from Profile",
   saveWerf: 'Save Werf',
   linkCopiedToClipBoard:  'Link copied to clipboard!',
 removeFromBookmarks: 'Remove from bookmarks',
  thereWasAnErrorInReportingThisUser: 'There was an error in reporting this user!',
  viewOriginal: "Original",
  showThisThread:'Show this thread',
   rewerf : 'Rewerf',

   werfAnalytics : "Werf Analytics",
   nothingFound:'Nothing found',
   year:'Year',
   day : 'Day',
  month : 'Month',
 thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
      "This should be the date of birth of the person using the account. Even if you’re making an account for your business or event.",
  editDateOfBirth : 'Edit date of birth?',
  deletePhoto :"Delete photo",
  removePhoto : "Remove photo",
   addPhoto :"Add photo",
   discard : "Discard",
 removeWerfAlert :
      "This can't be undone and you'll lose your changes",
 discardChanges : "Discard changes?",
  youShouldBeAtLeast14YearsOld: 'You should be at least 14 years old',
  contentOfDialog :"Content of Dialog",
   pinnedWerf : "Pinned Werf",
   hiddenPost : "Hidden Werfs",
  thisCanBeOnlyChangedAFewTimes :" This can be only changed a few times. Make sure you enter the age of the person using the account",


  aboutHashTag : 'About hashtag',
   werfHashTag : 'Werf hashtag',
 messageRequests : 'Message requests',
   enterGroupChatTitle:  "Enter group chat title",
   chooseOneFromYourExistingChatsOrStartANewOne:
      'Choose one from your existing chats, or start a new one',
  snoozeNotificationsFrom :  "Snooze notifications from",
  snoozeNotificationsFromTheGroup : "Snooze notifications from the group",
  snoozeMentions : "Snooze mentions",
  disableNotificationsWhenPeoplemention:"Disable notifications when people mention you in this conversation.",
  trySearchingForPeopleGroupsOrMessages : "Try searching for people,groups, or messages",
 werfieUser :  "Werfie User",
 otherChat :"other...",
 photoChat : 'Photo',
  videoChat : 'Video',
   fileChat : 'File',
   directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
      'Direct Messages are private conversations between you and other people on Twitter. Share Tweets, media, and more!',
  searchChats : "Search Chats",
   allTabChat : "All",
 peopleTabChat : "People",
  groupsTabChat :"Group",
  chatsTabChat :"Chats",
  noResultsFor : "No results for",
   theTermYouEnteredDidNotBring : "The term you entered did not bring up any results",
 message : "Message",
  addMembersToChat : 'Add members to chat',
   noMessagesYet : "No Messages Yet",
  doNotAllowMessages : "don't allow messages",
   notAllowedToMessage : "Not allowed to message.",
   youHaveBlockedThisUser : "You have blocked this user",
  startAMessage :  "Start a message",
  react :  "React",
   undo : "Undo",
  reactions : 'Reactions',
 messageRequestsFallHere :
      "Message requests from people you don't follow live here. To reply there message, you need to accept the request.",
   noMessageRequestAvailable : 'No Message Request Available',
   dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
      'Depending on the setting you select,different people can send you a direct message.',

  allowMessagesOnlyFromPeopleYouFollow :
      'Allow messages only from people you follow',
  youWontReceiveAnyMessageRequests :
      "You won't receive any message requests",
   allowMessageRequestsOnlyFromVerifiedUsers :
      "Allow message requests only from Verified users",
   peopleYouFollowWillStillBeAbleToMessageYou :
      "People you follow will still be able to message you",
   allowMessagesRequestsFromEveryone :
      'Allow messages requests from everyone',
   otherControls : "Other controls",
   filterLowQualityMessages : "Filter low-quality messages",
   hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
      "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",
   showReadReceipts : "Show read receipts",
  letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
      "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",




  getPushNotificationsToFindOut :"Get push notifications to find out what’s going on when you’re not on Werfie. You can turn them off anytime.",
   relatedToYouAndYourWerfs :"Related to you and your Werfs",
   whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "When you turn on Werf notifications from people you follow, you'll get push notifications about their Werfs.",
   topWerfs :"Top Werfs",
  tailoredForYou: "Tailored for you",
   rewerf : 'Rewerf',
   like : 'Like',
   photoTags : "Photo Tags",
   messageReactions : "Message Reactions",
   fromWerfie : "From Werfie",
   newsSports : "News / Sports",
 recommendations : "Recommendations",
 turnOnPush:"Turn on push\nnotifications",
  toReceiveNotificationsAsTheyHappen :"To receive notifications as they happen, turn on\npush notification, You'll also receive them when\nyou're not on Werfie. Turn them off anytime.",
  turnOn : "Turn on",
   newNotifications :  "New notifications",
   werfsEmailedToYou : "Werfs emailed to you",
 weekly : 'Weekly',
   newAboutWerfieProduct :"New about Werfie product and features updates",
   tipsOnGettingMoreOut: "Tips on getting more out of Werfie",
   thingsYouMissedSinceYou: "Things you missed since you last logged into Werfie",
   participationInWerfieResearchSurveys: "Participation in Werfie research surveys",
  suggestionsRorRecommendedAccounts: "Suggestions for recommended accounts",
  suggestionsBasedOnYourRecentFollows: "Suggestions based on your recent follows",


  qualityFilters : "Quality filters",
  chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Choose to filter out content such as duplicate and automated Werfs. This doesn't apply to notifications from accounts you follow and have interacted with recently.",

  emailNotification : 'Email Notifications',
  filters : "Filters",
 chooseTheNotification : "Choose the notification you'd like to see and those you don't",
  preferences : "Preferences",
 selectYourPreferencesByNotificationType :"Select your preferences by notification type.",

   werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
  'Werfie always uses some information,like where you signed up and and your current location,to help show you more relevant content.when this setting is enabled,Werfie may also personalize your experience based on other places you have been.',

   personalizeBasedOnPlacesYouHaveBeen :
  'Personalize based on places you have been',
  manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
  'Manage the location information Werfie uses to personalize your experience.',

  letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
  "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",

 showReadReceipts : "Show read receipts",
   hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
  "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",


   filterLowQualityMessages :"Filter low-quality messages",
   otherControls : "Other controls",
  peopleYouFollowWillStillBeAbleToMessageYou :
  "People you follow will still be able to message you",
   allowMessagesRequestsFromEveryone :
  'Allow messages requests from everyone',
   peopleYouFollowWillStillBeAbleToMessageYou:
  "People you follow will still be able to message you",
  allowMessageRequestsOnlyFromVerifiedUsers :
  "Allow message requests only from Verified users",
   youWontReceiveAnyMessageRequests :
  "You won't receive any message requests",
  allowMessagesOnlyFromPeopleYouFollow :
  'Allow messages only from people you follow',

  dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
  'Depending on the setting you select,different people can send you a direct message.',

   controlWhoCanMessageYou : 'Control who can message you',

   forever : " Forever",
  muteNotificationsFromPeople :"Mute notifications from people:",
   youDoNotFollow : "You don't follow",
   whoDoNotFollowYou : "Who don't follow you",
  withANewAccount : "With a new account",
   whoHaveDefaultProfilePhoto :"Who have default profile photo",
  whoHaveNotConfirmedTheirEmail : "Who haven't confirmed their email",
   whoHaveNotConfirmedTheirPhoneNumber :"Who haven't confirmed their phone number",

 duration : 'Duration',
 untilYouUnmuteTheWord : 'Until you unmute the word',
   hours24 : '24 hours',
   days7 : '7 days',
   days30 : '30 days',
  fromPeopleYouDontFollow : "From people you don't follow",
   homeTimeline : 'Home timeline',
   muteFrom : 'Mute from',
   youCanMuteOneWordUsernameOrHashtagAtATime :
  'You can mute one word,@username,or hashtag at a time.',
   enterWordOrPhrase : 'Enter word or phrase',
  mutedWord : 'Muted word',
  addMutedWords : 'Add muted words',
   youHaveNotMutedAnyWordYet : 'You have not muted any word yet',
   whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
  "when you mute words,you won't get any new notification for Werfs that include them or see Werfs with those words in your Home timeline.",


   youHaveNotMutedAnyPersonYet :
  'You have not muted any person yet',
HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
  "Here's everyone you muted.You can add remove them from this list.",
   whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
  "When you block someone,that person won't be able to follow or message you.and you won't see notification from them.",

 mutedNotification : 'Muted notifications',
   mutedWords: 'Muted words',
   mutedAccounts : 'Muted accounts',
   ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
  'Manage the accounts,word,and notification that you have muted or blocked.',

  thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
  'This prevents Werfs with potentially sensitive content displaying in your search results.',

 hideSensitiveContent: 'Hide sensitive content',
   removeBlockedAndMutedAccounts :
      'Remove blocked and muted accounts',
   useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
      'Use this to eliminate search results from account you have blocked or muted',


   personalization : 'Personalization',
  youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
      'you can personalize trends based on your location and who you follow',
  exploreLocation : 'Explore location',
 showContentInThisLocation : 'Show content in this location',
  WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
      'When this is on, you will see what is happening around you right now.',
  searchSettings  :'Search settings',
  exploreSettings : 'Explore settings',
 decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
  'Decide what you see on werfie based on your preferences like Topics',
  displayMediaThatMayContainSensitiveContent :
      'Display media that may contain sensitive content',

  addLocationInformationToYourWerfs :'Add location information to your Werfs',
  WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
  "When enabled,picture and videos you Werf will be marked as sensitive for people who don't want to see sensitive content.",
  markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
  'Mark media you Werf as having material that may be sensitive',
  manageTheInformationAssociatedWithYourWerfs :
  'Manage the information associated with your Werfs.',
  ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
  'if enabled,you will be able to attach location to your Werfs.',
  removeAllLocationInformationAttachedToYourWerfs :
      'Remove all location information attached to your Werfs',
 locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
      'Location labels you have added to your Werfs will no longer be visible on Werfie.com, Werfie for IOS, and Werfie for Android. These updates may take some time to go into effect.',


          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Manage what information you allow other people on Werfie.',
          protectYourTweets : 'Protect your Werfs',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'When selected, your werfie and account information are only visible to people who follow you',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'This will make them visible only to your werfie followers',
          protect : 'Protect',
          photoTagging : 'Photo tagging',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou:
          'Only people you follow can tag you',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Allow people to tag you in their photos and receive notifications when they do so',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou : 'Only people you follow can tag you',

          security : 'Security',
          manageYourAccountsSecurity : "Manage your accounts security",
          twoFactorAuthentication : "Two-factor authentication",
          manageYourAccountsSecurityKeepTrack : "Manage your accounts security and keep track of your account usage",
          helpProtectYourAccountFromUnauthorizedAccess :  "Help protect your account from unauthorized access by requiring a second authentication method in addition to your X password. You can choose a text message, authentication app, or security key.",
          verificationCodeSentToYourRegisteredEmail:"Enter 6-digits verification code Sent to your registered email",
          submit :'Submit',
          genderChangedSuccessfully : "Gender Changed Successfully",
          genderSettingTextDescription :"If you haven’t already specified a gender, this is the one associated with your account based on your profile and activity. This information won’t be displayed publicly.",
          male:  'Male',
          female : 'Female',
          other : 'Other',
          change:'Change',
          changeCountrySettings:'Change country',
          selectACountry:'Select a country',
          updateEmailAddress:'Update email address',
          current:'Current',
          changeEmailSetting:'Change email',
          gender:'Gender',
          accountCreation:'Account creation',
          Age:'Age',
          securityAndAccountAccess:'Security and account access',
  youHaveNotCreatedOrFollowedAnyLists: "You haven't created or followed any Lists. When you do, they'll show up here.",
 userCanPinnedOnly5  : 'User can pinned  only 5 ',
   pleaseEnterTheName  : 'Please enter the name ',
  list : 'Lists',
  listYouAre :"Lists you're on",
  listYouHave:"You haven't been added to any Lists yet",
  listAddedSomeOne:"When someone adds you to a List, it'll show up here",
  listMembers :'List Members',
 listFollowers  : 'List Followers',
  noMembers: 'No Members',
  noResults :'No results',
          noFollowers:'No Followers',
          manageWhatInformationYouSeeAndShareOnWerfie: 'Manage what information you see and share on Werfie.',
          noResponseFromServerMsg: 'We are experiencing some difficulties. Please try again later',

          filteredResult:'Filtered Result',
          forYou:'For you',
          noInternetAvailable:'No Internet Available!',
          welcomeToWerfie:'Welcome to Werfie',
          cantChooseEmailAsApass:
              "Your can't choose email as a password please \nchoose a secure password",
          passMustContainUpperCaseAndLeeter:
              'Password must contain at least one uppercase letter \nand one number',
          bothPasswordAndConfirmPassShouldMatch:
              'Both password and confirm password should match',
          DidNoTReceiveCode: "Didn't receive code?",
          verificationCode: 'Verification Code',
          enterYourNewPasswordHint: 'Enter your new password',
          ChangePasswordSettings: 'Change Password',
          trendingUpdates: 'Trending Updates',
          dobAddMsg: 'Add your date of birth to your ',
          audienceAndTagging: 'Audience and tagging',
          LearnMoreAboutPrivacyOnWerfie: 'Learn more about privacy on Werfie',
          nameCannotBeEmpty: "Name is required",
          nameLengthShouldMax20: "Name length should not greater than 20",
          nameStartsWithCharacter: "Name should start with Alphabets",
          pleaseProvideAValidEmail: "Please provide a valid email",
          werfieHandleIsRequired: "Werfie handle is required",
          passwordShouldBeMin8Char:
              'Password should be at least 8 character long',
          pleaseEnterYourBirthDate: 'Please Enter your Date of Birth',
          enterYourBirthDateOptional: 'Enter your date of birth (Optional)',
          topicsThatYouFollowShownHere:
              'Topics that you follow are shown here. To see all the things that Werfie thinks you’re interested in, check out Your Werfie data. You can also learn more about following Topics.',
          bySigningUpYouAgree: 'By signing up, you agree our',
          and: 'and',
          privacyUpdated: 'Privacy Updated',
          areYouSure: 'Are you sure?',
          doYouWantToExit: 'Do you want to exit the App',
          no: 'No',
          yes: 'Yes',
          werfUnsaved: 'Werf Unsaved successfully!',
          private: 'Make Private',
          name: 'Name',
          bio: "Bio",
          birthDate: 'Birth Date',
          create: 'Create',
          weWontSuggestThisTopic: "We won’t suggest this Topic anymore",
          youllSeeTopWerfs:
              "You'll see top Werfs about these right in your Home timeline",
          requestVerification: 'Request Verification',
          enterCurrentPassword: 'Enter current password',
          enterYourNewPassword:
              "Enter your new password and press Next button. We will send you a 6-digit code. You will need to enter that 6-digit code on the next screen to complete the process.",
          noWerfs: 'No Werfs',
          verified: 'Verified',
          getMoments: 'Get Moments',
          yourlist: 'Your Lists',
          copyProfileLink: 'Copy profile link',
          signInWithApple: 'Login with Apple',
          searchForAnItem: 'Search for an item...',
          changedTheCountryName: 'Changed the country name successfully!',
          editOrder: 'Edit Order',
          ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
              'This can’t be undone and it will be removed from your profile, the timeline of any accounts that follow you, and from Werfie search results.',
          writeAShortDesc: 'Write a short description about moments',
          addATitle: 'Add a title',
          publish: 'Publish',
          werfSearch: 'Werfs Search',
          werfsByAccount: "Werfs by account",
          werfsILiked: "Werfs I've liked",
          addWerfs: 'Add Werfs',
          allReply: 'All Reply',
          replyingTo: 'Replying to ',
          yourWerfieActivity: 'Your Werfie activity',
          manageWhatInformationYouSeeAndShareOnWerfie:
              'Manage what information you see and share on Werfie',
          doYouWantToLet: 'Do you want to let ',
          toMessageYou:
              ' To message you? They wont know that you have seen their message until you accept.',
          noMessageRequestAvailable: 'No Message Request Available',
          accept: 'Accept',
          reject: 'Delete',
          reportBlock: 'Report/Block',
          noMomentsList: 'No Moments',
          justNow: 'Just Now',
          clear: 'Clear',
          createANewWerf: 'Create a new werf',
          suggestedTopics: 'Suggested Topics',
          whenYouFollowMsg:
              "When you follow a List, you'll be able to quickly keep up with the experts on what you care about most.",
          chooseYourLists: 'Choose your Lists',
          discoverlist: 'Discover New Lists',
          pinnedList: "Pinned List",
          createNew: 'Create New',
          chooseAnExistingMomentOrCreateNew:
              'Choose and existing moment or create a new one',
          seizeTheMoment: 'Seize the Moment',
          momentDeleteSuccessfully: 'Moment Deleted Successfully',
          createMoment: 'Create Moment',
          removeMomentAlertMsg:
              'This can’t be undone and you’ll lose your Moment.',
          momentsDelete: 'Moments Delete?',
          nothingToSeeHere: 'Nothing to see here',
          nothingToSeeHerePinYour:
              'Nothing to see here yet — pin your favorite Lists to access them quickly.',
          viewHiddenReply: 'View Hidden Reply',
          block: 'Block',
          chooseOneFromYourExistingChatsOrStartANewOne:
              'Choose one from your existing chats, or start a new one',
          youDoNotHaveAChatSelected: 'You don’t have a chat selected',
          editGroup: 'Edit Group',
          colors: 'Colors',
          dark: "Dark",
          light: "Light",
          theseSettingsAffect:
              "These settings affect all the Werfie accounts on this browser.",
          customizeView: 'Customize your view',
          dismiss: 'Dismiss',
          thisWerfSeen: 'This werf was seen',
          youHaveAlreadyReportedWerf: 'You have already reported this werf',
          enterDescriptionFieldIsRequired:
              "Enter description field is required",
          searchLocation: 'Search location',
          tagLocation: 'Tag location',
          profileVisits: 'Profile Visits',
          newFollowers: 'New Followers',
          detailExpands: 'Detail Expands',
          engagements: 'Engagements',
          werfAnalytics: 'Werf Analytics',
          followed: 'Followed',
          notInterested: 'Not Interested',
          suggested: 'Suggested',
          add: 'Add',
          remove: 'Remove',
          members: 'Members',
          whenYouMakeAList:
              "When you make a List private, only you can see it.",
          makePrivate: 'Make Private',
          createNewList: 'Create New List',
          done: 'Done',
          editList: 'Edit List',
          manageMembers: 'Manage Members',
          delete: 'Delete',
          deleteForEveryOne: 'Delete for everyone',
          listYouAreON: "Lists you're on",
          newsSocial: 'News',
          filmTV: 'Entertainment',
          music: 'Music',
          travelAdventure: 'Travel',
          newChat: 'New Chat',
          noMsgsYet: 'No Messages Yet',
          addToYourList: 'Add To Your List',
          theTopicsYouFollow:
              "The Topics you follow are used to personalize the Werfs, events, and ads that you see, and show up publicly on your profile",
          verification: 'verification',
          country: 'Country',
          userNameSavedSuccessfully: 'Username saved successfully',
          topWerfs: 'Top Werfs',
          getEmailToFindOut:
              'Get emails to find out what’s going on when you’re not on Werfie. You can turn them off anytime.',
          pushNotifications: 'Push Notification',
          otpSentMsg:
              "We have just sent a 6-digit code. Enter that code in the place given below and press Confirm button",
          sendViaDirectMessage: 'Send via Direct Message',
          shareWerf: 'Share Werf',
          copylinkToWerf: 'Copy link to werf',
          pickWhoCanReplyMsg:
              "'Pick who can reply to this Werf. Keep in mind that anyone mentioned can always reply.'",
          whoCanReply: 'Who can reply?',
          everyoneCanReply: 'Everyone can Reply',
          onlyPeopleYouMention: 'Only people you mention',
          allwerf: 'All Werf',
          werf: 'Werf',
          werfs: 'Werfs',
          viewTranslated: 'Translate',
          accountInformation: 'Account Information',
          viewTopics: 'View Topics',
          confirmPassMsg: 'Confirm Your Password',
          wrongPasswordMsg: 'Wrong Password',
          unBlock: 'Unblock',
          loginWithGoogle: 'Login with Google',
          createYourPassword: 'Create your password',
          createYourWerfieHandle: 'Create your werfie handle',
          forwardMessage: 'Forward Message',
          copy: 'Copy message',
          messageDelete: 'Delete for me',
          deleteConversation: 'Delete Conversation',
          peopleInThisChat: 'People in this chat',
          views: 'views',
          werfSeenCountMsg: 'This werf was seen',
          times: 'times',
          newWerf: 'New Werf',
          newWerfs: 'New Werfs',
          pinPostMsg: 'Pin post to your profile!',
          unPinPostMsg: 'Unpin post to your profile!',
          removeWerfAlert: "This can't be undone and you'll lose your changes",
          quoteRewerf: 'Quote Rewerf',
          rewerfSuccessfully: 'ReWerf Successfully',
          werfYourReply: 'Werf your reply...',
          noReplyComments: 'Be the first one to reply',
          postDetail: 'Werf Detail',
          profileLinkCopy: 'Profile link copied successfully',
          muteUser: 'muted Successfully',
          userReportedSuccessfully: 'User reported successfully!',
          userBlockedSuccessfully: 'User blocked successfully!',
          werfReportedSuccssfully: 'Werf reported successfully',
          notificationsSettings: 'Notifications Settings',
          displaySettings: 'Display Settings',
          followings: 'Followings',
          popularUpdates: 'Popular Updates',
          privacyAndSafety: 'Privacy and safety',
          createWerf: 'Create Werf',
          chats: 'Chats',
          bookmarks: 'Bookmarks',
          bookmark: 'Bookmark',
          removeWerfFromBookMark: 'Remove werf from Bookmark',
          enterYourEmail: 'Enter your email',
          enterYourPassword: 'Enter your password',
          languageSettings: 'Language Settings',
          blockedAccountsSettings: 'Blocked Accounts Settings',
          selectYourPreferredLanguage: 'Select your preferred language',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Home',
          browse: 'Browse',
          hotTrends: 'Trending',
          saved: 'Saved',
          messages: 'Messages',
          myProfile: 'My profile',
          settings: 'Settings',
          notifications: 'Notifications',
          pushNotifications: 'Push Notifications',
          settingsType: 'Settings Type',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'Manage how Werfie content is displayed to you',
          selectYourProfileLanguage: 'Select your translation language',
          selectYourAppLanguage: 'Select your app language',
          enableDisableAutoTranslation: 'Enable / disable auto translation',

          /// english
          language: 'Language',
          YourAccount: 'Your account',
          username: 'Username',
          verificationAccount: 'Account Verification',
          snoozeNotification: 'Snooze Notification',
          version: 'Version',
          appVersion: 'App Version',
          deactivationAndDeletion: 'Deactivation and Deletion',
          confirmYourPasswords: 'Confirm Your Password',
          deactivateAccount: 'Deactivate account',
          or: 'OR',
          deleteAccount: 'Delete account',
          updateYourLanguageAndTranslation:
              'Update your language and translation settings',
          youHaveNotBlockedAnyPersonYet: 'You have not blocked any person yet',
          whoCanMessageYou: 'Who can message you',
          manageYourPrivacySettings: 'Manage your privacy settings',
          privacySettings: 'Privacy Settings',
          setYourPrivacySettings: 'Set Your Privacy Settings',
          messageSettings: 'Message Settings',
          noOne: 'No One',
          everyOne: 'EveryOne',
          daily: 'Daily',
          weekly: 'Weekly',
          off: 'Off',
          biweekly: 'Biweekly',
          ChangeUsernameSettings: 'Change username',
          enterYourWerfieHandle: 'Enter your werfie handle',
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "If you want to permanently delete your Werfie account,Once you Click the ok button,you won't be able to reactivate your account or retrieve any of the content or information you have added.",
          permanentlyDeleteAccount: "Permanently delete account",
          viewEditHistory: "View Edit History",
          reportWerf: 'Report werf',
          hideWerf: 'Hide Werf',
          showMenu:'Show Menu',
          reportUser: 'Report User',
          mute: 'Mute',
          unMute: "UnMute",
          deleteWerf: 'Delete Werf',
          viewWerfAnalytics: 'View Werf Analytics',
          pintoYourProfile: 'Pin to your profile',
          editWerf: 'Edit Werf',
          explore: 'Explore',

          lists: 'Lists',
          blockedAccounts: 'Blocked accounts',
          translations: 'Translations',
          viewListOfBlockedAccounts: 'View list of blocked accounts',
          realTimePostTranslation: 'Real time post translation',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'Select language at the time of uploading a video or audio',
          originalTranslatedScriptAudioPost:
              'Original or translated script of audio post',
          listenTranslatedScript: 'Listen to translated script',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Automatically translate messages in chat in users selected language',
          postedUpdate: 'created a werf',
          peopleWhoReacted: 'People who reacted',
          comments: 'Comments',
          peopleWhoRetweeted: 'People who rewerfed',
          leaveAComment: 'Leave a comment',
          post: 'Werf',
          cancel: 'Cancel',
          savePost: 'Save Post',
          report: 'Report',
          hide: 'Hide',
          shareLinkVia: 'Share Link via...',
          copyLink: 'Copy Link',
          fieldRequired: 'Field Required',
          enterDescription: 'Enter Description',
          selectCategory: 'Select Category',
          okay: 'Okay,',
          pleaseWait: 'Please wait...',
          search: 'Search',
          logout: 'Logout',
          writeSomethingHere: 'Write something here',
          addMore: 'Add More',
          image: 'Image',
          video: 'Video',
          videos: 'Videos',
          file: 'File',
          gif: 'GIF',
          audio: 'Audio',
          live: 'Live',
          doNotHaveAnAccount: "Don't have an account? ",
          register: 'Register',
          haveAnAccount: "Have an account? ",
          login: 'Login',
          whoToFollow: 'Who to follow',
          noSuggestion: 'No Suggestion',
          follow: 'Follow',
          unFollow: 'Unfollow',
          seeMore: 'See More',
          searchFilter: 'Search Filter',
          people: 'People',
          fromAnyone: 'From Anyone',
          peopleYouFollow: 'People You Follow',
          location: 'Location',
          anywhere: 'Anywhere',
          nearYou: 'Near You',
          advancedSearch: 'Advanced Search',
          trendsForYou: 'Trends For You',
          noTrending: 'There are no trends in your region',
          trendingIn: 'Trending in',
          // tweets: 'Werfs',
          noNotification: 'There are no notifications for you',
          refresh: 'Refresh',
          edit: 'Edit',
          save: 'Save',
          cFollow: 'Follow',
          addPeople: 'Add People',
          someText: 'some text',
          reportConversation: 'Report Conversation',
          leaveConversation: 'Leave Conversation',
          enterYourMessage: 'Start a message',
          showMoreComments: 'Show more comments',
          reBuzz: 'Rebuzz',
          noPosts: 'No updates for you',
          emailFieldCannotBeEmpty: 'Email / Phone cannot be empty',
          emailFormatIsInvalid: 'Email Format is invalid',
          rememberMe: 'Remember me',
          lostPassword: 'Lost Password?',
          cLOGIN: 'LOGIN',
          emailOrPasswordIsIncorrect: 'Email or password is incorrect',
          newsFeed: 'News Feed',
          trends: 'Trends',
          profile: 'Profile',
          newMessage: 'New Message',
          next: 'Next',
          searchPeople: 'Search People',
          saySomething: 'Say Something',
          noSearchResult: 'No Search Result',
          searchResult: 'Search Result',
          hidePost: 'Hide Post',
          showLess: 'Show Less',
          showMore: 'Show More',
          nothingYet: 'Nothing yet!',
          savedPosts: 'Saved Posts',
          enterYourFirstName: 'Enter your name',
          enterYourLastName: 'Enter your last name',
          enterYourUsername: 'Enter your username',
          signUp: 'Sign up',
          pleaseChooseACountry: 'Please choose a country',
          replied: 'replied',
          reply: 'Reply',
          delete: 'Delete',
          deleteForEveryOne:'Delete for everyone',
          messageDelete: 'Delete for me',
          replyToComment: 'Replying to',
          noFollower: 'No Follower',
          following: 'Following',
          followBack: 'Follow Back',
          followers: 'Followers',
          follower: 'Follower',
          noFollowings: 'No Followings',
          sendAMessageGetAMessage: 'Send a message, get a message',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'Direct Messages are private conversations between you and other people on Twitter. Share Tweets, media, and more!',
          startAConversation: 'Start a Conversation',
          groupInfo: 'Group Info',
          chatInfo: 'Chat Info',
          reactions: 'Reactions',
          youDoNotHaveAMessageSelected: 'You don’t have a message selected',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Choose one from your existing messages, or start a new one.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'Please enter verification code to verify your email',
          usernameOrEmail: 'Username or Email',
          enterVerificationCode: 'Enter verification code',
          confirmCode: 'Confirm Code',
          top: 'Top',
          latest: 'Latest',
          photos: 'Photos',
          files: 'Files',
          noPeople: 'No People',
          all: 'All',
          mentions: 'Mentions',
          replies: 'Reply',
          tweetsAndReplies: 'Werfs & Replies',
          media: 'Media',
          likes: 'Likes',
          searchPost: 'Search Updates',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.',
          resetYourPassword: 'Reset Your Password',
          enterCode: 'Enter Code',
          enterNewPassword: 'Enter New Password',
          reEnterPassword: 'Re-Enter Password',
          passwordCannotBeEmpty: 'Password cannot be Empty',
          passwordShouldBeCharacter: 'Password should be 8 character',
          passwordShouldBeMatched: 'Password should be Matched',
          resetPassword: 'Reset Password',
          email: 'Email',
          phone: 'Phone',
          blockUser: 'Block User',
          public: 'Public',
          mentionUsers: 'Mention Users',
          editProfile: 'Edit Profile',
          yourProfileIsUpdated: 'Your Profile is updated',
          seeProfile: 'See Profile',
          skipForNow: 'Skip for now',
          addBio: 'Add Bio',
          profileUpdated: 'Profile Updated',
          upDate: 'Update',
          goToProfile: 'Go to Profile',
          more: 'More',
          about: 'About',
          help: 'Help',
          privacyPolicy: 'Privacy Policy',
          blog: 'Blog',
          termsOfService: 'Terms of Service',
          youMustSelectACountry: 'You must select a country',
          usernameIsAlreadyTaken: 'Werfie Handle is already taken',
          goBack: 'Go back',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'An account has already been created with this email',
          yourPasswordIsResetSuccessfully:
              'Your password is reset successfully',
          returnToLogin: 'Return to Login',
          youHaveEnteredAnInvalidCode: 'You have entered an invalid code',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'Thank you for creating your account with Werfie. Stay Safe!',
          success: 'Success',
          goBackToHomePage: 'Go back to Home page',
          moments: 'Moments'
        },
        'ar': {
          ok : 'نعم',
          timesThisWerfWasSeenOnWerfie :'مرات شوهد هذا werf على Werfie',
          totalNumberOfTimesAUserHasInteractedWithAWerf: "إجمالي عدد المرات التي تفاعل فيها المستخدم مع werf.",
          timesPeopleViewedTheDetailsAboutThisWerf : "مرات شاهد الناس تفاصيل حول هذا werf",
          followsGainedDirectlyFromThisWerf : "المتابعات المكتسبة مباشرة من هذا werf",
          numberOfProfileViewsFromThisWerf : "عدد مشاهدات الملف الشخصي من هذا werf",
          deleteForEveryOne : 'الحذف للجميع',
          photo : 'صورة',
          emojis : 'الرموز التعبيرية',
          uploadFile: 'رفع ملف',
          createPoll :'إنشاء استطلاع',
          scheduleWerf :"الجدول الزمني ويرف",
          loginWithEmail : 'تسجيل الدخول باستخدام البريد الإلكتروني',
          usePhoneInstead :  "استخدم الهاتف بدلا من ذلك",
          useEmailInstead : "استخدم البريد الإلكتروني بدلاً من ذلك",
          noVerifiedFollower :'لا يوجد متابع معتمد',
          verifiedFollowers :  'المتابعين الذين تم التحقق منهم',
          signUpToYourAccount : "قم بالتسجيل في حسابك",
          pleaseEnterYourName : 'من فضلك أدخل إسمك',
          werfieHandleErrorMessage : 'الرجاء إدخال المقبض',
          emailErrorMessage : 'يرجى إدخال البريد الإلكتروني الصحيح',
          werfieHandle : 'مقبض ويرفي',
          pleaseEnterAValidDOB :'الرجاء إدخال تاريخ ميلاد صالح',
          pleaseEnterDOB : 'تاريخ الميلاد (يوم/شهر/سنة)',
          phone :'هاتف',
          suggestions : "اقتراحات",
          customizeYourExperience : "تخصيص تجربتك",
          trackWhereYouSeeWerfieContentAcrossTheWeb : "تتبع المكان الذي ترى فيه محتوى Werfie عبر الويب",
          werfieUsesThisDataToPersonalizeYourExperience : "يستخدم Werfie هذه البيانات لتخصيص تجربتك. لن يتم أبدًا تخزين سجل تصفح الويب هذا باسمك أو بريدك الإلكتروني أو رقم هاتفك",
          werfieMayUseYourContactInformationIncludingYouEmail : "قد تستخدم Werfie معلومات الاتصال الخاصة بك، بما في ذلك عنوان بريدك الإلكتروني ورقم هاتفك للأغراض الموضحة في سياسة الخصوصية الخاصة بنا.",
          pleaseAgreeToWerfieTermsConditions: "يرجى الموافقة على شروط وأحكام Werfie",
          createYourAccount :  "أنشئ حسابك",
          weSentYouACode : "أرسلنا لك رمزا",
          enterItBelowToVerify :"أدخله أدناه للتحقق",
          didNotReceiveEmail : "لم تتلقى البريد الإلكتروني؟",
          youWillNeedAPassword :"سوف تحتاج إلى كلمة مرور",
          passwordMustBeCharactersLong:"يجب أن تتكون كلمة المرور من 8 أحرف، بما في ذلك رقم واحد على الأقل، وحرف كبير واحد، وحرف خاص واحد.,",
          pleaseEnterAValidEmail : 'يرجى إدخال البريد الإلكتروني الصحيح',
          resend : "إعادة إرسال",

          google :"جوجل",
          apple :"تفاحة",
          worldNoor :"وورلد نور",
          forgotPassword : "هل نسيت كلمة السر؟",
          doNotMissWhatsHappening :"لا تفوت ما يحدث",
          peopleOnWerfieAreTheFirstToKnow :"الناس في ويرفي هم أول من يعرف",
          newToWerfie :  "جديد في ويرفي؟",
          signUpNowToGetYourOwnPersonalizedTimeline :'سجل الآن لتحصل على الجدول الزمني المخصص لك!',
          signUpWithGoogle :  "قم بالتسجيل مع جوجل",
          signUpWithApple :"قم بالتسجيل مع أبل",
          signUpWithEmailOrMobile : "قم بالتسجيل باستخدام البريد الإلكتروني أو الهاتف المحمول",
          loginWithWorldNoor : "تسجيل الدخول مع وورلد نور",
          bySigningUpYouAgreeOur : 'بالتسجيل، فإنك توافق على لدينا',
          trending :'الشائع',
          noUserNoTag : 'لا يوجد مستخدم && لا توجد علامة',
          noTrendsInThisRegion :'لا توجد اتجاهات في هذه المنطقة',
          weAreExperiencingSomeDifficulties : "نحن نواجه بعض الصعوبات. الرجاء معاودة المحاولة في وقت لاحق",
          noPost : 'لا يوجد مشاركة',

          signInToYourAccount : "تسجيل الدخول إلى حسابك",
          enterEmailPhone : "أدخل البريد الإلكتروني / الهاتف",
          itSeemsLikeYouAreARobot: " يبدو أنك روبوت. يرجى التحقق مرة أخرى",
          signIn:  "تسجيل الدخول",
          registerHere: "سجل هنا!",
          orContinueWith: "أو الاستمرار مع",
          somThingWentWrongWithConfiguration: "حدث خطأ ما في التكوين. حاول مرة اخرى",
          error:"خطأ",
          pleaseAllowEmailToContinueWithWerfie: "يرجى السماح للبريد الإلكتروني بمتابعة werfie",
          alert: "يُحذًِر",
          sorryForTheInconvenience:"نأسف للإزعاج. الرجاء معاودة المحاولة في وقت لاحق.",
          enterDigitsVerificationCodeSentToYourRegisteredEmail: "أدخل رمز التحقق المكون من 6 أرقام الذي تم إرساله إلى بريدك الإلكتروني المسجل",

          theUsernameHasAlreadyBeenTaken : 'لقد تم أخذ اسم المستخدم بالفعل.',
          thereWasAnErrorInSavingThisUsername : "حدث خطأ في حفظ اسم المستخدم هذا!",
          showMenu : 'قائمة العرض',
          thisPollHasExpired : 'انتهت صلاحية هذا الاستطلاع',
          youCannotVoteOnYourOwnPoll : 'لا يمكنك التصويت على الاستطلاع الخاص بك!',
          choice : "خيار",
          optionalPoll : "(خياري)",

          watchPartyLetGo :  "شاهد الحفلة، فلنذهب",
          createSpace :'خلق الفضاء',
          oopsSomethingWentWrongPleaseTryAgain : 'تبا شيء ما حدث بشكل خاطئ! حاول مرة اخرى',
          noSpacesAvailable : 'لا توجد مساحات متاحة',
          yourSpaceIsReady : "المساحة الخاصة بك جاهزة",
          spaceLinkCopiedSuccessfully : 'تم نسخ رابط الفضاء بنجاح',
          instant : 'فوري',
          nameYourSpace : 'قم بتسمية المساحة الخاصة بك',
          whatDoYouWantToTalkAbout :'ماذا تريد أن نتحدث عن؟',
          scheduleYourSpace : "جدولة المساحة الخاصة بك",
          confirm : 'يتأكد',
          selectTopic : 'حدد الموضوع',
          momentDeleteSuccessfully : "تم حذف اللحظة بنجاح",
          createSpaceSuccessfully : "إنشاء مساحة بنجاح",
          pleaseEnterTheSpaceName : "الرجاء إدخال اسم المساحة",
          spaces : 'المساحات',


          pleaseChooseEither1VideoOr1Pdf: "يرجى اختيار إما مقطع فيديو واحد أو ملف PDF واحد في المرة الواحدة أو ما يصل إلى 4 صور.",
          fileTypeIsNotAllowed:'نوع الملف غير مسموح به',
          thisPostIsScheduledFor: "تمت جدولة هذه المشاركة ل",
          askAQuestion: 'طرح سؤال...',
          pollLength:'طول الاستطلاع',
          hours: 'ساعات',
          minutes:'دقائق',
          removePoll: 'إزالة الاستطلاع',
          uploading: 'جارٍ التحميل...',
          addDescription: "اضف وصفا",
          willPostOn:  "سيتم النشر على",
          date:'تاريخ',
          youCannotScheduleAWerfInThePast: 'لا يمكنك جدولة Werf في الماضي',
          time: 'وقت',
          timeZone: 'وحدة زمنية',
          youHaveNoScheduledWerfs: 'ليس لديك أي werfs مجدولة',
          willSendOn:  "سوف ترسل",
          selectAll: 'اختر الكل',
          schedule: 'جدول',
          scheduledWerfs: 'Werfs المجدولة',
          deselectAll: 'الغاء تحديد الكل',
          yourImageVideoWillBeAvailableInAMoment: 'سوف تكون الصورة/الفيديو الخاص بك متاحة في لحظة.',
          pleaseEnterValidText: 'الرجاء إدخال نص صالح',
          takeAPhoto: "التقاط صورة",
          chooseFromGallery:  "اختر من المعرض",
          makeVideoWithPhoneCamera: "صنع فيديو بكاميرا الهاتف",
          unsentWerfs: 'Werfs غير المرسلة',

          commentsHere:'التعليقات هنا',
          ImageDescription : 'وصف الصورة',
          viewHiddenReplies: 'عرض الردود المخفية',
          undoRewerf: 'التراجع عن التجديد',
          share:  "يشارك",
          view:  "منظر",
          werfLinkCopiedSuccessfully: "تم نسخ رابط Werf بنجاح",
          addBookmark: "اضافة للمفضلة",
          removeBookmark: "إزالة المرجعية",
          werfSavedSuccessfully: 'تم حفظ ويرف بنجاح!',
          werfUnsavedSuccessfully:  'لم يتم حفظ Werf بنجاح!',
          thereWasAnErrorInUnSavingThisWerf: 'حدث خطأ في إلغاء حفظ هذا العمل!',
          thereWasAnErrorInSavingThisWerf:'حدث خطأ في حفظ هذا werf!',
          thereWasAnErrorInBlockingThisUser:'حدث خطأ أثناء حظر هذا المستخدم!',
          noEditHistory: 'لا يوجد تاريخ تحرير',
          unPinFromProfile: "قم بإلغاء التثبيت من الملف الشخصي",
          saveWerf: 'حفظ ويرف',
          linkCopiedToClipBoard:  'تم نسخ الرابط إلى الحافظة!',
          removeFromBookmarks: 'إزالة من الإشارات المرجعية',
          thereWasAnErrorInReportingThisUser: 'حدث خطأ في الإبلاغ عن هذا المستخدم!',
          viewOriginal: "إبداعي",
          showThisThread:'عرض هذا الموضوع',
          rewerf : 'ريويرف',

          werfAnalytics : "تحليلات ويرف",
          nothingFound:'لم يتم العثور على شيء',
          year:'سنة',
          day : 'يوم',
          month : 'شهر',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "يجب أن يكون هذا هو تاريخ ميلاد الشخص الذي يستخدم الحساب. حتى لو كنت تقوم بإنشاء حساب لعملك أو حدث ما.",
          editDateOfBirth : 'تعديل تاريخ الميلاد؟',
          deletePhoto :"حذف الصورة",
          removePhoto : "إزالة الصورة",
          addPhoto :"إضافة صورة",
          discard : "ينبذ",
          removeWerfAlert :
          "لا يمكن التراجع عن هذا الإجراء وستفقد التغييرات التي أجريتها",
          discardChanges : "هل تريد تجاهل التغييرات؟",
          youShouldBeAtLeast14YearsOld: 'يجب أن يكون عمرك 14 عامًا على الأقل',
          contentOfDialog :"محتوى الحوار",
          pinnedWerf : "ويرف المثبت",
          hiddenPost : "الورف المخفية",
          thisCanBeOnlyChangedAFewTimes :" لا يمكن تغيير هذا إلا عدة مرات. تأكد من إدخال عمر الشخص الذي يستخدم الحساب",


          aboutHashTag : 'حول الهاشتاج',
          werfHashTag : 'هاشتاغ ويرف',
          messageRequests : 'طلبات الرسائل',
          enterGroupChatTitle:  "أدخل عنوان الدردشة الجماعية",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'اختر واحدة من الدردشات الموجودة لديك، أو ابدأ واحدة جديدة',
          snoozeNotificationsFrom :  "تأجيل الإخطارات من",
          snoozeNotificationsFromTheGroup : "تأجيل الإخطارات من المجموعة",
          snoozeMentions : "يذكر غفوة",
          disableNotificationsWhenPeoplemention:"قم بتعطيل الإشعارات عندما يذكرك الأشخاص في هذه المحادثة.",
          trySearchingForPeopleGroupsOrMessages : "حاول البحث عن أشخاص أو مجموعات أو رسائل",
          werfieUser :  "مستخدم ويرفي",
          otherChat :"آخر...",
          photoChat : 'صورة',
          videoChat : 'فيديو',
          fileChat : 'ملف',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'الرسائل المباشرة هي محادثات خاصة بينك وبين أشخاص آخرين على تويتر. مشاركة التغريدات والوسائط والمزيد!',
          searchChats : "بحث في الدردشات",
          allTabChat : "الجميع",
          peopleTabChat : "الناس",
          groupsTabChat :"مجموعة",
          chatsTabChat :"الدردشات",
          noResultsFor : "لا توجد نتائج ل",
          theTermYouEnteredDidNotBring : "المصطلح الذي أدخلته لم يظهر أي نتائج",
          message : "رسالة",
          addMembersToChat : 'إضافة أعضاء للدردشة',
          noMessagesYet : "لا توجد رسائل حتى الآن",
          doNotAllowMessages : "لا تسمح بالرسائل",
          notAllowedToMessage : "غير مسموح بالمراسلة.",
          youHaveBlockedThisUser : "لقد قمت بحظر هذا المستخدم",
          startAMessage :  "ابدأ رسالة",
          react :  "تتفاعل",
          undo : "الغاء التحميل",
          reactions : 'تفاعلات',
          messageRequestsFallHere :
          "طلبات الرسائل من الأشخاص الذين لا تتابعهم مباشرة هنا. للرد على الرسالة، عليك قبول الطلب.",
          noMessageRequestAvailable : 'لا يتوفر طلب رسالة',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'اعتمادًا على الإعداد الذي تحدده، يمكن لأشخاص مختلفين إرسال رسالة مباشرة إليك.',

          allowMessagesOnlyFromPeopleYouFollow :
          'السماح بالرسائل الواردة من الأشخاص الذين تتابعهم فقط',
          youWontReceiveAnyMessageRequests :
          "لن تتلقى أي طلبات الرسائل",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "السماح بطلبات الرسائل من المستخدمين الذين تم التحقق منهم فقط",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "سيظل الأشخاص الذين تتابعهم قادرين على مراسلتك",
          allowMessagesRequestsFromEveryone :
          'السماح بطلبات الرسائل من الجميع',
          otherControls : "ضوابط أخرى",
          filterLowQualityMessages : "تصفية الرسائل ذات الجودة المنخفضة",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "قم بإخفاء طلبات الرسائل التي تم اكتشاف أنها من المحتمل أن تكون ممتدة أو منخفضة الجودة. سيتم إرسالها إلى صندوق بريد منفصل أسفل طلبات الرسائل الخاصة بك. لا يزال بإمكانك الوصول إليها إذا كنت تريد ذلك",
          showReadReceipts : "إظهار إيصالات القراءة",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "دع الأشخاص الذين تراسلهم يعرفون أنك رأيت رسائلهم. لا تظهر إيصالات القراءة في طلبات الرسائل",


          getPushNotificationsToFindOut :"احصل على إشعارات الدفع لمعرفة ما يحدث عندما لا تكون موجودًا في Werfie. يمكنك إيقاف تشغيلها في أي وقت.",
          relatedToYouAndYourWerfs :"المتعلقة بك وWerfs الخاص بك",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "عند تشغيل إشعارات Werf من الأشخاص الذين تتابعهم، ستتلقى إشعارات فورية حول Werf الخاصة بهم.",
          topWerfs :"أعلى ويرفس",
          tailoredForYou: "مصممة لك",
          rewerf : 'ريويرف',
          like : 'يحب',
          photoTags : "علامات الصورة",
          messageReactions : "ردود الفعل الرسالة",
          fromWerfie : "من ويرفي",
          newsSports : "أخبار / رياضة",
          recommendations : "التوصيات",
          turnOnPush:"قم بتشغيل\nالإشعارات",
          toReceiveNotificationsAsTheyHappen :"لتلقي الإشعارات فور حدوثها، قم بتشغيل\nإشعارات الدفع، وستتلقى هذه الإشعارات أيضًا عندما\nلا تكون في Werfie. قم بإيقاف تشغيلها في أي وقت.",
          turnOn : "شغله",
          newNotifications :  "إشعارات جديدة",
          werfsEmailedToYou : "تم إرسال Werfs إليك عبر البريد الإلكتروني",
          weekly : 'أسبوعي',
          newAboutWerfieProduct :"جديد حول تحديثات منتج وميزات Werfie",
          tipsOnGettingMoreOut: "نصائح للحصول على المزيد من Werfie",
          thingsYouMissedSinceYou: "الأشياء التي فاتتك منذ آخر مرة قمت فيها بتسجيل الدخول إلى Werfie",
          participationInWerfieResearchSurveys: "المشاركة في المسوحات البحثية Werfie",
          suggestionsRorRecommendedAccounts: "اقتراحات للحسابات الموصى بها",
          suggestionsBasedOnYourRecentFollows: "اقتراحات بناءً على متابعاتك الأخيرة",
          qualityFilters : "مرشحات الجودة",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"اختر تصفية المحتوى مثل Werfs المكررة والآلية. لا ينطبق هذا على الإشعارات الواردة من الحسابات التي تتابعها وتفاعلت معها مؤخرًا.",

          emailNotification : 'اشعارات البريد الالكتروني',
          filters : "المرشحات",
          chooseTheNotification : "اختر الإشعارات التي ترغب في رؤيتها وتلك التي لا تريدها",
          preferences : "التفضيلات",
          selectYourPreferencesByNotificationType :"حدد تفضيلاتك حسب نوع الإشعار.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'يستخدم Werfie دائمًا بعض المعلومات، مثل المكان الذي قمت بالتسجيل فيه وموقعك الحالي، للمساعدة في عرض محتوى أكثر صلة بك. عند تمكين هذا الإعداد، قد يقوم Werfie أيضًا بتخصيص تجربتك استنادًا إلى الأماكن الأخرى التي زرتها.',

          personalizeBasedOnPlacesYouHaveBeen :
          'إضفاء الطابع الشخصي على الأماكن التي كنت فيها',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'إدارة معلومات الموقع التي يستخدمها Werfie لتخصيص تجربتك.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "دع الأشخاص الذين تراسلهم يعرفون أنك رأيت رسائلهم. لا تظهر إيصالات القراءة في طلبات الرسائل",

          showReadReceipts : "إظهار إيصالات القراءة",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "قم بإخفاء طلبات الرسائل التي تم اكتشاف أنها من المحتمل أن تكون ممتدة أو منخفضة الجودة. سيتم إرسالها إلى صندوق بريد منفصل أسفل طلبات الرسائل الخاصة بك. لا يزال بإمكانك الوصول إليها إذا كنت تريد ذلك",


          filterLowQualityMessages :"تصفية الرسائل ذات الجودة المنخفضة",
          otherControls : "ضوابط أخرى",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "سيظل الأشخاص الذين تتابعهم قادرين على مراسلتك",
          allowMessagesRequestsFromEveryone :
          'السماح بطلبات الرسائل من الجميع',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "سيظل الأشخاص الذين تتابعهم قادرين على مراسلتك",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "السماح بطلبات الرسائل من المستخدمين الذين تم التحقق منهم فقط",
          youWontReceiveAnyMessageRequests :
          "لن تتلقى أي طلبات الرسائل",
          allowMessagesOnlyFromPeopleYouFollow :
          'السماح بالرسائل الواردة من الأشخاص الذين تتابعهم فقط',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'اعتمادًا على الإعداد الذي تحدده، يمكن لأشخاص مختلفين إرسال رسالة مباشرة إليك.',

          controlWhoCanMessageYou : 'التحكم في من يمكنه مراسلتك',

          forever : " للأبد",
          muteNotificationsFromPeople :"كتم الإشعارات من الأشخاص:",
          youDoNotFollow : "أنت لا تتبع",
          whoDoNotFollowYou : "من لا يتبعك",
          withANewAccount : "مع حساب جديد",
          whoHaveDefaultProfilePhoto :"الذين لديهم صورة الملف الشخصي الافتراضية",
          whoHaveNotConfirmedTheirEmail : "الذين لم يؤكدوا بريدهم الإلكتروني",
          whoHaveNotConfirmedTheirPhoneNumber :"الذين لم يؤكدوا رقم هاتفهم",
          duration : 'مدة',
          untilYouUnmuteTheWord : 'حتى تقوم بإلغاء كتم الكلمة',
          hours24 : '24 ساعة',
          days7 : '7 أيام',
          days30 : '30 يوما',
          fromPeopleYouDontFollow : "من الأشخاص الذين لا تتابعهم",
          homeTimeline : 'الجدول الزمني للمنزل',
          muteFrom : 'كتم من',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'يمكنك كتم كلمة واحدة أو @اسم مستخدم أو هاشتاج في المرة الواحدة.',
          enterWordOrPhrase : 'أدخل كلمة أو عبارة',
          mutedWord : 'كلمة مكتومة',
          addMutedWords : 'إضافة الكلمات الصامتة',
          youHaveNotMutedAnyWordYet : 'لم تقم بكتم أي كلمة حتى الآن',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "عند كتم الكلمات، لن تحصل على أي إشعار جديد للكلمات التي تتضمنها أو ترى الكلمات التي تحتوي على هذه الكلمات في المخطط الزمني لمنزلك.",

          youHaveNotMutedAnyPersonYet :
          'لم تقم بكتم صوت أي شخص حتى الآن',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "إليك كل الأشخاص الذين كتمت صوتهم. يمكنك إضافتهم وإزالتهم من هذه القائمة.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "عندما تحظر شخصًا ما، لن يتمكن هذا الشخص من متابعتك أو مراسلتك، ولن ترى إشعارًا منه.",

          mutedNotification : 'الإخطارات الصامتة',
          mutedWords: 'كلمات مكتومة',
          mutedAccounts : 'الحسابات المكتومة',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'إدارة الحسابات والكلمة والإشعارات التي قمت بكتمها أو حظرها.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'يؤدي هذا إلى منع ظهور Werfs الذي قد يحتوي على محتوى حساس في نتائج البحث.',

          hideSensitiveContent: 'إخفاء المحتوى الحساس',
          removeBlockedAndMutedAccounts :
          'إزالة الحسابات المحظورة والمكتومة',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'استخدم هذا لإزالة نتائج البحث من الحساب الذي قمت بحظره أو كتمه',
          personalization : 'إضفاء الطابع الشخصي',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'يمكنك تخصيص الاتجاهات بناءً على موقعك والأشخاص الذين تتابعهم',
          exploreLocation : 'استكشاف الموقع',
          showContentInThisLocation : 'عرض المحتوى في هذا الموقع',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'عندما يكون هذا قيد التشغيل، سترى ما يحدث من حولك الآن.',
          searchSettings  :'إعدادات البحث',
          exploreSettings : 'استكشاف الإعدادات',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'قرر ما تراه على werfie بناءً على تفضيلاتك مثل المواضيع',
          displayMediaThatMayContainSensitiveContent :
          'عرض الوسائط التي قد تحتوي على محتوى حساس',

          addLocationInformationToYourWerfs :'أضف معلومات الموقع إلى Werfs الخاص بك',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "عند تمكينه، سيتم وضع علامة على الصور ومقاطع الفيديو التي قمت بحفظها على أنها حساسة للأشخاص الذين لا يريدون رؤية محتوى حساس.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'قم بتمييز الوسائط التي تستخدمها على أنها تحتوي على مواد قد تكون حساسة',
          manageTheInformationAssociatedWithYourWerfs :
          'إدارة المعلومات المرتبطة بـ Werfs الخاص بك.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'إذا تم تمكينه، فستتمكن من إرفاق الموقع بـ Werfs الخاص بك.',
          removeAllLocationInformationAttachedToYourWerfs :
          'قم بإزالة جميع معلومات الموقع المرفقة بـ Werfs الخاص بك',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'لن تكون تسميات المواقع التي أضفتها إلى Werfs مرئية بعد الآن على Werfie.com وWerfie لنظام IOS وWerfie لنظام Android. قد تستغرق هذه التحديثات بعض الوقت حتى تدخل حيز التنفيذ.',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'إدارة المعلومات التي تسمح بها للآخرين على Werfie.',
          protectYourTweets : 'حماية Werfs الخاص بك',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'عند تحديده، تكون معلومات حسابك وwerfie مرئية فقط للأشخاص الذين يتابعونك',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'سيؤدي هذا إلى جعلها مرئية فقط لمتابعيك الويرفي',
          protect : 'يحمي',
          photoTagging : 'وضع علامات على الصور',
          AnyoneCanTagYou : 'يمكن لأي شخص وضع علامة عليك',
          onlyPeopleYouFollowCanTagYou:
          'يمكن فقط للأشخاص الذين تتابعهم وضع علامة عليك',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'اسمح للأشخاص بوضع علامة باسمك في صورهم وتلقي إشعارات عندما يفعلون ذلك',
          AnyoneCanTagYou : 'يمكن لأي شخص وضع علامة عليك',
          onlyPeopleYouFollowCanTagYou : 'يمكن فقط للأشخاص الذين تتابعهم وضع علامة عليك',
          security : 'حماية',
          manageYourAccountsSecurity : "إدارة أمان حساباتك",
          twoFactorAuthentication : "توثيق ذو عاملين",
          manageYourAccountsSecurityKeepTrack : "إدارة أمان حساباتك وتتبع استخدام حسابك",
          helpProtectYourAccountFromUnauthorizedAccess :  "ساعد في حماية حسابك من الوصول غير المصرح به عن طريق طلب طريقة مصادقة ثانية بالإضافة إلى كلمة مرور X الخاصة بك. يمكنك اختيار رسالة نصية أو تطبيق مصادقة أو مفتاح أمان.",
          verificationCodeSentToYourRegisteredEmail:"أدخل رمز التحقق المكون من 6 أرقام الذي تم إرساله إلى بريدك الإلكتروني المسجل",
          submit :'يُقدِّم',
          genderChangedSuccessfully : "تم تغيير الجنس بنجاح",
          genderSettingTextDescription :"إذا لم تكن قد حددت الجنس بالفعل، فهذا هو الجنس المرتبط بحسابك بناءً على ملفك الشخصي ونشاطك. لن يتم عرض هذه المعلومات للعامة.",
          male:  'ذكر',
          female : 'أنثى',
          other : 'آخر',
          change:'يتغير',
          changeCountrySettings:'تغيير الدولة',
          selectACountry:'اختر دولة',
          updateEmailAddress:'تحديث البريد الألكتروني',
          current:'حاضِر',
          changeEmailSetting:'تغيير الايميل',
          gender:'جنس',
          accountCreation:'إنشاء حساب',
          Age:'عمر',
          youHaveNotCreatedOrFollowedAnyLists: "لم تقم بإنشاء أو متابعة أي قوائم. عندما تفعل ذلك، سوف يظهرون هنا.",
          userCanPinnedOnly5  : 'يمكن للمستخدم تثبيت 5 فقط',
          pleaseEnterTheName  : 'الرجاء إدخال الاسم',
          list : 'القوائم',
          listYouAre :"القوائم التي أنت عليها",
          listYouHave:"لم تتم إضافتك إلى أي قوائم حتى الآن",
          listAddedSomeOne:"عندما يضيفك شخص ما إلى القائمة، ستظهر هنا",
          listMembers :'قائمة الأعضاء',
          listFollowers  : 'قائمة المتابعين',
          noMembers: 'لا يوجد أعضاء',
          noResults :'لا نتائج',
          noFollowers:'لا يوجد متابعين',
          manageWhatInformationYouSeeAndShareOnWerfie: 'إدارة المعلومات التي تراها وتشاركها على Werfie.',
          noResponseFromServerMsg: 'نحن نواجه بعض الصعوبات. الرجاء معاودة المحاولة في وقت لاحق',
          filteredResult:'النتيجة التي تمت تصفيتها',
          forYou:'لك',
          noInternetAvailable:'لا يوجد إنترنت متاح!',
          welcomeToWerfie:'مرحبا بكم في ويرفي',
          cantChooseEmailAsApass:
          "لا يمكنك اختيار البريد الإلكتروني ككلمة مرور، الرجاء \nاختيار كلمة مرور آمنة",
          passMustContainUpperCaseAndLeeter:
          'يجب أن تحتوي كلمة المرور على حرف كبير واحد على الأقل \nورقم واحد',
          bothPasswordAndConfirmPassShouldMatch:
          'يجب أن يتطابق كل من كلمة المرور وتأكيد كلمة المرور',
          DidNoTReceiveCode: "لم اتلق الرمز",
          verificationCode: 'رمز التحقق',
          enterYourNewPasswordHint: 'ادخل كلمة مرور جديدة',
          ChangePasswordSettings: 'تغيير كلمة المرور',
          trendingUpdates: 'الشائعات الحديثة',
          dobAddMsg: 'أضف تاريخ ميلادك إلى ',
          audienceAndTagging: 'الجمهور ووضع العلامات',
          LearnMoreAboutPrivacyOnWerfie:
              'تعرف على المزيد حول الخصوصية على Werfie',
          yourWerfieActivity: 'نشاط Werfi الخاص بك',
          yourAndTagging: 'الخاص بك ووضع العلامات',
          yourWerfs: 'ويرف الخاص بك',
          contentYouSee: "المحتوى الذي تراه",
          muteAndBlock: 'كتم الصوت والحظر',
          directMessages: 'رسالة مباشرة',
          dataSharingAndPersonalization: 'مشاركة البيانات والتخصيص',
          locationInformation: 'معلومات الموقع',

          nameCannotBeEmpty: "مطلوب اسم",
          nameLengthShouldMax20: "يجب ألا يزيد طول الاسم عن 20",
          nameStartsWithCharacter: "يجب أن يبدأ الاسم بالحروف الهجائية،",
          pleaseProvideAValidEmail: "يرجى تقديم عنوان بريد إلكتروني صالح،",
          werfieHandleIsRequired: "مطلوب معرف ويرفى",
          passwordShouldBeMin8Char:
              'يجب أن تتكون كلمة المرور من 8 أحرف على الأقل،',
          pleaseEnterYourBirthDate: 'الرجاء ادخال تاريخ ميلادك',
          enterYourBirthDateOptional: 'ادخل تاريخ ميلادك (اختيارى)',
          topicsThatYouFollowShownHere:
              'يتم عرض المواضيع التي تتابعها هنا. لرؤية كل الأشياء التي تعتقد Werfie أنك مهتم بها، راجع بيانات Werfie الخاصة بك. يمكنك أيضًا معرفة المزيد حول متابعة المواضيع.',
          bySigningUpYouAgree: 'من خلال التسجيل، فإنك توافق على لدينا،',
          and: 'و',
          privacyUpdated: 'تم تحديث الخصوصية',
          removeWerfFromBookMark: 'إزالة werf من الإشارة المرجعية',
          areYouSure: 'هل أنت متأكد؟',
          doYouWantToExit: 'هل تريد الخروج من التطبيق',
          no: 'لا',
          yes: 'نعم',
          werfUnsaved: 'لم يتم حفظ Werf بنجاح!',
          private: 'اجعلها شخصيه',
          name: 'اسم',
          bio: "السيرة الذاتية",
          birthDate: 'تاريخ الميلاد',
          create: 'يخلق',
          weWontSuggestThisTopic: "لن نقترح هذا الموضوع بعد الآن",
          youllSeeTopWerfs:
              "سترى أهم Werfs حول هذه الأمور مباشرةً في المخطط الزمني لمنزلك",
          requestVerification: 'طلب التحقق',
          enterCurrentPassword: 'إدخل كلمة السر الحالية',
          enterYourNewPassword:
              "أدخل كلمة المرور الجديدة واضغط على زر التالي. سنرسل لك رمزًا مكونًا من 4 أرقام على عنوان بريدك الإلكتروني. ستحتاج إلى إدخال هذا الرمز المكون من 4 أرقام في الشاشة التالية لإكمال العملية.",
          noWerfs: 'لا ورفس',
          verified: 'التأكيد',
          getMoments: 'احصل على لحظات',
          tweetsAndReplies: 'التغريدات والردود',
          yourlist: 'قوائمك',
          copyProfileLink: 'نسخ رابط الملف الشخصي',
          signInWithApple: 'سجل من خلال ابل',
          searchForAnItem: 'البحث عن عنصر...',
          editOrder: 'تحرير التسلسل',
          ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
              'لا يمكن التراجع عن هذا وستتم إزالته من ملفك الشخصي، والمخطط الزمني لأي حسابات تتابعك، ومن نتائج بحث Werfie.',
          writeAShortDesc: 'اكتب وصفًا قصيرًا عن اللحظات',
          addATitle: 'إضافة عنوان',
          publish: 'ينشر',
          likedBy: 'أعجبني ',
          werfSearch: 'بحث فيرفس',
          werfsByAccount: "ويرفز بالحساب",
          werfsILiked: "كلمات أعجبتني",
          addWerfs: 'أضف ورفس',
          allReply: 'كل رد',
          replyingTo: 'الرد على',
          werfYourReply: 'اكتب ردك ...',
          doYouWantToLet: 'هل تريد السماح ',
          toMessageYou: ' لمراسلتك؟ لن يعرفوا أنك رأيت رسالتهم حتى تقبلها.',
          noMomentsList: 'لا لحظات',
          justNow: 'الآن',
          clear: 'واضح',
          createANewWerf: 'قم بإنشاء ملف Werf جديد',
          suggestedTopics: 'الموضوعات المقترحة',
          whenYouFollowMsg:
              "عندما تتبع قائمة ، ستتمكن من مواكبة الخبراء بسرعة بشأن أكثر ما تهتم به.",
          chooseYourLists: 'اختر القوائم الخاصة بك',
          discoverlist: 'اكتشف قوائم جديدة',
          pinnedList: "قائمة مثبتة",
          createNew: 'خلق جديد إبداع جديد',
          chooseAnExistingMomentOrCreateNew:
              'اختر اللحظة الحالية أو أنشئ لحظة جديدة',
          seizeTheMoment: 'تمسك باللحظة',
          momentDeleteSuccessfully: 'تم حذف اللحظة بنجاح',
          createMoment: 'خلق لحظة',
          removeMomentAlertMsg: 'لا يمكن التراجع عن هذا وستفقد اللحظة.',
          momentsDelete: 'لحظات حذف؟',
          nothingToSeeHere: 'لا شيء لتراه هنا',
          nothingToSeeHerePinYour:
              'لا شيء تراه هنا حتى الآن - ثبّت قوائمك المفضلة للوصول إليها بسرعة.',
          viewHiddenReply: 'مشاهدة الرد المخفي',
          block: 'حاجز',
          chooseOneFromYourExistingChatsOrStartANewOne:
              'اختر واحدة من الدردشات الموجودة لديك ، أو ابدأ واحدة جديدة',
          youDoNotHaveAChatSelected: 'لم يتم تحديد الدردشة لديك',
          editGroup: 'تحرير المجموعة',
          colors: 'الألوان',
          dark: "الداكنة",
          light: "الفاتحة",
          theseSettingsAffect:
              "تؤثر هذه الإعدادات على جميع حسابات Werfie على هذا المتصفح.",
          customizeView: 'تخصيص العرض الخاص بك',
          dismiss: 'رفض',
          thisWerfSeen: 'مرات شوهد هذا werf.',
          youHaveAlreadyReportedWerf: 'لقد أبلغت بالفعل عن هذا werf',
          enterDescriptionFieldIsRequired: "مطلوب إدخال حقل الوصف",
          searchLocation: 'موقع البحث',
          tagLocation: 'علامة الموقع',
          profileVisits: 'زيارات الملف الشخصي',
          newFollowers: 'متابعين جدد',
          detailExpands: 'تفاصيل يوسع',
          engagements: 'ارتباط',
          impressions: 'انطباعات',
          werfAnalytics: 'تحليلات ورف',
          followed: 'متابعه',
          notInterested: 'غير مهتم',
          suggested: 'مقترح',
          add: 'يضيف',
          remove: 'يزيل',
          members: 'أعضاء',
          whenYouMakeAList: "عندما تجعل القائمة خاصة ، يمكنك فقط رؤيتها.",
          makePrivate: 'اجعلها شخصيه',
          createNewList: 'إنشاء قائمة جديدة',
          next: 'التالي',
          done: 'منتهي',
          editList: 'تحرير القائمة',
          manageMembers: 'إدارة الأعضاء',
          delete: 'يمسح',
          listYouAreON: "يسرد ما أنت عليه",
          newsSocial: 'أخبار',
          filmTV: 'ترفيه',
          music: 'موسيقى',
          travelAdventure: 'يسافر',
          newChat: 'دردشة جديدة',
          noMsgsYet: 'لا رسائل بعد',
          addToYourList: 'أضف إلى قائمتك',
          theTopicsYouFollow:
              "تُستخدم الموضوعات التي تتابعها لتخصيص Werfs والأحداث والإعلانات التي تراها وتظهر علنًا في ملفك الشخصي",
          verification: 'تَحَقّق',
          verificationAccount: 'تأكيد الحساب',
          country: 'دولة',
          userNameSavedSuccessfully: 'تم حفظ اسم المستخدم بنجاح!',
          deactivateAccount: 'تعطيل الحساب',
          daily: 'يوميًا',
          topWerfs: 'أعلى ورف',
          getEmailToFindOut:
              'احصل على رسائل بريد إلكتروني لمعرفة ما يحدث عندما لا تكون في Werfie. يمكنك إيقاف تشغيلها في أي وقت.',
          pushNotifications: 'دفع الإخطار',
          otpSentMsg:
              "لقد أرسلنا للتو رمزًا مكونًا من 6 أرقام على عنوان بريدك الإلكتروني. أدخل هذا الرمز في المكان الموضح أدناه واضغط على زر التأكيد",
          sendViaDirectMessage: 'إرسال عبر رسالة خاصّة',
          shareWerf: 'مشاركة ملف Werf',
          copylinkToWerf: 'انسخ الرابط إلى werf',
          pickWhoCanReplyMsg:
              "اختر من يمكنه الرد على هذا Werf. ضع في اعتبارك أن أي شخص مذكور يمكنه الرد دائمًا.،",
          whoCanReply: 'من يمكنه الرد؟',
          everyoneCanReply: 'من يمكنه الرد ؟',
          onlyPeopleYouMention: 'فقط الأشخاص الذين ذكرتهم',
          allwerf: 'كل Werf',
          werf: 'ورف',
          changeEmail: 'تغيير الايميل',
          werfs: 'تغريدات',
          viewTranslated: 'يترجم',
          changedTheCountryName: 'غير كلمة المرور الخاصة بك',
          viewTopics: 'مشاهدة المواضيع',
          confirmPassMsg: 'أكد رقمك السري',
          wrongPasswordMsg: 'كلمة مرور خاطئة',
          languageSettings: 'اعدادات اللغة',
          unBlock: 'رفع الحظر',
          loginWithGoogle: 'تسجيل الدخول عبر جوجل',
          createYourPassword: 'إنشاء كلمة مرورك',
          createYourWerfieHandle: 'قم بإنشاء مقبض werfie الخاص بك',
          forwardMessage: 'رسالة إلى الأمام',
          copy: 'نسخ الرسالة',
          messageDelete: 'حذف لك',
          deleteConversation: 'مسح المحادثة',
          peopleInThisChat: 'الأشخاص في هذه الدردشة',
          views: 'الآراء',
          werfSeenCountMsg: 'مرات شوهد هذا Werf',
          newWerf: 'جديد Werf',
          newWerfs: 'جديد Werfs',
          pinPostMsg: 'تثبيت آخر في ملف التعريف الخاص بك',
          unPinPostMsg: 'إزالة تثبيت إلى ملف التعريف الخاص بك!',
          removeWerfAlert: "لا يمكن التراجع عن هذا وستفقد تغييراتك",
          rewerf: 'إعادة',
          quoteRewerf: 'اقتبس Rewerf',
          rewerfSuccessfully: 'ReWerf بنجاح',
          noReplyComments: 'لا يوجد رد تعليقات',
          postDetail: 'تفاصيل ورف',
          profileLinkCopy: 'تم نسخ رابط الملف الشخصي بنجاح!',
          muteUser: 'كتم الصوت بنجاح',
          userReportedSuccessfully: 'أبلغ المستخدم بنجاح',
          userBlockedSuccessfully: 'تم حظر المستخدم بنجاح',
          werfReportedSuccssfully: 'تم الإبلاغ عن Werf بنجاح',
          notificationsSettings: 'إعدادات الإخطارات',
          displaySettings: 'اعدادات العرض',
          moments: 'لحظات',
          followings: 'يتابع',
          popularUpdates: 'تحديثات شعبية',
          privacyAndSafety: 'الخصوصية والأمان',
          pendingRequest: 'الطلبات المعلق ',
          accept: 'يقبل',
          reject: 'يرفض',
          reportBlock: 'حظر/تقرير',
          noMessageRequestAvailable: 'لا يوجد طلب رسالة متاح',

          messageRequests: 'طلبات الرسائل',
          messageRequestsFallHere:
              'إعادة إرسال الرسائل من الأشخاص الذين لا تتابعهم يعيشون هنا. للرد على الرسالة هناك تحتاج إلى قبول الطلب',
          notificationsSettings: 'إعدادات الإخطارات',
          createWerf: 'خلق Werf',
          chats: 'الدردشات',
          bookmarks: 'إشارات مرجعية',
          bookmark: 'المرجعية',
          enterYourEmail: 'أدخل بريدك الإلكتروني',
          enterYourPassword: 'ادخل رقمك السري',
          // languageSettings: 'اعدادات اللغة',
          blockedAccountsSettings: 'إعدادات الحسابات المحظورة',
          selectYourPreferredLanguage: 'اختر لغتك المفضلة',
          emailNotification: 'اشعارات البريد الالكتروني',
          securityAndAccountAccess: 'الأمن والوصول إلى الحساب',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'الصفحة الرئيسية',
          browse: 'تصفح',
          hotTrends: 'احدث التريندات',
          popularUpdates: 'التحديث الشعبي',
          saved: 'تم الحفظ',
          messages: 'رسائل',
          myProfile: 'ملفي',
          accountInformation: 'معلومات الحساب',
          settings: 'إعدادات',
          notifications: 'إشعارات',
          pushNotifications: 'دفع الإخطارات',
          settingsType: 'نوع الإعدادات',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'إدارة كيفية عرض محتوى BuzzNBee لك',
          selectYourProfileLanguage: 'حدد لغة ملف التعريف الخاص بك',
          selectYourAppLanguage: 'حدد لغة التطبيق الخاص بك',
          enableDisableAutoTranslation: 'تمكين أو تعطيل الترجمة الآلية',

          ///   arabic
          language: 'لغة',
          username: 'اسم االمستخدم',
          snoozeNotification: 'غفوة الإعلام',
          version: 'الإصدار',
          appVersion: 'نسخة التطبيق',
          lists: 'القوائم',
          deactivationAndDeletion: 'التعطيل والحذف',
          confirmYourPasswords: 'أكد رقمك السري',
          deactivateAccount: 'تعطيل الحساب',
          or: 'أو',
          deleteAccount: 'حذف الحساب',
          updateYourLanguageAndTranslation: 'قم بتحديث إعدادات اللغة والترجمة',
          manageYourPrivacySettings: 'إدارة إعدادات الخصوصية الخاصة بك',
          privacySettings: 'إعدادات الخصوصية',
          setYourPrivacySettings: 'اضبط إعدادات الخصوصية الخاصة بك',
          messageSettings: 'إعدادات الرسالة',
          noOne: 'لا احد',
          everyOne: 'كل واحد',
          daily: 'يوميًا',
          weekly: 'أسبوعي',
          off: 'عن',
          biweekly: 'كل أسبوعين',
          ChangeUsernameSettings: 'تغيير إعدادات اسم المستخدم',
          enterYourWerfieHandle: 'أدخل مقبض werfie الخاص بك',
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "إذا كنت تريد حذف حساب Werfie الخاص بك نهائيًا ، فبمجرد النقر فوق الزر موافق ، لن تتمكن من إعادة تنشيط حسابك أو استرداد أي محتوى أو معلومات قمت بإضافتها.",
          permanentlyDeleteAccount: "احذف الحساب نهائيًا",
          viewEditHistory: 'عرض محفوظات التحرير',
          reportWerf: 'تقرير werf',
          hideWerf: "إخفاء werf",
          showMore : "أظهر المزيد",
          reportUser: 'أبلغ عن مستخدم',
          mute: 'صامت',
          unMute: "إلغاء كتم الصوت",
          deleteWerf: "حذف Werf",
          viewWerfAnalytics: 'مشاهدة تحليلات Werf',
          pintoYourProfile: 'تثبيت في ملف التعريف الخاص بك',
          editWerf: 'تحرير Werf',
          explore: 'يستكشف',
          YourAccount: 'الحساب الخاص بك',
          blockedAccounts: 'الحسابات المحظورة',
          whoCanMessageYou: 'من يمكنه مراسلتك',
          youHaveNotBlockedAnyPersonYet: 'لم تقم بحظر أي شخص حتى الآن',
          translations: 'الترجمات',
          viewListOfBlockedAccounts: 'عرض قائمة الحسابات المحظورة',
          realTimePostTranslation: 'في الوقت الحقيقي بعد الترجمة',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'حدد اللغة وقت تحميل مقطع فيديو أو ملف صوتي',
          originalTranslatedScriptAudioPost:
              'النص الأصلي أو المترجم للمنشور الصوتي',
          listenTranslatedScript: 'استمع إلى نص مترجم',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'ترجمة الرسائل تلقائيًا في الدردشة باللغة المحددة للمستخدمين',
          postedUpdate: 'نشر تحديثا.',
          peopleWhoReacted: 'الناس الذين ردوا',
          comments: 'تعليقات',
          peopleWhoRetweeted: ' retweeted' + 'الناس الذين',
          leaveAComment: 'اترك تعليقا',
          post: 'بريد',
          cancel: 'يلغي',
          YourAccount: 'الحساب الخاص بك',
          savePost: 'حفظ المنشور',
          report: 'تقرير',
          hide: 'إخفاء',
          shareLinkVia: 'مشاركة الرابط عبر ...',
          copyLink: 'انسخ الرابط',
          fieldRequired: 'حقل مطلوب',
          enterDescription: 'أدخل الوصف',
          selectCategory: 'اختر الفئة',
          okay: 'تمام',
          pleaseWait: 'ارجوك انتظر...',
          search: 'بحث',
          logout: 'تسجيل خروج',
          topic: "المواضيع",
          writeSomethingHere: 'اكتب شيئًا هنا',
          addMore: 'أضف المزيد',
          image: 'صورة',
          video: 'فيديو',
          file: 'ملف',
          gif: 'GIF',
          audio: 'صوتي',
          live: 'يعيش',
          doNotHaveAnAccount: "ليس لديك حساب؟ ",
          register: 'سجل',
          haveAnAccount: "هل لديك حساب؟",
          login: 'تسجيل الدخول',
          whoToFollow: 'من الذي يتبع',
          noSuggestion: 'لا يوجد اقتراح',
          follow: 'يتبع',
          unFollow: 'الغاء المتابعة',
          seeMore: 'شاهد المزيد',
          searchFilter: 'تصفية البحث',
          people: 'الناس',
          fromAnyone: 'من اي شخص',
          peopleYouFollow: 'الأشخاص الذين تتابعهم',
          location: 'موقع',
          anywhere: 'في أى مكان',
          nearYou: 'بالقرب منك',
          advancedSearch: 'البحث المتقدم',
          trendsForYou: 'الاتجاهات بالنسبة لك',
          noTrending: 'لا توجد اتجاهات في منطقتك',
          trendingIn: 'تتجه في',
          // tweets: 'Tweets',
          noNotification: 'لا توجد إخطارات لك',
          refresh: 'ينعش',
          edit: 'يحرر',
          save: 'يحفظ',
          cFollow: 'يتبع',
          addPeople: 'أضف أشخاصا',
          someText: 'بعض النصوص',
          reportConversation: 'الإبلاغ عن محادثة',
          leaveConversation: 'غادر المحادثة',
          enterYourMessage: 'أدخل رسالتك',
          showMoreComments: 'أظهر المزيد من التعليقات',
          reBuzz: 'Rebuzz',
          noPosts: 'لا تحديثات لك',
          ChangeYourPassword: 'غير كلمة المرور الخاصة بك',
          emailFieldCannotBeEmpty: 'لا يمكن ترك حقل البريد الإلكتروني فارغًا',
          emailFormatIsInvalid: 'تنسيق البريد الإلكتروني غير صالح',
          rememberMe: 'تذكرنى',
          lostPassword: 'الرقم السرى غير صحيح',
          cLOGIN: 'تسجيل الدخول',
          emailOrPasswordIsIncorrect:
              'البريد الالكتروني او كلمة المرور غير صحيحة',
          newsFeed: 'موجز الأخبار',
          trends: 'اتجاهات',
          profile: 'الملف الشخصي',
          newMessage: 'رسالة جديدة',
          next: 'التالي',
          searchPeople: 'ابحث عن أشخاص',
          saySomething: 'قل شيئا',
          noSearchResult: 'لا توجد نتيجة بحث',
          searchResult: 'نتيجة البحث',
          hidePost: 'آخر اخفاء',
          showLess: 'عرض أقل',
          showMore: 'أظهر المزيد',
          nothingYet: 'لا شيء حتى الان!',
          savedPosts: 'المشاركات المحفوظة',
          enterYourFirstName: 'أدخل اسمك الأول',
          enterYourLastName: 'أدخل اسمك الأخير',
          enterYourUsername: 'أدخل اسم المستخدم الخاص بك',
          signUp: 'اشتراك',
          pleaseChooseACountry: 'الرجاء اختيار دولة',
          replied: 'أجاب',
          reply: 'رد',
          delete: 'حذف',
          replyToComment: ' الرد على',
          noFollower: 'لا متابع',
          following: 'التالية',
          followBack: 'تابع ما سبق',
          followers: 'متابعون',
          follower: 'تابع',
          noFollowings: 'لا أتباع',
          sendAMessageGetAMessage: ' احصل على رسالة, ارسل رسالة',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'الرسائل المباشرة هي محادثات خاصة بينك وبين أشخاص آخرين على BuzzNBee. مشاركة Buzz، وسائط ، والمزيد!',
          startAConversation: 'بدء محادثة',
          groupInfo: 'معلومات المجموعة',
          chatInfo: 'معلومات الدردشة',
          youDoNotHaveAMessageSelected: 'ليس لديك رسالة محددة',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'اختر واحدة من رسائلك الحالية ، أو ابدأ واحدة جديدة.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'الرجاء إدخال رمز التحقق للتحقق من بريدك الإلكتروني',
          usernameOrEmail: 'اسم المستخدم أو البريد الالكتروني',
          enterVerificationCode: 'أدخل رمز التحقق',
          confirmCode: 'تأكيد الرمز',
          top: 'قمة',
          latest: 'أحدث',
          photos: 'الصور',
          videos: 'أشرطة فيديو',
          files: 'الملفات',
          noPeople: 'لا اشخاص',
          all: 'الكل',
          mentions: 'الاشارات',
          replies: 'الردود',
          // tweetsAndReplies: 'Tweets & ' + 'الردود',
          media: 'وسائط',
          likes: 'الإعجابات',
          searchPost: 'تحديثات البحث',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'فقدت كلمة المرور الخاصة بك؟ الرجاء إدخال اسم المستخدم أو عنوان البريد الإلكتروني. سوف تتلقى رابطًا لإنشاء كلمة مرور جديدة عبر البريد الإلكتروني.',
          resetYourPassword: 'اعد ضبط كلمه السر',
          enterCode: 'ادخل الرمز',
          enterNewPassword: 'أدخل كلمة مرور جديدة',
          reEnterPassword: 'اعادة ادخال كلمة السر',
          passwordCannotBeEmpty: 'لا يمكن أن تكون كلمة المرور فارغة',
          passwordShouldBeCharacter: 'يجب أن تتكون كلمة المرور من 8 أحرف',
          passwordShouldBeMatched: 'يجب أن تكون كلمة المرور متطابقة',
          resetPassword: 'إعادة تعيين كلمة المرور',
          email: 'بريد الالكتروني',
          phone: 'هاتف',
          blockUser: 'حظر المستخدم',
          // reportUser: 'مستخدم محضور',
          public: 'عام',
          mentionUsers: 'اذكر المستخدمين',
          editProfile: 'إعداد الملف الشخصي',
          yourProfileIsUpdated: 'ملفك الشخصي محدث',
          seeProfile: 'انظر الملف الشخصي',
          skipForNow: 'تخطي في الوقت الراهن',
          addBio: 'أضف السيرة الذاتية',
          profileUpdated: 'تحديث الملف الشخصي',
          upDate: 'تحديث',
          goToProfile: 'اذهب إلى الملف الشخصي',
          more: 'أكثر',
          about: 'عن',
          help: 'يساعد',
          privacyPolicy: 'سياسة خاصة',
          blog: 'مدونة او مذكرة',
          termsOfService: 'شروط الخدمة',
          youMustSelectACountry: 'يجب عليك تحديد بلد',
          usernameIsAlreadyTaken: 'اسم المستخدم مسجل بالفعل',
          goBack: 'عد',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'تم إنشاء حساب بالفعل مع هذا البريد الإلكتروني',
          yourPasswordIsResetSuccessfully:
              'تم إعادة تعيين كلمة المرور الخاصة بك بنجاح',
          returnToLogin: 'العودة لتسجيل الدخول',
          youHaveEnteredAnInvalidCode: 'كنت قد دخلت رمز غير صالح',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'شكرًا لك على إنشاء حسابك مع BuzznBee ، وسيتواصل معك فريقنا خلال 24 ساعة. ابق بأمان!',
          success: 'النجاح',
          goBackToHomePage: 'العودة الى الصفحة الرئيسية',
        },
        'fr': {
          ok : "D'ACCORD",
          timesThisWerfWasSeenOnWerfie :'Fois où ce werf a été vu sur Werfie',
          totalNumberOfTimesAUserHasInteractedWithAWerf: "Nombre total de fois qu'un utilisateur a interagi avec un serveur.",
          timesPeopleViewedTheDetailsAboutThisWerf : "Nombre de fois où les gens ont consulté les détails de ce site",
          followsGainedDirectlyFromThisWerf : "Suit obtenu directement de ce werf",
          numberOfProfileViewsFromThisWerf : "Nombre de vues de profil de ce site",
          deleteForEveryOne : 'Supprimer pour tout le monde',
          photo : 'Photo',
          emojis : 'Émojis',
          uploadFile: 'Téléverser un fichier',
          createPoll :'Créer un sondage',
          scheduleWerf :"Horaires Werf",
          loginWithEmail : 'Connectez-vous avec e-mail',
          usePhoneInstead :  "Utilisez plutôt le téléphone",
          useEmailInstead : "Utilisez plutôt le courrier électronique",
          noVerifiedFollower :'Renvoyer',
          verifiedFollowers :  'Abonnés vérifiés',
          signUpToYourAccount : "Inscrivez-vous à votre compte",
          pleaseEnterYourName : "S'il vous plaît entrez votre nom",
          werfieHandleErrorMessage : 'Veuillez saisir un identifiant',
          emailErrorMessage : 'Veuillez entrer un email valide',
          werfieHandle : 'Poignée Werfie',
          pleaseEnterAValidDOB :'Veuillez saisir une date de naissance valide',
          pleaseEnterDOB : 'Date de naissance (JJ/MM/AAAA)',
          phone :'Téléphone',
          suggestions : "Suggestions",
          customizeYourExperience : "Personnalisez votre expérience",
          trackWhereYouSeeWerfieContentAcrossTheWeb : "Suivez où vous voyez le contenu Werfie sur le Web",
          werfieUsesThisDataToPersonalizeYourExperience : "Werfie utilise ces données pour personnaliser votre expérience. Cet historique de navigation Web ne sera jamais stocké avec votre nom, votre adresse e-mail ou votre numéro de téléphone",
          werfieMayUseYourContactInformationIncludingYouEmail : "Werfie peut utiliser vos coordonnées, y compris votre adresse e-mail et votre numéro de téléphone aux fins décrites dans notre politique de confidentialité.",
          pleaseAgreeToWerfieTermsConditions: "Veuillez accepter les conditions générales de Werfie",
          createYourAccount :  "Créez votre compte",
          weSentYouACode : "Nous vous avons envoyé un code",
          enterItBelowToVerify :"Entrez-le ci-dessous pour vérifier ",
          didNotReceiveEmail : "Vous n'avez pas reçu d'e-mail ?",
          youWillNeedAPassword :"Vous aurez besoin d'un mot de passe",
          passwordMustBeCharactersLong:"Le mot de passe doit comporter 8 caractères, dont au moins un chiffre, une lettre majuscule et un caractère spécial.",
          pleaseEnterAValidEmail : 'Veuillez entrer un email valide',
          resend : "Renvoyer",

          google :"Google",
          apple :"Pomme",
          worldNoor :"Mondenoor",
          doNotMissWhatsHappening :"Ne manquez pas ce qui se passe",
          peopleOnWerfieAreTheFirstToKnow :"Les gens de Werfie sont les premiers informés",
          newToWerfie :  "Nouveau sur Werfie ?",
          signUpNowToGetYourOwnPersonalizedTimeline :'Inscrivez-vous maintenant pour obtenir votre propre chronologie personnalisée!',
          signUpWithGoogle :  "Inscrivez-vous avec Google",
          signUpWithApple :"S'inscrire avec Apple",
          signUpWithEmailOrMobile : "Inscrivez-vous par e-mail ou mobile",
          loginWithWorldNoor : "Connectez-vous avec WorldNoor",
          bySigningUpYouAgreeOur : 'En vous inscrivant, vous acceptez notre',
          trending :'Tendance',
          noUserNoTag : 'Aucun utilisateur && Aucune balise',
          noTrendsInThisRegion :'Aucune tendance dans cette région',
          weAreExperiencingSomeDifficulties : "Nous rencontrons quelques difficultés. Veuillez réessayer plus tard",
          noPost : "Pas d'article",

          signInToYourAccount : "Connectez-vous à votre compte",
          enterEmailPhone : "Entrez votre e-mail/téléphone",
          forgotPassword : "Mot de passe oublié?",
          itSeemsLikeYouAreARobot: "On dirait que vous êtes un robot. veuillez vérifier à nouveau",
          signIn:  "Se connecter",
          registerHere: "Inscrivez-vous ici!",
          orContinueWith: "Ou continuez avec",
          somThingWentWrongWithConfiguration: "Un problème est survenu lors de la configuration. Veuillez réessayer",
          error:"Erreur",
          pleaseAllowEmailToContinueWithWerfie: "Veuillez autoriser le courrier électronique à continuer avec werfie",
          alert: "Alerte",
          sorryForTheInconvenience:"Désolé pour le dérangement. Veuillez réessayer plus tard.",
          enterDigitsVerificationCodeSentToYourRegisteredEmail: "Entrez le code de vérification à 6 chiffres Envoyé à votre adresse e-mail enregistrée",


          theUsernameHasAlreadyBeenTaken : "Le nom d'utilisateur est déjà pris.",
          thereWasAnErrorInSavingThisUsername : "Une erreur s'est produite lors de l'enregistrement de ce nom d'utilisateur!",
          showMenu : 'Afficher le menu',
          thisPollHasExpired : 'Ce sondage a expiré',
          youCannotVoteOnYourOwnPoll : 'Vous ne pouvez pas voter sur votre propre sondage!',
          choice : "Choix",
          optionalPoll : "(Facultatif)",

          watchPartyLetGo :  "Regardez la fête, allons-y",
          createSpace :"Créer de l'espace",
          oopsSomethingWentWrongPleaseTryAgain : "Oups… Quelque chose s'est mal passé! Veuillez réessayer",
          noSpacesAvailable : 'Aucune place disponible',
          yourSpaceIsReady : "Votre espace est prêt",
          spaceLinkCopiedSuccessfully : 'Lien spatial copié avec succès',
          instant : 'Instantané',
          nameYourSpace : 'Nommez votre espace',
          whatDoYouWantToTalkAbout :'De quoi veux-tu parler?',
          scheduleYourSpace : "Planifiez votre espace",
          confirm : 'Confirmer',
          selectTopic : 'Sélectionnez un sujet',
          momentDeleteSuccessfully : "Moment supprimé avec succès",
          createSpaceSuccessfully : "Créer de l'espace avec succès",
          pleaseEnterTheSpaceName : "Veuillez saisir le nom de l'espace",
          spaces : 'Les espaces',

          pleaseChooseEither1VideoOr1Pdf: "Veuillez choisir soit 1 vidéo, soit 1 PDF à la fois ou jusqu'à 4 photos.",
          fileTypeIsNotAllowed:"Le type de fichier n'est pas autorisé",
          thisPostIsScheduledFor: "Ce poste est prévu pour",
          askAQuestion: 'Poser une question...',
          pollLength:'Durée du sondage',
          hours: 'Heures',
          minutes:'Minutes',
          removePoll: 'Supprimer le sondage',
          uploading: 'Téléchargement...',
          addDescription: "Ajouter une description",
          willPostOn:  "Publiera sur",
          date:'Date',
          youCannotScheduleAWerfInThePast: 'Vous ne pouvez pas planifier un Werf dans le passé',
          time: 'Temps',
          timeZone: 'Fuseau horaire',
          youHaveNoScheduledWerfs: "Vous n'avez pas de travaux programmés",
          willSendOn:  "Enverra",
          selectAll: 'Tout sélectionner',
          schedule: 'Calendrier',
          scheduledWerfs: 'Travaux programmés',
          deselectAll: 'Tout déselectionner',
          yourImageVideoWillBeAvailableInAMoment: 'Votre image/vidéo sera disponible dans un instant.',
          pleaseEnterValidText: 'Veuillez saisir un texte valide',
          takeAPhoto: "Prendre une photo",
          chooseFromGallery:  "Choisir depuis la galerie",
          makeVideoWithPhoneCamera: "Faire une vidéo avec la caméra du téléphone",
          unsentWerfs: 'Werfs non envoyés',

          commentsHere:'commentaires ici',
          ImageDescription : "description de l'image",
          viewHiddenReplies: 'Afficher les réponses masquées',
          undoRewerf: 'Annuler le rewerf',
          share:  "Partager",
          view:  "Voir",
          werfLinkCopiedSuccessfully: "Lien Werf copié avec succès",
          addBookmark: "Ajouter un marque-page",
          removeBookmark: "Supprimer le signet",
          werfSavedSuccessfully: 'Werf a été enregistré avec succès!',
          werfUnsavedSuccessfully:  'Werf non enregistré avec succès!',
          thereWasAnErrorInUnSavingThisWerf: "Une erreur s'est produite lors de la désenregistrement de ce site!",
          thereWasAnErrorInSavingThisWerf:"Une erreur s'est produite lors de la sauvegarde de ce !",
          thereWasAnErrorInBlockingThisUser:"Une erreur s'est produite lors du blocage de cet utilisateur!",
          noEditHistory: "Pas d'historique des modifications",
          unPinFromProfile: "Désépingler du profil",
          saveWerf: 'Enregistrer Werf',
          linkCopiedToClipBoard:  'Lien copié dans le presse-papier!',
          removeFromBookmarks: 'Supprimer des favoris',
          thereWasAnErrorInReportingThisUser: "Une erreur s'est produite lors du signalement de cet utilisateur!",
          viewOriginal: "l'original",
          showThisThread:'Afficher ce fil',
          rewerf : 'Rewerf',

          werfAnalytics : "Werf Analytics",
          nothingFound:"Rien n'a été trouvé",
          year:'Année',
          day : 'Jour',
          month : 'Mois',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "Il doit s'agir de la date de naissance de la personne utilisant le compte. Même si vous créez un compte pour votre entreprise ou votre événement.",
          editDateOfBirth : 'Modifier la date de naissance?',
          deletePhoto :"Supprimer la photo",
          removePhoto : "Retirer photo",
          addPhoto :"Ajouter une photo",
          discard : "Jeter",
          removeWerfAlert :
          "Cette opération est irréversible et vous perdrez vos modifications.",
          discardChanges : "Annuler les modifications?",
          youShouldBeAtLeast14YearsOld: 'Vous devez avoir au moins 14 ans',
          contentOfDialog :"Contenu du dialogue",
          pinnedWerf : "Werf épinglé",
          hiddenPost : "Werfs cachés",
          thisCanBeOnlyChangedAFewTimes :" Cela ne peut être modifié que quelques fois. Assurez-vous de saisir l'âge de la personne utilisant le compte",


          aboutHashTag : 'À propos du hashtag',
          werfHashTag : 'Hashtag Werf',
          messageRequests : 'Demandes de messages',
          enterGroupChatTitle:  "Saisissez le titre de la discussion de groupe",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Choisissez-en une parmi vos discussions existantes ou démarrez-en une nouvelle',
          snoozeNotificationsFrom :  "Répéter les notifications de",
          snoozeNotificationsFromTheGroup : "Répéter les notifications du groupe",
          snoozeMentions : "Répéter les mentions",
          disableNotificationsWhenPeoplemention:"Désactivez les notifications lorsque des personnes vous mentionnent dans cette conversation.",
          trySearchingForPeopleGroupsOrMessages : "Essayez de rechercher des personnes, des groupes ou des messages",
          werfieUser :  "Utilisateur Werfie",
          otherChat :"autre...",
          photoChat : 'Photo',
          videoChat : 'Vidéo',
          fileChat : 'Déposer',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          "Les messages directs sont des conversations privées entre vous et d'autres personnes sur Twitter. Partagez des tweets, des médias et bien plus encore!",
          searchChats : "Rechercher des discussions",
          allTabChat : "Tout",
          peopleTabChat : "Personnes",
          groupsTabChat :"Groupe",
          chatsTabChat :"Discussions",
          noResultsFor : "Aucun résultat pour",
          theTermYouEnteredDidNotBring : "Le terme que vous avez saisi n'a donné aucun résultat",
          message : "Message",
          addMembersToChat : 'Ajouter des membres pour discuter',
          noMessagesYet : "Aucun message pour l'instant",
          doNotAllowMessages : "n'autorise pas les messages",
          notAllowedToMessage : "Pas autorisé à envoyer un message.",
          youHaveBlockedThisUser : "Vous avez bloqué cet utilisateur",
          startAMessage :  "Démarrer un message",
          react :  "Réagir",
          undo : "annuler",
          reactions : 'Réactions',
          messageRequestsFallHere :
          "Les demandes de messages de personnes que vous ne suivez pas sont en direct ici. Pour répondre à ce message, vous devez accepter la demande.",
          noMessageRequestAvailable : 'Aucune demande de message disponible',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'Selon le paramètre que vous sélectionnez, différentes personnes peuvent vous envoyer un message direct.',

          allowMessagesOnlyFromPeopleYouFollow :
          'Autoriser les messages uniquement des personnes que vous suivez',
          youWontReceiveAnyMessageRequests :
          "Vous ne recevrez aucune demande de message",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Autoriser les demandes de messages uniquement des utilisateurs vérifiés",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Les personnes que vous suivez pourront toujours vous envoyer des messages",
          allowMessagesRequestsFromEveryone :
          'Autoriser les demandes de messages de tout le monde',
          otherControls : "Autres contrôles",
          filterLowQualityMessages : "Filtrer les messages de mauvaise qualité",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Masquez les demandes de messages qui ont été détectées comme étant potentiellement longues ou de mauvaise qualité. Celles-ci seront envoyées dans une boîte de réception distincte au bas de vos demandes de messages. Vous pouvez toujours y accéder si vous le souhaitez.",
          showReadReceipts : "Afficher les confirmations de lecture",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Informez les personnes avec lesquelles vous envoyez des messages lorsque vous avez vu leurs messages. Les accusés de lecture ne s'affichent pas sur les demandes de message.",


          getPushNotificationsToFindOut :"Recevez des notifications push pour savoir ce qui se passe lorsque vous n'êtes pas sur Werfie. Vous pouvez les désactiver à tout moment.",
          relatedToYouAndYourWerfs :"Lié à vous et à vos Werfs",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "Lorsque vous activez les notifications Werf des personnes que vous suivez, vous recevez des notifications push concernant leurs Werfs.",
          topWerfs :"Meilleurs Werfs",
          tailoredForYou: "Sur mesure pour vous",
          rewerf : 'Rewerf',
          like : 'Comme',
          photoTags : "Balises photo",
          messageReactions : "Réactions aux messages",
          fromWerfie : "De Werfie",
          newsSports : "Actualités / Sports",
          recommendations : "Recommendations",
          turnOnPush:"Activer les\nnotifications push",
          toReceiveNotificationsAsTheyHappen :"Pour recevoir des notifications au fur et à mesure, activez\nla notification push. Vous les recevrez également lorsque\nvous n'êtes pas sur Werfie. Éteignez-les à tout moment.",
          turnOn : "Allumer",
          newNotifications :  "Nouvelles notifications",
          werfsEmailedToYou : "Werfs vous a envoyé un e-mail",
          weekly : 'Hebdomadaire',
          newAboutWerfieProduct :"Nouveautés sur les mises à jour des produits et fonctionnalités Werfie",
          tipsOnGettingMoreOut: "Conseils pour tirer le meilleur parti de Werfie",
          thingsYouMissedSinceYou: "Choses que vous avez manquées depuis votre dernière connexion à Werfie",
          participationInWerfieResearchSurveys: "Participation aux enquêtes de recherche Werfie",
          suggestionsRorRecommendedAccounts: "Suggestions de comptes recommandés",
          suggestionsBasedOnYourRecentFollows: "Suggestions basées sur vos abonnements récents",
          qualityFilters : "Filtres de qualité",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Choisissez de filtrer le contenu tel que les Werfs en double et automatisés. Cela ne s'applique pas aux notifications des comptes que vous suivez et avec lesquels vous avez interagi récemment.",

          emailNotification : 'Notifications par email',
          filters : "Filtres",
          chooseTheNotification : "Choisissez la notification que vous souhaitez voir et celles que vous ne souhaitez pas voir",
          preferences : "Préférences",
          selectYourPreferencesByNotificationType :"Sélectionnez vos préférences par type de notification.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
         " Werfie utilise toujours certaines informations, comme l'endroit où vous vous êtes inscrit et votre position actuelle, pour vous montrer un contenu plus pertinent. Lorsque ce paramètre est activé, Werfie peut également personnaliser votre expérience en fonction d'autres endroits où vous avez été.",

          personalizeBasedOnPlacesYouHaveBeen :
          'Personnalisez en fonction des endroits où vous avez été',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Gérez les informations de localisation utilisées par Werfie pour personnaliser votre expérience.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Informez les personnes avec lesquelles vous envoyez des messages lorsque vous avez vu leurs messages. Les accusés de lecture ne s'affichent pas sur les demandes de message.",

          showReadReceipts : "Afficher les confirmations de lecture",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Masquez les demandes de messages qui ont été détectées comme étant potentiellement longues ou de mauvaise qualité. Celles-ci seront envoyées dans une boîte de réception distincte au bas de vos demandes de messages. Vous pouvez toujours y accéder si vous le souhaitez.",


          filterLowQualityMessages :"Filtrer les messages de mauvaise qualité",
          otherControls : "Autres contrôles",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Les personnes que vous suivez pourront toujours vous envoyer des messages",
          allowMessagesRequestsFromEveryone :
          'Autoriser les demandes de messages de tout le monde',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "Les personnes que vous suivez pourront toujours vous envoyer des messages",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Autoriser les demandes de messages uniquement des utilisateurs vérifiés",
          youWontReceiveAnyMessageRequests :
          "Vous ne recevrez aucune demande de message",
          allowMessagesOnlyFromPeopleYouFollow :
          'Autoriser les messages uniquement des personnes que vous suivez',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'Selon le paramètre que vous sélectionnez, différentes personnes peuvent vous envoyer un message direct.',

          controlWhoCanMessageYou : 'Contrôlez qui peut vous envoyer un message',
          forever : " Pour toujours",
          muteNotificationsFromPeople :"Désactiver les notifications des personnes:",
          youDoNotFollow : "Tu ne suis pas",
          whoDoNotFollowYou : "Qui ne te suit pas",
          withANewAccount : "Avec un nouveau compte",
          whoHaveDefaultProfilePhoto :"Qui a une photo de profil par défaut",
          whoHaveNotConfirmedTheirEmail : "Qui n'ont pas confirmé leur email",
          whoHaveNotConfirmedTheirPhoneNumber :"Qui n'ont pas confirmé leur numéro de téléphone",
          duration : 'Durée',
          untilYouUnmuteTheWord : "Jusqu'à ce que tu réactives le mot",
          hours24 : '24 heures',
          days7 : '7 jours',
          days30 : '30 jours',
          fromPeopleYouDontFollow : "De personnes que vous ne suivez pas",
          homeTimeline : 'Chronologie de la maison',
          muteFrom : 'Muet de',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          "Vous pouvez désactiver un mot, @nom d'utilisateur ou hashtag à la fois.",
          enterWordOrPhrase : 'Saisissez un mot ou une expression',
          mutedWord : 'Mot en sourdine',
          addMutedWords : 'Ajouter des mots muets',
          youHaveNotMutedAnyWordYet : "Vous n'avez encore désactivé aucun mot",
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "lorsque vous coupez des mots, vous ne recevrez aucune nouvelle notification pour les Werfs qui les incluent et vous ne verrez pas les Werfs avec ces mots dans votre chronologie d'accueil.",

          youHaveNotMutedAnyPersonYet :
          "Vous n'avez encore désactivé personne",
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Voici toutes les personnes que vous avez désactivées. Vous pouvez les ajouter et les supprimer de cette liste.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "Lorsque vous bloquez quelqu'un, cette personne ne pourra pas vous suivre ni vous envoyer de message. Et vous ne recevrez aucune notification de sa part.",

          mutedNotification : 'Notifications désactivées',
          mutedWords: 'Mots en sourdine',
          mutedAccounts : 'Comptes masqués',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Gérez les comptes, les mots et les notifications que vous avez désactivés ou bloqués.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          "Cela empêche les sites Web contenant du contenu potentiellement sensible de s'afficher dans vos résultats de recherche.",
          hideSensitiveContent: 'Masquer le contenu sensible',
          removeBlockedAndMutedAccounts :
          'Supprimer les comptes bloqués et mis en sourdine',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'Utilisez-le pour éliminer les résultats de recherche du compte que vous avez bloqué ou désactivé',
          personalization : 'Personnalisation',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'vous pouvez personnaliser les tendances en fonction de votre emplacement et des personnes que vous suivez',
          exploreLocation : "Explorer l'emplacement",
          showContentInThisLocation : 'Afficher le contenu à cet emplacement',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'Lorsque cette option est activée, vous verrez ce qui se passe autour de vous en ce moment.',
          searchSettings  :'Paramètres de recherche',
          exploreSettings : 'Explorer les paramètres',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Décidez de ce que vous voyez sur werfie en fonction de vos préférences, comme les sujets',
          displayMediaThatMayContainSensitiveContent :
          "Affichage susceptible d'heurter la sensibilité",

          addLocationInformationToYourWerfs :'Ajoutez des informations de localisation à vos Werfs',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "Lorsqu'elles sont activées, les photos et vidéos de votre Werf seront marquées comme sensibles pour les personnes qui ne souhaitent pas voir de contenu sensible.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
         " Marquez les médias de votre Werf comme contenant du matériel susceptible d'être sensible",
          manageTheInformationAssociatedWithYourWerfs :
          'Gérez les informations associées à vos Werfs.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'si activé, vous pourrez attacher un emplacement à vos Werfs.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Supprimez toutes les informations de localisation attachées à vos Werfs',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          "Les étiquettes de localisation que vous avez ajoutées à vos Werfs ne seront plus visibles sur Werfie.com, Werfie pour IOS et Werfie pour Android. Ces mises à jour peuvent prendre un certain temps avant d'être appliquées.",

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Gérez les informations que vous autorisez aux autres personnes sur Werfie.',
          protectYourTweets : 'Protégez vos Werfs',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'Une fois sélectionné, votre compte et vos informations de compte ne sont visibles que par les personnes qui vous suivent.',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'Cela les rendra visibles uniquement à vos abonnés werfie',
          protect : 'Protéger',
          photoTagging : 'Marquage de photos',
          AnyoneCanTagYou : "N'importe qui peut te taguer",
          onlyPeopleYouFollowCanTagYou:
          'Seules les personnes que vous suivez peuvent vous identifier',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
         " Autorisez les gens à vous identifier sur leurs photos et à recevoir des notifications lorsqu'ils le font",
          AnyoneCanTagYou : "N'importe qui peut te taguer",
          onlyPeopleYouFollowCanTagYou : 'Seules les personnes que vous suivez peuvent vous identifier',
          security : 'Sécurité',
          manageYourAccountsSecurity : "Gérez la sécurité de vos comptesy",
          twoFactorAuthentication : "Authentification à deux facteurs",
          manageYourAccountsSecurityKeepTrack : "Gérez la sécurité de vos comptes et suivez l'utilisation de votre compte",
          helpProtectYourAccountFromUnauthorizedAccess :  "Aidez à protéger votre compte contre tout accès non autorisé en exigeant une deuxième méthode d'authentification en plus de votre mot de passe X. Vous pouvez choisir un message texte, une application d'authentification ou une clé de sécurité.",
          verificationCodeSentToYourRegisteredEmail:"Entrez le code de vérification à 6 chiffres Envoyé à votre adresse e-mail enregistrée",
          submit :'Soumettre',
          genderChangedSuccessfully : "Le sexe a changé avec succès",
          genderSettingTextDescription :"Si vous n'avez pas encore précisé de sexe, c'est celui associé à votre compte en fonction de votre profil et de votre activité. Ces informations ne seront pas affichées publiquement.",
          male:  'Mâle',
          female : 'Femelle',
          other : 'Autre',
          change:'Changement',
          changeCountrySettings:'changer de pays',
          selectACountry:'Choisissez un pays',
          updateEmailAddress:"mettre a jour l'adresse email",
          current:'Actuel',
          changeEmailSetting:"Changer l'e-mail",
          gender:'Genre',
          accountCreation:'Création de compte',
          Age:'Âge',
          securityAndAccountAccess:'Sécurité et accès au compte',
          youHaveNotCreatedOrFollowedAnyLists: "Vous n'avez créé ni suivi aucune liste. Quand vous le ferez, ils apparaîtront ici.",
          userCanPinnedOnly5  : "L'utilisateur ne peut en épingler que 5" ,
          pleaseEnterTheName  : 'Veuillez entrer le nom ',
          list : 'Listes',
          listYouAre :"Listes sur lesquelles vous êtes",
          listYouHave:"Vous n'avez encore été ajouté à aucune liste",
          listAddedSomeOne:"Lorsque quelqu'un vous ajoute à une liste, celle-ci s'affichera ici",
          listMembers :'Liste des membres',
          listFollowers  : 'Liste des abonnés',
          noMembers: 'Aucun membre',
          noResults :'Aucun résultat',
          noFollowers:'Aucun abonné',
          manageWhatInformationYouSeeAndShareOnWerfie: 'Gérez les informations que vous voyez et partagez sur Werfie.',
          noResponseFromServerMsg: 'Nous rencontrons quelques difficultés. Veuillez réessayer plus tard',
          filteredResult:'Résultat filtré',
          forYou:'Pour toi',
          noInternetAvailable:"Pas d'Internet disponible !",
          welcomeToWerfie:'Bienvenue chez werfi',
          cantChooseEmailAsApass:
          "Vous ne pouvez pas choisir une adresse e-mail comme mot de passe, veuillez \nchoisir un mot de passe sécurisé",
          passMustContainUpperCaseAndLeeter:
          'Le mot de passe doit contenir au moins une lettre majuscule \net un chiffre',
          bothPasswordAndConfirmPassShouldMatch:
          'Le mot de passe et le mot de passe de confirmation doivent correspondre',
          DidNoTReceiveCode: "Vous n'avez pas reçu le code ?",
          verificationCode: 'Le code de vérification',
          enterYourNewPasswordHint: 'Entrez votre nouveau mot de passe',
          ChangePasswordSettings: 'Changer le mot de passe',
          trendingUpdates: 'Mises à jour tendances',
          dobAddMsg: 'Ajoutez votre date de naissance à votre ',
          audienceAndTagging: 'Audience et marquage',
          LearnMoreAboutPrivacyOnWerfie:
              'En savoir plus sur la confidentialité sur Werfie',
          yourWerfieActivity: 'Votre activité Werfie',
          yourAndTagging: 'Votre et votre marquage',
          yourWerfs: 'Vos Werfs',
          contentYouSee: "Contenu que vous voyez",
          muteAndBlock: 'Muet et bloqué',
          directMessages: 'Message direct',
          dataSharingAndPersonalization:
              'Partage et personnalisation des données',
          locationInformation: 'Information de Lieu',

          nameCannotBeEmpty: "Le nom est requis",
          nameLengthShouldMax20: "La longueur du nom ne doit pas dépasser 20",
          nameStartsWithCharacter: "Le nom doit commencer par des alphabets",
          pleaseProvideAValidEmail: "Veuillez fournir un email valide",
          werfieHandleIsRequired: "Une poignée Werfie est requise",
          passwordShouldBeMin8Char:
              'Le mot de passe doit comporter au moins 8 caractères',
          pleaseEnterYourBirthDate: 'Veuillez entrer votre date de naissance',
          enterYourBirthDateOptional:
              'Entrez votre date de naissance (facultatif)',
          rewerf: 'Rewerf',
          topicsThatYouFollowShownHere:
              'Les sujets que vous suivez sont affichés ici. Pour voir tout ce qui, selon Werfie, vous intéresse, consultez vos données Werfie. Vous pouvez également en savoir plus sur les sujets suivants.',
          bySigningUpYouAgree: 'En vous inscrivant, vous acceptez notre,',
          and: 'et',
          privacyUpdated: 'Confidentialité mise à jour',
          removeWerfFromBookMark: 'Supprimer le site du favori',
          areYouSure: 'Es-tu sûr?',
          doYouWantToExit: "Voulez-vous quitter l'application",
          no: 'Non',
          yes: 'Oui',
          werfUnsaved: 'Werf Non sauvegardé avec succès !',
          private: 'Rendre privé',
          name: 'Nom',
          bio: "Biographie",
          birthDate: 'Date de naissance',
          create: 'Créer',
          weWontSuggestThisTopic: "Nous ne proposerons plus ce sujet",
          youllSeeTopWerfs:
              "Vous verrez les meilleurs Werfs à ce sujet directement dans votre chronologie d'accueil.",
          requestVerification: 'Demander une vérification',
          enterCurrentPassword: 'Entrer le mot de passe actuel',
          enterYourNewPassword:
              "Entrez votre nouveau mot de passe et appuyez sur le bouton Suivant. Nous vous enverrons un code à 6 chiffres sur votre adresse email. Vous devrez saisir ce code à 6 chiffres sur l'écran suivant pour terminer le processus.",
          noWerfs: 'Pas de Werfs',
          verified: 'Vérifié',
          getMoments: 'Werfs et réponses',
          tweetsAndReplies: 'Werfs & Replies',
          yourlist: 'Vos listes',
          copyProfileLink: 'Copier le lien du profil',
          signInWithApple: 'Connectez-vous avec Apple',
          searchForAnItem: 'Rechercher un article...',
          changedTheCountryName: "J'ai changé le nom du pays avec succès !",
          editOrder: "séquence d'édition",
          ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
              'Cela ne peut pas être annulé et il sera supprimé de votre profil, de la chronologie de tous les comptes qui vous suivent et des résultats de recherche Werfie.',
          writeAShortDesc: 'Schreiben Sie eine kurze Beschreibung über Momente',
          addATitle: 'Écrivez une brève description des moments',
          publish: 'Publier',
          likedBy: 'Aimé par ',
          werfSearch: 'Recherche de Werfs',
          werfsByAccount: "Werfs par compte",
          werfsILiked: "Les mots que j'ai aimés",
          addWerfs: 'Ajouter des Werfs',
          allReply: 'Tous Répondre',
          replyingTo: 'Répondre à ',
          werfYourReply: 'Werf votre réponse...',
          noMomentsList: 'Aucun moment',
          justNow: "Tout à l' heure",
          clear: 'Claire',
          createANewWerf: 'Créer un nouveau Werf',
          suggestedTopics: 'Sujets suggérés',
          whenYouFollowMsg:
              "Lorsque vous suivez une liste, vous serez en mesure de suivre rapidement les experts sur ce qui vous intéresse le plus.",
          chooseYourLists: 'Choisissez vos listes',
          discoverlist: 'Découvrez de nouvelles listes',
          pinnedList: "Liste épinglée",
          createNew: 'Créer un nouveau',
          chooseAnExistingMomentOrCreateNew:
              'Choisissez un moment existant ou créez-en un nouveau',
          seizeTheMoment: "Saisir l'instant",
          momentDeleteSuccessfully: 'Moment supprimé avec succès',
          createMoment: 'Créer un moment',
          removeMomentAlertMsg:
              'Cela ne peut pas être annulé et vous perdrez votre moment.',
          momentsDelete: 'Moments supprimés?',
          nothingToSeeHere: 'Rien à voir ici',
          nothingToSeeHerePinYour:
              'Rien à voir ici pour le moment - épinglez vos listes préférées pour y accéder rapidement.',
          viewHiddenReply: 'Afficher la réponse masquée',
          block: 'Bloc',
          chooseOneFromYourExistingChatsOrStartANewOne:
              'Choisissez-en un parmi vos chats existants ou démarrez-en un nouveau',
          youDoNotHaveAChatSelected: "Vous n'avez pas de chat sélectionné",
          editGroup: 'Modifier le groupe',
          colors: 'Couleurs',
          dark: "sombre",
          light: "lumière",
          theseSettingsAffect:
              "Ces paramètres affectent tous les comptes Werfie sur ce navigateur.",
          customizeView: 'Personnalisez votre vue',
          dismiss: 'Rejeter',
          thisWerfSeen: 'Fois ce werf a été vu.',
          youHaveAlreadyReportedWerf: 'Vous avez déjà signalé ce werf',
          enterDescriptionFieldIsRequired:
              "Le champ de description est obligatoire",
          searchLocation: 'Lieu de recherche',
          tagLocation: 'Emplacement de la balise',
          profileVisits: 'Visites de profil',
          newFollowers: 'Nouveaux adeptes',
          detailExpands: 'Le détail se développe',
          engagements: 'Engagements',
          impressions: 'Impressions',
          werfAnalytics: 'Werf Analytique',
          followed: 'suivi',
          notInterested: 'Pas intéressé',
          suggested: 'Suggéré',
          add: 'Ajouter',
          remove: 'Retirer',
          members: 'Membres',
          whenYouMakeAList:
              "Lorsque vous rendez une liste privée, vous seul pouvez la voir.",
          makePrivate: 'Rendre privé',
          createNewList: 'Créer une nouvelle liste',
          next: 'Suivante',
          done: 'Fait',
          editList: "Liste d'édition",
          manageMembers: 'Gérer les membres',
          delete: 'Supprimer',
          listYouAreON: "Listes sur lesquelles vous êtes",
          newsSocial: 'Nouvelles',
          filmTV: 'divertissement',
          music: 'musique',
          travelAdventure: 'Voyage',
          newChat: 'Nouvelle discussion',
          noMsgsYet: 'Aucun message pour le moment',
          addToYourList: 'Ajouter à votre liste',
          theTopicsYouFollow:
              "Die Themen, denen Sie folgen, werden verwendet, um die Werften, Veranstaltungen und Anzeigen, die Sie sehen, zu personalisieren und öffentlich in Ihrem Profil anzuzeigen",
          verification: 'vérification',
          verificationAccount: 'Vérification de compte',
          country: 'Pays',
          userNameSavedSuccessfully:
              "Nom d'utilisateur enregistré avec succès !",
          deactivateAccount: 'Désactiver le compte',
          off: 'Désactivé',
          weekly: 'Hebdomadaire',
          daily: 'Quotidienne',
          topWerfs: 'Top wef',
          getEmailToFindOut:
              "Recevez des e-mails pour savoir ce qui se passe lorsque vous n'êtes pas sur Werfie. Vous pouvez les désactiver à tout moment.",
          pushNotifications: 'Notification push',
          otpSentMsg:
              "Nous venons de vous envoyer un code à 6 chiffres sur votre adresse e-mail. Entrez ce code à l'endroit indiqué ci-dessous et appuyez sur le bouton Confirmer",
          sendViaDirectMessage: 'Envoyer par Message Privé',
          shareWerf: 'Partager Werf',
          copylinkToWerf: 'Copier le lien vers werf',
          pickWhoCanReplyMsg:
              "Choisissez qui peut répondre à ce Werf. Gardez à l'esprit que toute personne mentionnée peut toujours répondre.,",
          whoCanReply: 'Qui peut répondre ?',
          everyoneCanReply: 'Tout le monde peut répondre',
          onlyPeopleYouMention: 'Seules les personnes que vous mentionnez',
          allwerf: 'All Werf',
          werf: 'Werf',
          changeEmail: "Changer l'e-mail",
          werfs: 'Werfs',
          viewTranslated: 'Afficher traduit',
          ChangeYourPassword: 'changez votre mot de passe',
          accountInformation: 'Information sur le compte',
          viewTopics: 'Afficher les sujets',
          confirmPassMsg: 'Confirmer votre mot de passe',
          wrongPasswordMsg: 'Wrong Password',
          languageSettings: 'Paramètres de langue',
          unBlock: 'Débloquer',
          loginWithGoogle: 'Connectez-vous avec Google',
          createYourPassword: 'Créez votre mot de passe',
          createYourWerfieHandle: 'Créez votre poignée werfie',
          forwardMessage: 'Transférer le message',
          copy: 'Copier le message',
          messageDelete: 'Supprimer pour vous',
          deleteConversation: 'Supprimer la conversation',
          peopleInThisChat: 'Personnes dans ce chat',
          views: 'Vues',
          werfSeenCountMsg: 'Fois ce Werf a été vu',
          newWerf: 'Nouveau Werf',
          newWerfs: 'Nouveaux Werfs',
          pinPostMsg: 'Épinglez la publication à votre profil',
          unPinPostMsg: 'Détachez la publication de votre profil !',
          removeWerfAlert:
              "Cette opération est irréversible et vous perdrez vos modifications",
          quoteRewerf: 'Citation Rewerf',
          rewerf: 'Rewerf',
          rewerfSuccessfully: 'ReWerf réussi',
          noReplyComments: 'Aucun commentaire de réponse',
          postDetail: 'Détail de Werf',
          profileLinkCopy: 'Lien de profil copié avec succès !',
          muteUser: 'coupé avec succès',
          userReportedSuccessfully: 'Utilisateur signalé avec succès !',
          userBlockedSuccessfully: 'Utilisateur bloqué avec succès !',
          werfReportedSuccssfully: 'Werf signalé avec succès',
          YourAccount: 'Votre compte',
          notificationsSettings: 'Paramètres de notification',
          displaySettings: "Paramètres d'affichage",
          moments: 'Des moments',
          followings: 'Suivis',
          popularUpdates: 'Mises à jour populaires',
          privacyAndSafety: 'confidentialité et sécurité',
          createWerf: 'Créer Werf',
          chats: 'chattes',
          bookmarks: 'signets',
          bookmark: 'signet',
          enterYourEmail: 'Entrer votre Email',
          enterYourPassword: 'Tapez votre mot de passe',
          // languageSettings: 'Paramètres de langue',
          blockedAccountsSettings: 'Paramètres des comptes bloqués',
          selectYourPreferredLanguage: 'Sélectionnez votre langue préférée',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Accueil',
          browse: 'Parcourir',
          hotTrends: 'Tendances chaudes',
          saved: 'Enregistrée',
          messages: 'Messages',
          myProfile: 'Mon profil',
          settings: 'Paramètres',
          notifications: 'Notifications',
          settingsType: 'Type de paramètres',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'Gérer la façon dont le contenu BuzzNBee vous est affiché',
          selectYourProfileLanguage: 'Sélectionnez la langue de votre profil',
          selectYourAppLanguage: 'Sélectionnez la langue de votre application',
          enableDisableAutoTranslation:
              'Activer/désactiver la traduction automatique',
          language: 'Langue',

          ///   french
          username: "Nom d'utilisateur",
          snoozeNotification: 'Notification de répétition',
          version: 'Version',
          appVersion: "Version de l'application",
          lists: 'Listes',
          deactivationAndDeletion: "Désactivation et suppression",
          confirmYourPasswords: "Confirmer votre mot de passe",
          deactivateAccount: 'Désactiver le compte',
          or: 'OU ALORS',
          deleteAccount: "Supprimer le compte",
          updateYourLanguageAndTranslation:
              "Mettez à jour vos paramètres de langue et de traduction",
          manageYourPrivacySettings: "Gérer vos paramètres de confidentialité",
          privacySettings: "Paramètres de confidentialité",
          setYourPrivacySettings:
              'Définissez vos paramètres de confidentialité',
          messageSettings: 'Paramètres des messages',
          noOne: 'Personne',
          everyOne: 'Toutes les personnes',
          ChangeUsernameSettings:
              "Modifier les paramètres du nom d'utilisateur",
          enterYourWerfieHandle: "Entrez votre identifiant werfie",
          youHaveNotBlockedAnyPersonYet: "Vous n'avez encore bloqué personne",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "Si vous souhaitez supprimer définitivement votre compte Werfie, une fois que vous aurez cliqué sur le bouton OK, vous ne pourrez plus réactiver votre compte ni récupérer le contenu ou les informations que vous avez ajoutés.",
          permanentlyDeleteAccount: "Supprimer définitivement le compte",
          whoCanMessageYou: 'Qui peut vous envoyer un message',
          viewEditHistory: "Afficher l'historique des modifications",
          reportWerf: 'Rapporter',
          hideWerf: "Cacher",
          showMore:"Voir plus",
          reportUser: 'Dénoncer un utilisateur',
          mute: 'Mettre en sourdine',
          unMute: "Rétablir le son",
          deleteWerf: "Supprimer Werf",
          viewWerfAnalytics: 'Afficher Werf Analytics',
          pintoYourProfile: 'Épinglez à votre profil',
          editWerf: 'Modifier Werf',
          explore: 'Explorer',

          blockedAccounts: 'Comptes bloqués',
          translations: 'Traductions',
          viewListOfBlockedAccounts: 'Afficher la liste des comptes bloqués',
          realTimePostTranslation: 'Post-traduction en temps réel',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              "Sélectionnez la langue au moment du téléchargement d'une vidéo ou d'un audio",
          originalTranslatedScriptAudioPost:
              'Script original ou traduit de la publication audio',
          listenTranslatedScript: 'Écoutez le script traduit',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Traduire automatiquement les messages dans le chat dans la langue sélectionnée par les utilisateurs',
          postedUpdate: 'posté une mise à jour.',
          peopleWhoReacted: 'Les personnes qui ont réagi',
          comments: 'Commentaires',
          peopleWhoRetweeted: 'Les personnes qui ont retweeté',
          leaveAComment: 'laissez un commentaire',
          post: 'Poster',
          cancel: 'Annuler',
          savePost: 'Enregistrer la publication',
          report: 'Signaler',
          hide: 'Cacher',
          shareLinkVia: 'Partager le lien via...',
          copyLink: 'Copier le lien',
          fieldRequired: 'Champ obligatoire',
          enterDescription: 'Entrez la description',
          selectCategory: 'Choisir une catégorie',
          okay: "D'accord,",
          pleaseWait: "S'il vous plaît, attendez...",
          search: "Chercher",
          logout: 'Se déconnecter',
          writeSomethingHere: 'Écrivez quelque chose ici',
          addMore: 'Ajouter plus',
          image: 'Image',
          video: 'Vidéo',
          videos: 'Vidéos',
          file: 'Déposer',
          gif: 'GIF',
          audio: "l'audio",
          live: 'Habitent',
          doNotHaveAnAccount: "Vous n'avez pas de compte ? ",
          register: "S'inscrire",
          haveAnAccount: "Avoir un compte? ",
          login: 'Connexion',
          whoToFollow: 'Qui suivre',
          noSuggestion: 'Aucune suggestion',
          follow: 'Suivre',
          unFollow: 'Ne plus suivre',
          seeMore: 'Voir plus',
          searchFilter: 'Filtre de recherche',
          people: 'Personnes',
          fromAnyone: "De n'importe qui",
          peopleYouFollow: 'Les gens que vous suivez',
          location: 'Emplacement',
          anywhere: 'Partout',
          nearYou: 'Près de toi',
          advancedSearch: 'Recherche Avancée',
          trendsForYou: 'Tendances pour vous',
          noTrending: "Il n'y a pas de tendances dans votre région",
          trendingIn: 'Tendance dans',
          // tweets: 'Tweets',
          noNotification: "Il n'y a aucune notification pour vous",
          refresh: "rafraîchir",
          edit: 'Éditer',
          save: 'sauvegarder',
          cFollow: 'Suivre',
          addPeople: 'Ajouter des personnes',
          someText: 'Du texte',
          reportConversation: 'Signaler une conversation',
          leaveConversation: 'Quitter la conversation',
          enterYourMessage: 'entrez votre message',
          showMoreComments: 'Afficher plus de commentaires',
          reBuzz: 'Rebuzz',
          noPosts: "Aucune mise à jour pour vous",
          emailFieldCannotBeEmpty: 'Le champ e-mail ne peut pas être vide',
          emailFormatIsInvalid: "Le format de l'e-mail n'est pas valide",
          rememberMe: 'Souviens-toi de moi',
          lostPassword: 'Mot de passe perdu?',
          cLOGIN: 'CONNEXION',
          emailOrPasswordIsIncorrect: 'E-mail ou mot de passe incorrect',
          newsFeed: "Fil d'actualité",
          trends: 'Les tendances',
          profile: 'Profil',
          newMessage: 'Nouveau message',
          next: 'Prochaine',
          searchPeople: 'Rechercher des personnes',
          saySomething: 'Dis quelquechose',
          noSearchResult: 'Aucun résultat de recherche',
          searchResult: 'Résultat de la recherche',
          hidePost: 'Masquer le message',
          showLess: 'Montrer moins',
          showMore: 'Montre plus',
          nothingYet: 'Rien pour le moment!',
          savedPosts: 'Messages enregistrés',
          enterYourFirstName: 'Entrez votre prénom',
          enterYourLastName: 'Entrez votre nom de famille',
          enterYourUsername: "Entrez votre nom d'utilisateur",
          signUp: "S'inscrire",
          pleaseChooseACountry: 'Veuillez choisir un pays',
          replied: 'a répondu',
          reply: 'Répondre',
          delete: 'Effacer',
          replyToComment: 'Répondre au commentaire',
          noFollower: 'Aucun suiveur',
          following: 'Suivante',
          followBack: 'Suivre',
          followers: 'Suiveuses',
          follower: 'Disciple',
          noFollowings: 'Aucun suivi',
          sendAMessageGetAMessage: 'Envoyer un message, recevoir un message',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              "Les Messages Privés sont des conversations privées entre vous et d'autres personnes sur Twitter. Partagez des Tweets, des médias et plus encore !",
          startAConversation: 'Commencer une conversation',
          groupInfo: 'Informations sur le groupe',
          chatInfo: 'Informations sur le chat',
          youDoNotHaveAMessageSelected:
              "Vous n'avez pas de message sélectionné",
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Choisissez-en un parmi vos messages existants ou créez-en un nouveau.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'Veuillez entrer le code de vérification pour vérifier votre e-mail',
          usernameOrEmail: "Nom d'utilisateur ou email",
          enterVerificationCode: 'Entrez le code de vérification',
          confirmCode: 'Confirmer le code',
          top: 'Sommet',
          latest: 'Dernière',
          photos: 'Photos',
          files: 'Des dossiers',
          noPeople: 'Personne',
          all: 'Toute',
          mentions: 'Mentions',
          replies: 'réponses',
          // tweetsAndReplies: 'Tweets et réponses',
          media: 'Médias',
          likes: 'Aime',
          searchPost: 'Rechercher des mises à jour',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'Mot de passe perdu? Veuillez saisir votre identifiant ou adresse mail. Vous recevrez un lien pour créer un nouveau mot de passe par e-mail.',
          resetYourPassword: 'Réinitialisez votre mot de passe',
          enterCode: 'Entrez le code',
          enterNewPassword: 'Entrez un nouveau mot de passe',
          reEnterPassword: 'Entrez à nouveau le mot de passe',
          passwordCannotBeEmpty: 'Le mot de passe ne peut pas être vide',
          passwordShouldBeCharacter:
              'Le mot de passe doit comporter 8 caractères',
          passwordShouldBeMatched: 'Le mot de passe doit correspondre',
          resetPassword: 'réinitialiser le mot de passe',
          email: 'E-mail',
          blockUser: 'Bloquer un utilisateur',
          public: 'Publique',
          mentionUsers: 'Mentionner les utilisateurs',
          editProfile: 'Configurer le profil',
          yourProfileIsUpdated: 'Votre profil est mis à jour',
          seeProfile: 'Voir le profil',
          skipForNow: "Ignorer pour l'instant",
          addBio: 'Ajouter une biographie',
          profileUpdated: 'Profil mis à jour',
          upDate: 'Mettre à jour',
          goToProfile: 'Aller au profil',
          more: 'Suite',
          about: 'Sur',
          help: 'Aider',
          privacyPolicy: 'Politique de confidentialité',
          blog: 'Blog',
          termsOfService: "Conditions d'utilisation",
          youMustSelectACountry: 'Vous devez sélectionner un pays',
          usernameIsAlreadyTaken: "Nom d'utilisateur déjà pris",
          goBack: 'Retourner',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'Un compte a déjà été créé avec cet email',
          yourPasswordIsResetSuccessfully:
              'Votre mot de passe est réinitialisé avec succès',
          returnToLogin: 'Retour à la connexion',
          youHaveEnteredAnInvalidCode: 'Vous avez entré un code invalide',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              "Merci d'avoir créé votre compte avec BuzznBee. Notre équipe vous contactera dans les 24 heures. Être prudent!",
          success: 'Succès',
          goBackToHomePage: "Retournez à la page d'accueil",
          topic: 'les sujets'
        },
        'de': {
          ok : 'OK',
          timesThisWerfWasSeenOnWerfie :'Mal wurde dieser Werfer auf Werfie gesehen',
          totalNumberOfTimesAUserHasInteractedWithAWerf: "Gesamtzahl der Interaktionen eines Benutzers mit einem Werf.",
          timesPeopleViewedTheDetailsAboutThisWerf : "Mal haben sich die Leute die Details zu dieser Werft angesehen",
          followsGainedDirectlyFromThisWerf : "Follower, die direkt von diesem Werft stammen",
          numberOfProfileViewsFromThisWerf : "Anzahl der Profilaufrufe von diesem Werft",
          deleteForEveryOne : 'Für alle löschen',
          photo : 'Foto',
          emojis : 'Emojis',
          uploadFile: 'Datei hochladen',
          createPoll :'Umfrage erstellen',
          scheduleWerf :"Zeitplan Werft",
          loginWithEmail : 'Melden Sie sich mit E-Mail an',
          usePhoneInstead :  "Verwenden Sie stattdessen das Telefon",
          useEmailInstead : "Verwenden Sie stattdessen E-Mail",
          noVerifiedFollower :'Kein verifizierter Follower',
          verifiedFollowers :  'Verifizierte Follower',
          signUpToYourAccount : "Melden Sie sich bei Ihrem Konto an",
          pleaseEnterYourName : 'Bitte geben Sie Ihren Namen ein',
          werfieHandleErrorMessage : 'Bitte geben Sie einen Handle ein',
          emailErrorMessage : 'Bitte geben Sie eine gültige Email-Adresse ein',
          werfieHandle : 'Werfie-Griff',
          pleaseEnterAValidDOB :'Bitte geben Sie ein gültiges Geburtsdatum ein',
          pleaseEnterDOB : "Geburtsdatum (TT/MM/JJJJ)",
          phone :'Telefon',
          suggestions : "Vorschläge",
          customizeYourExperience : "Passen Sie Ihr Erlebnis individuell an",
          trackWhereYouSeeWerfieContentAcrossTheWeb : "Verfolgen Sie, wo Sie Werfie-Inhalte im Web sehen",
          werfieUsesThisDataToPersonalizeYourExperience : "Werfie verwendet diese Daten, um Ihr Erlebnis zu personalisieren. Dieser Webbrowser-Verlauf wird niemals zusammen mit Ihrem Namen, Ihrer E-Mail-Adresse oder Telefonnummer gespeichert",
          werfieMayUseYourContactInformationIncludingYouEmail : "Werfie kann Ihre Kontaktinformationen, einschließlich Ihrer E-Mail-Adresse und Telefonnummer, für die in unserer Datenschutzrichtlinie beschriebenen Zwecke verwenden.",
          pleaseAgreeToWerfieTermsConditions: "Bitte stimmen Sie den Allgemeinen Geschäftsbedingungen von Werfie zu",
          createYourAccount :  "Erstelle deinen Account",
          weSentYouACode : "Wir haben Ihnen einen Code geschickt",
          enterItBelowToVerify :"Geben Sie es unten zur Bestätigung ein",
          didNotReceiveEmail : "Keine E-Mail erhalten?",
          youWillNeedAPassword :"Sie benötigen ein Passwort",
          passwordMustBeCharactersLong:"Das Passwort muss 8 Zeichen lang sein und mindestens eine Zahl, einen Großbuchstaben und ein Sonderzeichen enthalten.",
          pleaseEnterAValidEmail : 'Bitte geben Sie eine gültige Email-Adresse ein',
          resend : "Erneut senden",

          google :"Google",
          apple :"Apfel",
          worldNoor :"Worldnoor",
          doNotMissWhatsHappening :"Verpassen Sie nicht, was passiert",
          peopleOnWerfieAreTheFirstToKnow :"Die Leute auf Werfie sind die Ersten, die es erfahren",
          newToWerfie :  "Neu bei Werfie?",
          signUpNowToGetYourOwnPersonalizedTimeline :'Melden Sie sich jetzt an, um Ihre persönliche Zeitleiste zu erhalten!',
          signUpWithGoogle :  "Melden Sie sich bei Google an",
          signUpWithApple :"Melden Sie sich bei Apple an",
          signUpWithEmailOrMobile : "Melden Sie sich per E-Mail oder Handy an",
          loginWithWorldNoor : "Melden Sie sich mit WorldNoor an",
          bySigningUpYouAgreeOur : 'Mit Ihrer Anmeldung stimmen Sie unseren zu',
          trending :'Im Trend',
          noUserNoTag : 'Kein Benutzer && Kein Tag',
          noTrendsInThisRegion :'Keine Trends in dieser Region',
          weAreExperiencingSomeDifficulties : "Wir haben einige Schwierigkeiten. Bitte versuchen Sie es später noch einmal",
          noPost : 'Keine Post',

          signInToYourAccount : "Melden Sie sich bei Ihrem Konto an",
          enterEmailPhone : "Geben Sie E-Mail/Telefon ein",
          forgotPassword : "Passwort vergessen?",
          itSeemsLikeYouAreARobot: "Es scheint, als wärst du ein Roboter. Bitte überprüfen Sie es erneut",
          signIn:  "Anmelden",
          registerHere: "Hier registrieren!",
          orContinueWith: "Oder fahren Sie fort mit",
          somThingWentWrongWithConfiguration: "Bei der Konfiguration ist ein Fehler aufgetreten. Bitte versuche es erneut",
          error:"Fehler",
          pleaseAllowEmailToContinueWithWerfie: "Bitte erlauben Sie eine E-Mail, um mit werfie fortzufahren",
          alert: "Alarm",
          sorryForTheInconvenience:"Entschuldigen Sie die Unannehmlichkeiten. Bitte versuchen Sie es später noch einmal.",
          enterDigitsVerificationCodeSentToYourRegisteredEmail: "Geben Sie den 6-stelligen Bestätigungscode ein, der an Ihre registrierte E-Mail-Adresse gesendet wird",


          theUsernameHasAlreadyBeenTaken : 'Der Benutzername ist bereits vergeben.',
          thereWasAnErrorInSavingThisUsername : "Beim Speichern dieses Benutzernamens ist ein Fehler aufgetreten!",
          showMenu : 'Zeige das Menü',
          thisPollHasExpired : 'Diese Umfrage ist abgelaufen',
          youCannotVoteOnYourOwnPoll : 'Sie können nicht an Ihrer eigenen Umfrage teilnehmen!',
          choice : "Auswahl",
          optionalPoll : "(Optional)",

          watchPartyLetGo :  "Party gucken, los geht's",
          createSpace :'Platz schaffen',
          oopsSomethingWentWrongPleaseTryAgain : 'Hoppla! Etwas ist schiefgelaufen! Bitte versuche es erneut',
          noSpacesAvailable : 'Keine Plätze verfügbar',
          yourSpaceIsReady : "Ihr Raum ist fertig",
          spaceLinkCopiedSuccessfully : 'Space-Link erfolgreich kopiert',
          instant : 'Sofortig',
          nameYourSpace : 'Benennen Sie Ihren Raum',
          whatDoYouWantToTalkAbout :'Worüber möchten Sie sprechen?',
          scheduleYourSpace : "Planen Sie Ihren Raum",
          confirm : 'Bestätigen',
          selectTopic : 'Wählen Sie Thema aus',
          momentDeleteSuccessfully : "Moment erfolgreich gelöscht",
          createSpaceSuccessfully : "Platz schaffen – erfolgreich",
          pleaseEnterTheSpaceName : "Bitte geben Sie den Raumnamen ein",
          spaces : 'Spaces',

          pleaseChooseEither1VideoOr1Pdf: "Bitte wählen Sie entweder jeweils 1 Video oder 1 PDF oder bis zu 4 Fotos.",
          fileTypeIsNotAllowed:'Der Dateityp ist nicht zulässig',
          thisPostIsScheduledFor: "Dieser Beitrag ist geplant für",
          askAQuestion: 'Stelle eine Frage...',
          pollLength:'Länge der Umfrage',
          hours: 'Std',
          minutes:'Protokoll',
          removePoll: 'Umfrage entfernen',
          uploading: 'Hochladen...',
          addDescription: "Beschreibung hinzufügen",
          willPostOn:  "Werde am posten",
          date:'Datum',
          youCannotScheduleAWerfInThePast: 'Sie können keinen Werf in der Vergangenheit planen',
          time: 'Zeit',
          timeZone: 'Zeitzone',
          youHaveNoScheduledWerfs: 'Sie haben keine geplanten Werften',
          willSendOn:  "Werde weiterschicken",
          selectAll: 'Wählen Sie Alle',
          schedule: 'Zeitplan',
          scheduledWerfs: 'Geplante Werften',
          deselectAll: 'Alle abwählen',
          yourImageVideoWillBeAvailableInAMoment: 'Ihr Bild/Video wird in Kürze verfügbar sein.',
          pleaseEnterValidText: 'Bitte geben Sie einen gültigen Text ein',
          takeAPhoto: "Mach ein Foto",
          chooseFromGallery:  "Aus der Galerie wählen",
          makeVideoWithPhoneCamera: "Machen Sie Videos mit der Telefonkamera",
          unsentWerfs: 'Nicht gesendete Werften',

          commentsHere:'Kommentare hier',
          ImageDescription : 'Bildbeschreibung',
          viewHiddenReplies: 'Versteckte Antworten anzeigen',
          undoRewerf: 'Rewerf rückgängig machen',
          share:  "Aktie",
          view:  "Sicht",
          werfLinkCopiedSuccessfully: "Werft-Link erfolgreich kopiert",
          addBookmark: "Lesezeichen hinzufügen",
          removeBookmark: "Lesezeichen entfernen",
          werfSavedSuccessfully: 'Werf erfolgreich gespeichert!',
          werfUnsavedSuccessfully:  'Werf erfolgreich entsichert!',
          thereWasAnErrorInUnSavingThisWerf: 'Beim Aufheben der Speicherung dieses werf ist ein Fehler aufgetreten!',
          thereWasAnErrorInSavingThisWerf:'Beim Speichern dieses werf ist ein Fehler aufgetreten!',
          thereWasAnErrorInBlockingThisUser:'Beim Blockieren dieses Benutzers ist ein Fehler aufgetreten!',
          noEditHistory: 'Kein Bearbeitungsverlauf',
          unPinFromProfile: "Vom Profil lösen",
          saveWerf: 'Werft retten',
          linkCopiedToClipBoard:  'Link in die Zwischenablage kopiert!',
          removeFromBookmarks: 'Aus Lesezeichen entfernen',
          thereWasAnErrorInReportingThisUser: 'Beim Melden dieses Benutzers ist ein Fehler aufgetreten!',
          viewOriginal: "Original",
          showThisThread:'Zeige diesen Thread',
          rewerf : 'Rewerf',

          werfAnalytics : "Werftanalytik",
          nothingFound:'Nichts gefunden',
          year:'Jahr',
          day : 'Tag',
          month : 'Monat',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "Dies sollte das Geburtsdatum der Person sein, die das Konto nutzt. Auch wenn Sie ein Konto für Ihr Unternehmen oder Ihre Veranstaltung erstellen.",
          editDateOfBirth : 'Geburtsdatum bearbeiten?',
          deletePhoto :"Foto löschen",
          removePhoto : "Foto entfernen",
          addPhoto :"Foto hinzufügen",
          discard : "Verwerfen",
          removeWerfAlert :
          "Dies kann nicht rückgängig gemacht werden und Ihre Änderungen gehen verloren",
          discardChanges : "Änderungen verwerfen?",
          youShouldBeAtLeast14YearsOld: 'Du solltest mindestens 14 Jahre alt sein',
          contentOfDialog :"Inhalt des Dialogs",
          pinnedWerf : "Gepinnter Werf",
          hiddenPost : "Versteckte Werften",
          thisCanBeOnlyChangedAFewTimes :" Dies kann nur wenige Male geändert werden. Stellen Sie sicher, dass Sie das Alter der Person angeben, die das Konto nutzt",


          aboutHashTag : 'Über Hashtag',
          werfHashTag : 'Werf-Hashtag',
          messageRequests : 'Nachrichtenanfragen',
          enterGroupChatTitle:  "Geben Sie den Titel des Gruppenchats ein",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Wählen Sie einen aus Ihren vorhandenen Chats aus oder starten Sie einen neuen',
          snoozeNotificationsFrom :  "Schlummerbenachrichtigungen von",
          snoozeNotificationsFromTheGroup : "Schlummerbenachrichtigungen der Gruppe",
          snoozeMentions : "Snooze-Erwähnungen",
          disableNotificationsWhenPeoplemention:"Deaktivieren Sie Benachrichtigungen, wenn Sie in dieser Konversation erwähnt werden.",
          trySearchingForPeopleGroupsOrMessages : "Versuchen Sie, nach Personen, Gruppen oder Nachrichten zu suchen",
          werfieUser :  "Werfie-Benutzer",
          otherChat :"andere...",
          photoChat : 'Foto',
          videoChat : 'Video',
          fileChat : 'Datei',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'Direktnachrichten sind private Gespräche zwischen Ihnen und anderen Personen auf Twitter. Teilen Sie Tweets, Medien und mehr!',
          searchChats : "Chats durchsuchen",
          allTabChat : "Alle",
          peopleTabChat : "Menschen",
          groupsTabChat :"Gruppe",
          chatsTabChat :"Chats",
          noResultsFor : "Keine Ergebnisse für",
          theTermYouEnteredDidNotBring : "Für den von Ihnen eingegebenen Begriff wurden keine Ergebnisse angezeigt",
          message : "Nachricht",
          addMembersToChat : 'Fügen Sie Mitglieder zum Chat hinzu',
          noMessagesYet : "Noch keine Nachrichten",
          doNotAllowMessages : "keine Nachrichten zulassen",
          notAllowedToMessage : "Es ist nicht gestattet, Nachrichten zu senden.",
          youHaveBlockedThisUser : "Sie haben diesen Benutzer blockiert",
          startAMessage :  "Starten Sie eine Nachricht",
          react :  "Reagieren",
          undo : "Rückgängig machen",
          reactions : 'Reaktionen',
          messageRequestsFallHere :
          "Nachrichtenanfragen von Personen, denen Sie nicht folgen, finden Sie hier live. Um auf diese Nachricht zu antworten, müssen Sie die Anfrage akzeptieren.",
          noMessageRequestAvailable : 'Keine Nachrichtenanfrage verfügbar',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'Abhängig von der von Ihnen gewählten Einstellung können verschiedene Personen Ihnen eine Direktnachricht senden.',

          allowMessagesOnlyFromPeopleYouFollow :
          'Erlauben Sie nur Nachrichten von Personen, denen Sie folgen',
          youWontReceiveAnyMessageRequests :
          "Sie erhalten keine Nachrichtenanfragen",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Erlauben Sie Nachrichtenanfragen nur von verifizierten Benutzern",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Personen, denen Sie folgen, können Ihnen weiterhin Nachrichten senden",
          allowMessagesRequestsFromEveryone :
          'Erlauben Sie Nachrichtenanfragen von allen',
          otherControls : "Andere Steuerelemente",
          filterLowQualityMessages : "Filtern Sie Nachrichten mit geringer Qualität",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Blenden Sie Nachrichtenanfragen aus, bei denen festgestellt wurde, dass sie potenziell umfangreich oder von geringer Qualität sind. Diese werden an einen separaten Posteingang am Ende Ihrer Nachrichtenanfragen gesendet. Sie können weiterhin darauf zugreifen, wenn Sie möchten",
          showReadReceipts : "Lesebestätigungen anzeigen",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Teilen Sie den Personen, mit denen Sie Nachrichten senden, mit, wenn Sie deren Nachrichten gesehen haben. Lesebestätigungen werden bei Nachrichtenanfragen nicht angezeigt",


          getPushNotificationsToFindOut :"Erhalten Sie Push-Benachrichtigungen, um herauszufinden, was los ist, wenn Sie nicht bei Werfie sind. Sie können sie jederzeit deaktivieren.",
          relatedToYouAndYourWerfs :"Bezogen auf Sie und Ihre Werfs",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "Wenn Sie Werf-Benachrichtigungen von Personen, denen Sie folgen, aktivieren, erhalten Sie Push-Benachrichtigungen über deren Werfs.",
          topWerfs :"Top-Werfe",
          tailoredForYou: "Maßgeschneidert für Sie",
          rewerf : 'Rewerf',
          like : 'Wie',
          photoTags : "Foto-Tags",
          messageReactions : "Nachrichtenreaktionen",
          fromWerfie : "Von Werfie",
          newsSports : "Nachrichten / Sport",
          recommendations : "Empfehlungen",
          turnOnPush:"Aktivieren Sie Push-Benachrichtigungen",
          toReceiveNotificationsAsTheyHappen :"Um Benachrichtigungen zu erhalten, sobald diese eintreten, aktivieren Sie die Push-Benachrichtigung. Sie erhalten sie auch, wenn Sie nicht auf Werfie sind. Schalten Sie sie jederzeit aus.",
          turnOn : "Anmachen",
          newNotifications :  "Neue Benachrichtigungen",
          werfsEmailedToYou : "Werfs hat Ihnen eine E-Mail geschickt",
          weekly : 'Wöchentlich',
          newAboutWerfieProduct :"Neues zu Werfie-Produkt- und Funktionsaktualisierungen",
          tipsOnGettingMoreOut: "Tipps, wie Sie Werfie optimal nutzen können",
          thingsYouMissedSinceYou: "Dinge, die Sie seit Ihrer letzten Anmeldung bei Werfie verpasst haben",
          participationInWerfieResearchSurveys: "Teilnahme an Werfie-Forschungsumfragen",
          suggestionsRorRecommendedAccounts: "Vorschläge für empfohlene Konten",
          suggestionsBasedOnYourRecentFollows: "Vorschläge basierend auf Ihren letzten Followern",
          qualityFilters : "Qualitätsfilter",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Wählen Sie die Option, Inhalte wie doppelte und automatisierte Werfs herauszufiltern. Dies gilt nicht für Benachrichtigungen von Konten, denen Sie folgen und mit denen Sie kürzlich interagiert haben.",

          emailNotification : 'E-Mail Benachrichtigungen',
          filters : "Filter",
          chooseTheNotification : "Wählen Sie die Benachrichtigung aus, die Sie sehen möchten, und die Benachrichtigungen, die Sie nicht sehen möchten",
          preferences : "Präferenzen",
          selectYourPreferencesByNotificationType :"Wählen Sie Ihre Präferenzen nach Benachrichtigungstyp aus.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie verwendet immer einige Informationen, wie z. B. den Ort, an dem Sie sich angemeldet haben, und Ihren aktuellen Standort, um Ihnen relevantere Inhalte anzuzeigen. Wenn diese Einstellung aktiviert ist, kann Werfie Ihr Erlebnis auch basierend auf anderen Orten, an denen Sie waren, personalisieren.',

          personalizeBasedOnPlacesYouHaveBeen :
          'Personalisieren Sie es basierend auf den Orten, an denen Sie waren',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Verwalten Sie die Standortinformationen, die Werfie verwendet, um Ihr Erlebnis zu personalisieren.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Teilen Sie den Personen, mit denen Sie Nachrichten senden, mit, wenn Sie deren Nachrichten gesehen haben. Lesebestätigungen werden bei Nachrichtenanfragen nicht angezeigt",

          showReadReceipts : "Lesebestätigungen anzeigen",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Blenden Sie Nachrichtenanfragen aus, bei denen festgestellt wurde, dass sie potenziell umfangreich oder von geringer Qualität sind. Diese werden an einen separaten Posteingang am Ende Ihrer Nachrichtenanfragen gesendet. Sie können weiterhin darauf zugreifen, wenn Sie möchten",


          filterLowQualityMessages :"Filtern Sie Nachrichten mit geringer Qualität",
          otherControls : "Andere Steuerelemente",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Personen, denen Sie folgen, können Ihnen weiterhin Nachrichten senden",
          allowMessagesRequestsFromEveryone :
          'Erlauben Sie Nachrichtenanfragen von allen',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "Personen, denen Sie folgen, können Ihnen weiterhin Nachrichten senden",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Erlauben Sie Nachrichtenanfragen nur von verifizierten Benutzern",
          youWontReceiveAnyMessageRequests :
          "Sie erhalten keine Nachrichtenanfragen",
          allowMessagesOnlyFromPeopleYouFollow :
          'Erlauben Sie nur Nachrichten von Personen, denen Sie folgen',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'Abhängig von der von Ihnen gewählten Einstellung können verschiedene Personen Ihnen eine Direktnachricht senden.',

          controlWhoCanMessageYou : 'Kontrollieren Sie, wer Ihnen Nachrichten senden kann',
          forever : " Für immer",
          muteNotificationsFromPeople :"Benachrichtigungen von Personen stummschalten:",
          youDoNotFollow : "You don't follow",
          whoDoNotFollowYou : "Wer folgt dir nicht?",
          withANewAccount : "Mit einem neuen Konto",
          whoHaveDefaultProfilePhoto :"Wer hat ein Standardprofilfoto?",
          whoHaveNotConfirmedTheirEmail : "Die ihre E-Mail-Adresse nicht bestätigt haben",
          whoHaveNotConfirmedTheirPhoneNumber :"Die ihre Telefonnummer nicht bestätigt haben",
          duration : 'Dauer',
          untilYouUnmuteTheWord : 'Bis Sie die Stummschaltung des Wortes aufheben',
          hours24 : '24 Stunden',
          days7 : '7 Tage',
          days30 : '30 Tage',
          fromPeopleYouDontFollow : "Von Leuten, denen du nicht folgst",
          homeTimeline : 'Home-Zeitleiste',
          muteFrom : 'Stumm von',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'Sie können jeweils ein Wort, einen @Benutzernamen oder einen Hashtag stummschalten.',
          enterWordOrPhrase : 'Geben Sie ein Wort oder eine Phrase ein',
          mutedWord : 'Gedämpftes Wort',
          addMutedWords : 'Fügen Sie gedämpfte Wörter hinzu',
          youHaveNotMutedAnyWordYet : 'Sie haben noch kein Wort stummgeschaltet',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "Wenn Sie Wörter stummschalten, erhalten Sie keine neue Benachrichtigung für Werfs, die diese Wörter enthalten, und Sie sehen keine Werfs mit diesen Wörtern in Ihrer Home-Timeline.",

          youHaveNotMutedAnyPersonYet :
          'Sie haben noch keine Person stummgeschaltet',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Hier sind alle Personen aufgeführt, die Sie stummgeschaltet haben. Sie können sie zu dieser Liste hinzufügen und daraus entfernen.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "Wenn Sie jemanden blockieren, kann diese Person Ihnen nicht folgen oder Ihnen keine Nachrichten senden, und Sie sehen keine Benachrichtigung von ihr.",

          mutedNotification : 'Stummgeschaltete Benachrichtigungen',
          mutedWords: 'Gedämpfte Worte',
          mutedAccounts : 'Stummgeschaltete Konten',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Verwalten Sie die Konten, Wörter und Benachrichtigungen, die Sie stummgeschaltet oder blockiert haben.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'Dies verhindert, dass Werfs mit potenziell sensiblen Inhalten in Ihren Suchergebnissen angezeigt werden.',

          hideSensitiveContent: 'Verstecken Sie sensible Inhalte',
          removeBlockedAndMutedAccounts :
          'Entfernen Sie gesperrte und stummgeschaltete Konten',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'Verwenden Sie diese Option, um Suchergebnisse aus dem Konto zu entfernen, das Sie gesperrt oder stummgeschaltet haben',
          personalization : 'Personalisierung',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'Sie können Trends basierend auf Ihrem Standort und der Person, der Sie folgen, personalisieren',
          exploreLocation : 'Standort erkunden',
          showContentInThisLocation : 'Inhalte an diesem Ort anzeigen',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'Wenn dies aktiviert ist, können Sie sehen, was gerade um Sie herum passiert.',
          searchSettings  :'Sucheinstellungen',
          exploreSettings : 'Entdecken Sie die Einstellungen',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Entscheiden Sie, was Sie auf werfie sehen, basierend auf Ihren Präferenzen, z. B. Themen',
          displayMediaThatMayContainSensitiveContent :
          'Zeigen Sie Medien an, die möglicherweise vertrauliche Inhalte enthalten',

          addLocationInformationToYourWerfs :'Fügen Sie Standortinformationen zu Ihren Werften hinzu',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "Wenn diese Option aktiviert ist, werden Ihre Bilder und Videos für Personen, die keine sensiblen Inhalte sehen möchten, als sensibel markiert.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'Markieren Sie die Medien Ihres Werfs als Materialien, die möglicherweise vertraulich sind',
          manageTheInformationAssociatedWithYourWerfs :
          'Verwalten Sie die mit Ihren Werften verknüpften Informationen.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'Wenn diese Option aktiviert ist, können Sie den Standort Ihren Werften zuordnen.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Entfernen Sie alle mit Ihren Werften verknüpften Standortinformationen',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'Standortbezeichnungen, die Sie Ihren Werfs hinzugefügt haben, sind auf Werfie.com, Werfie für IOS und Werfie für Android nicht mehr sichtbar. Es kann einige Zeit dauern, bis diese Updates wirksam werden.',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Verwalten Sie, welche Informationen Sie anderen Personen auf Werfie erlauben.',
          protectYourTweets : 'Schützen Sie Ihre Werften',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'Wenn diese Option ausgewählt ist, sind Ihre Werbe- und Kontoinformationen nur für Personen sichtbar, die Ihnen folgen',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'Dadurch werden sie nur für Ihre Werfi-Follower sichtbar',
          protect : 'Schützen',
          photoTagging : 'Foto-Tagging',
          AnyoneCanTagYou : 'Jeder kann dich markieren',
          onlyPeopleYouFollowCanTagYou:
          'Nur Personen, denen Sie folgen, können Sie markieren',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Erlauben Sie anderen, Sie auf ihren Fotos zu markieren und erhalten Sie in diesem Fall Benachrichtigungen',
          AnyoneCanTagYou : 'Jeder kann dich markieren',
          onlyPeopleYouFollowCanTagYou : 'Nur Personen, denen Sie folgen, können Sie markieren',
          security : 'Sicherheit',
          manageYourAccountsSecurity : "Verwalten Sie die Sicherheit Ihres Kontos",
          twoFactorAuthentication : "Zwei-Faktor-Authentifizierung",
          manageYourAccountsSecurityKeepTrack : "Verwalten Sie die Sicherheit Ihres Kontos und behalten Sie den Überblick über Ihre Kontonutzung",
          helpProtectYourAccountFromUnauthorizedAccess :  "Schützen Sie Ihr Konto vor unbefugtem Zugriff, indem Sie zusätzlich zu Ihrem X-Passwort eine zweite Authentifizierungsmethode erfordern. Sie können eine Textnachricht, eine Authentifizierungs-App oder einen Sicherheitsschlüssel auswählen.",
          verificationCodeSentToYourRegisteredEmail:"Geben Sie den 6-stelligen Bestätigungscode ein, der an Ihre registrierte E-Mail-Adresse gesendet wird",
          submit :'Einreichen',
          genderChangedSuccessfully : "Geschlecht erfolgreich geändert",
          genderSettingTextDescription :"Wenn Sie noch kein Geschlecht angegeben haben, ist dies das Geschlecht, das Ihrem Konto basierend auf Ihrem Profil und Ihrer Aktivität zugeordnet ist. Diese Informationen werden nicht öffentlich angezeigt.",
          male:  'Männlich',
          female : 'Weiblich',
          other : 'Andere',
          change:'Ändern',
          changeCountrySettings:'Land ändern',
          selectACountry:'Wähle ein Land',
          updateEmailAddress:'Aktualisiere Email Adresse',
          current:'Aktuell',
          changeEmailSetting:'Ändern Sie die E-Mail',
          gender:'Geschlecht',
          accountCreation:'Konto-Erstellung',
          Age:'Alter',
          securityAndAccountAccess:'Sicherheit und Kontozugriff',
          youHaveNotCreatedOrFollowedAnyLists: "Sie haben keine Listen erstellt oder ihnen gefolgt. Wenn Sie dies tun, werden sie hier angezeigt.",
          userCanPinnedOnly5  : 'Der Benutzer kann nur 5 anpinnen ',
          pleaseEnterTheName  : 'Bitte geben Sie den Namen ein ',
          list : 'Listen',
          listYouAre :"Listen, auf denen Sie stehen",
          listYouHave:"Sie wurden noch keiner Liste hinzugefügt",
          listAddedSomeOne:"Wenn Sie jemand zu einer Liste hinzufügt, wird dies hier angezeigt",
          listMembers :'Mitglieder auflisten',
          listFollowers  : 'Listen Sie Follower auf',
          noMembers: 'Keine Mitglieder',
          noResults :'Keine Ergebnisse',
          noFollowers:'Keine Follower',
          manageWhatInformationYouSeeAndShareOnWerfie: 'Verwalten Sie, welche Informationen Sie auf Werfie sehen und teilen.',
          noResponseFromServerMsg: 'Wij ondervinden enkele moeilijkheden. Probeer het later opnieuw',
          filteredResult:'Gefiltertes Ergebnis',
          forYou:'Für dich',
          noInternetAvailable:'Kein Internet verfügbar!',
          welcomeToWerfie:'Willkommen bei werfi',
          cantChooseEmailAsApass:
          "Sie können E-Mail nicht als Passwort auswählen. Bitte \nwählen Sie ein sicheres Passwort",
          passMustContainUpperCaseAndLeeter:
          'Das Passwort muss mindestens einen Großbuchstaben und eine Zahl enthalten',
          bothPasswordAndConfirmPassShouldMatch:
          'Sowohl das Passwort als auch das Bestätigungspasswort sollten übereinstimmen',
          DidNoTReceiveCode: "Sie haben den Code nicht erhalten?",
          verificationCode: 'Bestätigungscode',
          enterYourNewPasswordHint: 'Gib dein neues Passwort ein',
          ChangePasswordSettings: 'Kennwort ändern',
          trendingUpdates: 'Trendaktualisierungen',
          dobAddMsg: 'Fügen Sie Ihr Geburtsdatum zu Ihrem hinzu ',
          audienceAndTagging: 'Zielgruppe und Tagging',
          LearnMoreAboutPrivacyOnWerfie:
              'Erfahren Sie mehr über den Datenschutz auf Werfie',
          yourWerfieActivity: 'Deine Werfie-Aktivität',
          yourAndTagging: 'Ihr und Tagging',
          yourWerfs: 'Eure Werften',
          contentYouSee: "Inhalte, die Sie sehen",
          muteAndBlock: 'Stummschalten und blockieren',
          directMessages: 'Direktnachricht',
          dataSharingAndPersonalization: 'Datenaustausch und Personalisierung',
          locationInformation: 'Standortinformationen',

          nameCannotBeEmpty: "Name ist erforderlich",
          nameLengthShouldMax20:
              "Die Namenslänge sollte nicht größer als 20 sein",
          nameStartsWithCharacter: "Der Name sollte mit Alphabeten beginnen.",
          pleaseProvideAValidEmail:
              "Bitte geben Sie eine gültige E-Mail-Adresse an",
          werfieHandleIsRequired: "Werfie-Griff ist erforderlich",
          passwordShouldBeMin8Char:
              'Das Passwort sollte mindestens 8 Zeichen lang sein',
          pleaseEnterYourBirthDate: 'Bitte geben Sie Ihr Geburtsdatum ein',
          enterYourBirthDateOptional:
              'Geben Sie Ihr Geburtsdatum ein (optional)',
          rewerf: 'Rewerf',
          topicsThatYouFollowShownHere:
              'Themen, denen Sie folgen, werden hier angezeigt. Um alle Dinge zu sehen, an denen Werfie Ihrer Meinung nach interessiert ist, schauen Sie sich Ihre Werfie-Daten an. Sie können auch mehr über die folgenden Themen erfahren',
          bySigningUpYouAgree: 'Mit Ihrer Anmeldung stimmen Sie unseren,',
          and: 'Und',
          privacyUpdated: 'Datenschutz aktualisiert',
          removeWerfFromBookMark: 'Entfernen Sie werf aus dem Lesezeichen',
          areYouSure: 'Bist du sicher?',
          doYouWantToExit: 'Möchten Sie die App beenden?',
          no: 'NEIN',
          yes: 'Ja',
          werfUnsaved: "Werf erfolgreich aufgehoben!",
          private: 'Privatisieren',
          name: 'Name',
          bio: "Bio",
          birthDate: 'Geburtsdatum',
          create: 'Erstellen',
          weWontSuggestThisTopic:
              "Wir werden dieses Thema nicht mehr vorschlagen",
          youllSeeTopWerfs:
              "Die Top-Werfe dazu siehst du direkt in deiner Home-Timeline",
          requestVerification: 'Verifizierung anfordern',
          enterCurrentPassword: 'Aktuelles Passwort eingeben',
          enterYourNewPassword:
              "Geben Sie Ihr neues Passwort ein und klicken Sie auf die Schaltfläche „Weiter“. Wir senden Ihnen einen 6-stelligen Code an Ihre E-Mail-Adresse. Sie müssen diesen 6-stelligen Code auf dem nächsten Bildschirm eingeben, um den Vorgang abzuschließen.",
          noWerfs: 'Keine Werften',
          verified: 'Verifiziert',
          getMoments: 'Holen Sie sich Momente',
          tweetsAndReplies: 'Werfe & Antworten',
          yourlist: 'Ihre Listen',
          copyProfileLink: 'Profillink kopieren',
          signInWithApple: 'Melden Sie sich bei Apple an',
          searchForAnItem: 'Nach einem Artikel suchen...',
          changedTheCountryName: 'Der Ländername wurde erfolgreich geändert!',
          editOrder: 'Reihenfolge bearbeiten',
          ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
              'Dies kann nicht rückgängig gemacht werden und wird aus Ihrem Profil, der Chronik aller Konten, die Ihnen folgen, und aus den Werfie-Suchergebnissen entfernt.',
          writeAShortDesc: 'Schreiben Sie eine kurze Beschreibung über Momente',
          addATitle: 'Füge einen Titel hinzu',
          publish: 'Veröffentlichen',
          likedBy: 'Gefällt mir ',
          werfSearch: 'Werftsuche',
          werfsByAccount: "Werften nach Konto",
          werfsILiked: "Wörter, die mir gefallen haben",
          addWerfs: 'Werfe hinzufügen',
          allReply: 'Alle antworten',
          replyingTo: 'Antwort auf',
          werfYourReply: 'Werf deine Antwort...',
          noMomentsList: 'Keine Momente',
          justNow: 'Soeben',
          clear: 'Klar',
          createANewWerf: 'Erstellen Sie eine neue Werft',
          suggestedTopics: 'Vorgeschlagene Themen',
          whenYouFollowMsg:
              "Wenn Sie einer Liste folgen, können Sie schnell mit den Experten über das, was Ihnen am wichtigsten ist, auf dem Laufenden bleiben.",
          chooseYourLists: 'Wählen Sie Ihre Listen',
          discoverlist: 'Entdecken Sie neue Listen',
          pinnedList: "Angepinnte Liste",
          createNew: 'Erstelle neu',
          chooseAnExistingMomentOrCreateNew:
              'Wählen Sie einen vorhandenen Moment oder erstellen Sie einen neuen',
          seizeTheMoment: 'Den Augenblick nutzen',
          momentDeleteSuccessfully: 'Moment erfolgreich gelöscht',
          createMoment: 'Moment schaffen',
          removeMomentAlertMsg:
              'Dies kann nicht rückgängig gemacht werden und Sie verlieren Ihren Moment.',
          momentsDelete: 'Momente löschen?',
          nothingToSeeHere: 'Es gibt hier nichts zu sehen',
          nothingToSeeHerePinYour:
              'Hier gibt es noch nichts zu sehen – pinnen Sie Ihre Lieblingslisten an, um schnell darauf zuzugreifen.',
          viewHiddenReply: "Versteckte Antwort anzeigen",
          block: 'Block',
          chooseOneFromYourExistingChatsOrStartANewOne:
              'Wählen Sie einen aus Ihren vorhandenen Chats aus oder starten Sie einen neuen',
          youDoNotHaveAChatSelected: 'Sie haben keinen Chat ausgewählt',
          editGroup: 'Gruppe bearbeiten',
          colors: 'Farben',
          dark: "dunkel",
          light: "hell",
          theseSettingsAffect:
              "Diese Einstellungen wirken sich auf alle Werfie-Konten in diesem Browser aus.",
          customizeView: 'Passen Sie Ihre Ansicht an',
          dismiss: 'Zurückweisen',
          thisWerfSeen: 'Mal wurde dieser Werf gesehen.',
          youHaveAlreadyReportedWerf:
              'Sie haben diesen Werfer bereits gemeldet',
          enterDescriptionFieldIsRequired:
              "Das Feld „Beschreibung eingeben“ ist erforderlich",
          searchLocation: 'Standort suchen',
          tagLocation: 'Tag-Standort',
          profileVisits: 'Profilbesuche',
          newFollowers: 'Neue Follower',
          detailExpands: 'Detail wird erweitert',
          engagements: 'Engagements',
          impressions: 'Eindruck',
          werfAnalytics: 'Werftanalytik',
          followed: 'gefolgt',
          notInterested: 'Nicht interessiert',
          suggested: 'Empfohlen',
          add: 'Hinzufügen',
          remove: 'Entfernen',
          members: 'Mitglieder',
          whenYouMakeAList:
              "Wenn Sie eine Liste privat machen, können nur Sie sie sehen.",
          makePrivate: 'Privatisieren',
          createNewList: 'Neue Liste erstellen',
          next: 'Nächste',
          done: 'Erledigt',
          editList: 'Liste bearbeiten',
          manageMembers: 'Mitglieder verwalten',
          delete: 'Löschen',
          listYouAreON: "Listen, auf denen Sie stehen",
          newsSocial: 'Nachricht',
          filmTV: 'Unterhaltung',
          music: 'Musik',
          travelAdventure: 'Reisen',
          newChat: 'Neuer Chat',
          noMsgsYet: 'Noch keine Nachrichten',
          addToYourList: 'Zu Ihrer Liste hinzufügen',
          theTopicsYouFollow:
              "The Topics you follow are used to personalize the Werfs, events, and ads that you see, and show up publicly on your profile",
          verification: 'Überprüfung',
          verificationAccount: 'Bestätigung des Kontos',
          country: 'Land',
          userNameSavedSuccessfully: 'Benutzername erfolgreich gespeichert!',
          deactivateAccount: 'Benutzerkonto deaktivieren',
          off: 'Aus',
          weekly: 'Wöchentlich',
          daily: 'Täglich',
          topWerfs: 'Top Werfs',
          getEmailToFindOut:
              'Erhalten Sie E-Mails, um herauszufinden, was los ist, wenn Sie nicht bei Werfie sind. Sie können sie jederzeit deaktivieren.',
          pushNotifications: 'Push-Benachrichtigung',
          otpSentMsg:
              "Wir haben gerade einen 6-stelligen Code an Ihre E-Mail-Adresse gesendet. Geben Sie diesen Code an der unten angegebenen Stelle ein und klicken Sie auf die Schaltfläche „Bestätigen“.",
          sendViaDirectMessage: 'Senden Sie per Direktnachricht',
          shareWerf: 'Werft teilen',
          copylinkToWerf: 'Link nach werf kopieren',
          pickWhoCanReplyMsg:
              "Wählen Sie aus, wer auf diesen Werf antworten kann. Denken Sie daran, dass jeder, der erwähnt wird, jederzeit antworten kann.,",
          whoCanReply: 'Wer kann antworten?',
          everyoneCanReply: 'Jeder kann antworten',
          onlyPeopleYouMention: 'Nur die Personen, die Sie erwähnen',
          allwerf: 'Alles Werf',
          werf: 'Werft',
          changeEmail: 'Ändern Sie die E-Mail',
          werfs: 'Werfe',
          viewTranslated: 'Übersetzt anzeigen',
          ChangeYourPassword: 'Ändern Sie Ihr Passwort',
          accountInformation: 'Kontoinformationen',
          viewTopics: 'Themen anzeigen',
          confirmPassMsg: 'Bestätigen Sie Ihr Passwort',
          wrongPasswordMsg: 'Falsches Passwort',
          languageSettings: 'Spracheinstellungen',
          unBlock: 'Entsperren',
          loginWithGoogle: 'Melden Sie sich mit Google an',
          createYourPassword: 'Erstelle dein Passwort',
          createYourWerfieHandle: 'Erstellen Sie Ihren Werfi-Griff',
          forwardMessage: 'Nachricht weiterleiten',
          copy: 'Nachricht kopieren',
          messageDelete: 'Für Sie löschen',
          deleteConversation: 'Konversation löschen',
          peopleInThisChat: 'Leute in diesem Chat',
          views: 'Ansichten',
          werfSeenCountMsg: 'Mal wurde dieser Werf gesehen',
          newWerf: 'Neue Werft',
          newWerfs: 'Neue Werften',
          pinPostMsg: 'Beitrag an Ihr Profil anpinnen',
          unPinPostMsg: 'Beitrag von Ihrem Profil entfernen!',
          removeWerfAlert:
              "Dies kann nicht rückgängig gemacht werden und Ihre Änderungen gehen verloren",
          quoteRewerf: 'Zitat Rewerf',
          quoteRewerf: 'Rewerf',
          rewerfSuccessfully: 'ReWerf erfolgreich',
          noReplyComments: 'Keine Antwortkommentare',
          postDetail: 'Werftdetail',
          profileLinkCopy: 'Profillink erfolgreich kopiert!',
          muteUser: 'erfolgreich stummgeschaltet',
          userReportedSuccessfully: 'Benutzer hat erfolgreich gemeldet!',
          userBlockedSuccessfully: 'Benutzer erfolgreich blockiert!',
          werfReportedSuccssfully: 'Werf hat erfolgreich berichtet',
          YourAccount: 'Ihr Konto',
          notificationsSettings: 'Benachrichtigungseinstellungen',
          displaySettings: 'Bildschirmeinstellungen',
          moments: 'Momente',
          topic: 'Themen',
          followings: 'Folgen',
          popularUpdates: 'Beliebte Updates',
          privacyAndSafety: 'Privatsphäre und Sicherheit',
          createWerf: 'Werf erstellen',
          chats: 'chattet',
          bookmarks: 'Lesezeichen',
          bookmark: 'Lesezeichen',
          enterYourEmail: 'Geben sie ihre E-Mail Adresse ein',
          enterYourPassword: 'Geben Sie Ihr Passwort ein',
          // languageSettings: 'Sprache Einstellungen',
          blockedAccountsSettings: 'Einstellungen für gesperrte Konten',
          selectYourPreferredLanguage: 'Wählen Sie Ihre bevorzugte Sprache',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Heim',
          browse: 'Durchsuche',
          hotTrends: 'Heiße Trends',
          saved: 'Gerettet',
          messages: 'Mitteilungen',
          myProfile: 'Mein Profil',
          settings: 'Einstellungen',
          notifications: 'Benachrichtigungen',
          settingsType: 'Einstellungen Typ',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'Verwalten Sie, wie Ihnen BuzzNBee-Inhalte angezeigt werden',
          selectYourProfileLanguage: 'Wählen Sie Ihre Profilsprache',
          selectYourAppLanguage: 'Wählen Sie Ihre App-Sprache',
          enableDisableAutoTranslation:
              'Automatische Übersetzung aktivieren/deaktivieren',
          language: 'Sprache',

          ///   germen
          username: "Nutzername",
          snoozeNotification: 'Schlummerbenachrichtigung',
          version: 'Ausführung',
          appVersion: "App Version",
          lists: 'Listen',
          deactivationAndDeletion: "Deaktivierung und Löschung",
          confirmYourPasswords: "Bestätigen Sie Ihre Passwörter",
          deactivateAccount: 'Benutzerkonto deaktivieren',
          or: 'GOLD',
          deleteAccount: "Konto löschen",
          updateYourLanguageAndTranslation:
              "Aktualisieren Sie Ihre Sprach- und Übersetzungseinstellungen",
          manageYourPrivacySettings:
              "Verwalten Sie Ihre Datenschutzeinstellungen",
          privacySettings: "Datenschutzeinstellungen",
          setYourPrivacySettings:
              'Legen Sie Ihre Datenschutzeinstellungen fest',
          messageSettings: 'Nachrichteneinstellungen',
          noOne: "Niemand",
          everyOne: 'Alle',
          ChangeUsernameSettings: "Benutzernameneinstellungen ändern",
          enterYourWerfieHandle: "Geben Sie Ihr Server-Handle ein",
          youHaveNotBlockedAnyPersonYet:
              "Sie haben noch keine Person blockiert",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "Wenn Sie Ihr Werfie-Konto dauerhaft löschen möchten, können Sie nach dem Klicken auf die Schaltfläche „OK“ Ihr Konto nicht mehr reaktivieren oder die von Ihnen hinzugefügten Inhalte oder Informationen abrufen.",
          permanentlyDeleteAccount: "Konto dauerhaft löschen",
          whoCanMessageYou: 'Wer kann Ihnen eine Nachricht senden?',
          viewEditHistory: "Bearbeitungsverlauf anzeigen",
          reportWerf: 'Melde Werf',
          hideWerf: "Werfen verstecken",
          showMore:"Mehr anzeigen",
          reportUser: 'Benutzer melden',
          mute: 'Stumm',
          unMute: "Stummschaltung aufheben",
          deleteWerf: 'Werf löschen',
          viewWerfAnalytics: 'Sehen Sie sich Werf Analytics an',
          pintoYourProfile: 'An dein Profil anheften',
          editWerf: "Werf bearbeiten",
          explore: 'Erkunden',

          blockedAccounts: 'Gesperrte Konten',
          translations: 'Übersetzungen',
          viewListOfBlockedAccounts: 'Liste der gesperrten Konten anzeigen',
          realTimePostTranslation: 'Post-Übersetzung in Echtzeit',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'Sprache beim Hochladen eines Videos oder Audios auswählen',
          originalTranslatedScriptAudioPost:
              'Originales oder übersetztes Skript des Audiobeitrags',
          listenTranslatedScript: 'Übersetztes Skript anhören',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Nachrichten im Chat automatisch in die vom Benutzer ausgewählte Sprache übersetzen',
          postedUpdate: 'ein Update gepostet.',
          peopleWhoReacted: 'Leute, die reagiert haben',
          comments: 'Kommentare',
          peopleWhoRetweeted: 'Leute, die retweetet haben',
          leaveAComment: 'Hinterlasse einen Kommentar',
          post: 'Werf',
          cancel: 'Abbrechen',
          savePost: 'Beitrag speichern',
          report: 'Prüfbericht',
          hide: 'Verstecken',
          shareLinkVia: 'Link teilen über...',
          copyLink: 'Link kopieren',
          fieldRequired: 'Pflichtfeld',
          enterDescription: 'Beschreibung eingeben',
          selectCategory: 'Kategorie wählen',
          okay: 'Okay,',
          pleaseWait: 'Warten Sie mal...',
          search: 'Suche',
          logout: 'Ausloggen',
          writeSomethingHere: 'Schreiben Sie hier etwas',
          addMore: 'Mehr hinzufügen',
          image: 'Bild',
          video: 'Video',
          videos: 'Videos',
          file: 'Datei',
          gif: 'GIF',
          audio: 'Audio',
          live: 'Live',
          doNotHaveAnAccount: "Sie haben kein Konto? ",
          register: 'Registrieren',
          haveAnAccount: "Ein Konto haben? ",
          login: 'Anmeldung',
          whoToFollow: 'Wem folgen',
          noSuggestion: 'Kein Vorschlag',
          follow: 'Folgen',
          unFollow: 'Entfolgen',
          seeMore: 'Mehr sehen',
          searchFilter: 'Suchfilter',
          people: 'People',
          fromAnyone: 'Von irgendjemandem',
          peopleYouFollow: 'Menschen, denen du folgst',
          location: 'Standort',
          anywhere: 'Irgendwo',
          nearYou: 'Nahe bei dir',
          advancedSearch: 'Erweiterte Suche',
          trendsForYou: 'Trends für Sie',
          noTrending: 'Es gibt keine Trends in Ihrer Region',
          trendingIn: 'Im Trend',
          // tweets: 'Tweets',
          noNotification: 'Es gibt keine Benachrichtigungen für Sie',
          refresh: 'Aktualisierung',
          edit: 'Bearbeiten',
          save: 'Speichern',
          cFollow: 'Folgen',
          addPeople: 'Leute hinzufügen',
          someText: 'etwas Text',
          reportConversation: 'Konversation melden',
          leaveConversation: 'Konversation verlassen',
          enterYourMessage: 'Gib deine Nachricht ein',
          showMoreComments: 'Mehr Kommentare anzeigen',
          reBuzz: 'Rebuzz',
          noPosts: 'Keine Updates für dich',
          emailFieldCannotBeEmpty: 'E-Mail-Feld darf nicht leer sein',
          emailFormatIsInvalid: 'E-Mail-Format ist ungültig',
          rememberMe: 'Erinnere dich an mich',
          lostPassword: 'Passwort verloren?',
          cLOGIN: 'ANMELDUNG',
          emailOrPasswordIsIncorrect: 'Email oder Passwort ist falsch',
          newsFeed: 'Neuigkeiten',
          trends: 'Trends',
          profile: 'Profil',
          newMessage: 'Neue Nachricht',
          next: 'Nächste',
          searchPeople: 'Personen suchen',
          saySomething: 'Sag etwas',
          noSearchResult: 'Kein Suchergebnis',
          searchResult: 'Suchergebnis',
          hidePost: 'Beitrag ausblenden',
          showLess: 'Zeige weniger',
          showMore: 'Zeig mehr',
          nothingYet: 'Noch nichts!',
          savedPosts: 'Gespeicherte Beiträge',
          enterYourFirstName: 'Geben Sie Ihren Vornamen ein',
          enterYourLastName: 'Geben Sie Ihren Nachnamen ein',
          enterYourUsername: 'Geben Sie Ihren Benutzernamen ein',
          signUp: 'Anmelden',
          pleaseChooseACountry: 'Bitte wählen Sie ein Land',
          replied: 'antwortete',
          reply: 'Antwort',
          delete: 'Löschen',
          replyToComment: 'Auf Kommentar antworten',
          noFollower: 'Kein Follower',
          following: 'Folge',
          followBack: 'Auch Folgen',
          followers: 'Anhänger',
          follower: 'Anhängerin',
          noFollowings: 'Keine Folgen',
          sendAMessageGetAMessage:
              'Senden Sie eine Nachricht, erhalten Sie eine Nachricht',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'Direktnachrichten sind private Unterhaltungen zwischen Ihnen und anderen Personen auf Twitter. Teilen Sie Tweets, Medien und mehr!',
          startAConversation: 'Eine Konversation beginnen',
          groupInfo: 'Gruppe-Informationen',
          chatInfo: 'Chat-Informationen',
          youDoNotHaveAMessageSelected: 'Sie haben keine Nachricht ausgewählt',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Wählen Sie eine aus Ihren vorhandenen Nachrichten aus oder starten Sie eine neue.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'Bitte geben Sie den Bestätigungscode ein, um Ihre E-Mail zu bestätigen',
          usernameOrEmail: 'Benutzername oder E-Mail-Adresse',
          enterVerificationCode: 'Bestätigungscode eingeben',
          confirmCode: 'Bestätigungscode',
          top: 'Oberteil',
          latest: 'Neueste',
          photos: 'Fotos',
          files: 'Dateien',
          noPeople: 'Keine Leute',
          all: 'Alle',
          mentions: 'Erwähnungen',
          replies: 'Antworten',
          // tweetsAndReplies: 'Tweets & Antworten',
          media: 'Medien',
          likes: 'Likes',
          searchPost: 'Updates suchen',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'Passwort vergessen? Bitte geben Sie Ihren Benutzernamen oder Ihre E-Mail-Adresse ein. Sie erhalten einen Link zum Erstellen eines neuen Passworts per E-Mail.',
          resetYourPassword: 'Setze dein Passwort zurück',
          enterCode: 'Code eingeben',
          enterNewPassword: 'Neues Passwort eingeben',
          reEnterPassword: 'Kennwort erneut eingeben',
          passwordCannotBeEmpty: 'Passwort kann nicht leer sein',
          passwordShouldBeCharacter: 'Passwort sollte 8 Zeichen lang sein',
          passwordShouldBeMatched: 'Passwort sollte übereinstimmen',
          resetPassword: 'Passwort zurücksetzen',
          email: 'Email',
          blockUser: 'Benutzer blockieren',
          public: 'Öffentlich',
          mentionUsers: 'Benutzer erwähnen',
          editProfile: 'Profil einrichten',
          yourProfileIsUpdated: 'Ihr Profil wurde aktualisiert',
          seeProfile: 'Siehe Profil',
          skipForNow: 'Für jetzt überspringen',
          addBio: 'Bio hinzufügen',
          profileUpdated: 'Profil aktualisiert',
          upDate: 'Aktualisieren',
          goToProfile: 'Gehe zu Profil',
          more: 'Mehr',
          about: 'Über',
          help: 'Hilfe',
          privacyPolicy: 'Datenschutz-Bestimmungen',
          blog: 'Blog',
          termsOfService: 'Bedingungen von Dienstleistungen',
          youMustSelectACountry: 'Sie müssen ein Land auswählen',
          usernameIsAlreadyTaken: 'Benutzername ist bereits vergeben',
          goBack: 'Geh zurück',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'Mit dieser E-Mail wurde bereits ein Konto erstellt',
          yourPasswordIsResetSuccessfully:
              'Ihr Passwort wurde erfolgreich zurückgesetzt',
          returnToLogin: 'Zurück zum Login',
          youHaveEnteredAnInvalidCode:
              'Sie haben einen ungültigen Code eingegeben',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'Vielen Dank, dass Sie Ihr Konto bei BuzznBee erstellt haben. Unser Team wird sich innerhalb von 24 Stunden mit Ihnen in Verbindung setzen. Bleib sicher!',
          success: 'Erfolg',
          goBackToHomePage: 'Zurück zur Startseite',
        },
        'it': {
          ok : 'OK',
          timesThisWerfWasSeenOnWerfie :'Quante volte questo werf è stato visto su Werfie',
          totalNumberOfTimesAUserHasInteractedWithAWerf: "Numero totale di volte in cui un utente ha interagito con un werf.",
          timesPeopleViewedTheDetailsAboutThisWerf : "Molte volte le persone hanno visualizzato i dettagli di questo werf",
          followsGainedDirectlyFromThisWerf : "Segue ricavato direttamente da questo werf",
          numberOfProfileViewsFromThisWerf : "Numero di visualizzazioni del profilo da questo werf",
          deleteForEveryOne : 'Elimina per tutti',
          photo : 'Foto',
          emojis : 'Emoji',
          uploadFile: 'Caricare un file',
          createPoll :'Crea sondaggio',
          scheduleWerf :"Programma Werf",
          loginWithEmail : "Accedi con l'e-mail",
          usePhoneInstead :  "Usa invece il telefono",
          useEmailInstead : "Utilizza invece l'e-mail",
          noVerifiedFollower :'Nessun follower verificato',
          verifiedFollowers :  'Follower verificati',
          signUpToYourAccount : "Registrati al tuo account",
          pleaseEnterYourName : 'per favore inserisci il tuo nome',
          werfieHandleErrorMessage : 'Inserisci un handle',
          emailErrorMessage : 'Inserisci una email valida',
          werfieHandle : 'Maniglia Werfie',
          pleaseEnterAValidDOB :'Inserisci un DOB valido',
          pleaseEnterDOB : 'Data di nascita (GG/MM/AAAA)',
          phone :'Telefono',
          suggestions : "Suggerimenti",
          customizeYourExperience : "Personalizza la tua esperienza",
          trackWhereYouSeeWerfieContentAcrossTheWeb : "Tieni traccia di dove vedi i contenuti Werfie sul Web",
          werfieUsesThisDataToPersonalizeYourExperience : "Werfie utilizza questi dati per personalizzare la tua esperienza. Questa cronologia di navigazione web non verrà mai archiviata con il tuo nome, email o numero di telefono",
          werfieMayUseYourContactInformationIncludingYouEmail : "Werfie può utilizzare le tue informazioni di contatto, incluso il tuo indirizzo e-mail e il numero di telefono per gli scopi indicati nella nostra Informativa sulla privacy.",
          pleaseAgreeToWerfieTermsConditions: "Si prega di accettare i Termini e condizioni di Werfie",
          createYourAccount :  "crea il tuo account",
          weSentYouACode : "Ti abbiamo inviato un codice",
          enterItBelowToVerify :"Inseriscilo qui sotto per verificare",
          didNotReceiveEmail : "Non hai ricevuto l'e-mail?",
          youWillNeedAPassword :"Avrai bisogno di una password",
          passwordMustBeCharactersLong:"La password deve contenere 8 caratteri, di cui almeno un numero, una lettera maiuscola e un carattere speciale.",
          pleaseEnterAValidEmail : 'Inserisci una email valida',
          resend : "Invia nuovamente",

          google :"Google",
          apple :"Mela",
          worldNoor :"Mondonoor",
          doNotMissWhatsHappening :"Non perdere ciò che sta accadendo",
          peopleOnWerfieAreTheFirstToKnow :"Le persone su Werfie sono le prime a saperlo",
          newToWerfie :  "Nuovo a Werfie?",
          signUpNowToGetYourOwnPersonalizedTimeline :'Iscriviti ora per ottenere la tua timeline personalizzata!',
          signUpWithGoogle :  "Iscriviti con Google",
          signUpWithApple :"Iscriviti con Apple",
          signUpWithEmailOrMobile : "Iscriviti con e-mail o cellulare",
          loginWithWorldNoor : "Accedi con WorldNoor",
          bySigningUpYouAgreeOur : 'Iscrivendoti, accetti il nostro',
          trending :'Tendenza',
          noUserNoTag : 'Nessun utente && Nessun tag',
          noTrendsInThisRegion :'Nessuna tendenza in questa regione',
          weAreExperiencingSomeDifficulties : "Stiamo riscontrando alcune difficoltà. Per favore riprova più tardi",
          noPost : 'Nessun messaggio',
          signInToYourAccount : "Accedi al tuo account",
          enterEmailPhone : "Inserisci e-mail/telefono",
          forgotPassword : "Ha dimenticato la password?",
          itSeemsLikeYouAreARobot: "Sembra che tu sia un robot. per favore verifica di nuovo",
          signIn:  "Registrazione",
          registerHere: "Registrati qui!",
          orContinueWith: "Oppure continua con",
          somThingWentWrongWithConfiguration: "Qualcosa è andato storto con la configurazione. Per favore riprova",
          error:"Errore",
          pleaseAllowEmailToContinueWithWerfie: "Si prega di consentire all'e-mail di continuare con Werfie",
          alert: "Mettere in guardia",
          sorryForTheInconvenience:"Ci dispiace per l'inconvenienza. Per favore riprova più tardi.",
          enterDigitsVerificationCodeSentToYourRegisteredEmail: "Inserisci il codice di verifica a 6 cifre inviato alla tua email registrata",


          theUsernameHasAlreadyBeenTaken : 'Il nome utente è già stato preso.',
          thereWasAnErrorInSavingThisUsername : "Si è verificato un errore nel salvataggio di questo nome utente!",
          showMenu : 'Mostra Menù',
          thisPollHasExpired : 'Questo sondaggio è scaduto',
          youCannotVoteOnYourOwnPoll : 'Non puoi votare il tuo sondaggio!',
          choice : "Scelta",
          optionalPoll : "(Opzionale)",


          watchPartyLetGo :  "Guarda la festa, andiamo",
          createSpace :'Crea spazio',
          oopsSomethingWentWrongPleaseTryAgain : 'Oops! Qualcosa è andato storto! Per favore riprova',
          noSpacesAvailable : 'Nessuno spazio disponibile',
          yourSpaceIsReady : "Il tuo spazio è pronto",
          spaceLinkCopiedSuccessfully : 'Collegamento allo spazio copiato correttamente',
          instant : 'Immediato',
          nameYourSpace : 'Dai un nome al tuo spazio',
          whatDoYouWantToTalkAbout :'Di cosa vuoi parlare?',
          scheduleYourSpace : "Pianifica il tuo spazio",
          confirm : 'Confermare',
          selectTopic : 'Seleziona argomento',
          momentDeleteSuccessfully : "Momento eliminato con successo",
          createSpaceSuccessfully : "Crea spazio con successo",
          pleaseEnterTheSpaceName : "Inserisci il nome dello spazio",
          spaces : 'Spazi',

          pleaseChooseEither1VideoOr1Pdf: "Scegli 1 video o 1 Pdf alla volta o fino a 4 foto.",
          fileTypeIsNotAllowed:'Il tipo di file non è consentito',
          thisPostIsScheduledFor: "Questo post è previsto per",
          askAQuestion: 'Fai una domanda...',
          pollLength:'Lunghezza del sondaggio',
          hours: 'Ore',
          minutes:'Minuti',
          removePoll: 'Rimuovi sondaggio',
          uploading: 'Caricamento...',
          addDescription: "Aggiungi una descrizione",
          willPostOn:  "Pubblicherò su",
          date:'Data',
          youCannotScheduleAWerfInThePast: 'Non è possibile programmare un Werf nel passato',
          time: 'Tempo',
          timeZone: 'Fuso orario',
          youHaveNoScheduledWerfs: 'Non hai werf programmati',
          willSendOn:  "Invierò",
          selectAll: 'Seleziona tutto',
          schedule: 'Programma',
          scheduledWerfs: 'Werf programmati',
          deselectAll: 'Deselezionare tutto',
          yourImageVideoWillBeAvailableInAMoment: 'La tua immagine/video sarà disponibile in un attimo.',
          pleaseEnterValidText: 'Inserisci un testo valido',
          takeAPhoto: "Fare una foto",
          chooseFromGallery:  "Scegli dalla Galleria",
          makeVideoWithPhoneCamera: "Realizza video con la fotocamera del telefono",
          unsentWerfs: 'Werf non inviati',

          commentsHere:'commenti qui',
          ImageDescription : "descrizione dell'immagine",
          viewHiddenReplies: 'Visualizza le risposte nascoste',
          undoRewerf: 'Annulla Rewerf',
          share:  "Condividere",
          view:  "Visualizzazione",
          werfLinkCopiedSuccessfully: "Collegamento Werf copiato correttamente",
          addBookmark: "Aggiungi segnalibro",
          removeBookmark: "Rimuovi segnalibro",
          werfSavedSuccessfully: 'Werf salvato con successo!',
          werfUnsavedSuccessfully:  'Werf non salvato con successo!',
          thereWasAnErrorInUnSavingThisWerf: "Si è verificato un errore durante l'annullamento del salvataggio di questo werf!",
          thereWasAnErrorInSavingThisWerf:'Si è verificato un errore durante il salvataggio di questo werf!',
          thereWasAnErrorInBlockingThisUser:'Si è verificato un errore nel bloccare questo utente!',
          noEditHistory: 'Nessuna cronologia delle modifiche',
          unPinFromProfile: "Sblocca dal profilo",
          saveWerf: 'Salva Werf',
          linkCopiedToClipBoard:  'Link copiato negli appunti!',
          removeFromBookmarks: 'Rimuovi dai segnalibri',
          thereWasAnErrorInReportingThisUser: 'Si è verificato un errore nel segnalare questo utente!',
          viewOriginal: "originale",
          showThisThread:'Mostra questo thread',
          rewerf : 'Rewerf',

          werfAnalytics : "Werf Analytics",
          nothingFound:'Non abbiamo trovato nulla',
          year:'Anno',
          day : 'Giorno',
          month : 'Mese',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "Dovrebbe essere la data di nascita della persona che utilizza l'account. Anche se stai creando un account per la tua attività o il tuo evento.",
          editDateOfBirth : 'Modificare la data di nascita?',
          deletePhoto :"Elimina foto",
          removePhoto : "Rimuovi foto",
          addPhoto :"Aggiungi foto",
          discard : "Scartare",
          removeWerfAlert :
          "L'operazione non può essere annullata e perderai le modifiche",
          discardChanges : "Non salvare le modifiche?",
          youShouldBeAtLeast14YearsOld: 'Dovresti avere almeno 14 anni',
          contentOfDialog :"Contenuto del dialogo",
          pinnedWerf : "Werf bloccato",
          hiddenPost : "Werf nascosti",
          thisCanBeOnlyChangedAFewTimes :" Questo può essere modificato solo poche volte. Assicurati di inserire l'età della persona che utilizza l'account",


          aboutHashTag : "A proposito dell'hashtag",
          werfHashTag : 'Hashtag Werf',
          messageRequests : 'Richieste di messaggi',
          enterGroupChatTitle:  "Inserisci il titolo della chat di gruppo",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Scegline una dalle chat esistenti o avviane una nuova',
          snoozeNotificationsFrom :  "Posticipare le notifiche da",
          snoozeNotificationsFromTheGroup : "Posticipare le notifiche dal gruppo",
          snoozeMentions : "Menzioni posticipate",
          disableNotificationsWhenPeoplemention:"Disattiva le notifiche quando le persone ti menzionano in questa conversazione.",
          trySearchingForPeopleGroupsOrMessages : "Prova a cercare persone, gruppi o messaggi",
          werfieUser :  "Utente Werfie",
          otherChat :"altro...",
          photoChat : 'Foto',
          videoChat : 'video',
          fileChat : 'File',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'I messaggi diretti sono conversazioni private tra te e altre persone su Twitter. Condividi tweet, contenuti multimediali e altro ancora!',
          searchChats : "Cerca chat",
          allTabChat : "Tutto",
          peopleTabChat : "Persone",
          groupsTabChat :"Gruppo",
          chatsTabChat :"Chat",
          noResultsFor : "Nessun risultato per",
          theTermYouEnteredDidNotBring : "Il termine inserito non ha prodotto alcun risultato",
          message : "Messaggio",
          addMembersToChat : 'Aggiungi membri alla chat',
          noMessagesYet : "Nessun messaggio ancora",
          doNotAllowMessages : "non consentire messaggi",
          notAllowedToMessage : "Non è consentito inviare messaggi.",
          youHaveBlockedThisUser : "Hai bloccato questo utente",
          startAMessage :  "Inizia un messaggio",
          react :  "Reagire",
          undo : "Disfare",
          reactions : 'Reazioni',
          messageRequestsFallHere :
          "Richieste di messaggi da persone che non segui vivono qui. Per rispondere al messaggio è necessario accettare la richiesta.",
          noMessageRequestAvailable : 'Nessuna richiesta di messaggio disponibile',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          "A seconda dell'impostazione selezionata, diverse persone possono inviarti un messaggio diretto.",

          allowMessagesOnlyFromPeopleYouFollow :
          'Consenti messaggi solo dalle persone che segui',
          youWontReceiveAnyMessageRequests :
          "Non riceverai alcuna richiesta di messaggio",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Consenti richieste di messaggi solo da utenti verificati",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Le persone che segui potranno comunque inviarti messaggi",
          allowMessagesRequestsFromEveryone :
          'Consenti richieste di messaggi da parte di tutti',
          otherControls : "Altri controlli",
          filterLowQualityMessages : "Filtra i messaggi di bassa qualità",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Nascondi le richieste di messaggi che sono state rilevate come potenzialmente scadenti o di bassa qualità. Queste verranno inviate a una casella di posta separata nella parte inferiore delle richieste di messaggi. Puoi comunque accedervi se lo desideri",
          showReadReceipts : "Mostra conferme di lettura",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Fai sapere alle persone con cui stai messaggiando quando hai visto i loro messaggi. Le conferme di lettura non vengono visualizzate nelle richieste di messaggi",


          getPushNotificationsToFindOut :"Ricevi notifiche push per scoprire cosa succede quando non sei su Werfie. Puoi disattivarli in qualsiasi momento.",
          relatedToYouAndYourWerfs :"Relativo a te e ai tuoi Werf",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "Quando attivi le notifiche Werf dalle persone che segui, riceverai notifiche push sui loro Werf.",
          topWerfs :"I migliori Werf",
          tailoredForYou: "Su misura per te",
          rewerf : 'Rewerf',
          like : 'Come',
          photoTags : "Tag fotografici",
          messageReactions : "Reazioni ai messaggi",
          fromWerfie : "Da Werfie",
          newsSports : "Notizie / Sport",
          recommendations : "Recommendations",
          turnOnPush:"Attiva le\nnotifiche push",
          toReceiveNotificationsAsTheyHappen :"Per ricevere notifiche non appena si verificano, attiva\nnotifiche push. Le riceverai anche quando\nnon sei su Werfie. Spegnili in qualsiasi momento.",
          turnOn : "Accendere",
          newNotifications :  "Nuove notifiche",
          werfsEmailedToYou : "Werfs ti ha inviato un'e-mail",
          weekly : 'settimanalmente',
          newAboutWerfieProduct :"Novità sugli aggiornamenti dei prodotti e delle funzionalità Werfie",
          tipsOnGettingMoreOut: "Suggerimenti per ottenere di più da Werfie",
          thingsYouMissedSinceYou: "Cose che ti sei perso dall'ultima volta che hai effettuato l'accesso a Werfie",
          participationInWerfieResearchSurveys: "Partecipazione ai sondaggi di ricerca Werfie",
          suggestionsRorRecommendedAccounts: "Suggerimenti per gli account consigliati",
          suggestionsBasedOnYourRecentFollows: "Suggerimenti basati sui tuoi follower recenti",
          qualityFilters : "Filtri di qualità",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Scegli di filtrare contenuti come Werf duplicati e automatizzati. Ciò non si applica alle notifiche provenienti dagli account che segui e con cui hai interagito di recente.",

          emailNotification : 'notifiche di posta elettronica',
          filters : "Filtri",
          chooseTheNotification : "Scegli la notifica che desideri vedere e quelle no",
          preferences : "Preferences",
          selectYourPreferencesByNotificationType :"Seleziona le tue preferenze per tipo di notifica.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie utilizza sempre alcune informazioni, come il luogo in cui ti sei registrato e la tua posizione attuale, per mostrarti contenuti più pertinenti. Quando questa impostazione è abilitata, Werfie potrebbe anche personalizzare la tua esperienza in base ad altri luoghi in cui sei stato.',

          personalizeBasedOnPlacesYouHaveBeen :
          'Personalizza in base ai luoghi in cui sei stato',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Gestisci le informazioni sulla posizione che Werfie utilizza per personalizzare la tua esperienza.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Fai sapere alle persone con cui stai messaggiando quando hai visto i loro messaggi. Le conferme di lettura non vengono visualizzate nelle richieste di messaggi",

          showReadReceipts : "Mostra conferme di lettura",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Nascondi le richieste di messaggi che sono state rilevate come potenzialmente scadenti o di bassa qualità. Queste verranno inviate a una casella di posta separata nella parte inferiore delle richieste di messaggi. Puoi comunque accedervi se lo desideri",


          filterLowQualityMessages :"Filtra i messaggi di bassa qualità",
          otherControls : "Altri controlli",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Le persone che segui potranno comunque inviarti messaggi",
          allowMessagesRequestsFromEveryone :
          'Consenti richieste di messaggi da parte di tutti',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "Le persone che segui potranno comunque inviarti messaggi",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Consenti richieste di messaggi solo da utenti verificati",
          youWontReceiveAnyMessageRequests :
          "Non riceverai alcuna richiesta di messaggio",
          allowMessagesOnlyFromPeopleYouFollow :
          'Consenti messaggi solo dalle persone che segui',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
         " A seconda dell'impostazione selezionata, diverse persone possono inviarti un messaggio diretto.",

          controlWhoCanMessageYou : 'Controlla chi può inviarti messaggi',
          forever : " Per sempre",
          muteNotificationsFromPeople :"Disattiva le notifiche delle persone:",
          youDoNotFollow : "Non segui",
          whoDoNotFollowYou : "Chi non ti segue",
          withANewAccount : "Con un nuovo account",
          whoHaveDefaultProfilePhoto :"Chi ha una foto del profilo predefinita",
          whoHaveNotConfirmedTheirEmail : "Che non hanno confermato la propria email",
          whoHaveNotConfirmedTheirPhoneNumber :"Che non hanno confermato il proprio numero di telefono",
          duration : 'Durata',
          untilYouUnmuteTheWord :" Fino a quando non riattivi l'audio della parola",
          hours24 : '24 ore',
          days7 : '7 giorni',
          days30 : '30 giorni',
          fromPeopleYouDontFollow : "Da persone che non segui",
          homeTimeline : 'Cronologia domestica',
          muteFrom : 'Disattiva audio da',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          "Puoi disattivare l'audio di una parola, @nomeutente o hashtag alla volta.",
          enterWordOrPhrase : 'Inserisci una parola o una frase',
          mutedWord : 'Parola muta',
          addMutedWords : 'Aggiungi parole disattivate',
          youHaveNotMutedAnyWordYet : 'Non hai ancora disattivato nessuna parola',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "quando disattivi le parole, non riceverai alcuna nuova notifica per i Werf che le includono né vedrai i Werf con quelle parole nella tua cronologia principale.",

          youHaveNotMutedAnyPersonYet :
          "Non hai ancora disattivato l'audio di nessuna persona",
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Ecco tutti quelli che hai disattivato. Puoi aggiungerli e rimuoverli da questo elenco.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "Quando blocchi qualcuno, quella persona non potrà seguirti o inviarti messaggi e non vedrai le sue notifiche.",

          mutedNotification : 'Notifiche disattivate',
          mutedWords: 'Parole mute',
          mutedAccounts : 'Account disattivati',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Gestisci gli account, le parole e le notifiche che hai disattivato o bloccato.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'Ciò impedisce la visualizzazione di Werf con contenuti potenzialmente sensibili nei risultati di ricerca.',

          hideSensitiveContent: 'Nascondi contenuti sensibili',
          removeBlockedAndMutedAccounts :
          'Rimuovi gli account bloccati e disattivati',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
         " Utilizzalo per eliminare i risultati della ricerca dall'account che hai bloccato o disattivato",
          personalization : 'Personalizzazione',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'puoi personalizzare le tendenze in base alla tua posizione e a chi segui',
          exploreLocation : 'Esplora la posizione',
          showContentInThisLocation : 'Mostra il contenuto in questa posizione',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'Quando è attivo, vedrai cosa sta succedendo intorno a te in questo momento.',
          searchSettings  :'Impostazioni di ricerca',
          exploreSettings : 'Esplora le impostazioni',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Decidi cosa vedere su Werfie in base alle tue preferenze come Argomenti',
          displayMediaThatMayContainSensitiveContent :
          'Visualizzare contenuti che potrebbero contenere materiale sensibile',

          addLocationInformationToYourWerfs :'Aggiungi informazioni sulla posizione ai tuoi Werf',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "Se abilitato, le foto e i video che Werf verranno contrassegnati come sensibili per le persone che non vogliono vedere contenuti sensibili.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'Contrassegna i media che Werf contengono materiale che potrebbe essere sensibile',
          manageTheInformationAssociatedWithYourWerfs :
          'Gestisci le informazioni associate ai tuoi Werf.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'se abilitato, sarai in grado di allegare la posizione ai tuoi Werf.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Rimuovi tutte le informazioni sulla posizione allegate ai tuoi Werf',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
         " Le etichette di posizione che hai aggiunto ai tuoi Werf non saranno più visibili su Werfie.com, Werfie per IOS e Werfie per Android. L'entrata in vigore di questi aggiornamenti potrebbe richiedere del tempo.",

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Gestisci quali informazioni consenti ad altre persone su Werfie.',
          protectYourTweets : 'Proteggi i tuoi Werf',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'Se selezionato, il tuo werfie e le informazioni del tuo account sono visibili solo alle persone che ti seguono',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'Questo li renderà visibili solo ai tuoi follower werfie',
          protect : 'Proteggere',
          photoTagging : 'Etichettatura delle foto',
          AnyoneCanTagYou : 'Chiunque può taggarti',
          onlyPeopleYouFollowCanTagYou:
          'Solo le persone che segui possono taggarti',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Consenti alle persone di taggarti nelle loro foto e di ricevere notifiche quando lo fanno',
          AnyoneCanTagYou : 'Chiunque può taggarti',
          onlyPeopleYouFollowCanTagYou : 'Solo le persone che segui possono taggarti',
          security : 'Sicurezza',
          manageYourAccountsSecurity : "Gestisci la sicurezza dei tuoi account",
          twoFactorAuthentication : "Autenticazione a due fattori",
          manageYourAccountsSecurityKeepTrack : "Gestisci la sicurezza dei tuoi account e tieni traccia dell'utilizzo del tuo account",
          helpProtectYourAccountFromUnauthorizedAccess :  "Aiuta a proteggere il tuo account da accessi non autorizzati richiedendo un secondo metodo di autenticazione oltre alla tua password X. Puoi scegliere un messaggio di testo, un'app di autenticazione o una chiave di sicurezza.",
          verificationCodeSentToYourRegisteredEmail:"Inserisci il codice di verifica a 6 cifre inviato alla tua email registrata",
          submit :'Invia',
          genderChangedSuccessfully : "Genere cambiato con successo",
          genderSettingTextDescription :"Se non hai già specificato un sesso, questo è quello associato al tuo account in base al tuo profilo e alla tua attività. Queste informazioni non verranno visualizzate pubblicamente.",
          male:  'Maschio',
          female : 'Femmina',
          other : 'Altro',
          change:'Modifica',
          changeCountrySettings:'cambia Paese',
          selectACountry:'Seleziona un Paese',
          updateEmailAddress:"aggiorna l'indirizzo email",
          current:'Attuale',
          changeEmailSetting:'Cambia email',
          gender:'Genere',
          accountCreation:'Creazione account',
          Age:'Età',
          securityAndAccountAccess:"Sicurezza e accesso all'account",
          youHaveNotCreatedOrFollowedAnyLists: "Non hai creato né seguito alcuna lista. Quando lo farai, verranno visualizzati qui.",
          userCanPinnedOnly5  : "L'utente può bloccarne solo 5" ,
          pleaseEnterTheName  : 'Inserisci il nome ',
          list : 'Elenchi',
          listYouAre :"Elenchi in cui sei presente",
          listYouHave:"Non sei stato ancora aggiunto a nessuna lista",
          listAddedSomeOne:"Quando qualcuno ti aggiunge a un elenco, verrà visualizzato qui",
          listMembers :'Elenco membri',
          listFollowers  : 'Elenca follower',
          noMembers: 'Nessun membro',
          noResults :'Nessun risultato',
          noFollowers:'Nessun follower',
          manageWhatInformationYouSeeAndShareOnWerfie: 'Gestisci quali informazioni vedi e condividi su Werfie.',
          noResponseFromServerMsg: 'Stiamo riscontrando alcune difficoltà. Per favore riprova più tardi',
          filteredResult:'Risultato filtrato',
          forYou:'Per te',
          noInternetAvailable:'Nessuna connessione Internet disponibile!',
          welcomeToWerfie:'Benvenuti in werfi',
          cantChooseEmailAsApass:
          "Non puoi scegliere l'e-mail come password, scegli una password sicura",
          passMustContainUpperCaseAndLeeter:
          'La password deve contenere almeno una lettera maiuscola \ne un numero',
          bothPasswordAndConfirmPassShouldMatch:
          'Sia la password che la password di conferma devono corrispondere',
          DidNoTReceiveCode: "Non hai ricevuto il codice?",
          verificationCode: 'Codice di verifica',
          enterYourNewPasswordHint: 'Inserisci la tua nuova password',
          ChangePasswordSettings: 'Cambiare la password',
          trendingUpdates: 'Aggiornamenti di tendenza',
          dobAddMsg: "Aggiungi la tua data di nascita al tuo",
          audienceAndTagging: 'Pubblico e tag',
          LearnMoreAboutPrivacyOnWerfie:
              'Scopri di più sulla privacy su Werfie',
          yourWerfieActivity: 'La tua attività a Werfie',
          yourAndTagging: 'Il tuo e taggando',
          yourWerfs: 'I tuoi Werf',
          contentYouSee: "Contenuti che vedi",
          muteAndBlock: 'Disattiva e blocca',
          directMessages: 'Messaggio diretto',
          dataSharingAndPersonalization:
              'Condivisione e personalizzazione dei dati',
          locationInformation: 'Informazioni sulla posizione',

          nameCannotBeEmpty: "Il nome è obbligatorio",
          nameLengthShouldMax20:
              "La lunghezza del nome non deve essere superiore a 20",
          nameStartsWithCharacter: "Il nome dovrebbe iniziare con alfabeti",
          pleaseProvideAValidEmail: "Per favore inserisci un'email valida",
          werfieHandleIsRequired: "È richiesta la maniglia Werfie",
          passwordShouldBeMin8Char:
              'La password deve contenere almeno 8 caratteri',
          pleaseEnterYourBirthDate: 'Inserisci la tua data di nascita',
          enterYourBirthDateOptional:
              'Inserisci la tua data di nascita (facoltativo)',
          rewerf: 'Rewerf',
          topicsThatYouFollowShownHere:
              'Gli argomenti che segui vengono visualizzati qui. Per vedere tutte le cose che Werfie pensa che ti interessino, controlla i tuoi dati Werfie. Puoi anche saperne di più sui seguenti argomenti.',
          bySigningUpYouAgree: 'Iscrivendoti, accetti il ​​nostro,',
          and: 'E',
          privacyUpdated: 'Privacy aggiornata',
          removeWerfFromBookMark: 'Rimuovi werf dal segnalibro',
          areYouSure: 'Sei sicuro?',
          doYouWantToExit: "Vuoi uscire dall'app",
          no: 'NO',
          yes: 'SÌ',
          werfUnsaved: 'Werf non salvato con successo!',
          private: 'Rendere privato',
          name: 'Nome',
          bio: "Bio",
          birthDate: 'Data di nascita',
          create: 'Creare',
          weWontSuggestThisTopic: "Non suggeriremo più questo argomento",
          youllSeeTopWerfs:
              "Vedrai i migliori Werf su questi argomenti direttamente nella tua cronologia principale",
          requestVerification: 'Richiedi verifica',
          enterCurrentPassword: 'Immetti la password corrente',
          enterYourNewPassword:
              "Inserisci la tua nuova password e premi il pulsante Avanti. Ti invieremo un codice di 4 cifre sul tuo indirizzo email. Dovrai inserire il codice di 4 cifre nella schermata successiva per completare il processo.",
          noWerfs: 'Niente Werf',
          verified: 'Verificato',
          getMoments: 'Ottieni momenti',
          tweetsAndReplies: 'Werf e risposte',
          yourlist: 'Le tue liste',
          copyProfileLink: 'Copia il collegamento al profilo',
          signInWithApple: 'Accedi con Apple',
          searchForAnItem: 'Cerca un articolo...',
          changedTheCountryName: 'Modificato il nome del paese con successo!',
          editOrder: 'modificare la sequenza',
          ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
              'Questa operazione non può essere annullata e verrà rimossa dal tuo profilo, dalla sequenza temporale di tutti gli account che ti seguono e dai risultati di ricerca di Werfie.',
          writeAShortDesc: 'Scrivi una breve descrizione dei momenti',
          addATitle: 'Aggiungi un titolo',
          publish: 'Pubblicare',
          likedBy: 'Piaciuto a ',
          werfSearch: 'Ricerca Werf',
          werfsByAccount: "Werf per conto",
          werfsILiked: "Parole che mi sono piaciute",
          addWerfs: 'Aggiungi Werf',
          allReply: 'Tutti rispondono',
          replyingTo: 'Rispondere a ',
          werfYourReply: 'Scrivi la tua risposta...',
          noMomentsList: 'Nessun momento',
          justNow: 'Proprio adesso',
          clear: 'Chiara',
          createANewWerf: 'Crea un nuovo Werf',
          suggestedTopics: 'Argomenti consigliati',
          whenYouFollowMsg:
              "Quando segui un elenco, sarai in grado di tenere rapidamente il passo con gli esperti su ciò che ti interessa di più.",
          chooseYourLists: 'Scegli le tue liste',
          discoverlist: 'Scopri nuove liste',
          pinnedList: "Elenco appuntato",
          createNew: 'Creare nuovo',
          chooseAnExistingMomentOrCreateNew:
              'Scegli un momento esistente o creane uno nuovo',
          seizeTheMoment: "Cogli l'attimo",
          momentDeleteSuccessfully: 'Momento eliminato con successo',
          createMoment: 'Crea Momento',
          removeMomentAlertMsg:
              'Questo non può essere annullato e perderai il tuo Momento.',
          momentsDelete: 'Momenti Elimina?',
          nothingToSeeHere: 'Niente da vedere quì',
          nothingToSeeHerePinYour:
              "Non c'è ancora niente da vedere qui: appunta le tue liste preferite per accedervi rapidamente.",
          viewHiddenReply: 'Visualizza la risposta nascosta',
          block: 'Bloccare',
          chooseOneFromYourExistingChatsOrStartANewOne:
              'Scegline una dalle tue chat esistenti o avviane una nuova',
          youDoNotHaveAChatSelected: 'Non hai selezionato una chat',
          editGroup: 'Modifica gruppo',
          colors: 'Colori',
          dark: "scuro",
          light: "chiaro",
          theseSettingsAffect:
              "Queste impostazioni riguardano tutti gli account Werfie su questo browser.",
          customizeView: 'Personalizza la tua vista',
          dismiss: 'Congedare',
          thisWerfSeen: 'Volte questo werf è stato visto.',
          youHaveAlreadyReportedWerf: 'Hai già segnalato questo werf',
          enterDescriptionFieldIsRequired:
              "Il campo di inserimento della descrizione è obbligatorio",
          searchLocation: 'Cerca posizione',
          tagLocation: 'Contrassegna posizione',
          profileVisits: 'Visite al profilo',
          newFollowers: 'Nuovi seguaci',
          detailExpands: 'Il dettaglio si espande',
          engagements: 'Impegni',
          impressions: 'Impressioni',
          werfAnalytics: 'Werf Analytics',
          followed: 'seguito',
          notInterested: 'Non interessato',
          suggested: 'Suggerito',
          add: 'Aggiungere',
          remove: 'Rimuovere',
          members: 'Membri',
          whenYouMakeAList:
              "Quando rendi privata una lista, solo tu puoi vederla.",
          makePrivate: 'Rendere privato',
          createNewList: 'Create New List',
          next: 'Prossima',
          done: 'Fatto',
          editList: 'Modifica elenco',
          manageMembers: 'Gestisci membri',
          delete: 'Eliminare',
          listYouAreON: "Elenchi in cui ti trovi",
          newsSocial: 'Notizia',
          filmTV: 'divertimento',
          music: 'Music',
          travelAdventure: 'Viaggio',
          newChat: 'Nuova chat',
          noMsgsYet: 'Ancora nessun messaggio',
          addToYourList: 'Aggiungi alla tua lista',
          theTopicsYouFollow:
              "Gli argomenti che segui vengono utilizzati per personalizzare i Werfs, gli eventi e gli annunci che vedi e vengono visualizzati pubblicamente sul tuo profilo",
          verification: 'verifica',
          verificationAccount: "Verifica dell'account",
          country: 'Paese',
          userNameSavedSuccessfully: 'Nome utente salvato con successo!',
          deactivateAccount: 'Disattiva Account',
          off: 'Spento',
          weekly: 'settimanalmente',
          topWerfs: 'Quotidiana',
          getEmailToFindOut:
              'Ricevi e-mail per scoprire cosa succede quando non sei su Werfie. Puoi disattivarli in qualsiasi momento.',
          pushNotifications: 'Notifica push',
          otpSentMsg:
              "Abbiamo appena inviato un codice a 4 cifre al tuo indirizzo email. Inserisci quel codice nel posto indicato di seguito e premi il pulsante Conferma",
          sendViaDirectMessage: 'Invia tramite messaggio diretto',
          shareWerf: 'Condividi Werf',
          copylinkToWerf: 'Copia il collegamento a werf',
          pickWhoCanReplyMsg:
              "Scegli chi può rispondere a questo Werf. Tieni presente che chiunque sia menzionato può sempre rispondere.,",
          whoCanReply: 'Chi può rispondere?',
          everyoneCanReply: 'Tutti possono rispondere',
          onlyPeopleYouMention: 'Solo le persone di cui parli',
          allwerf: 'Tutto Werf',
          changeEmail: 'Cambia email',
          werfs: 'Werfs',
          viewTranslated: 'Tradotto',
          ChangeYourPassword: 'Cambia la tua password',
          accountInformation: 'Informazioni account',
          viewTopics: 'Visualizza argomenti',
          confirmPassMsg: 'Conferma la tua password',
          wrongPasswordMsg: 'Password errata',
          languageSettings: 'Impostazioni della lingua',
          unBlock: 'Sbloccare',
          loginWithGoogle: 'Accedi con Google',
          createYourPassword: 'crea la tua password',
          createYourWerfieHandle: 'Crea la tua maniglia werfie',
          forwardMessage: 'Inoltra messaggio',
          copy: 'Copia messaggio',
          messageDelete: 'Elimina per te',
          deleteConversation: 'Cancella la conversazione',
          peopleInThisChat: 'Persone in questa chat',
          views: 'Visualizzazioni',
          werfSeenCountMsg: 'Volte questo Werf è stato visto',
          newWerf: 'Nuovo Werf',
          newWerfs: 'Nuovi Werf',
          pinPostMsg: 'Fissa il post al tuo profilo',
          unPinPostMsg: 'Sblocca il post sul tuo profilo!',
          removeWerfAlert:
              "Questa operazione non può essere annullata e perderai le modifiche",
          quoteRewerf: 'Citazione Rewerf',
          rewerfSuccessfully: 'ReWerf con successo',
          noReplyComments: 'Nessun commento di risposta',
          postDetail: 'Particolare del Werf',
          profileLinkCopy: 'Link al profilo copiato con successo!',
          muteUser: 'silenziato con successo',
          userReportedSuccessfully: 'Utente segnalato con successo!',
          userBlockedSuccessfully: 'Utente bloccato con successo!',
          werfReportedSuccssfully: 'Werf segnalato con successo',
          YourAccount: 'Il tuo account',
          notificationsSettings: 'Impostazioni delle notifiche',
          displaySettings: 'Impostazioni di visualizzazione',
          moments: 'Momenti',
          topic: 'temi',
          followings: 'Seguidoras',
          popularUpdates: 'Actualizaciones populares',
          privacyAndSafety: 'privacidad y seguridad',
          createWerf: 'Crear Werf',
          chats: 'charlas',
          bookmarks: 'marcadores',
          bookmark: 'marcadore',
          enterYourEmail: 'Introduce tu correo electrónico',
          enterYourPassword: 'Ingresa tu contraseña',
          // languageSettings: 'Configuraciones de idioma',
          blockedAccountsSettings: 'Configuración de cuentas bloqueadas',
          selectYourPreferredLanguage: 'Seleccione su idioma preferido',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Hogar',
          browse: 'Navegar',
          hotTrends: 'Tendencias calientes',
          saved: 'Salvado',
          messages: 'Mensajes',
          myProfile: 'Mi perfil',
          settings: 'Ajustes',
          notifications: 'Notificaciones',
          settingsType: 'Tipo de configuración',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'Administra cómo se te muestra el contenido de BuzzNBee',
          selectYourProfileLanguage: 'Seleccione el idioma de su perfil',
          selectYourAppLanguage: 'Seleccione el idioma de su aplicación',
          enableDisableAutoTranslation:
              'Habilitar / deshabilitar la traducción automática',
          language: 'Idioma',

          ///   spanish
          username: "Nombre de usuario",
          snoozeNotification: 'Notificación de repetición',
          version: 'Versión',
          appVersion: "Version de aplicacion",
          lists: 'Liza',
          deactivationAndDeletion: "Desactivación y Eliminación",
          confirmYourPasswords: "Confirmar la contraseña",
          deactivateAccount: 'Desactivar cuenta',
          or: 'ORO',
          deleteAccount: "Borrar cuenta",
          updateYourLanguageAndTranslation:
              "Actualice su configuración de idioma y traducción",
          manageYourPrivacySettings:
              "Administre su configuración de privacidad",
          privacySettings: "La configuración de privacidad",
          setYourPrivacySettings: 'Establezca su configuración de privacidad',
          messageSettings: 'Configuración de mensajes',
          noOne: "Ninguna",
          everyOne: 'Todo el mundo',
          ChangeUsernameSettings:
              "Cambiar la configuración del nombre de usuario",
          enterYourWerfieHandle: "Ingrese su identificador de servidor",
          youHaveNotBlockedAnyPersonYet: "Você ainda não bloqueou ninguém",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "Si desea eliminar permanentemente su cuenta de Werfie, una vez que haga clic en el botón Aceptar, no podrá reactivar su cuenta ni recuperar el contenido o la información que haya agregado.",
          permanentlyDeleteAccount: "Eliminar cuenta de forma permanente",
          whoCanMessageYou: 'Quién puede enviarte un mensaje',
          viewEditHistory: 'Ver historial de edición',
          reportWerf: 'Reportar error',
          hideWerf: 'Ocultar trabajo',
          showMore:"Mostrar más",
          reportUser: 'Reportar usuario',
          mute: 'Muda',
          unMute: "No silenciar",
          deleteWerf: 'Eliminar Werf',
          viewWerfAnalytics: 'Ver Werf Analytics',
          pintoYourProfile: 'Anclar a tu perfil',
          editWerf: "Editar Werf",
          explore: 'Explorar',

          blockedAccounts: 'Cuentas bloqueadas',
          translations: 'Traducciones',
          viewListOfBlockedAccounts: 'Ver lista de cuentas bloqueadas',
          realTimePostTranslation: 'Traducción de publicaciones en tiempo real',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'Seleccionar idioma al momento de subir un video o audio',
          originalTranslatedScriptAudioPost:
              'Guión original o traducido de la publicación de audio',
          listenTranslatedScript: 'Escuche el guión traducido',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Traducir automáticamente los mensajes en el chat en el idioma seleccionado por los usuarios',
          postedUpdate: 'publicó una actualización.',
          peopleWhoReacted: 'Personas que reaccionaron',
          comments: 'Comentarios',
          peopleWhoRetweeted: 'Personas que retuitearon',
          leaveAComment: 'Deja un comentario',
          post: 'Correo',
          cancel: 'Cancelar',
          savePost: 'Guardar publicación',
          report: 'Reporte',
          hide: 'Esconder',
          shareLinkVia: 'Compartir enlace a través de ...',
          copyLink: 'Copiar link',
          fieldRequired: 'Campo requerido',
          enterDescription: 'Ingrese descripción',
          selectCategory: 'selecciona una categoría',
          okay: 'Okey,',
          pleaseWait: 'Espere por favor...',
          search: 'Buscar',
          logout: 'Cerrar sesión',
          writeSomethingHere: 'Escribe algo aquí',
          addMore: 'Añadir más',
          image: 'Imagen',
          video: 'Video',
          videos: 'Videos',
          file: 'Expediente',
          gif: 'GIF',
          audio: 'Audio',
          live: 'Vivir',
          doNotHaveAnAccount: "¿No tienes una cuenta? ",
          register: 'Registrarse',
          haveAnAccount: "¿Tener una cuenta?",
          login: 'Acceso',
          whoToFollow: 'A quién seguir',
          noSuggestion: 'Ninguna sugerencia',
          follow: 'Seguir',
          unFollow: 'Dejar de seguir',
          seeMore: 'Ver más',
          searchFilter: 'Filtro de búsqueda',
          people: 'Gente',
          fromAnyone: 'De cualquiera',
          peopleYouFollow: 'Las personas que sigues',
          location: 'Localización',
          anywhere: 'En cualquier sitio',
          nearYou: 'Cerca de usted',
          advancedSearch: 'Búsqueda Avanzada',
          trendsForYou: 'Tendencias para ti',
          noTrending: 'No hay tendencias en su Región',
          trendingIn: 'Tendencia en',
          // tweets: 'Tweets',
          noNotification: 'No hay notificaciones para ti',
          refresh: 'ricaricare',
          edit: 'Editar',
          save: 'Ahorrar',
          cFollow: 'Seguir',
          addPeople: 'Añadir personas',
          someText: 'algún texto',
          reportConversation: 'Informar conversación',
          leaveConversation: 'Dejar la conversación',
          enterYourMessage: 'Ingrese su mensaje',
          showMoreComments: 'Mostrar más comentarios',
          reBuzz: 'Rebuzz',
          noPosts: 'No hay actualizaciones para ti',
          emailFieldCannotBeEmpty:
              'El campo de correo electrónico no puede estar vacío',
          emailFormatIsInvalid: 'El formato de correo electrónico no es válido',
          rememberMe: 'Recuérdame',
          lostPassword: '¿Contraseña perdida?',
          cLOGIN: 'ACCESO',
          emailOrPasswordIsIncorrect:
              'Correo electrónico o la contraseña son incorrectos',
          newsFeed: 'Noticias',
          trends: 'Tendencias',
          profile: 'Perfil',
          newMessage: 'Nuevo mensaje',
          next: 'Próxima',
          searchPeople: 'Busca gente',
          saySomething: 'Di algo',
          noSearchResult: 'Sin resultado de búsqueda',
          searchResult: 'Resultado de búsqueda',
          hidePost: 'Esconder la publicación',
          showLess: 'Muestra menos',
          showMore: 'Mostrar más',
          nothingYet: '¡Nada aún!',
          savedPosts: 'Publicaciones guardadas',
          enterYourFirstName: 'Ponga su primer nombre',
          enterYourLastName: 'Ingrese su apellido',
          enterYourUsername: 'Ingrese su nombre de usuario',
          signUp: 'Inscribirse',
          pleaseChooseACountry: 'Por favor elija un pais',
          replied: 'respondida',
          reply: 'Respuesta',
          delete: 'Borrar',
          replyToComment: 'Responder al comentario',
          noFollower: 'Sin seguidor',
          following: 'Siguiente',
          followBack: 'Seguir de vuelta',
          followers: 'Seguidoras',
          follower: 'Seguidora',
          noFollowings: 'No hay seguidores',
          sendAMessageGetAMessage: 'Envíe un mensaje, reciba un mensaje',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'Los mensajes directos son conversaciones privadas entre usted y otras personas en Twitter. ¡Comparte tweets, contenido multimedia y más!',
          startAConversation: 'Iniciar una conversación',
          groupInfo: 'Información del grupo',
          chatInfo: 'Información de chat',
          youDoNotHaveAMessageSelected: 'No tienes un mensaje seleccionado',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Elija uno de sus mensajes existentes o comience uno nuevo.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'Ingrese el código de verificación para verificar su correo electrónico',
          usernameOrEmail: 'Nombre de usuario o correo electrónico',
          enterVerificationCode: 'Ingrese el código de verificación',
          confirmCode: 'Confirma código',
          top: 'Cima',
          latest: 'Más reciente',
          photos: 'Fotos',
          files: 'Archivos',
          noPeople: 'Nadie',
          all: 'Todos',
          mentions: 'Menciones',
          replies: 'Respuestas',
          // tweetsAndReplies: 'Tweets y respuestas',
          media: 'Medios de comunicación',
          likes: 'Likes',
          searchPost: 'Actualizaciones de búsqueda',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              '¿Perdiste tu contraseña? Ingrese su nombre de usuario o dirección de correo electrónico. Recibirá un enlace para crear una nueva contraseña por correo electrónico.',
          resetYourPassword: 'Restablecer su contraseña',
          enterCode: 'Introduzca el código',
          enterNewPassword: 'Ingrese nueva clave',
          reEnterPassword: 'Escriba la contraseña otra vez',
          passwordCannotBeEmpty: 'La contraseña no puede estar vacía',
          passwordShouldBeCharacter: 'La contraseña debe tener 8 caracteres',
          passwordShouldBeMatched: 'La contraseña debe coincidir',
          resetPassword: 'Restablecer la contraseña',
          email: 'Correo electrónico',
          blockUser: 'Bloquear usuario',
          public: 'Pública',
          mentionUsers: 'Mencionar usuarias',
          editProfile: 'Configurar perfil',
          yourProfileIsUpdated: 'Su perfil está actualizado',
          seeProfile: 'Ver el perfil',
          skipForNow: 'Saltar por ahora',
          addBio: 'Agregar biografía',
          profileUpdated: 'Perfil actualizado',
          upDate: 'Actualizar',
          goToProfile: 'Ir al perfil',
          more: 'Más',
          about: 'Sobre',
          help: 'Ayudar',
          privacyPolicy: 'Política de privacidad',
          blog: 'Blog',
          termsOfService: 'Términos de servicio',
          youMustSelectACountry: 'Debes seleccionar un país',
          usernameIsAlreadyTaken: 'Este nombre de usuario ya está tomado',
          goBack: 'Regresa',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'Ya se ha creado una cuenta con este correo electrónico',
          yourPasswordIsResetSuccessfully:
              'Tu contraseña se restableció correctamente',
          returnToLogin: 'Volver al inicio de sesión',
          youHaveEnteredAnInvalidCode:
              'Usted ha introducido un código inválido',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'Gracias por crear su cuenta con BuzznBee, nuestro equipo se comunicará con usted en 24 horas. ¡Mantenerse a salvo!',
          success: 'Éxito',
          goBackToHomePage: 'Volver a la página principal',
        },
        'es': {
          ok : 'DE ACUERDO',
          timesThisWerfWasSeenOnWerfie :'Veces que este werf fue visto en Werfie',
          totalNumberOfTimesAUserHasInteractedWithAWerf: "Número total de veces que un usuario ha interactuado con un werf.",
          timesPeopleViewedTheDetailsAboutThisWerf : "Veces que la gente vio los detalles sobre este werf.",
          followsGainedDirectlyFromThisWerf : "Seguidores obtenidos directamente de este werf.",
          numberOfProfileViewsFromThisWerf : "Número de vistas de perfil de este werf",
          deleteForEveryOne : 'Eliminar para todos',
          photo : 'Foto',
          emojis : 'emojis',
          uploadFile: 'Subir archivo',
          createPoll :'Crear encuesta',
          scheduleWerf :"Horario Werf",
          loginWithEmail : 'Iniciar sesión con correo electrónico',
          usePhoneInstead :  "Utilice el teléfono en su lugar",
          useEmailInstead : "Utilice el correo electrónico en su lugar",
          noVerifiedFollower :'Ningún seguidor verificado',
          verifiedFollowers :  'Seguidores verificados',
          signUpToYourAccount : "Regístrese en su cuenta",
          pleaseEnterYourName : 'por favor, escriba su nombre',
          werfieHandleErrorMessage : 'Por favor introduce un identificador',
          emailErrorMessage : 'Por favor introduzca una dirección de correo electrónico válida',
          werfieHandle : 'Mango Werfie',
          pleaseEnterAValidDOB :'Por favor ingrese una fecha de nacimiento válida',
          pleaseEnterDOB : 'Fecha de nacimiento (DD/MM/AAAA)',
          phone :'Teléfono',
          suggestions : "Sugerencias",
          customizeYourExperience : "Personaliza tu experiencia",
          trackWhereYouSeeWerfieContentAcrossTheWeb : "Realice un seguimiento de dónde ve el contenido de Werfie en la web",
          werfieUsesThisDataToPersonalizeYourExperience : "Werfie utiliza estos datos para personalizar su experiencia. Este historial de navegación web nunca se almacenará con su nombre, correo electrónico o número de teléfono.",
          werfieMayUseYourContactInformationIncludingYouEmail : "Werfie puede utilizar su información de contacto, incluida su dirección de correo electrónico y número de teléfono, para los fines descritos en nuestra Política de privacidad.",
          pleaseAgreeToWerfieTermsConditions: "Por favor acepte los Términos y condiciones de Werfie",
          createYourAccount :  "Crea tu cuenta",
          weSentYouACode : "Te enviamos un código",
          enterItBelowToVerify :"Ingrese a continuación para verificar",
          didNotReceiveEmail : "Necesitarás una contraseña",
          youWillNeedAPassword :"Necesitarás una contraseña",
          passwordMustBeCharactersLong:"La contraseña debe tener 8 caracteres, incluido al menos un número, una letra mayúscula y un carácter especial.",
          pleaseEnterAValidEmail : 'Por favor introduzca una dirección de correo electrónico válida',
          resend : "Reenviar",

          google :"Google",
          apple :"Manzana",
          worldNoor :"Mundonoor",
          doNotMissWhatsHappening :"No te pierdas lo que está pasando",
          peopleOnWerfieAreTheFirstToKnow :"Los personas en Werfie son los primeros en saberlo.",
          newToWerfie :  "¿Nuevo en Werfie?",
          signUpNowToGetYourOwnPersonalizedTimeline :'Regístrese ahora para obtener su propia línea de tiempo personalizada!',
          signUpWithGoogle :  "Regístrate con Google",
          signUpWithApple :"Regístrate con Apple",
          signUpWithEmailOrMobile : "Regístrese con correo electrónico o teléfono móvil",
          loginWithWorldNoor : "Iniciar sesión con WorldNoor",
          bySigningUpYouAgreeOur : 'Al registrarte, aceptas nuestra',
          trending :'Tendencias',
          noUserNoTag : 'Sin usuario && Sin etiqueta',
          noTrendsInThisRegion :'No hay tendencias en esta región',
          weAreExperiencingSomeDifficulties : "Estamos experimentando algunas dificultades. Por favor, inténtelo de nuevo más tarde",
          noPost : 'Sin publicación',
          signInToYourAccount : "Iniciar sesión en su cuenta",
          enterEmailPhone : "Ingrese el correo electrónico/teléfono",
          forgotPassword : "¿Has olvidado tu contraseña?",
          itSeemsLikeYouAreARobot: "Parece que eres un robot. por favor verifique nuevamente",
          signIn:  "Iniciar sesión",
          registerHere: "¡Registrar aquí!",
          orContinueWith: "O continuar con",
          somThingWentWrongWithConfiguration: "Algo salió mal con la configuración. Inténtalo de nuevo",
          error:"Error",
          pleaseAllowEmailToContinueWithWerfie: "Por favor permita que el correo electrónico continúe con werfie.",
          alert: "Alerta",
          sorryForTheInconvenience:"Lo siento por los inconvenientes ocasionados. Por favor, inténtelo de nuevo más tarde.",
          enterDigitsVerificationCodeSentToYourRegisteredEmail: "Ingrese el código de verificación de 6 dígitos Enviado a su correo electrónico registrado",


          theUsernameHasAlreadyBeenTaken : 'El nombre de usuario ya esta en uso.',
          thereWasAnErrorInSavingThisUsername : "¡Hubo un error al guardar este nombre de usuario!",
          showMenu : 'Muestrame el menu',
          thisPollHasExpired : 'Esta encuesta ha caducado',
          youCannotVoteOnYourOwnPoll : '¡No puedes votar en tu propia encuesta!',
          choice : "Elección",
          optionalPoll : "(Opcional)",

          watchPartyLetGo :  "Mira la fiesta, vamos",
          createSpace :'Crear espacio',
          oopsSomethingWentWrongPleaseTryAgain : '¡Huy! Algo salió mal! Inténtalo de nuevo',
          noSpacesAvailable : 'No hay espacios disponibles',
          yourSpaceIsReady : "Tu espacio está listo",
          spaceLinkCopiedSuccessfully : 'El enlace del espacio se copió correctamente.',
          instant : 'Instantáneo',
          nameYourSpace : 'Nombra tu espacio',
          whatDoYouWantToTalkAbout :'¿De qué quieres hablar?',
          scheduleYourSpace : "Agenda tu espacio",
          confirm : 'Confirmar',
          selectTopic : 'Seleccionar tema',
          momentDeleteSuccessfully : "Momento eliminado con éxito",
          createSpaceSuccessfully : "Crea espacio con éxito",
          pleaseEnterTheSpaceName : "Por favor ingresa el nombre del espacio",
          spaces : 'Espacios',

          pleaseChooseEither1VideoOr1Pdf: "Elija 1 video o 1 PDF a la vez o hasta 4 fotos.",
          fileTypeIsNotAllowed:'El tipo de archivo no está permitido',
          thisPostIsScheduledFor: "Esta publicación está programada para",
          askAQuestion: 'Hacer una pregunta...',
          pollLength:'Duración de la encuesta',
          hours: 'Horas',
          minutes:'Minutos',
          removePoll: 'Eliminar encuesta',
          uploading: 'Subiendo...',
          addDescription: "Agregar descripción",
          willPostOn:  "Publicará en",
          date:'Fecha',
          youCannotScheduleAWerfInThePast: 'No puedes programar un Werf en el pasado',
          time: 'Tiempo',
          timeZone: 'Zona horaria',
          youHaveNoScheduledWerfs: 'No tienes werfs programados.',
          willSendOn:  "Enviará",
          selectAll: 'Seleccionar todo',
          schedule: 'Cronograma',
          scheduledWerfs: 'Werfs programados',
          deselectAll: 'Deseleccionar todo',
          yourImageVideoWillBeAvailableInAMoment: 'Su imagen/vídeo estará disponible en un momento.',
          pleaseEnterValidText: 'Por favor ingresa un texto válido',
          takeAPhoto: "Toma una foto",
          chooseFromGallery:  "Elegir de la galería",
          makeVideoWithPhoneCamera: "Hacer video con la cámara del teléfono.",
          unsentWerfs: 'Werfs no enviados',

          commentsHere:'comentarios aquí',
          ImageDescription : 'descripción de la imagen',
          viewHiddenReplies: 'Ver respuestas ocultas',
          undoRewerf: 'Deshacer rewerf',
          share:  "Compartir",
          view:  "Vista",
          werfLinkCopiedSuccessfully: "Enlace Werf copiado exitosamente",
          addBookmark: "Añadir marcador",
          removeBookmark: "Quitar marcador",
          werfSavedSuccessfully: '¡Werf se salvó con éxito!',
          werfUnsavedSuccessfully:  'Werf no salvado con éxito!',
          thereWasAnErrorInUnSavingThisWerf: '¡Hubo un error al cancelar la salvación de este werf!',
          thereWasAnErrorInSavingThisWerf:'¡Hubo un error al guardar a este werf!',
          thereWasAnErrorInBlockingThisUser:'¡Hubo un error al bloquear a este usuario!',
          noEditHistory: 'Sin historial de edición',
          unPinFromProfile: "Desanclar del perfil",
          saveWerf: 'Salvar a Werf',
          linkCopiedToClipBoard:  '¡Enlace copiado al portapapeles!',
          removeFromBookmarks: 'Quitar de favoritos',
          thereWasAnErrorInReportingThisUser: '¡Hubo un error al informar a este usuario!',
          viewOriginal: "original",
          showThisThread:'Mostrar este hilo',
          rewerf : 'Rewerf',

          werfAnalytics : "Análisis Werf",
          nothingFound:'Nada Encontrado',
          year:'Año',
          day : 'Día',
          month : 'Mes',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "Esta debe ser la fecha de nacimiento de la persona que utiliza la cuenta. Incluso si estás creando una cuenta para tu negocio o evento.",
          editDateOfBirth : '¿Editar fecha de nacimiento?',
          deletePhoto :"Borrar foto",
          removePhoto : "Quitar foto",
          addPhoto :"Añadir foto",
          discard : "Desechar",
          removeWerfAlert :
          "Esto no se puede deshacer y perderás los cambios.",
          discardChanges : "¿Descartar los cambios?",
          youShouldBeAtLeast14YearsOld: 'Debes tener al menos 14 años.',
          contentOfDialog :"Contenido del diálogo",
          pinnedWerf : "Werf fijado",
          hiddenPost : "Werfs ocultos",
          thisCanBeOnlyChangedAFewTimes :" Esto sólo se puede cambiar unas cuantas veces. Asegúrese de ingresar la edad de la persona que usa la cuenta.",


          aboutHashTag : 'Acerca del hashtag',
          werfHashTag : 'Hashtag de Werf',
          messageRequests : 'Solicitudes de mensajes',
          enterGroupChatTitle:  "Ingrese el título del chat grupal",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Elija uno de sus chats existentes o inicie uno nuevo',
          snoozeNotificationsFrom :  "Posponer notificaciones de",
          snoozeNotificationsFromTheGroup : "Posponer notificaciones del grupo",
          snoozeMentions : "Posponer menciones",
          disableNotificationsWhenPeoplemention:"Desactiva las notificaciones cuando la gente te mencione en esta conversación.",
          trySearchingForPeopleGroupsOrMessages : "Intenta buscar personas, grupos o mensajes.",
          werfieUser :  "Usuario Werfie",
          otherChat :"otro...",
          photoChat : 'Foto',
          videoChat : 'Video',
          fileChat : 'Archivo',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'Los Mensajes Directos son conversaciones privadas entre usted y otras personas en Twitter. ¡Comparte tweets, medios y más!',
          searchChats : "Buscar chats",
          allTabChat : "Todo",
          peopleTabChat : "Gente",
          groupsTabChat :"Grupo",
          chatsTabChat :"Charlas",
          noResultsFor : "No hay resultados para",
          theTermYouEnteredDidNotBring : "El término que ingresaste no arrojó ningún resultado.",
          message : "Mensaje",
          addMembersToChat : 'Agregar miembros para chatear',
          noMessagesYet : "Aún no hay mensajes",
          doNotAllowMessages : "no permitir mensajes",
          notAllowedToMessage : "No se permite enviar mensajes.",
          youHaveBlockedThisUser : "Has bloqueado a este usuario",
          startAMessage :  "iniciar un mensaje",
          react :  "Reaccionar",
          undo : "Deshacer",
          reactions : 'Reacciones',
          messageRequestsFallHere :
          "Solicitudes de mensajes de personas que no sigues en vivo aquí. Para responder ese mensaje, debe aceptar la solicitud.",
          noMessageRequestAvailable : 'No hay solicitud de mensaje disponible',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'Dependiendo de la configuración que seleccione, diferentes personas pueden enviarle un mensaje directo.',

          allowMessagesOnlyFromPeopleYouFollow :
          'Permitir mensajes solo de las personas que sigues',
          youWontReceiveAnyMessageRequests :
          "No recibirás ninguna solicitud de mensaje.",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Permitir solicitudes de mensajes solo de usuarios verificados",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Las personas a las que sigues aún podrán enviarte mensajesu",
          allowMessagesRequestsFromEveryone :
          'Permitir solicitudes de mensajes de todosne',
          otherControls : "Otros controles",
          filterLowQualityMessages : "Filtrar mensajes de baja calidad",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Oculte las solicitudes de mensajes que se hayan detectado como potencialmente extensas o de baja calidad. Se enviarán a una bandeja de entrada separada en la parte inferior de sus solicitudes de mensajes. Aún puede acceder a ellas si lo desea.",
          showReadReceipts : "Mostrar recibos de lectura",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Informe a las personas con las que está enviando mensajes cuando haya visto sus mensajes. Los recibos de lectura no se muestran en las solicitudes de mensajes.",


          getPushNotificationsToFindOut :"Recibe notificaciones automáticas para saber qué sucede cuando no estás en Werfie. Puedes desactivarlos en cualquier momento.",
          relatedToYouAndYourWerfs :"Relacionado con ti y tus Werfs",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "Cuando activas las notificaciones Werf de las personas que sigues, recibirás notificaciones automáticas sobre sus Werfs.",
          topWerfs :"Mejores jugadores",
          tailoredForYou: "Adaptado para usted",
          rewerf : 'Rewerf',
          like : 'Como',
          photoTags : "Etiquetas de foto",
          messageReactions : "Reacciones al mensaje",
          fromWerfie : "De Werfie",
          newsSports : "Noticias / Deportes",
          recommendations : "Recommendations",
          turnOnPush:"Activar\nnotificaciones push",
          toReceiveNotificationsAsTheyHappen :"Para recibir notificaciones a medida que ocurren, activa\nlas notificaciones automáticas. También las recibirás cuando\nno estés en Werfie. Apágalos en cualquier momento.",
          turnOn : "Encender",
          newNotifications :  "Nuevas notificaciones",
          werfsEmailedToYou : "Werfs te envió un correo electrónico",
          weekly : 'Semanalmente',
          newAboutWerfieProduct :"Novedades sobre actualizaciones de características y productos de Werfie",
          tipsOnGettingMoreOut: "Consejos para sacarle más provecho a Werfie",
          thingsYouMissedSinceYou: "Cosas que te perdiste desde la última vez que iniciaste sesión en Werfie",
          participationInWerfieResearchSurveys: "Participación en encuestas de investigación de Werfie.",
          suggestionsRorRecommendedAccounts: "Sugerencias para cuentas recomendadas",
          suggestionsBasedOnYourRecentFollows: "Sugerencias basadas en tus seguidores recientes",
          qualityFilters : "Filtros de calidad",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Elija filtrar contenido como Werfs duplicados y automatizados. Esto no se aplica a las notificaciones de cuentas que sigues y con las que has interactuado recientemente.",

          emailNotification : 'Notificaciónes de Correo Electrónico',
          filters : "Filtros",
          chooseTheNotification : "Elige las notificaciones que te gustaría ver y las que no",
          preferences : "Preferencias",
          selectYourPreferencesByNotificationType :"Seleccione sus preferencias por tipo de notificación.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie siempre utiliza cierta información, como dónde se registró y su ubicación actual, para ayudar a mostrarle contenido más relevante. Cuando esta configuración está habilitada, Werfie también puede personalizar su experiencia en función de otros lugares en los que haya estado.',

          personalizeBasedOnPlacesYouHaveBeen :
          'Personaliza según los lugares en los que has estado',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Administre la información de ubicación que Werfie utiliza para personalizar su experiencia.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Informe a las personas con las que está enviando mensajes cuando haya visto sus mensajes. Los recibos de lectura no se muestran en las solicitudes de mensajes.",

          showReadReceipts : "Mostrar recibos de lectura",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Oculte las solicitudes de mensajes que se hayan detectado como potencialmente extensas o de baja calidad. Se enviarán a una bandeja de entrada separada en la parte inferior de sus solicitudes de mensajes. Aún puede acceder a ellas si lo desea.",


          filterLowQualityMessages :"Filtrar mensajes de baja calidad",
          otherControls : "Otros controles",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "Las personas a las que sigues aún podrán enviarte mensajes",
          allowMessagesRequestsFromEveryone :
          'Permitir solicitudes de mensajes de todos',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "Las personas a las que sigues aún podrán enviarte mensajes",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Permitir solicitudes de mensajes solo de usuarios verificados",
          youWontReceiveAnyMessageRequests :
          "No recibirás ninguna solicitud de mensaje.",
          allowMessagesOnlyFromPeopleYouFollow :
          'Permitir mensajes solo de las personas que sigues',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'Dependiendo de la configuración que seleccione, diferentes personas pueden enviarle un mensaje directo.',

          controlWhoCanMessageYou : 'Controla quién puede enviarte mensajes',
          forever : " Para siempre",
          muteNotificationsFromPeople :"Silenciar notificaciones de personas:",
          youDoNotFollow : "tu no sigues",
          whoDoNotFollowYou : "Quien no te sigue",
          withANewAccount : "Con una cuenta nueva",
          whoHaveDefaultProfilePhoto :"Que tienen foto de perfil predeterminada",
          whoHaveNotConfirmedTheirEmail : "Quienes no han confirmado su correo electrónico",
          whoHaveNotConfirmedTheirPhoneNumber :"Que no han confirmado su número de teléfono",
          duration : 'Duración',
          untilYouUnmuteTheWord : 'Hasta que desactives la palabra',
          hours24 : '24 horas',
          days7 : '7 días',
          days30 : '30 dias',
          fromPeopleYouDontFollow : "De gente que no sigues",
          homeTimeline : 'Línea de tiempo de inicio',
          muteFrom : 'Silenciar desde',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'Puedes silenciar una palabra, @nombre de usuario o hashtag a la vez.',
          enterWordOrPhrase : 'Introduce palabra o frase',
          mutedWord : 'palabra silenciada',
          addMutedWords : 'Agregar palabras silenciadas',
          youHaveNotMutedAnyWordYet : 'Aún no has silenciado ninguna palabra',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "Cuando silencias palabras, no recibirás ninguna notificación nueva de Werfs que las incluya ni verás Werfs con esas palabras en tu línea de tiempo de inicio.",

          youHaveNotMutedAnyPersonYet :
          'Aún no has silenciado a ninguna persona',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Aquí están todas las personas que silenciaste. Puedes agregarlas y eliminarlas de esta lista.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "Cuando bloqueas a alguien, esa persona no podrá seguirte ni enviarte mensajes y no verás sus notificaciones.",

          mutedNotification : 'Notificaciones silenciadas',
          mutedWords: 'palabras silenciadas',
          mutedAccounts : 'Cuentas silenciadas',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Administre las cuentas, palabras y notificaciones que ha silenciado o bloqueado.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'Esto evita que se muestren Werfs con contenido potencialmente confidencial en los resultados de búsqueda.',

          hideSensitiveContent: 'Ocultar contenido sensible',
          removeBlockedAndMutedAccounts :
          'Eliminar cuentas bloqueadas y silenciadas',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'Utilízalo para eliminar los resultados de búsqueda de la cuenta que has bloqueado o silenciado.',
          personalization : 'Personalización',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'Puedes personalizar las tendencias según tu ubicación y a quién sigues.',
          exploreLocation : 'Explorar ubicación',
          showContentInThisLocation : 'Mostrar contenido en esta ubicación',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'Cuando esto esté activado, verás lo que está sucediendo a tu alrededor en este momento.',
          searchSettings  :'Configuración de búsqueda',
          exploreSettings : 'Explorar configuraciones',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Decide lo que ves en werfie según tus preferencias, como Temas',
          displayMediaThatMayContainSensitiveContent :
          'el material mostrado puede tener contenido sensible',

          addLocationInformationToYourWerfs :'Agregue información de ubicación a sus Werfs',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "Cuando esté habilitado, las imágenes y los videos que usted obtenga se marcarán como confidenciales para las personas que no quieran ver contenido confidencial.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'Marque los medios que Werf tiene como material que puede ser sensible',
          manageTheInformationAssociatedWithYourWerfs :
          'Gestiona la información asociada a tus Werfs.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'Si está habilitado, podrá adjuntar la ubicación a sus Werfs.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Elimina toda la información de ubicación adjunta a tus Werfs',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'Las etiquetas de ubicación que haya agregado a sus Werfs ya no serán visibles en Werfie.com, Werfie para IOS y Werfie para Android. Estas actualizaciones pueden tardar algún tiempo en entrar en vigor.',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Gestiona qué información permites a otras personas en Werfie.',
          protectYourTweets : 'Protege a tus Werfs',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'Cuando se selecciona, su werfie y la información de su cuenta solo son visibles para las personas que lo siguen.',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'Esto los hará visibles sólo para tus seguidores werfie.',
          protect : 'Proteger',
          photoTagging : 'Etiquetado de fotos',
          AnyoneCanTagYou : 'Cualquiera puede etiquetarte',
          onlyPeopleYouFollowCanTagYou:
          'Sólo las personas que sigues pueden etiquetarte',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Permitir que las personas te etiqueten en sus fotos y recibir notificaciones cuando lo hagan',
          AnyoneCanTagYou : 'Cualquiera puede etiquetarte',
          onlyPeopleYouFollowCanTagYou : 'Sólo las personas que sigues pueden etiquetarte',
          security : 'Seguridad',
          manageYourAccountsSecurity : "Gestiona la seguridad de tus cuentas",
          twoFactorAuthentication : "Autenticación de dos factores",
          manageYourAccountsSecurityKeepTrack : "Administre la seguridad de sus cuentas y realice un seguimiento del uso de su cuenta.",
          helpProtectYourAccountFromUnauthorizedAccess :  "Ayude a proteger su cuenta del acceso no autorizado solicitando un segundo método de autenticación además de su contraseña X. Puede elegir un mensaje de texto, una aplicación de autenticación o una clave de seguridad.",
          verificationCodeSentToYourRegisteredEmail:"Ingrese el código de verificación de 6 dígitos Enviado a su correo electrónico registrado",
          submit :'Entregar',
          genderChangedSuccessfully : "El género cambió con éxito",
          genderSettingTextDescription :"Si aún no has especificado un género, este es el asociado a tu cuenta según tu perfil y actividad. Esta información no se mostrará públicamente.",
          male:  'Masculino',
          female : 'Femenina',
          other : 'Otro',
          change:'Cambiar',
          changeCountrySettings:'Cambiar pais',
          selectACountry:'Seleccione un país',
          updateEmailAddress:'Actualización de la dirección de correo electrónico',
          current:'Actual',
          changeEmailSetting:'Cambiar e-mail',
          gender:'Género',
          accountCreation:'Creación de cuenta',
          Age:'Edad',
          securityAndAccountAccess:'Seguridad y acceso a la cuenta',
          youHaveNotCreatedOrFollowedAnyLists: "No has creado ni seguido ninguna lista. Cuando lo hagas, aparecerán aquí.",
          userCanPinnedOnly5  : 'El usuario puede anclar solo 5 ',
          pleaseEnterTheName  : 'Por favor ingrese el nombre ',
          list : 'Liza',
          listYouAre :"Listas en las que estás",
          listYouHave:"Aún no te han agregado a ninguna lista",
          listAddedSomeOne:"Cuando alguien te agregue a una lista, aparecerá aquí",
          listMembers :'Lista de miembros',
          listFollowers  : 'Lista de seguidores',
          noMembers: 'Sin miembros',
          noResults :'No hay resultados',
          noFollowers:'Sin seguidores',
          manageWhatInformationYouSeeAndShareOnWerfie: 'Administre la información que ve y comparte en Werfie.',
          noResponseFromServerMsg: 'Estamos experimentando algunas dificultades. Por favor, inténtelo de nuevo más tarde',
          filteredResult:'Resultado filtrado',
          forYou:'Para ti',
          noInternetAvailable:'¡No hay Internet disponible!',
          welcomeToWerfie:'Bienvenido a werfi',
          cantChooseEmailAsApass:
          "No puede elegir el correo electrónico como contraseña. \nElija una contraseña segura.",
          passMustContainUpperCaseAndLeeter:
          'La contraseña debe contener al menos una letra mayúscula \ny un número',
          bothPasswordAndConfirmPassShouldMatch:
          'Tanto la contraseña como la contraseña de confirmación deben coincidir',
          DidNoTReceiveCode: "¿No recibiste el código?",
          verificationCode: 'Código de verificación',
          enterYourNewPasswordHint: 'Introduzca su nueva contraseña',
          ChangePasswordSettings: 'Cambiar la contraseña',
          trendingUpdates: 'Actualizaciones de tendencias',
          dobAddMsg: 'Añade tu fecha de nacimiento a tu ',
          audienceAndTagging: 'Audiencia y etiquetado',
          LearnMoreAboutPrivacyOnWerfie:
              'Obtenga más información sobre la privacidad en Werfie',
          yourWerfieActivity: 'Tu actividad Werfie',
          yourAndTagging: 'Tu y etiquetando',
          yourWerfs: 'Tus Werfs',
          contentYouSee: "Contenido que ves",
          muteAndBlock: 'Silenciar y bloquear',
          directMessages: 'Mensaje directo',
          dataSharingAndPersonalization:
              'Intercambio de datos y personalización',
          locationInformation: 'Información sobre la ubicación',
          nameCannotBeEmpty: "Se requiere el nombre",
          nameLengthShouldMax20:
              "La longitud del nombre no debe ser superior a 20",
          nameStartsWithCharacter: "El nombre debe comenzar con Alfabetos",
          pleaseProvideAValidEmail:
              "Por favor proporcione un correo electrónico válido",
          werfieHandleIsRequired: "Se requiere mango Werfie",
          passwordShouldBeMin8Char:
              'La contraseña debe tener al menos 8 caracteres',
          pleaseEnterYourBirthDate:
              'Por favor, introduzca su fecha de nacimiento',
          enterYourBirthDateOptional:
              'Ingresa tu fecha de nacimiento (Opcional)',
          rewerf: 'Rewerf',
          topicsThatYouFollowShownHere:
              'Los temas que sigues se muestran aquí. Para ver todas las cosas que Werfie cree que te interesan, consulta Tus datos de Werfie. También puede obtener más información sobre los siguientes temas.',
          bySigningUpYouAgree: 'Al registrarte, aceptas nuestra,',
          and: 'y',
          privacyUpdated: 'Privacidad actualizada',
          removeWerfFromBookMark: 'Quitar werf del marcador',
          areYouSure: 'Estas segura?',
          doYouWantToExit: '¿Quieres salir de la aplicación?',
          no: 'No',
          yes: 'Sí',
          werfUnsaved: 'Werf ¡No se guardó correctamente!',
          private: 'Hacer privado',
          name: 'Nombre',
          bio: "Biografía",
          birthDate: 'Fecha de nacimiento',
          create: 'Crear',
          weWontSuggestThisTopic: "Ya no sugeriremos este tema",
          youllSeeTopWerfs:
              "Verás los mejores Werfs sobre estos directamente en tu línea de tiempo de inicio.",
          requestVerification: 'Solicitar verificación',
          enterCurrentPassword: 'Introducir la contraseña actual',
          enterYourNewPassword:
              "Ingrese su nueva contraseña y presione el botón Siguiente. Le enviaremos un código de 4 dígitos a su dirección de correo electrónico. Deberá ingresar ese código de 4 dígitos en la siguiente pantalla para completar el proceso.",
          noWerfs: 'Sin Werfs',
          verified: 'Verificada',
          getMoments: 'Obtener momentos',
          tweetsAndReplies: 'Werfs y respuestas',
          yourlist: 'Tus listas',
          copyProfileLink: 'Copiar enlace de perfil',
          signInWithApple: 'Iniciar sesión con Apple',
          searchForAnItem: 'Buscar un artículo...',
          changedTheCountryName: '¡Cambié el nombre del país con éxito!',
          editOrder: 'editar secuencia',
          ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
              'Esto no se puede deshacer y se eliminará de su perfil, de la línea de tiempo de cualquier cuenta que lo siga y de los resultados de búsqueda de Werfie.',
          writeAShortDesc: 'Escribe una breve descripción sobre momentos.',
          addATitle: 'Añade un titulo',
          publish: 'Publicar',
          likedBy: 'Apreciado por',
          werfSearch: 'Búsqueda de Werfs',
          werfsByAccount: "Werfs por cuenta",
          werfsILiked: "palabras que me han gustado",
          addWerfs: 'Agregar Werfs',
          allReply: 'Todos responden',
          replyingTo: 'respondiendo a ',
          werfYourReply: 'Verifica tu respuesta...',
          noMomentsList: 'sin momentos',
          justNow: "En este momento",
          clear: 'Clara',
          createANewWerf: 'Crear un nuevo Werf',
          suggestedTopics: 'Temas sugeridos',
          whenYouFollowMsg:
              "Cuando sigue una Lista, podrá mantenerse rápidamente al día con los expertos sobre lo que más le interesa.",
          chooseYourLists: 'Elige tus Listas',
          discoverlist: 'Descubre nuevas listas',
          pinnedList: "Lista anclada",
          createNew: 'Crear nueva',
          chooseAnExistingMomentOrCreateNew:
              'Elija un momento existente o cree uno nuevo',
          seizeTheMoment: "Aprovechar el momento",
          momentDeleteSuccessfully: 'Momento eliminado con éxito',
          createMoment: 'Crear momento',
          removeMomentAlertMsg:
              'Esto no se puede deshacer y perderá su Momento.',
          momentsDelete: 'Momentos ¿Eliminar?',
          nothingToSeeHere: 'Nada que ver aqui',
          nothingToSeeHerePinYour:
              'No hay nada que ver aquí todavía: fije sus Listas favoritas para acceder a ellas rápidamente.',
          viewHiddenReply: 'Ver respuesta oculta',
          block: 'Bloquear',
          chooseOneFromYourExistingChatsOrStartANewOne:
              'Elija uno de sus chats existentes o inicie uno nuevo',
          youDoNotHaveAChatSelected: 'No tienes un chat seleccionado',
          editGroup: 'Editar grupo',
          colors: 'Colores',
          dark: "oscuro",
          light: "claro",
          theseSettingsAffect:
              "Esta configuración afecta a todas las cuentas de Werfie en este navegador.",
          customizeView: 'Personaliza tu vista',
          dismiss: 'Despedir',
          thisWerfSeen: 'Veces esta werf fue visto.',
          youHaveAlreadyReportedWerf: 'Ya reportaste este werf',
          enterDescriptionFieldIsRequired:
              "Enter description field is required",
          searchLocation: 'Buscar ubicación',
          tagLocation: 'Ubicación de la etiqueta',
          profileVisits: 'Visitas de perfil',
          newFollowers: 'Nuevas seguidoras',
          detailExpands: 'Detalle se expande',
          engagements: 'Compromisos',
          impressions: 'impresiones',
          werfAnalytics: 'Análisis Werf',
          followed: 'seguido',
          notInterested: 'No interesada',
          suggested: 'Sugerida',
          add: 'Agregar',
          remove: 'Eliminar',
          members: 'miembros',
          whenYouMakeAList:
              "Cuando haces una lista privada, solo tú puedes verla.",
          makePrivate: 'Hacer privada',
          createNewList: 'Crear nueva lista',
          next: 'Próxima',
          done: 'Hecho',
          editList: 'Lista de edición',
          manageMembers: 'Administrar miembros',
          delete: 'Borrar',
          listYouAreON: "Listas en las que estás",
          newsSocial: 'Noticias',
          filmTV: 'entretenimiento',
          music: 'musica',
          travelAdventure: 'Viajar',
          newChat: 'Nueva conversación',
          noMsgsYet: 'No hay mensajes todavía',
          addToYourList: 'Añadir a tu lista',
          theTopicsYouFollow:
              "Los Temas que sigue se utilizan para personalizar los Werfs, los eventos y los anuncios que ve y se muestran públicamente en su perfil.",
          verification: 'verificación',
          verificationAccount: 'Verificación de la cuenta',
          country: 'País',
          userNameSavedSuccessfully: '¡Nombre de usuario guardado con éxito!',
          deactivateAccount: 'desactivar cuenta',
          off: 'Apagada',
          weekly: 'Semanalmente',
          daily: 'A diario',
          topWerfs: 'Top Werfs',
          getEmailToFindOut:
              'Recibe correos electrónicos para saber qué sucede cuando no estás en Werfie. Puedes apagarlos en cualquier momento.',
          pushNotifications: 'Notificación de inserción',
          otpSentMsg:
              "Acabamos de enviar un código de 4 dígitos a su dirección de correo electrónico. Ingrese ese código en el lugar que se indica a continuación y presione el botón Confirmar",
          sendViaDirectMessage: 'Enviar por mensaje directo',
          shareWerf: 'Compartir Werf',
          copylinkToWerf: 'Copiar enlace a Werf',
          pickWhoCanReplyMsg:
              'Elige quién puede responder a este Werf. Tenga en cuenta que cualquier persona mencionada siempre puede responder.,',
          whoCanReply: '¿Quién puede responder?',
          everyoneCanReply: 'Todas pueden responder',
          onlyPeopleYouMention: 'Solo las personas que mencionas',
          allwerf: 'Todo Werf',
          changeEmail: 'Cambiar e-mail',
          werfs: 'Werfs',
          viewTranslated: 'traducido',
          ChangeYourPassword: 'cambia tu contraseña',
          accountInformation: 'Información de la cuenta',
          viewTopics: 'Ver temas',
          confirmPassMsg: 'Confirmar la contraseña',
          wrongPasswordMsg: 'Contraseña incorrecta',
          languageSettings: 'Ajustes de idioma',
          unBlock: 'Desatascar',
          loginWithGoogle: 'Iniciar sesión con Google',
          createYourPassword: 'Crea tu contraseña',
          createYourWerfieHandle: 'Crea tu mango werfie',
          forwardMessage: 'Reenviar mensaje',
          copy: 'Copiar mensaje',
          messageDelete: 'eliminar por ti',
          deleteConversation: 'Eliminar la conversación',
          peopleInThisChat: 'Personas en este chat',
          views: 'Puntos de vista',
          werfSeenCountMsg: 'Veces esta Werf fue vista',
          newWerf: 'Nueva Werf',
          newWerfs: 'Nuevas Werfs',
          pinPostMsg: 'Fijar publicación en tu perfil',
          unPinPostMsg: '¡Desanclar la publicación a tu perfil!',
          removeWerfAlert: "Esto no se puede deshacer y perderá los cambios.",
          quoteRewerf: 'Cita Rewerf',
          rewerfSuccessfully: 'ReWerf con éxito',
          noReplyComments: 'Sin comentarios de respuesta',
          postDetail: 'Detalle Werf',
          profileLinkCopy: '¡El enlace del perfil se copió con éxito!',
          muteUser: 'silenciado con éxito',
          userReportedSuccessfully: 'Usuario reportado con éxito!',
          userBlockedSuccessfully: 'Usuario bloqueado con éxito!',
          werfReportedSuccssfully: 'Werf reportado con éxito',
          YourAccount: 'Su cuenta',
          notificationsSettings: 'Configuracion de notificaciones',
          displaySettings: 'Configuración de pantalla',
          moments: 'Momentos',
          topic: 'temas',
          followings: 'Seguidoras',
          popularUpdates: 'Atualizações populares',
          privacy: 'Privacidade',
          createWerf: 'Criar Werf',
          chats: 'bate-papos',
          bookmarks: 'favoritas',
          bookmarks: 'favorita',
          enterYourEmail: 'Digite seu e-mail',
          enterYourPassword: 'Coloque sua senha',
          // languageSettings: 'Configurações de linguagem',
          blockedAccountsSettings: 'Configurações de contas bloqueadas',
          selectYourPreferredLanguage: 'Selecione seu idioma preferido',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Casa',
          browse: 'Navegar',
          hotTrends: 'Tendências quentes',
          saved: 'Salvou',
          messages: 'Mensagens',
          myProfile: 'Meu perfil',
          settings: 'Definições',
          notifications: 'Notificações',
          settingsType: 'Tipo de configuração',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'Gerenciar como o conteúdo do BuzzNBee é exibido para você',
          selectYourProfileLanguage: 'Selecione o idioma do seu perfil',
          selectYourAppLanguage: 'Selecione o idioma do seu aplicativo',
          enableDisableAutoTranslation:
              'Ativar / desativar tradução automática',
          language: 'Língua',

          ///   Português
          username: "Nome do usuário",
          snoozeNotification: "Adiar Notificação",
          version: "Versão",
          appVersion: "Versão do aplicativo",
          lists: "Listas",
          deactivationAndDeletion: "Desativação e exclusão",
          confirmYourPasswords: "Confirme suas senhas",
          deactivateAccount: 'Desativar conta',
          or: 'OU',
          deleteAccount: "Deletar conta",
          updateYourLanguageAndTranslation: "Atualize seu idioma e tradução",
          manageYourPrivacySettings:
              "Gerenciar suas configurações de privacidade",
          privacySettings: "Configurações de privacidade",
          setYourPrivacySettings: 'Defina suas configurações de privacidade',
          messageSettings: "Configurações de mensagem",
          noOne: "Ninguém",
          everyOne: 'Todos',
          ChangeUsernameSettings: "MudarConfigurações de nome de usuário",
          enterYourWerfieHandle: "Digite seu identificador wefie",
          youHaveNotBlockedAnyPersonYet: "Anda belum memblokir siapa pun",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "Se você deseja excluir permanentemente sua conta Werfie, depois de clicar no botão ok, você não poderá reativar sua conta ou recuperar qualquer conteúdo ou informação que adicionou.",
          permanentlyDeleteAccount: "Excluir conta permanentemente",
          whoCanMessageYou: 'Quem pode enviar uma mensagem para você',
          viewEditHistory: 'Ver Histórico de Edição',
          reportWerf: 'Relatório wef',
          hideWerf: 'Ocultar werf',
          showMore:"Mostrar mais",
          reportUser: 'Reportar usuário',
          mute: 'Mudo',
          unMute: "Ativar som",
          deleteWerf: 'Excluir Werf',
          viewWerfAnalytics: 'Ver Werf Analytics',
          pintoYourProfile: 'Fixe no seu perfil',
          editWerf: 'Editar Werf',
          explore: "Explorar",

          blockedAccounts: 'Contas bloqueadas',
          translations: 'Traduções',
          viewListOfBlockedAccounts: 'Ver lista de contas bloqueadas',
          realTimePostTranslation: 'Pós-tradução em tempo real',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'Selecione o idioma no momento de enviar um vídeo ou áudio',
          originalTranslatedScriptAudioPost:
              'Roteiro original ou traduzido da postagem de áudio',
          listenTranslatedScript: 'Ouça o roteiro traduzido',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Traduzir mensagens automaticamente no bate-papo no idioma selecionado pelos usuários',
          postedUpdate: 'postou uma atualização.',
          peopleWhoReacted: 'Pessoas que reagiram',
          comments: 'Comentários',
          peopleWhoRetweeted: 'Pessoas que retuitaram',
          leaveAComment: 'Deixe um comentário',
          post: 'Publicar',
          cancel: 'Cancelar',
          savePost: 'Salvar postagem',
          report: 'Relatório',
          hide: 'Esconder',
          shareLinkVia: 'Compartilhar link via ...',
          copyLink: 'Link de cópia',
          fieldRequired: 'Campo requerido',
          enterDescription: 'Insira a descrição',
          selectCategory: 'Selecione a Categoria',
          okay: 'OK,',
          pleaseWait: 'Por favor, espere...',
          search: 'Procurar',
          logout: 'Sair',
          writeSomethingHere: 'Escreva algo aqui',
          addMore: 'Adicione mais',
          image: 'Imagem',
          video: 'Vídeo',
          videos: 'Vídeos',
          file: 'Arquivo',
          gif: 'GIF',
          audio: 'Áudio',
          live: 'Ao vivo',
          doNotHaveAnAccount: "Não tem uma conta? ",
          register: 'Registro',
          haveAnAccount: "Ter uma conta? ",
          login: 'Conecte-se',
          whoToFollow: 'Quem seguir',
          noSuggestion: 'Sem sugestão',
          follow: 'Seguir',
          unFollow: 'Deixar de seguir',
          seeMore: 'Ver mais',
          searchFilter: 'Filtro de Pesquisa',
          people: 'Pessoas',
          fromAnyone: 'De qualquer um',
          peopleYouFollow: 'Pessoas que você segue',
          location: 'Localização',
          anywhere: 'Em qualquer lugar',
          nearYou: 'Perto de você',
          advancedSearch: 'Busca Avançada',
          trendsForYou: 'Tendências para você',
          noTrending: 'Não há tendências em sua região',
          trendingIn: 'Tendências em',
          // tweets: 'Tweets',
          noNotification: 'Não há notificações para você',
          refresh: 'atualizar',
          edit: 'Editar',
          save: 'Salve ',
          cFollow: 'Seguir',
          addPeople: 'Adicionar pessoas',
          someText: 'algum texto',
          reportConversation: 'Reportar conversa',
          leaveConversation: 'Deixar conversa',
          enterYourMessage: 'Digite sua mensagem',
          showMoreComments: 'Mostrar mais comentários',
          reBuzz: 'Rebuzz',
          noPosts: 'Sem atualizações para você',
          emailFieldCannotBeEmpty: 'O campo do email não pode estar vazio',
          emailFormatIsInvalid: 'O formato do email é inválido',
          rememberMe: 'Lembre de mim',
          lostPassword: 'Senha perdida?',
          cLOGIN: 'CONECTE-SE',
          emailOrPasswordIsIncorrect: 'E-mail ou senha está incorreto',
          newsFeed: 'Notícias',
          trends: 'Tendências',
          profile: 'Perfil',
          newMessage: 'Nova mensagem',
          next: 'Próxima',
          searchPeople: 'Pesquisar Pessoas',
          saySomething: 'Diga algo',
          noSearchResult: 'Nenhum resultado de pesquisa',
          searchResult: 'Resultado da pesquisa',
          hidePost: 'Esconder publicação',
          showLess: 'Mostre menos',
          showMore: 'Mostre mais',
          nothingYet: 'Nada ainda!',
          savedPosts: 'Postagens salvas',
          enterYourFirstName: 'Digite seu primeiro nome',
          enterYourLastName: 'Digite seu sobrenome',
          enterYourUsername: 'entre com seu nome de usuário',
          signUp: 'Inscrever-se',
          pleaseChooseACountry: 'Por favor escolha um país',
          replied: 'respondeu',
          reply: 'Responder',
          delete: 'Excluir',
          replyToComment: 'Responder para comentar',
          noFollower: 'Sem seguidor',
          following: 'Seguindo',
          followBack: 'Seguir de volta',
          followers: 'Seguidoras',
          follower: 'Seguidora',
          noFollowings: 'Sem seguimentos',
          sendAMessageGetAMessage: 'Envie uma mensagem, receba uma mensagem',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'Mensagens diretas são conversas privadas entre você e outras pessoas no Twitter. Compartilhe tweets, mídia e muito mais!',
          startAConversation: 'Inicie uma conversa',
          groupInfo: 'Informação do Grupo',
          chatInfo: 'Informações de bate-papo',
          youDoNotHaveAMessageSelected: 'Você não tem uma mensagem selecionada',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Escolha uma das mensagens existentes ou inicie uma nova.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'Por favor, insira o código de verificação para verificar seu e-mail',
          usernameOrEmail: 'Nome de usuário ou email',
          enterVerificationCode: 'Digite o código de verificação',
          confirmCode: 'Confirme o código',
          top: 'Principal',
          latest: 'Mais recentes',
          photos: 'Fotos',
          files: 'arquivos',
          noPeople: 'Ninguém',
          all: 'Tudo',
          mentions: 'Menções',
          replies: 'Respostas',
          // tweetsAndReplies: 'Tweets e Respostas',
          media: 'meios de comunicação',
          likes: 'Gosta',
          searchPost: 'Atualizações de pesquisa',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'Perdeu sua senha? Por favor, digite seu nome de usuário ou endereço de e-mail. Você receberá um link para criar uma nova senha por e-mail.',
          resetYourPassword: 'Redefina sua senha',
          enterCode: 'Coloque o código',
          enterNewPassword: 'Insira a nova senha',
          reEnterPassword: 'Digite novamente a senha',
          passwordCannotBeEmpty: 'A senha não pode estar vazia',
          passwordShouldBeCharacter: 'A senha deve ter 8 caracteres',
          passwordShouldBeMatched: 'A senha deve ser correspondida',
          resetPassword: 'Redefinir senha',
          email: 'O email',
          blockUser: 'Bloquear usuário',
          public: 'Pública',
          mentionUsers: 'Mencionar usuários',
          editProfile: 'Configurar Perfil',
          yourProfileIsUpdated: 'Seu perfil está atualizado',
          seeProfile: 'Ver Perfil',
          skipForNow: 'Pular por agora',
          addBio: 'Adicionar Bio',
          profileUpdated: 'Perfil atualizado',
          upDate: 'Atualizar',
          goToProfile: 'Vá para o perfil',
          more: 'Mais',
          about: 'Cerca de',
          help: 'Ajuda',
          privacyPolicy: 'Política de Privacidade',
          blog: 'Blog',
          termsOfService: 'Termos de serviço',
          youMustSelectACountry: 'Você deve selecionar um país',
          usernameIsAlreadyTaken: 'O nome de usuário já está em uso',
          goBack: 'Volte',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'Já foi criada uma conta com este e-mail',
          yourPasswordIsResetSuccessfully:
              'Sua senha foi redefinida com sucesso',
          returnToLogin: 'Retornar ao Login',
          youHaveEnteredAnInvalidCode: 'Você digitou um código inválido',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'Obrigado por criar sua conta no BuzznBee. Nossa equipe entrará em contato com você em 24 horas. Fique seguro!',
          success: 'Sucesso',
          goBackToHomePage: 'Volte para a página inicial',
        },
        'hi': {
          ok : 'ठीक है',
          timesThisWerfWasSeenOnWerfie :'कई बार यह वेयर्फ़ वेयरफ़ी पर देखा गया था',
          totalNumberOfTimesAUserHasInteractedWithAWerf: "किसी उपयोगकर्ता द्वारा किसी वेयरफ़ के साथ इंटरैक्ट किए जाने की कुल संख्या।",
          timesPeopleViewedTheDetailsAboutThisWerf : "टाइम्स लोगों ने इस वेयरफ के बारे में विवरण देखा",
          followsGainedDirectlyFromThisWerf : "इस वेयरफ़ से सीधे अनुसरण प्राप्त होता है",
          numberOfProfileViewsFromThisWerf : "इस वेयरफ़ से प्रोफ़ाइल दृश्यों की संख्या",
          deleteForEveryOne : 'सभी के लिए हटाएँ',
          photo : 'तस्वीर',
          emojis : 'emojis',
          uploadFile: 'फ़ाइल अपलोड करें',
          createPoll :'पोल बनाएं',
          scheduleWerf :"अनुसूची Werf",
          loginWithEmail : 'ईमेल से लॉगिन करें',
          usePhoneInstead :  "इसके बजाय फ़ोन का उपयोग करें",
          useEmailInstead : "इसके बजाय ईमेल का प्रयोग करें",
          noVerifiedFollower :'कोई सत्यापित अनुयायी नहीं',
          verifiedFollowers :  'सत्यापित अनुयायी',
          signUpToYourAccount : "अपने खाते में साइन अप करें",
          pleaseEnterYourName : 'कृपया अपना नाम दर्ज करें',
          werfieHandleErrorMessage : 'कृपया एक हैंडल दर्ज करें',
          emailErrorMessage : 'कृपया एक मान्य ईमेल दर्ज करें',
          werfieHandle : 'वेरफ़ी हैंडल',
          pleaseEnterAValidDOB :'कृपया एक वैध जन्मतिथि दर्ज करें',
          pleaseEnterDOB : 'जन्म तिथि (दिन/माह/वर्ष)',
          phone :'फ़ोन',
          suggestions : "सुझाव",
          customizeYourExperience : "अपने अनुभव को अनुकूलित करें",
          trackWhereYouSeeWerfieContentAcrossTheWeb : "ट्रैक करें कि आप वेब पर वेरफ़ी सामग्री कहाँ देखते हैं",
          werfieUsesThisDataToPersonalizeYourExperience : "Werfi आपके अनुभव को वैयक्तिकृत करने के लिए इस डेटा का उपयोग करता है। यह वेब ब्राउज़िंग इतिहास कभी भी आपके नाम, ईमेल या फ़ोन नंबर के साथ संग्रहीत नहीं किया जाएगा",
          werfieMayUseYourContactInformationIncludingYouEmail : "Werfie हमारी गोपनीयता नीति में उल्लिखित उद्देश्यों के लिए आपके ईमेल पते और फ़ोन नंबर सहित आपकी संपर्क जानकारी का उपयोग कर सकता है।",
          pleaseAgreeToWerfieTermsConditions: "कृपया वेरफ़ी के नियम एवं शर्तों से सहमत हों",
          createYourAccount :  "अपना खाता बनाएं",
          weSentYouACode : "हमने आपको एक कोड भेजा है",
          enterItBelowToVerify :"सत्यापित करने के लिए इसे नीचे दर्ज करें",
          didNotReceiveEmail : "ईमेल प्राप्त नहीं हुआ?",
          youWillNeedAPassword :"आपको एक पासवर्ड की आवश्यकता होगी",
          passwordMustBeCharactersLong:"पासवर्ड 8 अक्षर लंबा होना चाहिए, जिसमें कम से कम एक संख्या, एक बड़ा अक्षर और एक विशेष अक्षर शामिल हो।",
          pleaseEnterAValidEmail : 'कृपया एक मान्य ईमेल दर्ज करें',
          resend : "पुन: भेजें",
          google :"गूगल",
          apple :"सेब",
          worldNoor :"विश्वनूर",
          doNotMissWhatsHappening :"जो हो रहा है उसे मत चूकिए",
          peopleOnWerfieAreTheFirstToKnow :"वेरफ़ी के लोग सबसे पहले इसके बारे में जानते हैं",
          newToWerfie :  "वेर्फ़ी में नए हैं?",
          signUpNowToGetYourOwnPersonalizedTimeline :'अपनी व्यक्तिगत टाइमलाइन प्राप्त करने के लिए अभी साइन अप करें!',
          signUpWithGoogle :  "गूगल के साथ साइन अप करें",
          signUpWithApple :"सेब के साथ साइन अप करें",
          signUpWithEmailOrMobile : "ईमेल या मोबाइल से साइन अप करें",
          loginWithWorldNoor : "वर्ल्डनूर के साथ लॉगिन करें",
          bySigningUpYouAgreeOur : 'साइन अप करके, आप हमारी बात से सहमत हैं',
          trending :'रुझान',
          noUserNoTag : 'कोई उपयोगकर्ता नहीं && कोई टैग नहीं',
          noTrendsInThisRegion :'इस क्षेत्र में कोई रुझान नहीं',
          weAreExperiencingSomeDifficulties : "हमें कुछ कठिनाइयों का सामना करना पड़ रहा है. कृपया बाद में पुन: प्रयास करें",
          noPost : 'कोई पोस्ट नहीं',
          signInToYourAccount : "अपने अकाउंट में साइन इन करें",
          enterEmailPhone : "ईमेल/फ़ोन दर्ज करें",
          forgotPassword : "पासवर्ड भूल गए?",
          itSeemsLikeYouAreARobot: "ऐसा लगता है मानो आप कोई रोबोट हों. कृपया पुनः सत्यापित करें",
          signIn:  "दाखिल करना",
          registerHere: "यहां रजिस्टर करें!",
          orContinueWith: "या जारी रखें",
          somThingWentWrongWithConfiguration: "कॉन्फ़िगरेशन में कुछ गड़बड़ी हुई. कृपया पुन: प्रयास करें",
          error:"गलती",
          pleaseAllowEmailToContinueWithWerfie: "कृपया ईमेल को वेयरफ़ी के साथ जारी रखने की अनुमति दें",
          alert: "चेतावनी",
          sorryForTheInconvenience:"असुविधा के लिए खेद है। कृपया बाद में पुन: प्रयास करें।",
          enterDigitsVerificationCodeSentToYourRegisteredEmail: "आपके पंजीकृत ईमेल पर भेजा गया 6 अंकों का सत्यापन कोड दर्ज करें",

          theUsernameHasAlreadyBeenTaken : 'उपयोगकर्ता नाम पहले ही ले लिया गया है।',
          thereWasAnErrorInSavingThisUsername : "इस उपयोक्तानाम को सहेजने में त्रुटि हुई!",
          showMenu : 'मेनू दिखाओ',
          thisPollHasExpired : 'यह मतदान समाप्त हो गया है',
          youCannotVoteOnYourOwnPoll : 'आप अपने स्वयं के मतदान पर मतदान नहीं कर सकते!',
          choice : "पसंद",
          optionalPoll : "(वैकल्पिक)",

          watchPartyLetGo :  "पार्टी देखो, चलो चलते हैं",
          createSpace :'जगह बनाएं',
          oopsSomethingWentWrongPleaseTryAgain : 'ओह! कुछ गलत हो गया है! कृपया पुन: प्रयास करें',
          noSpacesAvailable : 'कोई स्थान उपलब्ध नहीं है',
          yourSpaceIsReady : "आपकी जगह तैयार है",
          spaceLinkCopiedSuccessfully : 'स्पेस लिंक सफलतापूर्वक कॉपी किया गया',
          instant : 'तुरंत',
          nameYourSpace : 'अपने स्थान को नाम दें',
          whatDoYouWantToTalkAbout :'आप किस बारे में बात करना चाहते हैं?',
          scheduleYourSpace : "अपना स्थान निर्धारित करें",
          confirm : 'पुष्टि करना',
          selectTopic : 'विषय चुनें',
          momentDeleteSuccessfully : "क्षण सफलतापूर्वक हटाया गया",
          createSpaceSuccessfully : "सफलतापूर्वक स्थान बनाएं",
          pleaseEnterTheSpaceName : "कृपया स्थान का नाम दर्ज करें",
          spaces : 'खाली स्थान',

          pleaseChooseEither1VideoOr1Pdf: "कृपया एक समय में 1 वीडियो या 1 पीडीएफ या अधिकतम 4 फ़ोटो चुनें।",
          fileTypeIsNotAllowed:'फ़ाइल प्रकार की अनुमति नहीं है',
          thisPostIsScheduledFor: "यह पोस्ट के लिए निर्धारित है",
          askAQuestion: 'प्रश्न पूछें...',
          pollLength:'मतदान की लंबाई',
          hours: 'घंटे',
          minutes:'मिनट',
          removePoll: 'पोल हटाएँ',
          uploading: 'अपलोड हो रहा है...',
          addDescription: "विवरण जोड़ें",
          willPostOn:  "पर पोस्ट करूंगा",
          date:'तारीख',
          youCannotScheduleAWerfInThePast: 'आप अतीत में एक Werf शेड्यूल नहीं कर सकते',
          time: 'समय',
          timeZone: 'समय क्षेत्र',
          youHaveNoScheduledWerfs: 'आपके पास कोई शेड्यूल किया गया वेयरफ़ नहीं है',
          willSendOn:  "आगे भेज देंगे",
          selectAll: 'सबका चयन करें',
          schedule: 'अनुसूची',
          scheduledWerfs: 'अनुसूचित Werfs',
          deselectAll: 'सबको अचयनित करो',
          yourImageVideoWillBeAvailableInAMoment: 'आपकी छवि/वीडियो कुछ ही देर में उपलब्ध हो जाएगी.',
          pleaseEnterValidText: 'कृपया मान्य पाठ दर्ज करें',
          takeAPhoto: "एक तस्वीर लें",
          chooseFromGallery:  "गैलरी से चयन करो",
          makeVideoWithPhoneCamera: "फ़ोन कैमरे से वीडियो बनाएं",
          unsentWerfs: 'अनसेंड वर्फ़्स',

          commentsHere:'टिप्पणियाँ यहाँ',
          ImageDescription : 'चित्र का वर्णन',
          viewHiddenReplies: 'छिपे हुए उत्तर देखें',
          undoRewerf: 'रीवर्फ़ को पूर्ववत करें',
          share:  "शेयर करना",
          view:  "देखना",
          werfLinkCopiedSuccessfully: "Werf लिंक सफलतापूर्वक कॉपी किया गया",
          addBookmark: "बुकमार्क जोड़ें",
          removeBookmark: "बुकमार्क हटाएँ",
          werfSavedSuccessfully: 'वेर्फ़ सफलतापूर्वक सहेजा गया!',
          werfUnsavedSuccessfully:  'Werf सफलतापूर्वक सहेजा नहीं गया!',
          thereWasAnErrorInUnSavingThisWerf: 'इस वेयरफ़ को सहेजने में त्रुटि हुई!',
          thereWasAnErrorInSavingThisWerf:'इस वेयरफ़ को सहेजने में त्रुटि हुई!',
          thereWasAnErrorInBlockingThisUser:'इस उपयोगकर्ता को ब्लॉक करने में त्रुटि हुई!',
          noEditHistory: 'कोई संपादन इतिहास नहीं',
          unPinFromProfile: "प्रोफ़ाइल से अनपिन करें",
          saveWerf: 'वेर्फ़ को बचाएं',
          linkCopiedToClipBoard:  'लिंक क्लिपबोर्ड पर कॉपी किया गया!',
          removeFromBookmarks: 'बुकमार्क से हटाएँ',
          thereWasAnErrorInReportingThisUser: 'इस उपयोगकर्ता को रिपोर्ट करने में त्रुटि हुई!',
          viewOriginal: "मूल",
          showThisThread:'यह धागा दिखाओ',
          rewerf : 'Rewerf',

          werfAnalytics : "वेर्फ़ एनालिटिक्स",
          nothingFound:'कुछ भी नहीं मिला',
          year:'वर्ष',
          day : 'दिन',
          month : 'महीना',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "यह खाते का उपयोग करने वाले व्यक्ति की जन्मतिथि होनी चाहिए। भले ही आप अपने व्यवसाय या ईवेंट के लिए खाता बना रहे हों।",
          editDateOfBirth : 'जन्मतिथि संपादित करें?',
          deletePhoto :"फोटो हटाएं",
          removePhoto : "फ़ोटो हटाएँ",
          addPhoto :"तस्वीर जोड़ो",
          discard : "खारिज करना",
          removeWerfAlert :
          "इसे पूर्ववत नहीं किया जा सकता और आप अपने परिवर्तन खो देंगे",
          discardChanges : "परिवर्तनों को निरस्त करें?",
          youShouldBeAtLeast14YearsOld: 'आपकी आयु कम से कम 14 वर्ष होनी चाहिए',
          contentOfDialog :"संवाद की सामग्री",
          pinnedWerf : "पिन किया हुआ वेर्फ़",
          hiddenPost : "छुपे हुए वेयरफ़्स",
          thisCanBeOnlyChangedAFewTimes :" इसे केवल कुछ ही बार बदला जा सकता है. सुनिश्चित करें कि आपने खाते का उपयोग करने वाले व्यक्ति की आयु दर्ज की है",


          aboutHashTag : 'हैशटैग के बारे में',
          werfHashTag : 'वेर्फ़ हैशटैग',
          messageRequests : 'संदेश अनुरोध',
          enterGroupChatTitle:  "समूह चैट शीर्षक दर्ज करें",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'अपनी मौजूदा चैट में से एक चुनें, या एक नई चैट शुरू करें',
          snoozeNotificationsFrom :  "से सूचनाएं स्नूज़ करें",
          snoozeNotificationsFromTheGroup : "समूह से सूचनाएं स्नूज़ करें",
          snoozeMentions : "उल्लेखों को स्नूज़ करें",
          disableNotificationsWhenPeoplemention:"जब लोग इस वार्तालाप में आपका उल्लेख करें तो सूचनाएं अक्षम करें।",
          trySearchingForPeopleGroupsOrMessages : "लोगों, समूहों या संदेशों को खोजने का प्रयास करें",
          werfieUser :  "वेरफ़ी उपयोगकर्ता",
          otherChat :"अन्य...",
          photoChat : 'तस्वीर',
          videoChat : 'वीडियो',
          fileChat : 'फ़ाइल',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'प्रत्यक्ष संदेश आपके और ट्विटर पर अन्य लोगों के बीच निजी बातचीत हैं। ट्वीट, मीडिया और बहुत कुछ साझा करें!',
          searchChats : "चैट खोजें",
          allTabChat : "सभी",
          peopleTabChat : "लोग",
          groupsTabChat :"समूह",
          chatsTabChat :"चैट",
          noResultsFor : "के लिए कोई परिणाम नहीं",
          theTermYouEnteredDidNotBring : "आपके द्वारा दर्ज किया गया शब्द कोई परिणाम नहीं लाया",
          message : "संदेश",
          addMembersToChat : 'चैट में सदस्यों को जोड़ें',
          noMessagesYet : "अभी तक कोई संदेश नहीं",
          doNotAllowMessages : "संदेशों की अनुमति न दें",
          notAllowedToMessage : "संदेश भेजने की अनुमति नहीं है.",
          youHaveBlockedThisUser : "आपने इस उपयोगकर्ता को ब्लॉक कर दिया है",
          startAMessage :  "एक संदेश प्रारंभ करें",
          react :  "प्रतिक्रिया",
          undo : "पूर्ववत",
          reactions : 'प्रतिक्रियाओं',
          messageRequestsFallHere :
          "जिन लोगों को आप फ़ॉलो नहीं करते उनसे संदेश अनुरोध यहां लाइव होते हैं। वहां संदेश का उत्तर देने के लिए, आपको अनुरोध स्वीकार करना होगा।",
          noMessageRequestAvailable : 'कोई संदेश अनुरोध उपलब्ध नहीं है',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'आपके द्वारा चुनी गई सेटिंग के आधार पर, अलग-अलग लोग आपको सीधा संदेश भेज सकते हैं।',

          allowMessagesOnlyFromPeopleYouFollow :
          'केवल उन्हीं लोगों के संदेशों को अनुमति दें जिनका आप अनुसरण करते हैं',
          youWontReceiveAnyMessageRequests :
          "आपको कोई संदेश अनुरोध प्राप्त नहीं होगा",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "केवल सत्यापित उपयोगकर्ताओं से संदेश अनुरोधों की अनुमति दें",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "जिन लोगों को आप फ़ॉलो करते हैं वे अब भी आपको संदेश भेज सकेंगे",
          allowMessagesRequestsFromEveryone :
          'सभी के संदेश अनुरोधों को अनुमति दें',
          otherControls : "अन्य नियंत्रण",
          filterLowQualityMessages : "निम्न गुणवत्ता वाले संदेशों को फ़िल्टर करें",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "उन संदेश अनुरोधों को छुपाएं जो संभावित रूप से लंबे या निम्न-गुणवत्ता वाले पाए गए हैं। इन्हें आपके संदेश अनुरोधों के नीचे एक अलग इनबॉक्स में भेजा जाएगा। यदि आप चाहें तो आप अभी भी उन तक पहुंच सकते हैं",
          showReadReceipts : "पढ़ी गई रसीदें दिखाएँ",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "जिन लोगों को आप संदेश भेज रहे हैं उन्हें बताएं कि आपने उनके संदेश कब देखे हैं। संदेश अनुरोधों पर पढ़ी गई रसीदें नहीं दिखाई जाती हैं",


          getPushNotificationsToFindOut :"जब आप वेरफ़ी पर नहीं हों तो क्या हो रहा है, यह जानने के लिए पुश सूचनाएँ प्राप्त करें। आप इन्हें किसी भी समय बंद कर सकते हैं.",
          relatedToYouAndYourWerfs :"आपसे और आपके Werfs से संबंधित",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "जब आप जिन लोगों को फ़ॉलो करते हैं उनसे Werf सूचनाएं चालू करते हैं, तो आपको उनके Werfs के बारे में पुश सूचनाएं प्राप्त होंगी।",
          topWerfs :"शीर्ष वेयरफ़्स",
          tailoredForYou: "खास आपके लिए तैयार",
          rewerf : 'Rewerf',
          like : 'पसंद',
          photoTags : "फोटो टैग",
          messageReactions : "संदेश प्रतिक्रियाएँ",
          fromWerfie : "वेरफ़ी से",
          newsSports : "समाचार/खेलकूद",
          recommendations : "सिफारिशों",
          turnOnPush:"पुश\nसूचनाएं चालू करें",
          toReceiveNotificationsAsTheyHappen :"सूचनाएं मिलते ही प्राप्त करने के लिए, पुश नोटिफिकेशन चालू करें, आप उन्हें तब भी प्राप्त करेंगे जब आप वेरफ़ी पर नहीं होंगे। इन्हें किसी भी समय बंद कर दें.",
          turnOn : "चालू करो",
          newNotifications :  "नई सूचनाएं",
          werfsEmailedToYou : "Werfs ने आपको ईमेल किया है",
          weekly : 'साप्ताहिक',
          newAboutWerfieProduct :"Werfie उत्पाद और सुविधाओं के अपडेट के बारे में नया",
          tipsOnGettingMoreOut: "वेर्फ़ी से और अधिक लाभ प्राप्त करने के लिए युक्तियाँ",
          thingsYouMissedSinceYou: "वे चीज़ें जो आप पिछली बार वेरफ़ी में लॉग इन करने के बाद से चूक गए थे",
          participationInWerfieResearchSurveys: "वेरफ़ी अनुसंधान सर्वेक्षणों में भागीदारी",
          suggestionsRorRecommendedAccounts: "अनुशंसित खातों के लिए सुझाव",
          suggestionsBasedOnYourRecentFollows: "आपके हालिया अनुसरणों के आधार पर सुझाव",
          qualityFilters : "गुणवत्ता फिल्टर",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"डुप्लिकेट और स्वचालित Werfs जैसी सामग्री को फ़िल्टर करना चुनें। यह उन खातों की सूचनाओं पर लागू नहीं होता है जिन्हें आप फ़ॉलो करते हैं और जिनके साथ आपने हाल ही में इंटरैक्ट किया है।",

          emailNotification : 'ईमेल सूचनाएं',
          filters : "फिल्टर",
          chooseTheNotification : "वह अधिसूचना चुनें जिसे आप देखना चाहते हैं और जिसे आप नहीं देखना चाहते हैं",
          preferences : "पसंद",
          selectYourPreferencesByNotificationType :"अधिसूचना प्रकार के अनुसार अपनी प्राथमिकताएँ चुनें।",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie आपको अधिक प्रासंगिक सामग्री दिखाने में सहायता के लिए हमेशा कुछ जानकारी का उपयोग करता है, जैसे कि आपने कहां साइन अप किया था और आपका वर्तमान स्थान। जब यह सेटिंग सक्षम होती है, तो Werfie आपके अनुभव को उन अन्य स्थानों के आधार पर भी वैयक्तिकृत कर सकता है जहां आप गए हैं।',

          personalizeBasedOnPlacesYouHaveBeen :
          'आप जिन स्थानों पर गए हैं उनके आधार पर वैयक्तिकृत करें',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'आपके अनुभव को वैयक्तिकृत करने के लिए Werfie द्वारा उपयोग की जाने वाली स्थान जानकारी प्रबंधित करें।',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "जिन लोगों को आप संदेश भेज रहे हैं उन्हें बताएं कि आपने उनके संदेश कब देखे हैं। संदेश अनुरोधों पर पढ़ी गई रसीदें नहीं दिखाई जाती हैं",

          showReadReceipts : "पढ़ी गई रसीदें दिखाएँ",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "उन संदेश अनुरोधों को छुपाएं जो संभावित रूप से लंबे या निम्न-गुणवत्ता वाले पाए गए हैं। इन्हें आपके संदेश अनुरोधों के नीचे एक अलग इनबॉक्स में भेजा जाएगा। यदि आप चाहें तो आप अभी भी उन तक पहुंच सकते हैं",


          filterLowQualityMessages :"निम्न गुणवत्ता वाले संदेशों को फ़िल्टर करें",
          otherControls : "अन्य नियंत्रण",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "जिन लोगों को आप फ़ॉलो करते हैं वे अब भी आपको संदेश भेज सकेंगे",
          allowMessagesRequestsFromEveryone :
          'सभी के संदेश अनुरोधों को अनुमति दें',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "जिन लोगों को आप फ़ॉलो करते हैं वे अब भी आपको संदेश भेज सकेंगे",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "केवल सत्यापित उपयोगकर्ताओं से संदेश अनुरोधों की अनुमति दें",
          youWontReceiveAnyMessageRequests :
          "आपको कोई संदेश अनुरोध प्राप्त नहीं होगा",
          allowMessagesOnlyFromPeopleYouFollow :
          'केवल उन्हीं लोगों के संदेशों को अनुमति दें जिनका आप अनुसरण करते हैं',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'आपके द्वारा चुनी गई सेटिंग के आधार पर, अलग-अलग लोग आपको सीधा संदेश भेज सकते हैं।',

          controlWhoCanMessageYou : 'नियंत्रित करें कि कौन आपको संदेश भेज सकता है',
          forever : " हमेशा के लिए",
          muteNotificationsFromPeople :"लोगों की सूचनाएं म्यूट करें:",
          youDoNotFollow : "आप अनुसरण नहीं करते",
          whoDoNotFollowYou : "जो आपको फॉलो नहीं करते",
          withANewAccount : "नये खाते के साथ",
          whoHaveDefaultProfilePhoto :"जिनके पास डिफॉल्ट प्रोफाइल फोटो है",
          whoHaveNotConfirmedTheirEmail : "जिन्होंने अपने ईमेल की पुष्टि नहीं की है",
          whoHaveNotConfirmedTheirPhoneNumber :"जिन्होंने अपने फ़ोन नंबर की पुष्टि नहीं की है",
          duration : 'अवधि',
          untilYouUnmuteTheWord : 'जब तक आप शब्द को अनम्यूट नहीं करते',
          hours24 : 'चौबीस घंटे',
          days7 : '7 दिन',
          days30 : 'तीस दिन',
          fromPeopleYouDontFollow : "उन लोगों से जिन्हें आप फ़ॉलो नहीं करते",
          homeTimeline : 'होम टाइमलाइन',
          muteFrom : 'से म्यूट करें',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'आप एक समय में एक शब्द,@उपयोगकर्ता नाम, या हैशटैग को म्यूट कर सकते हैं।',
          enterWordOrPhrase : 'शब्द या वाक्यांश दर्ज करें',
          mutedWord : 'मौन शब्द',
          addMutedWords : 'म्यूट शब्द जोड़ें',
          youHaveNotMutedAnyWordYet : 'आपने अभी तक कोई भी शब्द म्यूट नहीं किया है',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "जब आप शब्दों को म्यूट करते हैं, तो आपको Werfs के लिए कोई नई सूचना नहीं मिलेगी जिसमें वे शामिल हों या अपनी होम टाइमलाइन में उन शब्दों के साथ Werfs न देखें।",

          youHaveNotMutedAnyPersonYet :
          'आपने अभी तक किसी भी व्यक्ति को म्यूट नहीं किया है',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "यहां वे सभी लोग हैं जिन्हें आपने म्यूट किया है। आप उन्हें इस सूची से हटा सकते हैं।",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "जब आप किसी को ब्लॉक करते हैं, तो वह व्यक्ति आपको फ़ॉलो या मैसेज नहीं कर पाएगा और आप उसकी अधिसूचना नहीं देख पाएंगे।",

          mutedNotification : 'म्यूट की गई सूचनाएं',
          mutedWords: 'मौन शब्द',
          mutedAccounts : 'म्यूट किए गए खाते',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'उन खातों, शब्दों और सूचनाओं को प्रबंधित करें जिन्हें आपने म्यूट या ब्लॉक किया है।',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'यह Werfs को आपके खोज परिणामों में संभावित रूप से संवेदनशील सामग्री प्रदर्शित होने से रोकता है।',

          hideSensitiveContent: 'संवेदनशील सामग्री छिपाएँ',
          removeBlockedAndMutedAccounts :
          'अवरुद्ध और मौन खाते हटाएँ',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'आपके द्वारा ब्लॉक किए गए या म्यूट किए गए खाते से खोज परिणाम हटाने के लिए इसका उपयोग करें',
          personalization : 'वैयक्तिकरण',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'आप अपने स्थान और आप किसे फ़ॉलो करते हैं, उसके आधार पर रुझानों को वैयक्तिकृत कर सकते हैं',
          exploreLocation : 'स्थान का अन्वेषण करें',
          showContentInThisLocation : 'इस स्थान पर सामग्री दिखाएँ',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'जब यह चालू होगा, तो आप देखेंगे कि इस समय आपके आसपास क्या हो रहा है।',
          searchSettings  :'खोज सेंटिंग',
          exploreSettings : 'सेटिंग्स का अन्वेषण करें',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'विषयों जैसी अपनी प्राथमिकताओं के आधार पर तय करें कि आप वेयरफ़ी पर क्या देखते हैं',
          displayMediaThatMayContainSensitiveContent :
          'संवेदनशील सामग्री हो सकती है मीडिया को दिखाये',
          addLocationInformationToYourWerfs :'अपने Werfs में स्थान की जानकारी जोड़ें',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "सक्षम होने पर, आपके चित्र और वीडियो को उन लोगों के लिए संवेदनशील के रूप में चिह्नित किया जाएगा जो संवेदनशील सामग्री नहीं देखना चाहते हैं।",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'मीडिया यू वेर्फ़ को ऐसी सामग्री के रूप में चिह्नित करें जो संवेदनशील हो सकती है',
          manageTheInformationAssociatedWithYourWerfs :
          'अपने Werfs से जुड़ी जानकारी प्रबंधित करें।',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'यदि सक्षम किया गया है, तो आप अपने Werfs में स्थान संलग्न करने में सक्षम होंगे।',
          removeAllLocationInformationAttachedToYourWerfs :
          'अपने Werfs से जुड़ी सभी स्थान जानकारी हटा दें',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'आपके द्वारा अपने Werfs में जोड़े गए स्थान लेबल अब Werfie.com, IOS के लिए Werfie और Android के लिए Werfie पर दिखाई नहीं देंगे। इन अद्यतनों को प्रभावी होने में कुछ समय लग सकता है।',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'प्रबंधित करें कि आप Werfie पर अन्य लोगों को कौन सी जानकारी की अनुमति देते हैं।',
          protectYourTweets : 'अपने Werfs को सुरक्षित रखें',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'चयनित होने पर, आपकी वेयरफ़ी और खाता जानकारी केवल उन लोगों को दिखाई देती है जो आपका अनुसरण करते हैं',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'इससे वे केवल आपके वेयरफ़ी फ़ॉलोअर्स को ही दिखाई देंगे',
          protect : 'रक्षा करना',
          photoTagging : 'फोटो टैगिंग',
          AnyoneCanTagYou : 'कोई भी आपको टैग कर सकता है',
          onlyPeopleYouFollowCanTagYou:
          'केवल वे लोग जिन्हें आप फ़ॉलो करते हैं वे ही आपको टैग कर सकते हैं',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'लोगों को अपनी तस्वीरों में आपको टैग करने की अनुमति दें और जब वे ऐसा करें तो सूचनाएं प्राप्त करें',
          AnyoneCanTagYou : 'कोई भी आपको टैग कर सकता है',
          onlyPeopleYouFollowCanTagYou : 'केवल वे लोग जिन्हें आप फ़ॉलो करते हैं वे ही आपको टैग कर सकते हैं',
          security : 'सुरक्षा',
          manageYourAccountsSecurity : "अपने खातों की सुरक्षा प्रबंधित करें",
          twoFactorAuthentication : "दो तरीकों से प्रमाणीकरण",
          manageYourAccountsSecurityKeepTrack : "अपने खाते की सुरक्षा प्रबंधित करें और अपने खाते के उपयोग पर नज़र रखें",
          helpProtectYourAccountFromUnauthorizedAccess :  "अपने एक्स पासवर्ड के अतिरिक्त दूसरी प्रमाणीकरण विधि की आवश्यकता के द्वारा अपने खाते को अनधिकृत पहुंच से सुरक्षित रखने में सहायता करें। आप एक टेक्स्ट संदेश, प्रमाणीकरण ऐप या सुरक्षा कुंजी चुन सकते हैं।",
          verificationCodeSentToYourRegisteredEmail:"आपके पंजीकृत ईमेल पर भेजा गया 6 अंकों का सत्यापन कोड दर्ज करें",
          submit :'जमा करना',
          genderChangedSuccessfully : "लिंग सफलतापूर्वक बदला गया",
          genderSettingTextDescription :"यदि आपने पहले से कोई लिंग निर्दिष्ट नहीं किया है, तो यह आपकी प्रोफ़ाइल और गतिविधि के आधार पर आपके खाते से जुड़ा लिंग है। यह जानकारी सार्वजनिक रूप से प्रदर्शित नहीं की जाएगी.",
          male:  'पुरुष',
          female : 'महिला',
          other : 'अन्य',
          change:'परिवर्तन',
          changeCountrySettings:'देश बदलें',
          selectACountry:'कोई देश चुनें',
          updateEmailAddress:'ईमेल पता अपडेट करें',
          current:'मौजूदा',
          changeEmailSetting:'बदले ई - मेल',
          gender:'लिंग',
          accountCreation:'खाता निर्माण',
          Age:'आयु',
          securityAndAccountAccess:'सुरक्षा और खाता पहुंच',
          youHaveNotCreatedOrFollowedAnyLists: "आपने कोई सूची नहीं बनाई या उसका अनुसरण नहीं किया है. जब आप ऐसा करेंगे, तो वे यहां दिखाई देंगे।",
          userCanPinnedOnly5  : 'यूजर केवल 5 को ही पिन कर सकता है',
          pleaseEnterTheName  : 'कृपया नाम दर्ज करें',
          list : 'सूचियों',
          listYouAre :"जिन सूचियों पर आप हैं",
          listYouHave:"आपको अभी तक किसी भी सूची में नहीं जोड़ा गया है",
          listAddedSomeOne:"जब कोई आपको किसी सूची में जोड़ता है, तो यह यहां दिखाई देगा",
          listMembers :'सदस्यों की सूची बनाएं',
          listFollowers  : 'अनुयायियों की सूची बनाएं',
          noMembers: 'कोई सदस्य नहीं',
          noResults :'कोई परिणाम नहीं',
          noFollowers:'कोई अनुयायी नहीं',
          manageWhatInformationYouSeeAndShareOnWerfie: 'प्रबंधित करें कि आप वर्फी पर कौन सी जानकारी देखते हैं और साझा करते हैं।',
          noResponseFromServerMsg: 'हमें कुछ कठिनाइयों का सामना करना पड़ रहा है. कृपया बाद में पुन: प्रयास करें',
          filteredResult:'फ़िल्टर किया गया परिणाम',
          forYou:'आपके लिए',
          noInternetAvailable:'कोई इंटरनेट उपलब्ध नहीं!',
          welcomeToWerfie:'वर्फ़ी में आपका स्वागत है',
          welcomeToWerfie:'वर्फ़ी में आपका स्वागत है',
          cantChooseEmailAsApass:
          "आप ईमेल को पासवर्ड के रूप में नहीं चुन सकते, कृपया कोई सुरक्षित पासवर्ड चुनें",
          passMustContainUpperCaseAndLeeter:
          'पासवर्ड में कम से कम एक बड़ा अक्षर और एक नंबर होना चाहिए',
          bothPasswordAndConfirmPassShouldMatch:
          'पासवर्ड और कन्फर्म पासवर्ड दोनों मेल खाने चाहिए',
          DidNoTReceiveCode: "कोड प्राप्त नहीं हुआ?",
          verificationCode: 'सत्यापन कोड',
          enterYourNewPasswordHint: 'अपना नया पासवर्ड दर्ज करें',
          ChangePasswordSettings: 'पासवर्ड बदलें',
          trendingUpdates: 'रुझान वाले अपडेट',
          dobAddMsg: 'अपनी जन्मतिथि को अपने साथ जोड़ें ',
          audienceAndTagging: 'श्रोतागण और टैगिंग',
          LearnMoreAboutPrivacyOnWerfie:
              'वर्फी पर गोपनीयता के बारे में और जानें',
          yourWerfieActivity: 'आपकी वरफ़ी गतिविधि',
          yourAndTagging: 'आपका और टैगिंग',
          yourWerfs: 'आपके वर्फ्स',
          contentYouSee: "आप जो सामग्री देखते हैं",
          muteAndBlock: 'म्यूट करें और ब्लॉक करें',
          directMessages: 'सीधा संदेश',
          dataSharingAndPersonalization: 'डेटा साझाकरण और वैयक्तिकरण',
          locationInformation: 'स्थिति सूचना',
          nameCannotBeEmpty: "नाम आवश्यक है",
          nameLengthShouldMax20: "नाम की लंबाई 20 से अधिक नहीं होनी चाहिए",
          nameStartsWithCharacter: "नाम अक्षर से शुरू होना चाहिए",
          pleaseProvideAValidEmail: "कृपया सही ईमेल पता बताएं",
          werfieHandleIsRequired: "वर्फी हैंडल की आवश्यकता है",
          passwordShouldBeMin8Char: 'पासवर्ड कम से कम 8 अक्षर लंबा होना चाहिए',
          pleaseEnterYourBirthDate: 'अपनी जन्मतिथि भरें',
          enterYourBirthDateOptional: 'अपनी जन्मतिथि दर्ज करें (वैकल्पिक)',
          rewerf: 'रिवर्फ़',
          topicsThatYouFollowShownHere:
              'जिन विषयों का आप अनुसरण करते हैं वे यहां दिखाए गए हैं। वे सभी चीज़ें देखने के लिए जिनमें वेरफ़ी के अनुसार आपकी रुचि है, अपना वर्फी डेटा देखें। आप निम्नलिखित विषयों के बारे में और भी जान सकते हैं।',
          bySigningUpYouAgree: 'साइन अप करके, आप हमसे सहमत हैं,',
          and: 'और',
          privacyUpdated: 'गोपनीयता अपडेट की गई',
          removeWerfFromBookMark: 'बुकमार्क से वर्फ हटाएँ',
          areYouSure: 'क्या आपको यकीन है?',
          doYouWantToExit: 'क्या आप ऐप से बाहर निकलना चाहते हैं',
          no: 'नहीं',
          yes: 'हाँ',
          werfUnsaved: 'वेर्फ़ सफलतापूर्वक सहेजा नहीं गया!',
          private: 'निजी बनाना',
          name: 'नाम',
          bio: "बायो",
          birthDate: 'जन्म तिथि',
          create: 'बनाएं',
          weWontSuggestThisTopic: "हम अब इस विषय का सुझाव नहीं देंगे",
          youllSeeTopWerfs:
              "आप सीधे अपनी होम टाइमलाइन में इनके बारे में शीर्ष वेयर्फ़ देखेंगे",
          requestVerification: 'सत्यापन का अनुरोध करें',
          enterCurrentPassword: 'वर्तमान पासवर्ड दर्ज करें',
          enterYourNewPassword:
              "अपना नया पासवर्ड डालें और नेक्स्ट बटन दबाएँ। हम आपको आपके ईमेल पते पर 6 अंकों का कोड भेजेंगे। प्रक्रिया पूरी करने के लिए आपको अगली स्क्रीन पर वह 6 अंकों का कोड दर्ज करना होगा।",
          noWerfs: 'कोई वर्फ नहीं',
          verified: 'सत्यापित',
          getMoments: 'क्षण प्राप्त करें',
          tweetsAndReplies: 'वर्फ्स और उत्तर',
          yourlist: 'आपकी सूचियाँ',
          copyProfileLink: 'प्रोफ़ाइल लिंक कॉपी करें',
          signInWithApple: 'Apple के साथ साइन इन करें',
          searchForAnItem: 'कोई आइटम खोजें...',
          changedTheCountryName: 'देश का नाम सफलतापूर्वक बदला!',
          editOrder: 'क्रम संपादित करें',
          ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
              'इसे पूर्ववत नहीं किया जा सकता है और इसे आपकी प्रोफ़ाइल, आपको फ़ॉलो करने वाले किसी भी खाते की टाइमलाइन और वेरफ़ी खोज परिणामों से हटा दिया जाएगा।',
          writeAShortDesc: 'क्षणों के बारे में संक्षिप्त विवरण लिखें',
          addATitle: 'एक शीर्षक जोड़ें',
          publish: 'प्रकाशित करना',
          likedBy: 'द्वारा पसंद किया गया ',
          werfSearch: 'वर्फ्स खोज',
          werfsByAccount: "खाते द्वारा वर्फ़्स",
          werfsILiked: "शब्द जो मुझे पसंद आये",
          addWerfs: 'वर्फ़्स जोड़ें',
          allReply: 'सभी उत्तर दें',
          replyingTo: 'जवाब दे रहे है ',
          werfYourReply: 'अपना उत्तर दें...',
          noMomentsList: 'कोई क्षण नहीं',
          justNow: 'अभी किया',
          clear: 'साफ़',
          createANewWerf: 'एक नया वर्फ बनाएं',
          suggestedTopics: 'सुझाए गए विषय',
          whenYouFollowMsg:
              "जब आप किसी सूची का अनुसरण करते हैं, तो आप जिस चीज़ की सबसे अधिक परवाह करते हैं उस पर तुरंत विशेषज्ञों से संपर्क कर पाएंगे।",
          chooseYourLists: 'अपनी सूचियाँ चुनें',
          discoverlist: 'नई सूचियाँ खोजें',
          pinnedList: "पिन की गई सूची",
          createNew: 'नया निर्माण',
          chooseAnExistingMomentOrCreateNew: 'मौजूदा क्षण चुनें या नया बनाएं',
          seizeTheMoment: 'इस पल को सीज़ करे|',
          momentDeleteSuccessfully: 'क्षण सफलतापूर्वक हटा दिया गया',
          createMoment: 'क्षण बनाएँ',
          removeMomentAlertMsg:
              'इसे पूर्ववत नहीं किया जा सकता और आप अपना क्षण खो देंगे।',
          momentsDelete: 'क्षण हटाएं?',
          nothingToSeeHere: 'यहाँ देखने के लिए कुछ नहीं है',
          nothingToSeeHerePinYour:
              'यहां अभी तक देखने के लिए कुछ भी नहीं है - अपनी पसंदीदा सूचियों तक तुरंत पहुंचने के लिए उन्हें पिन करें।',
          viewHiddenReply: 'छिपा हुआ उत्तर देखें',
          block: 'ब्लॉक',
          chooseOneFromYourExistingChatsOrStartANewOne:
              'अपनी मौजूदा चैट में से एक चुनें, या एक नई चैट शुरू करें',
          youDoNotHaveAChatSelected: 'आपके पास कोई चैट चयनित नहीं है',
          editGroup: 'समूह संपादित करें',
          colors: 'रंग',
          dark: "गहरा",
          light: "हल्का",
          theseSettingsAffect:
              "ये सेटिंग्स इस ब्राउज़र पर सभी Werfie खातों को प्रभावित करती हैं।",
          customizeView: 'अपना दृश्य अनुकूलित करें',
          dismiss: 'नकार देना',
          thisWerfSeen: 'कई बार यह वर्फ देखा गया था।',
          youHaveAlreadyReportedWerf:
              'आप पहले ही इस वर्फ की रिपोर्ट कर चुके हैं',
          enterDescriptionFieldIsRequired: "विवरण फ़ील्ड दर्ज करना आवश्यक है",
          searchLocation: 'स्थान खोजें',
          tagLocation: 'स्थान टैग करें',
          profileVisits: 'प्रोफ़ाइल विज़िट',
          newFollowers: 'नए अनुयायियों',
          detailExpands: 'विवरण का विस्तार',
          engagements: 'संलग्नताएँ',
          followed: 'फॉलो किये गए',
          notInterested: 'रुचि नहीं',
          suggested: 'सुझाव दिया',
          add: 'जोड़े',
          remove: 'निकालना',
          members: 'सदस्यों',
          whenYouMakeAList:
              'जब आप किसी सूची को निजी बनाते हैं, तो केवल आप ही उसे देख सकते हैं।',
          makePrivate: 'निजी बनाना',
          createNewList: 'नई सूची बनाएं',
          next: 'अगला',
          done: 'पूर्ण',
          editList: 'संपादन सूची',
          manageMembers: 'सदस्यों को प्रबंधित करें',
          delete: 'मिटाए',
          listYouAreON: "जिन सूचियों पर आप हैं",
          newsSocial: 'समाचार',
          filmTV: 'मनोरंजन',
          music: 'संगीत',
          travelAdventure: 'यात्रा',
          newChat: 'नई चैट',
          noMsgsYet: 'अभी तक कोई संदेश नहीं',
          addToYourList: 'अपनी सूची में जोड़ें',
          theTopicsYouFollow:
              "आपके द्वारा अनुसरण किए जाने वाले विषयों का उपयोग आपके द्वारा देखे जाने वाले वर्फ्स, ईवेंट और विज्ञापनों को वैयक्तिकृत करने और आपकी प्रोफ़ाइल पर सार्वजनिक रूप से दिखाने के लिए किया जाता है",
          verification: 'सत्यापन',
          verificationAccount: 'खाता सत्यापन',
          country: 'देश',
          userNameSavedSuccessfully: 'उपयोगकर्ता नाम सफलतापूर्वक सहेजा गया!',
          deactivateAccount: 'खाता निष्क्रिय करें',
          off: 'बंद',
          daily: 'प्रतिदिन',
          topWerfs: 'शीर्ष वर्फ्स',
          getEmailToFindOut:
              'जब आप वेरफ़ी पर नहीं हों तो क्या हो रहा है, यह जानने के लिए ईमेल प्राप्त करें। आप इन्हें किसी भी समय बंद कर सकते हैं.',
          pushNotifications: 'पुश नोटीफिकेशन',
          otpSentMsg:
              "हमने अभी आपके ईमेल पते पर 6 अंकों का कोड भेजा है। उस कोड को नीचे दी गई जगह पर डालें और कन्फर्म बटन दबाएँ",
          sendViaDirectMessage: 'सीधे संदेश के माध्यम से भेजें',
          shareWerf: 'वर्फ साझा करें',
          copylinkToWerf: 'वर्फ पर लिंक कॉपी करें',
          pickWhoCanReplyMsg:
              "चुनें कि इस Werf का उत्तर कौन दे सकता है। ध्यान रखें कि उल्लिखित कोई भी व्यक्ति हमेशा उत्तर दे सकता है।",
          whoCanReply: 'कौन उत्तर दे सकता है?',
          everyoneCanReply: 'हर कोई उत्तर दे सकता है',
          onlyPeopleYouMention: 'केवल वे लोग जिनका आप उल्लेख करते हैं',
          allwerf: 'सभी वर्फ',
          werf: 'वर्फ',
          changeEmail: 'ईमेल बदले',
          werfs: 'वर्फ्स',
          viewTranslated: 'अनुवाद',
          ChangeYourPassword: 'अपना पासवर्ड बदलें',
          accountInformation: 'खाता संबंधी जानकारी',
          viewTopics: 'विषय देखें',
          confirmPassMsg: 'अपने पासवर्ड की पुष्टि करें',
          wrongPasswordMsg: 'गलत पासवर्ड',
          languageSettings: 'भाषा सेटिंग्स',
          unBlock: 'अनवरोधित',
          loginWithGoogle: 'गूगल से लॉगिन करें',
          createYourPassword: 'अपना पासवर्ड बनाएं',
          createYourWerfieHandle: 'अपना वर्फी हैंडल बनाएं',
          forwardMessage: 'अग्रेषित संदेश',
          copy: 'संदेश कॉपी करें',
          messageDelete: 'आपके लिए हटाएं',
          deleteConversation: 'बातचीत मिटाएं',
          peopleInThisChat: 'इस चैट में लोग',
          views: 'दृश्य',
          werfSeenCountMsg: 'टाइम्स इस वेर्फ़ को देखा गया था',
          newWerf: 'न्यू वेर्फ़',
          newWerfs: 'नए वर्फ्स',
          pinPostMsg: 'पोस्ट को अपनी प्रोफ़ाइल पर पिन करें',
          unPinPostMsg: 'अपनी प्रोफ़ाइल पर पोस्ट अनपिन करें!',
          removeWerfAlert:
              "इसे पूर्ववत नहीं किया जा सकता और आप अपने परिवर्तन खो देंगे",
          quoteRewerf: 'उद्धरण रिवर्फ़',
          rewerfSuccessfully: 'ReWerf सफलतापूर्वक',
          noReplyComments: 'कोई उत्तर टिप्पणियाँ नहीं',
          postDetail: 'वर्फ विवरण',
          profileLinkCopy: 'प्रोफ़ाइल लिंक सफलतापूर्वक कॉपी किया गया!',
          muteUser: 'को सफलतापूर्वक शांत कर दिया गया है ',
          userReportedSuccessfully: 'उपयोगकर्ता को सफलतापूर्वक रिपोर्ट किया!',
          userBlockedSuccessfully:
              'उपयोगकर्ता को सफलतापूर्वक ब्लॉक कर दिया गया!',
          werfReportedSuccssfully: 'वेर्फ़ ने सफलतापूर्वक रिपोर्ट दी',
          YourAccount: 'आपका खाता',
          notificationsSettings: 'अधिसूचना सेटिंग्स',
          displaySettings: 'प्रदर्शन सेटिंग्स',
          moments: 'लम्हें',
          followings: 'फोल्लोविंग्स',
          popularUpdates: 'लोकप्रिय अपडेट',
          privacyAndSafety: 'गोपनीयता और सुरक्षा',
          createWerf: 'वर्फ बनाएं',
          chats: 'चैट',
          bookmark: 'बुकमार्क',
          bookmarks: 'बुकमार्क्स',
          topic: 'विषय',
          enterYourEmail: 'अपना ईमेल दर्ज करें',
          enterYourPassword: 'अपना कूटशब्द भरें',
          // languageSettings: 'भाषा सेटिंग',
          blockedAccountsSettings: 'अवरुद्ध खाता सेटिंग्स',
          selectYourPreferredLanguage: 'अपनी पसंदीदा भाषा चुनें',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'घर',
          browse: 'ब्राउज़',
          hotTrends: 'गर्म रुझान',
          saved: 'बचाया',
          messages: 'संदेशों',
          myProfile: 'मेरी प्रोफाइल',
          settings: 'समायोजन',
          notifications: 'सूचनाएं',
          settingsType: 'सेटिंग्स प्रकार',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'प्रबंधित करें कि BuzzNBee सामग्री आपको कैसे प्रदर्शित की जाती है',
          selectYourProfileLanguage: 'अपनी प्रोफ़ाइल भाषा चुनें',
          selectYourAppLanguage: 'अपनी ऐप भाषा चुनें',
          enableDisableAutoTranslation: 'ऑटो अनुवाद सक्षम / अक्षम करें',
          language: 'भाषा',

          ///   hindi
          username: "उपयोगकर्ता नाम",
          snoozeNotification: "स्नूज़ अधिसूचना",
          version: "संस्करण",
          appVersion: "एप्लिकेशन वेरीज़न",
          lists: "सूचियों",
          deactivationAndDeletion: "निष्क्रियता और विलोपन",
          confirmYourPasswords: "अपने पासवर्ड की पुष्टि करें",
          deactivateAccount: 'खाता निष्क्रिय करें',
          or: 'सोना',
          deleteAccount: "खाता हटा दो",
          updateYourLanguageAndTranslation: "अपनी भाषा और अनुवाद को अपडेट करें",
          manageYourPrivacySettings: "अपनी गोपनीयता सेटिंग प्रबंधित करें",
          privacySettings: "गोपनीय सेटिंग",
          setYourPrivacySettings: 'अपनी गोपनीयता सेटिंग्स सेट करें',
          messageSettings: 'संदेश सेटिंग्स',
          noOne: "किसी को भी नहीं",
          everyOne: 'हर कोई',
          ChangeUsernameSettings: "उपयोगकर्ता नाम सेटिंग्स बदलें",
          enterYourWerfieHandle: "अपना वर्फी हैंडल दर्ज करें",
          youHaveNotBlockedAnyPersonYet:
              "आपने अभी तक किसी व्यक्ति को अवरोधित नहीं किया है",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "यदि आप अपने वर्फी खाते को स्थायी रूप से हटाना चाहते हैं, तो एक बार जब आप ओके बटन पर क्लिक कर देते हैं, तो आप अपने खाते को पुनः सक्रिय नहीं कर पाएंगे या आपके द्वारा जोड़ी गई किसी भी सामग्री या जानकारी को पुनः प्राप्त नहीं कर पाएंगे।",
          permanentlyDeleteAccount: "स्थायी रूप से खाता हटाएं",
          whoCanMessageYou: 'आपको कौन मैसेज कर सकता है',
          viewEditHistory: 'संपादन इतिहास देखें',
          reportWerf: 'रिपोर्ट करें',
          hideWerf: 'वर्फ छुपाएं',
          showMore:'और दिखाओ',
          reportUser: 'उपयोगकर्ता को रिपोर्ट करें',
          mute: 'म्यूट',
          unMute: "अनम्यूट",
          deleteWerf: "वर्फ हटाएं",
          viewWerfAnalytics: 'वर्फ एनालिटिक्स देखें',
          pintoYourProfile: 'अपने प्रोफ़ाइल पर पिन करें',
          editWerf: 'वर्फ संपादित करें',
          explore: 'अन्वेषण करना',

          blockedAccounts: 'ब्लॉक किए गए खाते',
          translations: 'अनुवाद',
          viewListOfBlockedAccounts: 'अवरुद्ध खातों की सूची देखें',
          realTimePostTranslation: 'रीयल टाइम पोस्ट अनुवाद',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'वीडियो या ऑडियो अपलोड करते समय भाषा चुनें',
          originalTranslatedScriptAudioPost:
              'ऑडियो पोस्ट की मूल या अनुवादित स्क्रिप्ट',
          listenTranslatedScript: 'अनुवादित स्क्रिप्ट सुनें',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'उपयोगकर्ताओं द्वारा चुनी गई भाषा में चैट में संदेशों का स्वचालित रूप से अनुवाद करें',
          postedUpdate: 'एक अद्यतन पोस्ट किया।',
          peopleWhoReacted: 'जिन लोगों ने प्रतिक्रिया दी',
          comments: 'टिप्पणियाँ',
          peopleWhoRetweeted: 'रीट्वीट करने वाले लोग',
          leaveAComment: 'एक टिप्पणी छोड़ें',
          post: 'पोस्ट',
          cancel: 'रद्द करें',
          savePost: 'पोस्ट सहेजें',
          report: 'प्रतिवेदन',
          hide: 'छिपाना',
          shareLinkVia: 'के माध्यम से लिंक साझा करें...',
          copyLink: 'लिंक की प्रतिलिपि करें',
          fieldRequired: 'आवश्यक क्षेत्र',
          enterDescription: 'विवरण दर्ज करें',
          selectCategory: 'श्रेणी का चयन करें',
          okay: 'ठीक,',
          pleaseWait: 'कृपया प्रतीक्षा करें...',
          search: 'खोज',
          logout: 'लॉग आउट',
          writeSomethingHere: 'यहाँ कुछ लिखें',
          addMore: 'अधिक जोड़ें',
          image: 'छवि',
          video: 'वीडियो',
          videos: 'वीडियो',
          file: 'फ़ाइल',
          gif: 'GIF',
          audio: 'ऑडियो',
          live: 'रहना',
          doNotHaveAnAccount: "खाता नहीं है? ",
          register: 'रजिस्टर करें',
          haveAnAccount: "खाता होना? ",
          login: 'लॉग इन करें',
          whoToFollow: 'किसका अनुगमन करना है',
          noSuggestion: 'कोई सुझाव नहीं',
          follow: 'फॉलो करे',
          unFollow: 'अनफॉलो करे',
          seeMore: 'और देखें',
          searchFilter: 'फ़िल्टर खोजें',
          people: 'लोग',
          fromAnyone: 'किसी से भी',
          peopleYouFollow: 'लॉग जिनका तुम अनुसरण करते हो',
          location: 'स्थान',
          anywhere: 'कहीं भी',
          nearYou: 'तुम्हारे पास',
          advancedSearch: 'उन्नत खोज',
          trendsForYou: 'आपके लिए रुझान',
          noTrending: 'आपके क्षेत्र में कोई रुझान नहीं है',
          trendingIn: 'रुझान में',
          // tweets: 'ट्वीट्स',
          noNotification: 'आपके लिए कोई सूचना नहीं हैं',
          refresh: 'ताज़ा',
          edit: 'संपादित करें',
          save: 'सहेजें',
          cFollow: 'का पालन करें',
          addPeople: 'लोगों को जोड़ें',
          someText: 'कुछ पाठ',
          reportConversation: 'बातचीत की रिपोर्ट करें',
          leaveConversation: 'बातचीत को छोड़ दो',
          enterYourMessage: 'अपना संदेश दर्ज करें',
          showMoreComments: 'अधिक टिप्पणियां दिखाएं',
          reBuzz: 'Rebuzz',
          noPosts: 'आपके लिए कोई अपडेट नहीं',
          emailFieldCannotBeEmpty: 'ईमेल फ़ील्ड खाली नहीं हो सकती',
          emailFormatIsInvalid: 'ईमेल प्रारूप अमान्य है',
          rememberMe: 'पहचाना की नहीं',
          lostPassword: 'पासवर्ड खो गया? ',
          cLOGIN: 'लॉग इन करें',
          emailOrPasswordIsIncorrect: 'ईमेल या पासवर्ड गलत है',
          newsFeed: 'समाचार फ़ीड',
          trends: 'प्रवृत्तियों',
          profile: 'प्रोफ़ाइल',
          newMessage: 'नया संदेश',
          next: 'अगला',
          searchPeople: 'लोगों को खोजें',
          saySomething: 'कुछ कहो',
          noSearchResult: 'कोई खोज परिणाम नहीं',
          searchResult: 'परिणाम खोजें',
          hidePost: 'पोस्ट छिपाएं',
          showLess: 'कम दिखाएं',
          showMore: 'और दिखाओ',
          nothingYet: 'अभी तक कुछ नही!',
          savedPosts: 'सहेजी गई पोस्ट',
          enterYourFirstName: 'अपना नाम दर्ज करें',
          enterYourLastName: 'अपना अंतिम नाम दर्ज करें',
          enterYourUsername: 'अपने उपयोगकर्ता नाम दर्ज करें',
          signUp: 'साइन अप करें',
          pleaseChooseACountry: 'कृपया एक देश चुनें',
          replied: 'ने उत्तर दिया',
          reply: 'जवाब',
          delete: 'हटाएं',
          replyToComment: 'को उत्तर ',
          noFollower: 'कोई अनुयायी नहीं',
          following: 'निम्नलिखित',
          followBack: 'वापस पीछा करो',
          followers: 'समर्थक',
          follower: 'अनुगामी',
          noFollowings: 'कोई अनुसरण नहीं',
          sendAMessageGetAMessage: 'संदेश भेजें, संदेश प्राप्त करें',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'प्रत्यक्ष संदेश वर्फी पर आपके और अन्य लोगों के बीच की निजी बातचीत हैं। ट्वीट्स, मीडिया, और बहुत कुछ साझा करें!',
          startAConversation: 'एक बातचीत शुरू',
          groupInfo: 'समूह जानकारी',
          chatInfo: 'चैट जानकारी',
          youDoNotHaveAMessageSelected: 'आपके पास कोई संदेश चयनित नहीं है',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'अपने मौजूदा संदेशों में से एक चुनें, या एक नया शुरू करें।',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'कृपया अपना ईमेल सत्यापित करने के लिए सत्यापन कोड दर्ज करें',
          usernameOrEmail: 'उपयोगकर्ता का नाम या ईमेल',
          enterVerificationCode: 'सत्यापन कोड दर्ज करें',
          confirmCode: 'कोड की पुष्टि करें',
          top: 'शीर्ष',
          latest: 'नवीनतम',
          photos: 'तस्वीरें',
          files: 'फ़ाइलें',
          noPeople: 'कोई लोग नहीं',
          all: 'सभी',
          mentions: 'का उल्लेख है',
          replies: 'जवाब',
          // tweetsAndReplies: 'ट्वीट और जवाब',
          media: 'मीडिया',
          likes: 'को यह पसंद है',
          searchPost: 'अपडेट खोजें',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'आपका पासवर्ड खो गया है? कृपया अपना नाम या ईमेल पता दर्ज करें। आपको ईमेल के माध्यम से एक नया पासवर्ड बनाने के लिए एक लिंक प्राप्त होगा।',
          resetYourPassword: 'अपना पासवर्ड रीसेट करें',
          enterCode: 'कोड दर्ज करें',
          enterNewPassword: 'नया पासवर्ड दर्ज करें',
          reEnterPassword: 'पासवर्ड फिर से दर्ज करें',
          passwordCannotBeEmpty: 'पासवर्ड खाली नहीं हो सकता',
          passwordShouldBeCharacter: 'पासवर्ड 8 कैरेक्टर का होना चाहिए',
          passwordShouldBeMatched: 'पासवर्ड का मिलान होना चाहिए',
          resetPassword: 'पासवर्ड रीसेट',
          email: 'ईमेल',
          blockUser: 'खंड उपयोगकर्ता',
          public: 'सह लोक',
          mentionUsers: 'उपयोगकर्ताओं का उल्लेख करें',
          editProfile: 'प्रोफ़ाइल सेट करें',
          yourProfileIsUpdated: 'आपकी प्रोफ़ाइल अपडेट की गई है',
          seeProfile: 'प्रोफ़ाइल देखें',
          skipForNow: 'अभी के लिए जाने दे',
          addBio: 'जैव जोड़ें',
          profileUpdated: 'प्रोफाइल अद्यतन किया गया',
          upDate: 'अद्यतन',
          goToProfile: 'प्रोफ़ाइल करने के लिए जाना',
          more: 'अधिक',
          about: 'के बारे में',
          help: 'मदद',
          privacyPolicy: 'गोपनीयता नीति',
          blog: 'ब्लॉग',
          termsOfService: 'सेवा की शर्तें',
          youMustSelectACountry: 'आपको एक देश चुनना होगा',
          usernameIsAlreadyTaken: 'उपयोगकर्ता का नाम पहले से लिया है',
          goBack: 'वापस जाओ',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'इस ईमेल के साथ एक खाता पहले ही बनाया जा चुका है',
          yourPasswordIsResetSuccessfully:
              'आपका पासवर्ड सफलतापूर्वक रीसेट कर दिया गया है',
          returnToLogin: 'लॉगिन पर लौटें',
          youHaveEnteredAnInvalidCode: 'आपने एक अमान्य कोड दर्ज किया है',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'BuzznBee के साथ अपना खाता बनाने के लिए धन्यवाद। हमारी टीम 24 घंटे में आपसे संपर्क करेगी। सुरक्षित रहें!',
          success: 'सफलता',
          goBackToHomePage: 'होम पेज पर वापस जाएं',
        },

        /// --- currently we are not using these languages--- ///
        'da': {
          theUsernameHasAlreadyBeenTaken : 'The username has already been taken.',
          thereWasAnErrorInSavingThisUsername : " There was an error in saving this Username!",
          showMenu : 'Show Menu',
          thisPollHasExpired : 'This poll has expired',
          youCannotVoteOnYourOwnPoll : 'You cannot vote on your own poll!',
          choice : "Choice",
          optionalPoll : "(Optional)",
          watchPartyLetGo :  "Watch party, let's go",
          createSpace :'Create Space',
          oopsSomethingWentWrongPleaseTryAgain : 'Oops…Something went wrong! Please try again',
          noSpacesAvailable : 'No spaces available',
          yourSpaceIsReady : "Your space is ready",
          spaceLinkCopiedSuccessfully : 'Space link copied successfully',
          instant : 'Instant',
          nameYourSpace : 'Name your space',
          whatDoYouWantToTalkAbout :'What do you want to talk about?',
          scheduleYourSpace : "Schedule your space",
          confirm : 'Confirm',
          selectTopic : 'Select Topic',
          momentDeleteSuccessfully : "Moment Deleted Successfully",
          createSpaceSuccessfully : "Create Space Successfully",
          pleaseEnterTheSpaceName : "Please enter the space name",
          spaces : 'Spaces',

          pleaseChooseEither1VideoOr1Pdf: "Please choose either 1 video or 1 Pdf at a time or up to 4 photos.",
          fileTypeIsNotAllowed:'File type is not allowed',
          thisPostIsScheduledFor: "This post is scheduled for",
          askAQuestion: 'Ask a question...',
          pollLength:'Poll length',
          hours: 'Hours',
          minutes:'Minutes',
          removePoll: 'Remove Poll',
          uploading: 'Uploading...',
          addDescription: "Add Description",
          willPostOn:  "Will Post on",
          date:'Date',
          youCannotScheduleAWerfInThePast: 'You cannot schedule a Werf in the past',
          time: 'Time',
          timeZone: 'Time zone',
          youHaveNoScheduledWerfs: 'You have no scheduled werfs',
          willSendOn:  "Will send on",
          selectAll: 'Select all',
          schedule: 'Schedule',
          scheduledWerfs: 'Scheduled Werfs',
          deselectAll: 'Deselect all',
          yourImageVideoWillBeAvailableInAMoment: 'Your image/video will be available in a moment.',
          pleaseEnterValidText: 'Please enter valid text',
          takeAPhoto: "Take a Photo",
          chooseFromGallery:  "Choose from Gallery",
          makeVideoWithPhoneCamera: "Make video with phone camera",
          unsentWerfs: 'Unsent Werfs',
          commentsHere:'comments here',
          ImageDescription : 'Image description',
          viewHiddenReplies: 'View Hidden Replies',
          undoRewerf: 'Undo Rewerf',
          share:  "Share",
          view:  "View",
          werfLinkCopiedSuccessfully: "Werf link copied successfully",
          addBookmark: "Add Bookmark",
          removeBookmark: "Remove Bookmark",
          werfSavedSuccessfully: 'Werf saved successfully!',
          werfUnsavedSuccessfully:  'Werf unsaved successfully!',
          thereWasAnErrorInUnSavingThisWerf: 'There was an error in unsaving this werf!',
          thereWasAnErrorInSavingThisWerf:'There was an error in saving this werf!',
          thereWasAnErrorInBlockingThisUser:'There was an error in blocking this user!',
          noEditHistory: 'No edit history',
          unPinFromProfile: "UnPin from Profile",
          saveWerf: 'Save Werf',
          linkCopiedToClipBoard:  'Link copied to clipboard!',
          removeFromBookmarks: 'Remove from bookmarks',
          thereWasAnErrorInReportingThisUser: 'There was an error in reporting this user!',
          viewOriginal: "Original",
          showThisThread:'Show this thread',
          rewerf : 'Rewerf',

          nothingFound:'Nothing found',
          year:'Year',
          day : 'Day',
          month : 'Month',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "This should be the date of birth of the person using the account. Even if you’re making an account for your business or event.",
          editDateOfBirth : 'Edit date of birth?',
          deletePhoto :"Delete photo",
          removePhoto : "Remove photo",
          addPhoto :"Add photo",
          discard : "Discard",
          removeWerfAlert :
          "This can't be undone and you'll lose your changes",
          discardChanges : "Discard changes?",
          youShouldBeAtLeast14YearsOld: 'You should be at least 14 years old',
          contentOfDialog :"Content of Dialog",
          pinnedWerf : "Pinned Werf",
          hiddenPost : "Hidden Werfs",
          thisCanBeOnlyChangedAFewTimes :" This can be only changed a few times. Make sure you enter the age of the person using the account",


          aboutHashTag : 'About hashtag',
          werfHashTag : 'Werf hashtag',
          messageRequests : 'Message requests',
          enterGroupChatTitle:  "Enter group chat title",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Choose one from your existing chats, or start a new one',
          snoozeNotificationsFrom :  "Snooze notifications from",
          snoozeNotificationsFromTheGroup : "Snooze notifications from the group",
          snoozeMentions : "Snooze mentions",
          disableNotificationsWhenPeoplemention:"Disable notifications when people mention you in this conversation.",
          trySearchingForPeopleGroupsOrMessages : "Try searching for people,groups, or messages",
          werfieUser :  "Werfie User",
          otherChat :"other...",
          photoChat : 'Photo',
          videoChat : 'Video',
          fileChat : 'File',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'Direct Messages are private conversations between you and other people on Twitter. Share Tweets, media, and more!',
          searchChats : "Search Chats",
          allTabChat : "All",
          peopleTabChat : "People",
          groupsTabChat :"Group",
          chatsTabChat :"Chats",
          noResultsFor : "No results for",
          theTermYouEnteredDidNotBring : "The term you entered did not bring up any results",
          message : "Message",
          addMembersToChat : 'Add members to chat',
          noMessagesYet : "No Messages Yet",
          doNotAllowMessages : "don't allow messages",
          notAllowedToMessage : "Not allowed to message.",
          youHaveBlockedThisUser : "You have blocked this user",
          startAMessage :  "Start a message",
          react :  "React",
          undo : "Undo",
          reactions : 'Reactions',
          messageRequestsFallHere :
          "Message requests from people you don't follow live here. To reply there message, you need to accept the request.",
          noMessageRequestAvailable : 'No Message Request Available',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'Depending on the setting you select,different people can send you a direct message.',

          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          otherControls : "Other controls",
          filterLowQualityMessages : "Filter low-quality messages",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",
          showReadReceipts : "Show read receipts",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",


          getPushNotificationsToFindOut :"Get push notifications to find out what’s going on when you’re not on Werfie. You can turn them off anytime.",
          relatedToYouAndYourWerfs :"Related to you and your Werfs",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "When you turn on Werf notifications from people you follow, you'll get push notifications about their Werfs.",
          topWerfs :"Top Werfs",
          tailoredForYou: "Tailored for you",
          rewerf : 'Rewerf',
          like : 'Like',
          photoTags : "Photo Tags",
          messageReactions : "Message Reactions",
          fromWerfie : "From Werfie",
          newsSports : "News / Sports",
          recommendations : "Recommendations",
          turnOnPush:"Turn on push\nnotifications",
          toReceiveNotificationsAsTheyHappen :"To receive notifications as they happen, turn on\npush notification, You'll also receive them when\nyou're not on Werfie. Turn them off anytime.",
          turnOn : "Turn on",
          newNotifications :  "New notifications",
          werfsEmailedToYou : "Werfs emailed to you",
          weekly : 'Weekly',
          newAboutWerfieProduct :"New about Werfie product and features updates",
          tipsOnGettingMoreOut: "Tips on getting more out of Werfie",
          thingsYouMissedSinceYou: "Things you missed since you last logged into Werfie",
          participationInWerfieResearchSurveys: "Participation in Werfie research surveys",
          suggestionsRorRecommendedAccounts: "Suggestions for recommended accounts",
          suggestionsBasedOnYourRecentFollows: "Suggestions based on your recent follows",
          qualityFilters : "Quality filters",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Choose to filter out content such as duplicate and automated Werfs. This doesn't apply to notifications from accounts you follow and have interacted with recently.",

          emailNotification : 'Email Notifications',
          filters : "Filters",
          chooseTheNotification : "Choose the notification you'd like to see and those you don't",
          preferences : "Preferences",
          selectYourPreferencesByNotificationType :"Select your preferences by notification type.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie always uses some information,like where you signed up and and your current location,to help show you more relevant content.when this setting is enabled,Werfie may also personalize your experience based on other places you have been.',

          personalizeBasedOnPlacesYouHaveBeen :
          'Personalize based on places you have been',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Manage the location information Werfie uses to personalize your experience.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",

          showReadReceipts : "Show read receipts",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",


          filterLowQualityMessages :"Filter low-quality messages",
          otherControls : "Other controls",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "People you follow will still be able to message you",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'Depending on the setting you select,different people can send you a direct message.',

          controlWhoCanMessageYou : 'Control who can message you',
          forever : " Forever",
          muteNotificationsFromPeople :"Mute notifications from people:",
          youDoNotFollow : "You don't follow",
          whoDoNotFollowYou : "Who don't follow you",
          withANewAccount : "With a new account",
          whoHaveDefaultProfilePhoto :"Who have default profile photo",
          whoHaveNotConfirmedTheirEmail : "Who haven't confirmed their email",
          whoHaveNotConfirmedTheirPhoneNumber :"Who haven't confirmed their phone number",
          duration : 'Duration',
          untilYouUnmuteTheWord : 'Until you unmute the word',
          hours24 : '24 hours',
          days7 : '7 days',
          days30 : '30 days',
          fromPeopleYouDontFollow : "From people you don't follow",
          homeTimeline : 'Home timeline',
          muteFrom : 'Mute from',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'You can mute one word,@username,or hashtag at a time.',
          enterWordOrPhrase : 'Enter word or phrase',
          mutedWord : 'Muted word',
          addMutedWords : 'Add muted words',
          youHaveNotMutedAnyWordYet : 'You have not muted any word yet',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "when you mute words,you won't get any new notification for Werfs that include them or see Werfs with those words in your Home timeline.",

          youHaveNotMutedAnyPersonYet :
          'You have not muted any person yet',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Here's everyone you muted.You can add remove them from this list.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "When you block someone,that person won't be able to follow or message you.and you won't see notification from them.",

          mutedNotification : 'Muted notifications',
          mutedWords: 'Muted words',
          mutedAccounts : 'Muted accounts',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Manage the accounts,word,and notification that you have muted or blocked.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'This prevents Werfs with potentially sensitive content displaying in your search results.',

          hideSensitiveContent: 'Hide sensitive content',
          removeBlockedAndMutedAccounts :
          'Remove blocked and muted accounts',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'Use this to eliminate search results from account you have blocked or muted',
          personalization : 'Personalization',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'you can personalize trends based on your location and who you follow',
          exploreLocation : 'Explore location',
          showContentInThisLocation : 'Show content in this location',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'When this is on, you will see what is happening around you right now.',
          searchSettings  :'Search settings',
          exploreSettings : 'Explore settings',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Decide what you see on werfie based on your preferences like Topics',
          displayMediaThatMayContainSensitiveContent :
          'Display media that may contain sensitive content',
          addLocationInformationToYourWerfs :'Add location information to your Werfs',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "When enabled,picture and videos you Werf will be marked as sensitive for people who don't want to see sensitive content.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'Mark media you Werf as having material that may be sensitive',
          manageTheInformationAssociatedWithYourWerfs :
          'Manage the information associated with your Werfs.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'if enabled,you will be able to attach location to your Werfs.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Remove all location information attached to your Werfs',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'Location labels you have added to your Werfs will no longer be visible on Werfie.com, Werfie for IOS, and Werfie for Android. These updates may take some time to go into effect.',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Manage what information you allow other people on Werfie.',
          protectYourTweets : 'Protect your Werfs',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'When selected, your werfie and account information are only visible to people who follow you',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'This will make them visible only to your werfie followers',
          protect : 'Protect',
          photoTagging : 'Photo tagging',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou:
          'Only people you follow can tag you',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Allow people to tag you in their photos and receive notifications when they do so',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou : 'Only people you follow can tag you',
          security : 'Security',
          manageYourAccountsSecurity : "Manage your accounts security",
          twoFactorAuthentication : "Two-factor authentication",
          manageYourAccountsSecurityKeepTrack : "Manage your accounts security and keep track of your account usage",
          helpProtectYourAccountFromUnauthorizedAccess :  "Help protect your account from unauthorized access by requiring a second authentication method in addition to your X password. You can choose a text message, authentication app, or security key.",
          verificationCodeSentToYourRegisteredEmail:"Enter 6-digits verification code Sent to your registered email",
          submit :'Submit',
          genderChangedSuccessfully : "Gender Changed Successfully",
          genderSettingTextDescription :"If you haven’t already specified a gender, this is the one associated with your account based on your profile and activity. This information won’t be displayed publicly.",
          male:  'Male',
          female : 'Female',
          other : 'Other',
          change:'Change',
          changeCountrySettings:'Change country',
          selectACountry:'Select a country',
          updateEmailAddress:'Update email address',
          current:'Current',
          changeEmailSetting:'Change email',
          gender:'Gender',
          accountCreation:'Account creation',
          Age:'Age',
          securityAndAccountAccess:'Security and account access',
          youHaveNotCreatedOrFollowedAnyLists: "You haven't created or followed any Lists. When you do, they'll show up here.",
          userCanPinnedOnly5  : 'User can pinned  only 5 ',
          pleaseEnterTheName  : 'Please enter the name ',
          list : 'Lists',
          listYouAre :"Lists you're on",
          listYouHave:"You haven't been added to any Lists yet",
          listAddedSomeOne:"When someone adds you to a List, it'll show up here",
          listMembers :'List Members',
          listFollowers  : 'List Followers',
          noMembers: 'No Members',
          noResults :'No results',
          noFollowers:'No Followers',
          YourAccount: 'حساب شما',
          notificationsSettings: 'تنظیمات اعلان ها',
          displaySettings: 'تنظیمات نمایشگر',
          moments: 'لحظات',
          topic: 'موضوعات',
          followings: 'موارد زیر',
          popularUpdates: 'به روز رسانی های محبوب',
          privacy: 'حریم خصوصی',
          createWerf: 'Werf را ایجاد کنید',
          chats: 'چت ها',
          bookmarks: 'نشانک ها',
          enterYourEmail: 'ایمیل خود را وارد کنید',
          enterYourPassword: 'رمز عبور خود را وارد کنید',
          languageSettings: 'تنظیمات زبان',
          blockedAccountsSettings: 'تنظیمات حسابهای مسدود شده',
          selectYourPreferredLanguage: 'زبان مورد نظر خود را انتخاب کنید',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'صفحه اصلی',
          browse: 'مرور کردن',
          hotTrends: 'گرایش های داغ',
          saved: 'ذخیره',
          messages: 'پیام ها',
          myProfile: 'پروفایل من',
          settings: 'تنظیمات',
          notifications: 'اطلاعیه',
          settingsType: 'تنظیمات نوع',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'نحوه نمایش محتوای BuzzNBee به شما را مدیریت کنید',
          selectYourProfileLanguage: 'زبان نمایه خود را انتخاب کنید',
          selectYourAppLanguage: 'زبان برنامه خود را انتخاب کنید',
          enableDisableAutoTranslation: 'فعال / غیرفعال کردن ترجمه خودکار',
          language: 'زبان',

          ///   persian
          username: "نام کاربری",
          snoozeNotification: 'به تعویق انداختن اعلان',
          version: 'نسخه',
          appVersion: "AppVersion",
          lists: 'لیست ها',
          deactivationAndDeletion: "غیرفعال سازی و حذف",
          confirmYourPasswords: "رمزهای عبور خود را تأیید کنید",
          deactivateAccount: 'غیرفعال کردن اکانت',
          or: 'طلا',
          deleteAccount: "حذف حساب کاربری",
          updateYourLanguageAndTranslation: "زبان و ترجمه خود را به روز کنید",
          manageYourPrivacySettings: "تنظیمات حریم خصوصی خود را مدیریت کنید",
          privacySettings: "تنظیمات حریم خصوصی",
          setYourPrivacySettings: 'تنظیمات حریم خصوصی خود را تنظیم کنید',
          messageSettings: 'تنظیمات پیام',
          noOne: "هیچکس",
          everyOne: 'هر کس',
          ChangeUsernameSettings: "تنظیمات نام کاربری را تغییر دهید",
          enterYourWerfieHandle: "دسته Werfie خود را وارد کنید",
          youHaveNotBlockedAnyPersonYet: "شما هنوز هیچ شخصی را بلاک نکرده اید",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "اگر می‌خواهید حساب Werfie خود را برای همیشه حذف کنید، پس از کلیک بر روی دکمه تأیید، نمی‌توانید حساب خود را دوباره فعال کنید یا هیچ یک از محتوا یا اطلاعاتی را که اضافه کرده‌اید بازیابی کنید.",
          permanentlyDeleteAccount: "حذف دائمی حساب",
          whoCanMessageYou: 'چه کسی می تواند به شما پیام دهد',
          viewEditHistory: 'مشاهده تاریخچه ویرایش',
          reportWerf: 'گزارش werf',
          mute: 'بی صدا',
          unMute: "لغو نادیده گرفتن",
          deleteWerf: 'ورف رو حذف کن',
          viewWerfAnalytics: 'Werf Analytics را مشاهده کنید',
          pintoYourProfile: 'به نمایه خود پین کنید',
          editWerf: 'ورف را ویرایش کنید',
          explore: 'کاوش کنید',

          blockedAccounts: 'حسابهای مسدود شده',
          translations: 'ترجمه ها',
          viewListOfBlockedAccounts: 'مشاهده لیست حسابهای مسدود شده',
          realTimePostTranslation: 'ترجمه پست زمان واقعی',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'هنگام بارگذاری فیلم یا صدا ، زبان را انتخاب کنید',
          originalTranslatedScriptAudioPost:
              'اسکریپت اصلی یا ترجمه شده پست صوتی',
          listenTranslatedScript: 'به متن ترجمه شده گوش دهید',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'به صورت خودکار پیام ها را در چت به زبان انتخاب شده کاربران ترجمه کنید',
          postedUpdate: 'آپدیت ارسال کرد',
          peopleWhoReacted: 'افرادی که واکنش نشان دادند',
          comments: 'نظرات',
          peopleWhoRetweeted: 'افرادی که بازنشر کردند',
          leaveAComment: 'پیام بگذارید',
          post: 'پست',
          cancel: 'لغو کنید',
          savePost: 'ذخیره پست',
          report: 'گزارش',
          hide: 'پنهان شدن',
          shareLinkVia: 'اشتراک گذاری پیوند از طریق ...',
          copyLink: 'پیوند را کپی کنید',
          fieldRequired: 'فیلد مورد نیاز',
          enterDescription: 'توضیحات را وارد کنید',
          selectCategory: 'دسته را انتخاب کنید',
          okay: 'باشه،',
          pleaseWait: 'لطفا صبر کنید...',
          search: 'جستجو کردن',
          logout: 'خروج',
          writeSomethingHere: 'اینجا چیزی بنویس',
          addMore: 'افزودن بیشتر',
          image: 'تصویر',
          video: 'ویدیو',
          videos: 'فیلم های',
          file: 'فایل',
          gif: 'GIF',
          audio: 'سمعی',
          live: 'زنده',
          doNotHaveAnAccount: "حساب ندارید؟ ",
          register: 'ثبت نام',
          haveAnAccount: "حساب دارید؟ ",
          login: 'وارد شدن',
          whoToFollow: 'چه کسی را دنبال کند',
          noSuggestion: 'بدون پیشنهاد',
          follow: 'دنبال کردن',
          unFollow: 'لغو دنبال کردن',
          seeMore: 'بیشتر ببین',
          searchFilter: 'فیلتر جستجو',
          people: 'مردم',
          fromAnyone: 'از هر کسی',
          peopleYouFollow: 'افرادی که شما آنها را دنبال می کنید',
          location: 'محل',
          anywhere: 'هر جا',
          nearYou: 'نزدیک تو',
          advancedSearch: 'جستجوی پیشرفته',
          trendsForYou: 'روند برای شما',
          noTrending: 'هیچ گرایشی در منطقه شما وجود ندارد',
          trendingIn: 'روند در',
          // tweets: 'توییت ها',
          noNotification: 'هیچ اعلانی برای شما وجود ندارد',
          edit: 'ویرایش کنید',
          save: 'صرفه جویی',
          cFollow: 'دنبال کردن',
          addPeople: 'اضافه کردن مردم',
          someText: 'مقداری متن',
          reportConversation: 'گزارش مکالمه',
          leaveConversation: 'ترک گفتگو',
          enterYourMessage: 'پیام خود را وارد کنید',
          showMoreComments: 'نمایش نظرات بیشتر',
          reBuzz: 'Rebuzz',
          noPosts: 'هیچ به روزرسانی برای شما وجود ندارد',
          emailFieldCannotBeEmpty: 'فیلد ایمیل نمی تواند خالی باشد',
          emailFormatIsInvalid: 'قالب ایمیل نامعتبر است',
          rememberMe: 'مرا به خاطر بسپار',
          lostPassword: 'رمز فراموش شده؟',
          cLOGIN: 'وارد شدن',
          emailOrPasswordIsIncorrect: 'آدرس ایمیل یا رمز عبور نادرست می باشد',
          newsFeed: 'اخبار',
          trends: 'گرایش ها',
          profile: 'مشخصات',
          newMessage: 'پیام جدید',
          next: 'بعد',
          searchPeople: 'افراد را جستجو کنید',
          saySomething: 'چیزی بگو',
          noSearchResult: 'بدون نتیجه جستجو',
          searchResult: 'نتیجه جستجو',
          hidePost: 'مخفی کردن پست',
          showLess: 'کمتر نشان دهید',
          showMore: 'بیشتر نشان بده، اطلاعات بیشتر',
          nothingYet: 'هنوز هیچی!',
          savedPosts: 'پست های ذخیره شده',
          enterYourFirstName: 'نام خود را وارد کنید',
          enterYourLastName: 'نام خانوادگی خود را وارد کنید',
          enterYourUsername: 'نام کاربری خود را وارد کنید',
          signUp: 'ثبت نام',
          pleaseChooseACountry: 'لطفا کشوری را انتخاب کنید',
          replied: 'پاسخ داد',
          reply: 'پاسخ',
          delete: 'حذف',
          replyToComment: 'پاسخ به نظر',
          noFollower: 'بدون دنبال کننده',
          following: 'ذیل',
          followBack: 'بازگشت را دنبال کنید',
          followers: 'دنبال کنندگان',
          follower: 'دنباله رو',
          noFollowings: 'هیچ دنبال کننده ای وجود ندارد',
          sendAMessageGetAMessage: 'پیام ارسال کنید ، پیام بگیرید',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'پیام های مستقیم مکالمات خصوصی بین شما و سایر افراد در توییتر است. توییت ها ، رسانه ها و موارد دیگر را به اشتراک بگذارید!',
          startAConversation: 'شروع مکالمه',
          groupInfo: 'اطلاعات گروه',
          chatInfo: 'اطلاعات چت',
          youDoNotHaveAMessageSelected: 'پیامی انتخاب نکرده اید',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'یکی از پیام های موجود خود را انتخاب کنید یا پیام جدیدی را شروع کنید.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'لطفاً کد تأیید را برای تأیید ایمیل خود وارد کنید',
          usernameOrEmail: 'نام کاربری یا پست الکترونیک',
          enterVerificationCode: 'کد تایید را وارد کنید',
          confirmCode: 'کد را تأیید کنید',
          top: 'بالا',
          latest: 'آخرین',
          photos: 'عکس ها',
          files: 'فایل ها',
          noPeople: 'بدون مردم',
          all: 'همه',
          mentions: 'ذکر می کند',
          replies: 'پاسخ ها',
          // tweetsAndReplies: 'توییت‌ها و پاسخ‌ها',
          media: 'رسانه ها',
          likes: 'دوست دارد',
          searchPost: 'جستجو در به روز رسانی',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'رمز عبور خود را گم کرده اید؟ لطفا نام کاربری یا آدرس ایمیل خود را وارد نمایید. پیوندی برای ایجاد رمز عبور جدید از طریق ایمیل دریافت خواهید کرد.',
          resetYourPassword: 'گذرواژه خود را بازنشانی کنید',
          enterCode: 'کد را وارد کنید',
          enterNewPassword: 'رمز عبور جدید را وارد کنید',
          reEnterPassword: 'رمز عبور را دوباره وارد کنید',
          passwordCannotBeEmpty: 'رمز عبور نمی تواند خالی باشد',
          passwordShouldBeCharacter: 'رمز عبور باید 8 کاراکتر باشد',
          passwordShouldBeMatched: 'رمز عبور باید مطابقت داشته باشد',
          resetPassword: 'بازنشانی رمز عبور',
          email: 'پست الکترونیک',
          blockUser: 'مسدود کردن کاربر',
          public: 'عمومی',
          mentionUsers: 'کاربران را ذکر کنید',
          editProfile: 'تنظیم نمایه',
          yourProfileIsUpdated: 'نمایه شما به روز شده است',
          seeProfile: 'به نمایه مراجعه کنید',
          skipForNow: 'فعلا رد شوید',
          addBio: 'بیو اضافه کنید',
          profileUpdated: 'پروفایل به روز شد',
          upDate: 'به روز رسانی',
          goToProfile: 'به پروفایل بروید',
          more: 'بیشتر',
          about: 'در باره',
          help: 'کمک',
          privacyPolicy: 'سیاست حفظ حریم خصوصی',
          blog: 'وبلاگ',
          termsOfService: 'شرایط استفاده از خدمات',
          youMustSelectACountry: 'شما باید یک کشور را انتخاب کنید',
          usernameIsAlreadyTaken: 'نام کاربری قبلاً گرفته شده است',
          goBack: 'برگرد',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'قبلاً حسابی با این ایمیل ایجاد شده است',
          yourPasswordIsResetSuccessfully: 'رمز عبور شما با موفقیت بازنشانی شد',
          returnToLogin: 'بازگشت به ورود',
          youHaveEnteredAnInvalidCode: 'شما یک کد نامعتبر وارد کرده اید',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'از اینکه حساب خود را با BuzznBee ایجاد کردید متشکریم. تیم ما 24 ساعت دیگر با شما تماس می گیرد. ایمن بمانید!',
          success: 'موفقیت',
          goBackToHomePage: 'بازگشت به صفحه اصلی',
        },
        'ru': {
          theUsernameHasAlreadyBeenTaken : 'The username has already been taken.',
          thereWasAnErrorInSavingThisUsername : " There was an error in saving this Username!",
          showMenu : 'Show Menu',
          thisPollHasExpired : 'This poll has expired',
          youCannotVoteOnYourOwnPoll : 'You cannot vote on your own poll!',
          choice : "Choice",
          optionalPoll : "(Optional)",
          watchPartyLetGo :  "Watch party, let's go",
          createSpace :'Create Space',
          oopsSomethingWentWrongPleaseTryAgain : 'Oops…Something went wrong! Please try again',
          noSpacesAvailable : 'No spaces available',
          yourSpaceIsReady : "Your space is ready",
          spaceLinkCopiedSuccessfully : 'Space link copied successfully',
          instant : 'Instant',
          nameYourSpace : 'Name your space',
          whatDoYouWantToTalkAbout :'What do you want to talk about?',
          scheduleYourSpace : "Schedule your space",
          confirm : 'Confirm',
          selectTopic : 'Select Topic',
          momentDeleteSuccessfully : "Moment Deleted Successfully",
          createSpaceSuccessfully : "Create Space Successfully",
          pleaseEnterTheSpaceName : "Please enter the space name",
          spaces : 'Spaces',

          pleaseChooseEither1VideoOr1Pdf: "Please choose either 1 video or 1 Pdf at a time or up to 4 photos.",
          fileTypeIsNotAllowed:'File type is not allowed',
          thisPostIsScheduledFor: "This post is scheduled for",
          askAQuestion: 'Ask a question...',
          pollLength:'Poll length',
          hours: 'Hours',
          minutes:'Minutes',
          removePoll: 'Remove Poll',
          uploading: 'Uploading...',
          addDescription: "Add Description",
          willPostOn:  "Will Post on",
          date:'Date',
          youCannotScheduleAWerfInThePast: 'You cannot schedule a Werf in the past',
          time: 'Time',
          timeZone: 'Time zone',
          youHaveNoScheduledWerfs: 'You have no scheduled werfs',
          willSendOn:  "Will send on",
          selectAll: 'Select all',
          schedule: 'Schedule',
          scheduledWerfs: 'Scheduled Werfs',
          deselectAll: 'Deselect all',
          yourImageVideoWillBeAvailableInAMoment: 'Your image/video will be available in a moment.',
          pleaseEnterValidText: 'Please enter valid text',
          takeAPhoto: "Take a Photo",
          chooseFromGallery:  "Choose from Gallery",
          makeVideoWithPhoneCamera: "Make video with phone camera",
          unsentWerfs: 'Unsent Werfs',
          commentsHere:'comments here',
          ImageDescription : 'Image description',
          viewHiddenReplies: 'View Hidden Replies',
          undoRewerf: 'Undo Rewerf',
          share:  "Share",
          view:  "View",
          werfLinkCopiedSuccessfully: "Werf link copied successfully",
          addBookmark: "Add Bookmark",
          removeBookmark: "Remove Bookmark",
          werfSavedSuccessfully: 'Werf saved successfully!',
          werfUnsavedSuccessfully:  'Werf unsaved successfully!',
          thereWasAnErrorInUnSavingThisWerf: 'There was an error in unsaving this werf!',
          thereWasAnErrorInSavingThisWerf:'There was an error in saving this werf!',
          thereWasAnErrorInBlockingThisUser:'There was an error in blocking this user!',
          noEditHistory: 'No edit history',
          unPinFromProfile: "UnPin from Profile",
          saveWerf: 'Save Werf',
          linkCopiedToClipBoard:  'Link copied to clipboard!',
          removeFromBookmarks: 'Remove from bookmarks',
          thereWasAnErrorInReportingThisUser: 'There was an error in reporting this user!',
          viewOriginal: "Original",
          showThisThread:'Show this thread',
          rewerf : 'Rewerf',
          nothingFound:'Nothing found',
          year:'Year',
          day : 'Day',
          month : 'Month',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "This should be the date of birth of the person using the account. Even if you’re making an account for your business or event.",
          editDateOfBirth : 'Edit date of birth?',
          deletePhoto :"Delete photo",
          removePhoto : "Remove photo",
          addPhoto :"Add photo",
          discard : "Discard",
          removeWerfAlert :
          "This can't be undone and you'll lose your changes",
          discardChanges : "Discard changes?",
          youShouldBeAtLeast14YearsOld: 'You should be at least 14 years old',
          contentOfDialog :"Content of Dialog",
          pinnedWerf : "Pinned Werf",
          hiddenPost : "Hidden Werfs",
          thisCanBeOnlyChangedAFewTimes :" This can be only changed a few times. Make sure you enter the age of the person using the account",


          aboutHashTag : 'About hashtag',
          werfHashTag : 'Werf hashtag',
          messageRequests : 'Message requests',
          enterGroupChatTitle:  "Enter group chat title",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Choose one from your existing chats, or start a new one',
          snoozeNotificationsFrom :  "Snooze notifications from",
          snoozeNotificationsFromTheGroup : "Snooze notifications from the group",
          snoozeMentions : "Snooze mentions",
          disableNotificationsWhenPeoplemention:"Disable notifications when people mention you in this conversation.",
          trySearchingForPeopleGroupsOrMessages : "Try searching for people,groups, or messages",
          werfieUser :  "Werfie User",
          otherChat :"other...",
          photoChat : 'Photo',
          videoChat : 'Video',
          fileChat : 'File',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'Direct Messages are private conversations between you and other people on Twitter. Share Tweets, media, and more!',
          searchChats : "Search Chats",
          allTabChat : "All",
          peopleTabChat : "People",
          groupsTabChat :"Group",
          chatsTabChat :"Chats",
          noResultsFor : "No results for",
          theTermYouEnteredDidNotBring : "The term you entered did not bring up any results",
          message : "Message",
          addMembersToChat : 'Add members to chat',
          noMessagesYet : "No Messages Yet",
          doNotAllowMessages : "don't allow messages",
          notAllowedToMessage : "Not allowed to message.",
          youHaveBlockedThisUser : "You have blocked this user",
          startAMessage :  "Start a message",
          react :  "React",
          undo : "Undo",
          reactions : 'Reactions',
          messageRequestsFallHere :
          "Message requests from people you don't follow live here. To reply there message, you need to accept the request.",
          noMessageRequestAvailable : 'No Message Request Available',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'Depending on the setting you select,different people can send you a direct message.',

          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          otherControls : "Other controls",
          filterLowQualityMessages : "Filter low-quality messages",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",
          showReadReceipts : "Show read receipts",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",


          getPushNotificationsToFindOut :"Get push notifications to find out what’s going on when you’re not on Werfie. You can turn them off anytime.",
          relatedToYouAndYourWerfs :"Related to you and your Werfs",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "When you turn on Werf notifications from people you follow, you'll get push notifications about their Werfs.",
          topWerfs :"Top Werfs",
          tailoredForYou: "Tailored for you",
          rewerf : 'Rewerf',
          like : 'Like',
          photoTags : "Photo Tags",
          messageReactions : "Message Reactions",
          fromWerfie : "From Werfie",
          newsSports : "News / Sports",
          recommendations : "Recommendations",
          turnOnPush:"Turn on push\nnotifications",
          toReceiveNotificationsAsTheyHappen :"To receive notifications as they happen, turn on\npush notification, You'll also receive them when\nyou're not on Werfie. Turn them off anytime.",
          turnOn : "Turn on",
          newNotifications :  "New notifications",
          werfsEmailedToYou : "Werfs emailed to you",
          weekly : 'Weekly',
          newAboutWerfieProduct :"New about Werfie product and features updates",
          tipsOnGettingMoreOut: "Tips on getting more out of Werfie",
          thingsYouMissedSinceYou: "Things you missed since you last logged into Werfie",
          participationInWerfieResearchSurveys: "Participation in Werfie research surveys",
          suggestionsRorRecommendedAccounts: "Suggestions for recommended accounts",
          suggestionsBasedOnYourRecentFollows: "Suggestions based on your recent follows",
          qualityFilters : "Quality filters",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Choose to filter out content such as duplicate and automated Werfs. This doesn't apply to notifications from accounts you follow and have interacted with recently.",

          emailNotification : 'Email Notifications',
          filters : "Filters",
          chooseTheNotification : "Choose the notification you'd like to see and those you don't",
          preferences : "Preferences",
          selectYourPreferencesByNotificationType :"Select your preferences by notification type.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie always uses some information,like where you signed up and and your current location,to help show you more relevant content.when this setting is enabled,Werfie may also personalize your experience based on other places you have been.',

          personalizeBasedOnPlacesYouHaveBeen :
          'Personalize based on places you have been',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Manage the location information Werfie uses to personalize your experience.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",

          showReadReceipts : "Show read receipts",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",


          filterLowQualityMessages :"Filter low-quality messages",
          otherControls : "Other controls",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "People you follow will still be able to message you",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'Depending on the setting you select,different people can send you a direct message.',

          controlWhoCanMessageYou : 'Control who can message you',
          forever : " Forever",
          muteNotificationsFromPeople :"Mute notifications from people:",
          youDoNotFollow : "You don't follow",
          whoDoNotFollowYou : "Who don't follow you",
          withANewAccount : "With a new account",
          whoHaveDefaultProfilePhoto :"Who have default profile photo",
          whoHaveNotConfirmedTheirEmail : "Who haven't confirmed their email",
          whoHaveNotConfirmedTheirPhoneNumber :"Who haven't confirmed their phone number",
          duration : 'Duration',
          untilYouUnmuteTheWord : 'Until you unmute the word',
          hours24 : '24 hours',
          days7 : '7 days',
          days30 : '30 days',
          fromPeopleYouDontFollow : "From people you don't follow",
          homeTimeline : 'Home timeline',
          muteFrom : 'Mute from',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'You can mute one word,@username,or hashtag at a time.',
          enterWordOrPhrase : 'Enter word or phrase',
          mutedWord : 'Muted word',
          addMutedWords : 'Add muted words',
          youHaveNotMutedAnyWordYet : 'You have not muted any word yet',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "when you mute words,you won't get any new notification for Werfs that include them or see Werfs with those words in your Home timeline.",

          youHaveNotMutedAnyPersonYet :
          'You have not muted any person yet',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Here's everyone you muted.You can add remove them from this list.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "When you block someone,that person won't be able to follow or message you.and you won't see notification from them.",

          mutedNotification : 'Muted notifications',
          mutedWords: 'Muted words',
          mutedAccounts : 'Muted accounts',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Manage the accounts,word,and notification that you have muted or blocked.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'This prevents Werfs with potentially sensitive content displaying in your search results.',

          hideSensitiveContent: 'Hide sensitive content',
          removeBlockedAndMutedAccounts :
          'Remove blocked and muted accounts',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'Use this to eliminate search results from account you have blocked or muted',
          personalization : 'Personalization',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'you can personalize trends based on your location and who you follow',
          exploreLocation : 'Explore location',
          showContentInThisLocation : 'Show content in this location',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'When this is on, you will see what is happening around you right now.',
          searchSettings  :'Search settings',
          exploreSettings : 'Explore settings',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Decide what you see on werfie based on your preferences like Topics',
          displayMediaThatMayContainSensitiveContent :
          'Display media that may contain sensitive content',
          addLocationInformationToYourWerfs :'Add location information to your Werfs',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "When enabled,picture and videos you Werf will be marked as sensitive for people who don't want to see sensitive content.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'Mark media you Werf as having material that may be sensitive',
          manageTheInformationAssociatedWithYourWerfs :
          'Manage the information associated with your Werfs.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'if enabled,you will be able to attach location to your Werfs.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Remove all location information attached to your Werfs',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'Location labels you have added to your Werfs will no longer be visible on Werfie.com, Werfie for IOS, and Werfie for Android. These updates may take some time to go into effect.',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Manage what information you allow other people on Werfie.',
          protectYourTweets : 'Protect your Werfs',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'When selected, your werfie and account information are only visible to people who follow you',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'This will make them visible only to your werfie followers',
          protect : 'Protect',
          photoTagging : 'Photo tagging',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou:
          'Only people you follow can tag you',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Allow people to tag you in their photos and receive notifications when they do so',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou : 'Only people you follow can tag you',
          security : 'Security',
          manageYourAccountsSecurity : "Manage your accounts security",
          twoFactorAuthentication : "Two-factor authentication",
          manageYourAccountsSecurityKeepTrack : "Manage your accounts security and keep track of your account usage",
          helpProtectYourAccountFromUnauthorizedAccess :  "Help protect your account from unauthorized access by requiring a second authentication method in addition to your X password. You can choose a text message, authentication app, or security key.",
          verificationCodeSentToYourRegisteredEmail:"Enter 6-digits verification code Sent to your registered email",
          submit :'Submit',
          genderChangedSuccessfully : "Gender Changed Successfully",
          genderSettingTextDescription :"If you haven’t already specified a gender, this is the one associated with your account based on your profile and activity. This information won’t be displayed publicly.",
          male:  'Male',
          female : 'Female',
          other : 'Other',
          change:'Change',
          changeCountrySettings:'Change country',
          selectACountry:'Select a country',
          updateEmailAddress:'Update email address',
          current:'Current',
          changeEmailSetting:'Change email',
          gender:'Gender',
          accountCreation:'Account creation',
          Age:'Age',
          securityAndAccountAccess:'Security and account access',
          youHaveNotCreatedOrFollowedAnyLists: "You haven't created or followed any Lists. When you do, they'll show up here.",
          userCanPinnedOnly5  : 'User can pinned  only 5 ',
          pleaseEnterTheName  : 'Please enter the name ',
          list : 'Lists',
          listYouAre :"Lists you're on",
          listYouHave:"You haven't been added to any Lists yet",
          listAddedSomeOne:"When someone adds you to a List, it'll show up here",
          listMembers :'List Members',
          listFollowers  : 'List Followers',
          noMembers: 'No Members',
          noResults :'No results',
          noFollowers:'No Followers',
          YourAccount: 'Akun Anda',
          notificationsSettings: 'Pengaturan Notifikasi',
          displaySettings: 'Pengaturan tampilan',
          moments: 'Momen',
          topic: 'topik',
          followings: 'Mengikuti',
          popularUpdates: 'Pembaruan Populer',
          privacyAndSafety: 'Privasi dan Keamanan',
          createWerf: 'Buat Werf',
          chats: 'obrolan',
          bookmarks: 'penanda buku',
          enterYourEmail: 'Masukkan email Anda',
          enterYourPassword: 'Masukkan kata sandi Anda',
          languageSettings: 'Pengaturan Bahasa',
          blockedAccountsSettings: 'Pengaturan Akun yang Diblokir',
          selectYourPreferredLanguage: 'Pilih bahasa pilihan Anda',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Rumah',
          browse: 'Jelajahi',
          hotTrends: 'Tren Panas',
          saved: 'Diselamatkan',
          messages: 'Pesan',
          myProfile: 'Profil saya',
          settings: 'Pengaturan',
          notifications: 'Pemberitahuan',
          settingsType: 'Jenis Pengaturan',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'Kelola bagaimana konten BuzzNBee ditampilkan kepada Anda',
          selectYourProfileLanguage: 'Pilih bahasa profil Anda',
          selectYourAppLanguage: 'Pilih bahasa aplikasi Anda',
          enableDisableAutoTranslation:
              'Aktifkan / nonaktifkan terjemahan otomatis',
          language: 'Bahasa',

          ///   Bahasa Indonesia
          username: "Nama belakang",
          snoozeNotification: "Tunda Pemberitahuan",
          version: "Versi: kapan",
          appVersion: "Versi Aplikasi",
          lists: "Daftar",
          deactivationAndDeletion: "Penonaktifan dan Penghapusan",
          confirmYourPasswords: "Konfirmasi Kata Sandi Anda",
          deactivateAccount: 'Nonaktifkan akun',
          or: 'EMAS',
          deleteAccount: "Hapus akun",
          updateYourLanguageAndTranslation:
              "Perbarui bahasa dan terjemahan Anda",
          manageYourPrivacySettings: "Kelola pengaturan privasi Anda",
          privacySettings: "Pengaturan Privasi",
          setYourPrivacySettings: 'Tetapkan pengaturan privasi Anda',
          messageSettings: "Pengaturan pesan",
          noOne: "Tidak ada",
          everyOne: 'Setiap orang',
          ChangeUsernameSettings: "Ubah Pengaturan Nama Pengguna",
          enterYourWerfieHandle: "Masukkan pegangan werfie Anda",
          youHaveNotBlockedAnyPersonYet: "Anda belum memblokir siapa pun",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "Jika Anda ingin menghapus akun Werfie Anda secara permanen, Setelah Anda mengklik tombol ok, Anda tidak akan dapat mengaktifkan kembali akun Anda atau mengambil konten atau informasi apa pun yang telah Anda tambahkan.",
          permanentlyDeleteAccount: "Hapus Akun Secara Permanen",
          whoCanMessageYou: 'Siapa yang dapat mengirimi Anda pesan',
          viewEditHistory: 'Lihat Sunting Riwayat',
          reportWerf: 'Laporkan wer',
          hideWerf: 'Sembunyikan wer',
          showMore:'Tampilkan Lebih Banyak',
          reportUser: 'Laporan pengguna',
          mute: 'Bisu',
          unMute: "Membunyikan",
          deleteWerf: "Hapus Werf",
          viewWerfAnalytics: 'Lihat Analisis Werf',
          pintoYourProfile: 'Sematkan ke profil Anda',
          editWerf: 'Sunting Werf',
          explore: 'Mengeksplorasi',

          blockedAccounts: 'Akun yang diblokir',
          translations: 'Terjemahan',
          viewListOfBlockedAccounts: 'Lihat daftar akun yang diblokir',
          realTimePostTranslation: 'Terjemahan pos waktu nyata',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'Pilih bahasa saat mengunggah video atau audio',
          originalTranslatedScriptAudioPost:
              'Skrip asli atau terjemahan dari postingan audio',
          listenTranslatedScript: 'Dengarkan skrip yang diterjemahkan',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Terjemahkan pesan secara otomatis dalam obrolan dalam bahasa yang dipilih pengguna',
          postedUpdate: 'diposting pembaruan.',
          peopleWhoReacted: 'Orang yang bereaksi',
          comments: 'Komentar',
          peopleWhoRetweeted: 'Orang yang me-retweet',
          leaveAComment: 'Tinggalkan komentar',
          post: 'Pos',
          cancel: 'Membatalkan',
          savePost: 'Simpan Posting',
          report: 'Laporan',
          hide: 'Bersembunyi',
          shareLinkVia: 'Bagikan Tautan melalui...',
          copyLink: 'Salin tautan',
          fieldRequired: 'Bidang Diperlukan',
          enterDescription: 'Masukkan Deskripsi',
          selectCategory: 'Pilih Kategori',
          okay: 'Oke,',
          pleaseWait: 'Mohon tunggu...',
          search: 'Mencari',
          logout: 'Keluar',
          writeSomethingHere: 'Tulis Sesuatu Disini',
          addMore: 'Tambahkan Lebih Banyak',
          image: 'Gambar',
          video: 'Video',
          videos: 'Videos',
          file: 'Mengajukan',
          gif: 'GIF',
          audio: 'audio',
          live: 'Hidup',
          doNotHaveAnAccount: "Tidak punya akun? ",
          register: 'Daftar',
          haveAnAccount: "Punya akun? ",
          login: 'Gabung',
          whoToFollow: 'Siapa yang harus diikuti?',
          noSuggestion: 'Tidak Ada Saran',
          follow: 'Mengikuti',
          unFollow: 'Berhenti mengikuti',
          seeMore: 'Lihat Selengkapnya',
          searchFilter: 'Cari Filter',
          people: 'Rakyat',
          fromAnyone: 'Dari Siapapun',
          peopleYouFollow: 'Orang yang anda ikuti',
          location: 'Lokasi',
          anywhere: 'Dimana saja',
          nearYou: 'Di dekat Anda',
          advancedSearch: 'Pencarian Lanjutan',
          trendsForYou: 'Tren Untuk Anda',
          noTrending: 'Tidak ada tren di Wilayah Anda',
          trendingIn: 'Sedang tren',
          // tweets: 'Tweet',
          noNotification: 'Tidak ada pemberitahuan untuk Anda',
          edit: 'Sunting',
          save: 'Menyimpan',
          cFollow: 'Mengikuti',
          addPeople: 'Tambahkan orang',
          someText: 'beberapa teks',
          reportConversation: 'Laporkan Percakapan',
          leaveConversation: 'Meninggalkan percakapan',
          enterYourMessage: 'Masukkan pesan Anda',
          showMoreComments: 'Tampilkan lebih banyak komentar',
          reBuzz: 'Rebuzz',
          noPosts: 'Tidak ada pembaruan untuk Anda',
          emailFieldCannotBeEmpty: 'Bidang Email tidak boleh kosong',
          emailFormatIsInvalid: 'Format Email tidak valid',
          rememberMe: 'Ingat saya',
          lostPassword: 'Kehilangan Kata sandi?',
          cLOGIN: 'GABUNG',
          emailOrPasswordIsIncorrect: 'Email atau kata sandi salah',
          newsFeed: 'Umpan Berita',
          trends: 'Tren',
          profile: 'Profil',
          newMessage: 'Pesan baru',
          next: 'Lanjut',
          searchPeople: 'Cari Orang',
          saySomething: 'Katakan sesuatu',
          noSearchResult: 'Tidak Ada Hasil Pencarian',
          searchResult: 'Hasil pencarian',
          hidePost: 'Sembunyikan Posting',
          showLess: 'Tampilkan Lebih Sedikit',
          showMore: 'Menampilkan lebih banyak',
          nothingYet: 'Belum ada!',
          savedPosts: 'Postingan Tersimpan',
          enterYourFirstName: 'Masukkan nama depan Anda',
          enterYourLastName: 'Masukkan nama belakang Anda',
          enterYourUsername: 'Masukkan nama pengguna Anda',
          signUp: 'Daftar',
          pleaseChooseACountry: 'Silakan pilih negara',
          replied: 'menjawab',
          reply: 'Membalas',
          delete: 'Menghapus',
          replyToComment: 'Balas komentar',
          noFollower: 'Tidak Ada Pengikut',
          following: 'Mengikuti',
          followBack: 'Ikuti kembali',
          followers: 'pengikut',
          follower: 'Pengikut',
          noFollowings: 'Tidak Ada yang Mengikuti',
          sendAMessageGetAMessage: 'Kirim pesan, dapatkan pesan',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'Direct Message adalah percakapan pribadi antara Anda dan orang lain di Twitter. Bagikan Tweet, media, dan lainnya!',
          startAConversation: 'Mulai Percakapan',
          groupInfo: 'Info kelompok',
          chatInfo: 'Info Obrolan',
          youDoNotHaveAMessageSelected:
              'Anda tidak memiliki pesan yang dipilih',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Pilih salah satu dari pesan Anda yang ada, atau mulai yang baru.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'Silakan masukkan kode verifikasi untuk memverifikasi email Anda',
          usernameOrEmail: 'Username atau email',
          enterVerificationCode: 'Masukkan kode verifikasi',
          confirmCode: 'Konfirmasi Kode',
          top: 'Atas',
          latest: 'Terbaru',
          photos: 'Foto',
          files: 'File',
          noPeople: 'Tidak ada orang',
          all: 'Semua',
          mentions: 'Sebutan',
          replies: 'Balasan',
          // tweetsAndReplies: 'Tweet & Balasan',
          media: 'Media',
          likes: 'Suka',
          searchPost: 'Cari Pembaruan',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'Kehilangan password? Silakan masukkan nama pengguna atau alamat email Anda. Anda akan menerima tautan untuk membuat kata sandi baru melalui email.',
          resetYourPassword: 'Mereset password Anda',
          enterCode: 'Memasukkan kode',
          enterNewPassword: 'Masukan kata sandi baru',
          reEnterPassword: 'Masukkan Kembali password',
          passwordCannotBeEmpty: 'Kata sandi tidak boleh Kosong',
          passwordShouldBeCharacter: 'Kata sandi harus 8 karakter',
          passwordShouldBeMatched: 'Kata sandi harus Cocok',
          resetPassword: 'Setel Ulang Kata Sandi',
          email: 'Surel',
          blockUser: 'Blokir Pengguna',
          public: 'Publik',
          mentionUsers: 'Sebutkan Pengguna',
          editProfile: 'Siapkan Profil',
          yourProfileIsUpdated: 'Profil Anda Diperbarui',
          seeProfile: 'Lihat Profil',
          skipForNow: 'Lewati untuk sekarang',
          addBio: 'Tambahkan Bio',
          profileUpdated: 'Profil diperbarui',
          upDate: 'Memperbarui',
          goToProfile: 'Buka Profil',
          more: 'Lagi',
          about: 'Tentang',
          help: 'Membantu',
          privacyPolicy: 'Kebijakan pribadi',
          blog: 'Blog',
          termsOfService: 'Persyaratan Layanan',
          youMustSelectACountry: 'Anda harus memilih negara',
          usernameIsAlreadyTaken: 'Nama pengguna sudah diambil',
          goBack: 'Kembali',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'Akun telah dibuat dengan email ini',
          yourPasswordIsResetSuccessfully:
              'Kata sandi Anda berhasil disetel ulang',
          returnToLogin: 'Kembali ke Login',
          youHaveEnteredAnInvalidCode:
              'Anda telah memasukkan kode yang tidak valid',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'Terima kasih telah membuat akun Anda dengan BuzznBee. Tim kami akan menghubungi Anda dalam 24 jam. Tetap aman!',
          success: 'Kesuksesan',
          goBackToHomePage: 'Kembali ke halaman Beranda',
        },
        'es': {
          theUsernameHasAlreadyBeenTaken : 'The username has already been taken.',
          thereWasAnErrorInSavingThisUsername : " There was an error in saving this Username!",
          showMenu : 'Show Menu',
          thisPollHasExpired : 'This poll has expired',
          youCannotVoteOnYourOwnPoll : 'You cannot vote on your own poll!',
          choice : "Choice",
          optionalPoll : "(Optional)",
          watchPartyLetGo :  "Watch party, let's go",
          createSpace :'Create Space',
          oopsSomethingWentWrongPleaseTryAgain : 'Oops…Something went wrong! Please try again',
          noSpacesAvailable : 'No spaces available',
          yourSpaceIsReady : "Your space is ready",
          spaceLinkCopiedSuccessfully : 'Space link copied successfully',
          instant : 'Instant',
          nameYourSpace : 'Name your space',
          whatDoYouWantToTalkAbout :'What do you want to talk about?',
          scheduleYourSpace : "Schedule your space",
          confirm : 'Confirm',
          selectTopic : 'Select Topic',
          momentDeleteSuccessfully : "Moment Deleted Successfully",
          createSpaceSuccessfully : "Create Space Successfully",
          pleaseEnterTheSpaceName : "Please enter the space name",
          spaces : 'Spaces',

          pleaseChooseEither1VideoOr1Pdf: "Please choose either 1 video or 1 Pdf at a time or up to 4 photos.",
          fileTypeIsNotAllowed:'File type is not allowed',
          thisPostIsScheduledFor: "This post is scheduled for",
          askAQuestion: 'Ask a question...',
          pollLength:'Poll length',
          hours: 'Hours',
          minutes:'Minutes',
          removePoll: 'Remove Poll',
          uploading: 'Uploading...',
          addDescription: "Add Description",
          willPostOn:  "Will Post on",
          date:'Date',
          youCannotScheduleAWerfInThePast: 'You cannot schedule a Werf in the past',
          time: 'Time',
          timeZone: 'Time zone',
          youHaveNoScheduledWerfs: 'You have no scheduled werfs',
          willSendOn:  "Will send on",
          selectAll: 'Select all',
          schedule: 'Schedule',
          scheduledWerfs: 'Scheduled Werfs',
          deselectAll: 'Deselect all',
          yourImageVideoWillBeAvailableInAMoment: 'Your image/video will be available in a moment.',
          pleaseEnterValidText: 'Please enter valid text',
          takeAPhoto: "Take a Photo",
          chooseFromGallery:  "Choose from Gallery",
          makeVideoWithPhoneCamera: "Make video with phone camera",
          unsentWerfs: 'Unsent Werfs',

      commentsHere:'comentarios aquí',
      ImageDescription : 'descripción de la imagen',
      viewHiddenReplies: 'Ver respuestas ocultas',
      undoRewerf: 'Deshacer rewerf',
      share:  "Compartir",
      view:  "Vista",
      werfLinkCopiedSuccessfully: "Enlace Werf copiado exitosamente",
      addBookmark: "Añadir marcador",
      removeBookmark: "Quitar marcador",
      werfSavedSuccessfully: '¡Werf se salvó con éxito!',
      werfUnsavedSuccessfully:  'Werf no salvado con éxito!',
      thereWasAnErrorInUnSavingThisWerf: '¡Hubo un error al cancelar la salvación de este werf!',
      thereWasAnErrorInSavingThisWerf:'¡Hubo un error al guardar a este werf!',
      thereWasAnErrorInBlockingThisUser:'¡Hubo un error al bloquear a este usuario!',
      noEditHistory: 'Sin historial de edición',
      unPinFromProfile: "Desanclar del perfil",
      saveWerf: 'Salvar a Werf',
      linkCopiedToClipBoard:  '¡Enlace copiado al portapapeles!',
      removeFromBookmarks: 'Quitar de favoritos',
      thereWasAnErrorInReportingThisUser: '¡Hubo un error al informar a este usuario!',
      viewOriginal: "original",
      showThisThread:'Mostrar este hilo',
      rewerf : 'Rewerf',

      werfAnalytics : "Análisis Werf",
      nothingFound:'Nada Encontrado',
      year:'Año',
      day : 'Día',
      month : 'Mes',
      thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
      "Esta debe ser la fecha de nacimiento de la persona que utiliza la cuenta. Incluso si estás creando una cuenta para tu negocio o evento.",
      editDateOfBirth : '¿Editar fecha de nacimiento?',
      deletePhoto :"Borrar foto",
      removePhoto : "Quitar foto",
      addPhoto :"Añadir foto",
      discard : "Desechar",
      removeWerfAlert :
      "Esto no se puede deshacer y perderás los cambios.",
      discardChanges : "¿Descartar los cambios?",
      youShouldBeAtLeast14YearsOld: 'Debes tener al menos 14 años.',
      contentOfDialog :"Contenido del diálogo",
      pinnedWerf : "Werf fijado",
      hiddenPost : "Werfs ocultos",
      thisCanBeOnlyChangedAFewTimes :" Esto sólo se puede cambiar unas cuantas veces. Asegúrese de ingresar la edad de la persona que usa la cuenta.",


      aboutHashTag : 'Acerca del hashtag',
      werfHashTag : 'Hashtag de Werf',
      messageRequests : 'Solicitudes de mensajes',
      enterGroupChatTitle:  "Ingrese el título del chat grupal",
      chooseOneFromYourExistingChatsOrStartANewOne:
      'Elija uno de sus chats existentes o inicie uno nuevo',
      snoozeNotificationsFrom :  "Posponer notificaciones de",
      snoozeNotificationsFromTheGroup : "Posponer notificaciones del grupo",
      snoozeMentions : "Posponer menciones",
      disableNotificationsWhenPeoplemention:"Desactiva las notificaciones cuando la gente te mencione en esta conversación.",
      trySearchingForPeopleGroupsOrMessages : "Intenta buscar personas, grupos o mensajes.",
      werfieUser :  "Usuario Werfie",
      otherChat :"otro...",
      photoChat : 'Foto',
      videoChat : 'Video',
      fileChat : 'Archivo',
      directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
      'Los Mensajes Directos son conversaciones privadas entre usted y otras personas en Twitter. ¡Comparte tweets, medios y más!',
      searchChats : "Buscar chats",
      allTabChat : "Todo",
      peopleTabChat : "Gente",
      groupsTabChat :"Grupo",
      chatsTabChat :"Charlas",
      noResultsFor : "No hay resultados para",
      theTermYouEnteredDidNotBring : "El término que ingresaste no arrojó ningún resultado.",
      message : "Mensaje",
      addMembersToChat : 'Agregar miembros para chatear',
      noMessagesYet : "Aún no hay mensajes",
      doNotAllowMessages : "no permitir mensajes",
      notAllowedToMessage : "No se permite enviar mensajes.",
      youHaveBlockedThisUser : "Has bloqueado a este usuario",
      startAMessage :  "iniciar un mensaje",
      react :  "Reaccionar",
      undo : "Deshacer",
      reactions : 'Reacciones',
      messageRequestsFallHere :
      "Solicitudes de mensajes de personas que no sigues en vivo aquí. Para responder ese mensaje, debe aceptar la solicitud.",
      noMessageRequestAvailable : 'No hay solicitud de mensaje disponible',
      dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
      'Dependiendo de la configuración que seleccione, diferentes personas pueden enviarle un mensaje directo.',

      allowMessagesOnlyFromPeopleYouFollow :
      'Permitir mensajes solo de las personas que sigues',
      youWontReceiveAnyMessageRequests :
      "No recibirás ninguna solicitud de mensaje.",
      allowMessageRequestsOnlyFromVerifiedUsers :
      "Permitir solicitudes de mensajes solo de usuarios verificados",
      peopleYouFollowWillStillBeAbleToMessageYou :
      "Las personas a las que sigues aún podrán enviarte mensajesu",
      allowMessagesRequestsFromEveryone :
      'Permitir solicitudes de mensajes de todosne',
      otherControls : "Otros controles",
      filterLowQualityMessages : "Filtrar mensajes de baja calidad",
      hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
      "Oculte las solicitudes de mensajes que se hayan detectado como potencialmente extensas o de baja calidad. Se enviarán a una bandeja de entrada separada en la parte inferior de sus solicitudes de mensajes. Aún puede acceder a ellas si lo desea.",
      showReadReceipts : "Mostrar recibos de lectura",
      letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
      "Informe a las personas con las que está enviando mensajes cuando haya visto sus mensajes. Los recibos de lectura no se muestran en las solicitudes de mensajes.",


      getPushNotificationsToFindOut :"Recibe notificaciones automáticas para saber qué sucede cuando no estás en Werfie. Puedes desactivarlos en cualquier momento.",
      relatedToYouAndYourWerfs :"Relacionado con ti y tus Werfs",
      whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "Cuando activas las notificaciones Werf de las personas que sigues, recibirás notificaciones automáticas sobre sus Werfs.",
      topWerfs :"Mejores jugadores",
      tailoredForYou: "Adaptado para usted",
      rewerf : 'Rewerf',
      like : 'Como',
      photoTags : "Etiquetas de foto",
      messageReactions : "Reacciones al mensaje",
      fromWerfie : "De Werfie",
      newsSports : "Noticias / Deportes",
      recommendations : "Recommendations",
      turnOnPush:"Activar\nnotificaciones push",
      toReceiveNotificationsAsTheyHappen :"Para recibir notificaciones a medida que ocurren, activa\nlas notificaciones automáticas. También las recibirás cuando\nno estés en Werfie. Apágalos en cualquier momento.",
      turnOn : "Encender",
      newNotifications :  "Nuevas notificaciones",
      werfsEmailedToYou : "Werfs te envió un correo electrónico",
      weekly : 'Semanalmente',
      newAboutWerfieProduct :"Novedades sobre actualizaciones de características y productos de Werfie",
      tipsOnGettingMoreOut: "Consejos para sacarle más provecho a Werfie",
      thingsYouMissedSinceYou: "Cosas que te perdiste desde la última vez que iniciaste sesión en Werfie",
      participationInWerfieResearchSurveys: "Participación en encuestas de investigación de Werfie.",
      suggestionsRorRecommendedAccounts: "Sugerencias para cuentas recomendadas",
      suggestionsBasedOnYourRecentFollows: "Sugerencias basadas en tus seguidores recientes",
      qualityFilters : "Filtros de calidad",
      chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Elija filtrar contenido como Werfs duplicados y automatizados. Esto no se aplica a las notificaciones de cuentas que sigues y con las que has interactuado recientemente.",

      emailNotification : 'Notificaciónes de Correo Electrónico',
      filters : "Filtros",
      chooseTheNotification : "Elige las notificaciones que te gustaría ver y las que no",
      preferences : "Preferencias",
      selectYourPreferencesByNotificationType :"Seleccione sus preferencias por tipo de notificación.",
      werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
      'Werfie siempre utiliza cierta información, como dónde se registró y su ubicación actual, para ayudar a mostrarle contenido más relevante. Cuando esta configuración está habilitada, Werfie también puede personalizar su experiencia en función de otros lugares en los que haya estado.',

      personalizeBasedOnPlacesYouHaveBeen :
      'Personaliza según los lugares en los que has estado',
      manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
      'Administre la información de ubicación que Werfie utiliza para personalizar su experiencia.',

      letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
      "Informe a las personas con las que está enviando mensajes cuando haya visto sus mensajes. Los recibos de lectura no se muestran en las solicitudes de mensajes.",

      showReadReceipts : "Mostrar recibos de lectura",
      hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
      "Oculte las solicitudes de mensajes que se hayan detectado como potencialmente extensas o de baja calidad. Se enviarán a una bandeja de entrada separada en la parte inferior de sus solicitudes de mensajes. Aún puede acceder a ellas si lo desea.",


      filterLowQualityMessages :"Filtrar mensajes de baja calidad",
      otherControls : "Otros controles",
      peopleYouFollowWillStillBeAbleToMessageYou :
      "Las personas a las que sigues aún podrán enviarte mensajes",
      allowMessagesRequestsFromEveryone :
      'Permitir solicitudes de mensajes de todos',
      peopleYouFollowWillStillBeAbleToMessageYou:
      "Las personas a las que sigues aún podrán enviarte mensajes",
      allowMessageRequestsOnlyFromVerifiedUsers :
      "Permitir solicitudes de mensajes solo de usuarios verificados",
      youWontReceiveAnyMessageRequests :
      "No recibirás ninguna solicitud de mensaje.",
      allowMessagesOnlyFromPeopleYouFollow :
      'Permitir mensajes solo de las personas que sigues',

      dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
      'Dependiendo de la configuración que seleccione, diferentes personas pueden enviarle un mensaje directo.',

      controlWhoCanMessageYou : 'Controla quién puede enviarte mensajes',
      forever : " Para siempre",
      muteNotificationsFromPeople :"Silenciar notificaciones de personas:",
      youDoNotFollow : "tu no sigues",
      whoDoNotFollowYou : "Quien no te sigue",
      withANewAccount : "Con una cuenta nueva",
      whoHaveDefaultProfilePhoto :"Que tienen foto de perfil predeterminada",
      whoHaveNotConfirmedTheirEmail : "Quienes no han confirmado su correo electrónico",
      whoHaveNotConfirmedTheirPhoneNumber :"Que no han confirmado su número de teléfono",
      duration : 'Duración',
      untilYouUnmuteTheWord : 'Hasta que desactives la palabra',
      hours24 : '24 horas',
      days7 : '7 días',
      days30 : '30 dias',
      fromPeopleYouDontFollow : "De gente que no sigues",
      homeTimeline : 'Línea de tiempo de inicio',
      muteFrom : 'Silenciar desde',
      youCanMuteOneWordUsernameOrHashtagAtATime :
      'Puedes silenciar una palabra, @nombre de usuario o hashtag a la vez.',
      enterWordOrPhrase : 'Introduce palabra o frase',
      mutedWord : 'palabra silenciada',
      addMutedWords : 'Agregar palabras silenciadas',
      youHaveNotMutedAnyWordYet : 'Aún no has silenciado ninguna palabra',
      whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
      "Cuando silencias palabras, no recibirás ninguna notificación nueva de Werfs que las incluya ni verás Werfs con esas palabras en tu línea de tiempo de inicio.",

      youHaveNotMutedAnyPersonYet :
      'Aún no has silenciado a ninguna persona',
      HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
      "Aquí están todas las personas que silenciaste. Puedes agregarlas y eliminarlas de esta lista.",
      whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
      "Cuando bloqueas a alguien, esa persona no podrá seguirte ni enviarte mensajes y no verás sus notificaciones.",

      mutedNotification : 'Notificaciones silenciadas',
      mutedWords: 'palabras silenciadas',
      mutedAccounts : 'Cuentas silenciadas',
      ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
      'Administre las cuentas, palabras y notificaciones que ha silenciado o bloqueado.',
      thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
      'Esto evita que se muestren Werfs con contenido potencialmente confidencial en los resultados de búsqueda.',

      hideSensitiveContent: 'Ocultar contenido sensible',
      removeBlockedAndMutedAccounts :
      'Eliminar cuentas bloqueadas y silenciadas',
      useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
      'Utilízalo para eliminar los resultados de búsqueda de la cuenta que has bloqueado o silenciado.',
      personalization : 'Personalización',
      youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
      'Puedes personalizar las tendencias según tu ubicación y a quién sigues.',
      exploreLocation : 'Explorar ubicación',
      showContentInThisLocation : 'Mostrar contenido en esta ubicación',
      WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
      'Cuando esto esté activado, verás lo que está sucediendo a tu alrededor en este momento.',
      searchSettings  :'Configuración de búsqueda',
      exploreSettings : 'Explorar configuraciones',
      decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
      'Decide lo que ves en werfie según tus preferencias, como Temas',
      displayMediaThatMayContainSensitiveContent :
      'el material mostrado puede tener contenido sensible',

      addLocationInformationToYourWerfs :'Agregue información de ubicación a sus Werfs',
      WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
      "Cuando esté habilitado, las imágenes y los videos que usted obtenga se marcarán como confidenciales para las personas que no quieran ver contenido confidencial.",
      markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
      'Marque los medios que Werf tiene como material que puede ser sensible',
      manageTheInformationAssociatedWithYourWerfs :
      'Gestiona la información asociada a tus Werfs.',
      ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
      'Si está habilitado, podrá adjuntar la ubicación a sus Werfs.',
      removeAllLocationInformationAttachedToYourWerfs :
      'Elimina toda la información de ubicación adjunta a tus Werfs',
      locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
      'Las etiquetas de ubicación que haya agregado a sus Werfs ya no serán visibles en Werfie.com, Werfie para IOS y Werfie para Android. Estas actualizaciones pueden tardar algún tiempo en entrar en vigor.',

      manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Gestiona qué información permites a otras personas en Werfie.',
      protectYourTweets : 'Protege a tus Werfs',
      whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
      'Cuando se selecciona, su werfie y la información de su cuenta solo son visibles para las personas que lo siguen.',
      thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'Esto los hará visibles sólo para tus seguidores werfie.',
      protect : 'Proteger',
      photoTagging : 'Etiquetado de fotos',
      AnyoneCanTagYou : 'Cualquiera puede etiquetarte',
      onlyPeopleYouFollowCanTagYou:
      'Sólo las personas que sigues pueden etiquetarte',
      allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
      'Permitir que las personas te etiqueten en sus fotos y recibir notificaciones cuando lo hagan',
      AnyoneCanTagYou : 'Cualquiera puede etiquetarte',
      onlyPeopleYouFollowCanTagYou : 'Sólo las personas que sigues pueden etiquetarte',
      security : 'Seguridad',
      manageYourAccountsSecurity : "Gestiona la seguridad de tus cuentas",
      twoFactorAuthentication : "Autenticación de dos factores",
      manageYourAccountsSecurityKeepTrack : "Administre la seguridad de sus cuentas y realice un seguimiento del uso de su cuenta.",
      helpProtectYourAccountFromUnauthorizedAccess :  "Ayude a proteger su cuenta del acceso no autorizado solicitando un segundo método de autenticación además de su contraseña X. Puede elegir un mensaje de texto, una aplicación de autenticación o una clave de seguridad.",
      verificationCodeSentToYourRegisteredEmail:"Ingrese el código de verificación de 6 dígitos Enviado a su correo electrónico registrado",
      submit :'Entregar',
      genderChangedSuccessfully : "El género cambió con éxito",
      genderSettingTextDescription :"Si aún no has especificado un género, este es el asociado a tu cuenta según tu perfil y actividad. Esta información no se mostrará públicamente.",
      male:  'Masculino',
      female : 'Femenina',
      other : 'Otro',
      change:'Cambiar',
      changeCountrySettings:'Cambiar pais',
      selectACountry:'Seleccione un país',
      updateEmailAddress:'Actualización de la dirección de correo electrónico',
      current:'Actual',
      changeEmailSetting:'Cambiar e-mail',
      gender:'Género',
      accountCreation:'Creación de cuenta',
      Age:'Edad',
      securityAndAccountAccess:'Seguridad y acceso a la cuenta',
      youHaveNotCreatedOrFollowedAnyLists: "No has creado ni seguido ninguna lista. Cuando lo hagas, aparecerán aquí.",
      userCanPinnedOnly5  : 'El usuario puede anclar solo 5 ',
      pleaseEnterTheName  : 'Por favor ingrese el nombre ',
      list : 'Liza',
      listYouAre :"Listas en las que estás",
      listYouHave:"Aún no te han agregado a ninguna lista",
      listAddedSomeOne:"Cuando alguien te agregue a una lista, aparecerá aquí",
      listMembers :'Lista de miembros',
      listFollowers  : 'Lista de seguidores',
      noMembers: 'Sin miembros',
      noResults :'No hay resultados',
      noFollowers:'Sin seguidores',
      manageWhatInformationYouSeeAndShareOnWerfie: 'Administre la información que ve y comparte en Werfie.',
      noResponseFromServerMsg: 'Estamos experimentando algunas dificultades. Por favor, inténtelo de nuevo más tarde',
      filteredResult:'Resultado filtrado',
      forYou:'Para ti',
      noInternetAvailable:'¡No hay Internet disponible!',
      welcomeToWerfie:'Bienvenido a werfi',
      cantChooseEmailAsApass:
      "No puede elegir el correo electrónico como contraseña. \nElija una contraseña segura.",
      passMustContainUpperCaseAndLeeter:
      'La contraseña debe contener al menos una letra mayúscula \ny un número',
      bothPasswordAndConfirmPassShouldMatch:
      'Tanto la contraseña como la contraseña de confirmación deben coincidir',
      DidNoTReceiveCode: "¿No recibiste el código?",
      verificationCode: 'Código de verificación',
      enterYourNewPasswordHint: 'Introduzca su nueva contraseña',
      ChangePasswordSettings: 'Cambiar la contraseña',
      trendingUpdates: 'Actualizaciones de tendencias',
      dobAddMsg: 'Añade tu fecha de nacimiento a tu ',
      audienceAndTagging: 'Audiencia y etiquetado',
      LearnMoreAboutPrivacyOnWerfie:
      'Obtenga más información sobre la privacidad en Werfie',
      yourWerfieActivity: 'Tu actividad Werfie',
      yourAndTagging: 'Tu y etiquetando',
      yourWerfs: 'Tus Werfs',
      contentYouSee: "Contenido que ves",
      muteAndBlock: 'Silenciar y bloquear',
      directMessages: 'Mensaje directo',
      dataSharingAndPersonalization:
      'Intercambio de datos y personalización',
      locationInformation: 'Información sobre la ubicación',
      nameCannotBeEmpty: "Se requiere el nombre",
      nameLengthShouldMax20:
      "La longitud del nombre no debe ser superior a 20",
      nameStartsWithCharacter: "El nombre debe comenzar con Alfabetos",
      pleaseProvideAValidEmail:
      "Por favor proporcione un correo electrónico válido",
      werfieHandleIsRequired: "Se requiere mango Werfie",
      passwordShouldBeMin8Char:
      'La contraseña debe tener al menos 8 caracteres',
      pleaseEnterYourBirthDate:
      'Por favor, introduzca su fecha de nacimiento',
      enterYourBirthDateOptional:
      'Ingresa tu fecha de nacimiento (Opcional)',
      rewerf: 'Rewerf',
      topicsThatYouFollowShownHere:
      'Los temas que sigues se muestran aquí. Para ver todas las cosas que Werfie cree que te interesan, consulta Tus datos de Werfie. También puede obtener más información sobre los siguientes temas.',
      bySigningUpYouAgree: 'Al registrarte, aceptas nuestra,',
      and: 'y',
      privacyUpdated: 'Privacidad actualizada',
      removeWerfFromBookMark: 'Quitar werf del marcador',
      areYouSure: 'Estas segura?',
      doYouWantToExit: '¿Quieres salir de la aplicación?',
      no: 'No',
      yes: 'Sí',
      werfUnsaved: 'Werf ¡No se guardó correctamente!',
      private: 'Hacer privado',
      name: 'Nombre',
      bio: "Biografía",
      birthDate: 'Fecha de nacimiento',
      create: 'Crear',
      weWontSuggestThisTopic: "Ya no sugeriremos este tema",
      youllSeeTopWerfs:
      "Verás los mejores Werfs sobre estos directamente en tu línea de tiempo de inicio.",
      requestVerification: 'Solicitar verificación',
      enterCurrentPassword: 'Introducir la contraseña actual',
      enterYourNewPassword:
      "Ingrese su nueva contraseña y presione el botón Siguiente. Le enviaremos un código de 4 dígitos a su dirección de correo electrónico. Deberá ingresar ese código de 4 dígitos en la siguiente pantalla para completar el proceso.",
      noWerfs: 'Sin Werfs',
      verified: 'Verificada',
      getMoments: 'Obtener momentos',
      tweetsAndReplies: 'Werfs y respuestas',
      yourlist: 'Tus listas',
      copyProfileLink: 'Copiar enlace de perfil',
      signInWithApple: 'Iniciar sesión con Apple',
      searchForAnItem: 'Buscar un artículo...',
      changedTheCountryName: '¡Cambié el nombre del país con éxito!',
      editOrder: 'editar secuencia',
      ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults:
      'Esto no se puede deshacer y se eliminará de su perfil, de la línea de tiempo de cualquier cuenta que lo siga y de los resultados de búsqueda de Werfie.',
      writeAShortDesc: 'Escribe una breve descripción sobre momentos.',
      addATitle: 'Añade un titulo',
      publish: 'Publicar',
      likedBy: 'Apreciado por',
      werfSearch: 'Búsqueda de Werfs',
      werfsByAccount: "Werfs por cuenta",
      werfsILiked: "palabras que me han gustado",
      addWerfs: 'Agregar Werfs',
      allReply: 'Todos responden',
      replyingTo: 'respondiendo a ',
      werfYourReply: 'Verifica tu respuesta...',
      noMomentsList: 'sin momentos',
      justNow: "En este momento",
      clear: 'Clara',
      createANewWerf: 'Crear un nuevo Werf',
      suggestedTopics: 'Temas sugeridos',
      whenYouFollowMsg:
      "Cuando sigue una Lista, podrá mantenerse rápidamente al día con los expertos sobre lo que más le interesa.",
      chooseYourLists: 'Elige tus Listas',
      discoverlist: 'Descubre nuevas listas',
      pinnedList: "Lista anclada",
      createNew: 'Crear nueva',
      chooseAnExistingMomentOrCreateNew:
      'Elija un momento existente o cree uno nuevo',
      seizeTheMoment: "Aprovechar el momento",
      momentDeleteSuccessfully: 'Momento eliminado con éxito',
      createMoment: 'Crear momento',
      removeMomentAlertMsg:
      'Esto no se puede deshacer y perderá su Momento.',
      momentsDelete: 'Momentos ¿Eliminar?',
      nothingToSeeHere: 'Nada que ver aqui',
      nothingToSeeHerePinYour:
      'No hay nada que ver aquí todavía: fije sus Listas favoritas para acceder a ellas rápidamente.',
      viewHiddenReply: 'Ver respuesta oculta',
      block: 'Bloquear',
      chooseOneFromYourExistingChatsOrStartANewOne:
      'Elija uno de sus chats existentes o inicie uno nuevo',
      youDoNotHaveAChatSelected: 'No tienes un chat seleccionado',
      editGroup: 'Editar grupo',
      colors: 'Colores',
      dark: "oscuro",
      light: "claro",
      theseSettingsAffect:
      "Esta configuración afecta a todas las cuentas de Werfie en este navegador.",
      customizeView: 'Personaliza tu vista',
      dismiss: 'Despedir',
      thisWerfSeen: 'Veces esta werf fue visto.',
      youHaveAlreadyReportedWerf: 'Ya reportaste este werf',
      enterDescriptionFieldIsRequired:
      "Enter description field is required",
      searchLocation: 'Buscar ubicación',
      tagLocation: 'Ubicación de la etiqueta',
      profileVisits: 'Visitas de perfil',
      newFollowers: 'Nuevas seguidoras',
      detailExpands: 'Detalle se expande',
      engagements: 'Compromisos',
      impressions: 'impresiones',
      werfAnalytics: 'Análisis Werf',
      followed: 'seguido',
      notInterested: 'No interesada',
      suggested: 'Sugerida',
      add: 'Agregar',
      remove: 'Eliminar',
      members: 'miembros',
      whenYouMakeAList:
      "Cuando haces una lista privada, solo tú puedes verla.",
      makePrivate: 'Hacer privada',
      createNewList: 'Crear nueva lista',
      next: 'Próxima',
      done: 'Hecho',
      editList: 'Lista de edición',
      manageMembers: 'Administrar miembros',
      delete: 'Borrar',
      listYouAreON: "Listas en las que estás",
      newsSocial: 'Noticias',
      filmTV: 'entretenimiento',
      music: 'musica',
      travelAdventure: 'Viajar',
      newChat: 'Nueva conversación',
      noMsgsYet: 'No hay mensajes todavía',
      addToYourList: 'Añadir a tu lista',
      theTopicsYouFollow:
      "Los Temas que sigue se utilizan para personalizar los Werfs, los eventos y los anuncios que ve y se muestran públicamente en su perfil.",
      verification: 'verificación',
      verificationAccount: 'Verificación de la cuenta',
      country: 'País',
      userNameSavedSuccessfully: '¡Nombre de usuario guardado con éxito!',
      deactivateAccount: 'desactivar cuenta',
      off: 'Apagada',
      weekly: 'Semanalmente',
      daily: 'A diario',
      topWerfs: 'Top Werfs',
      getEmailToFindOut:
      'Recibe correos electrónicos para saber qué sucede cuando no estás en Werfie. Puedes apagarlos en cualquier momento.',
      pushNotifications: 'Notificación de inserción',
      otpSentMsg:
      "Acabamos de enviar un código de 4 dígitos a su dirección de correo electrónico. Ingrese ese código en el lugar que se indica a continuación y presione el botón Confirmar",
      sendViaDirectMessage: 'Enviar por mensaje directo',
      shareWerf: 'Compartir Werf',
      copylinkToWerf: 'Copiar enlace a Werf',
      pickWhoCanReplyMsg:
      'Elige quién puede responder a este Werf. Tenga en cuenta que cualquier persona mencionada siempre puede responder.,',
      whoCanReply: '¿Quién puede responder?',
      everyoneCanReply: 'Todas pueden responder',
      onlyPeopleYouMention: 'Solo las personas que mencionas',
      allwerf: 'Todo Werf',
      changeEmail: 'Cambiar e-mail',
      werfs: 'Werfs',
      viewTranslated: 'Ver traducido',
      ChangeYourPassword: 'cambia tu contraseña',
      accountInformation: 'Información de la cuenta',
      viewTopics: 'Ver temas',
      confirmPassMsg: 'Confirmar la contraseña',
      wrongPasswordMsg: 'Contraseña incorrecta',
      languageSettings: 'Ajustes de idioma',
      unBlock: 'Desatascar',
      loginWithGoogle: 'Iniciar sesión con Google',
      createYourPassword: 'Crea tu contraseña',
      createYourWerfieHandle: 'Crea tu mango werfie',
      forwardMessage: 'Reenviar mensaje',
      copy: 'Copiar mensaje',
      messageDelete: 'eliminar por ti',
      deleteConversation: 'Eliminar la conversación',
      peopleInThisChat: 'Personas en este chat',
      views: 'Puntos de vista',
      werfSeenCountMsg: 'Veces esta Werf fue vista',
      newWerf: 'Nueva Werf',
      newWerfs: 'Nuevas Werfs',
      pinPostMsg: 'Fijar publicación en tu perfil',
      unPinPostMsg: '¡Desanclar la publicación a tu perfil!',
      removeWerfAlert: "Esto no se puede deshacer y perderá los cambios.",
      quoteRewerf: 'Cita Rewerf',
      rewerfSuccessfully: 'ReWerf con éxito',
      noReplyComments: 'Sin comentarios de respuesta',
      postDetail: 'Detalle Werf',
      profileLinkCopy: '¡El enlace del perfil se copió con éxito!',
      muteUser: 'silenciado con éxito',
      userReportedSuccessfully: 'Usuario reportado con éxito!',
      userBlockedSuccessfully: 'Usuario bloqueado con éxito!',
      werfReportedSuccssfully: 'Werf reportado con éxito',
      YourAccount: 'Su cuenta',
      notificationsSettings: 'Configuracion de notificaciones',
      displaySettings: 'Configuración de pantalla',
      moments: 'Momentos',
      topic: 'temas',
      followings: 'Seguidoras',
      popularUpdates: 'Atualizações populares',
      privacy: 'Privacidade',
      createWerf: 'Criar Werf',
      chats: 'bate-papos',
      bookmarks: 'favoritas',
      bookmarks: 'favorita',
      enterYourEmail: 'Digite seu e-mail',
      enterYourPassword: 'Coloque sua senha',
      // languageSettings: 'Configurações de linguagem',
      blockedAccountsSettings: 'Configurações de contas bloqueadas',
      selectYourPreferredLanguage: 'Selecione seu idioma preferido',
      english: 'English',
      arabic: 'عربي',
      french: 'Français',
      german: 'Deutsche',
      spanish: 'Española',
      hindi: 'हिंदी',
      indonesia: 'Bahasa Indonesia',
      portuguese: 'Português',
      turkish: 'Turca',
      somali: 'Shoomaali',
      persian: 'فارسی',
      home: 'Casa',
      browse: 'Navegar',
      hotTrends: 'Tendências quentes',
      saved: 'Salvou',
      messages: 'Mensagens',
      myProfile: 'Meu perfil',
      settings: 'Definições',
      notifications: 'Notificações',
      settingsType: 'Tipo de configuração',
      manageHowBuzzNBeeContentIsDisplayedToYou:
      'Gerenciar como o conteúdo do BuzzNBee é exibido para você',
      selectYourProfileLanguage: 'Selecione o idioma do seu perfil',
      selectYourAppLanguage: 'Selecione o idioma do seu aplicativo',
      enableDisableAutoTranslation:
      'Ativar / desativar tradução automática',
      language: 'Língua',

      ///   Português
      username: "Nome do usuário",
      snoozeNotification: "Adiar Notificação",
      version: "Versão",
      appVersion: "Versão do aplicativo",
      lists: "Listas",
      deactivationAndDeletion: "Desativação e exclusão",
      confirmYourPasswords: "Confirme suas senhas",
      deactivateAccount: 'Desativar conta',
      or: 'OU',
      deleteAccount: "Deletar conta",
      updateYourLanguageAndTranslation: "Atualize seu idioma e tradução",
      manageYourPrivacySettings:
      "Gerenciar suas configurações de privacidade",
      privacySettings: "Configurações de privacidade",
      setYourPrivacySettings: 'Defina suas configurações de privacidade',
      messageSettings: "Configurações de mensagem",
      noOne: "Ninguém",
      everyOne: 'Todos',
      ChangeUsernameSettings: "MudarConfigurações de nome de usuário",
      enterYourWerfieHandle: "Digite seu identificador wefie",
      youHaveNotBlockedAnyPersonYet: "Anda belum memblokir siapa pun",
      IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
      "Se você deseja excluir permanentemente sua conta Werfie, depois de clicar no botão ok, você não poderá reativar sua conta ou recuperar qualquer conteúdo ou informação que adicionou.",
      permanentlyDeleteAccount: "Excluir conta permanentemente",
      whoCanMessageYou: 'Quem pode enviar uma mensagem para você',
      viewEditHistory: 'Ver Histórico de Edição',
      reportWerf: 'Relatório wef',
      hideWerf: 'Ocultar werf',
      showMore:"Mostrar mais",
      reportUser: 'Reportar usuário',
      mute: 'Mudo',
      unMute: "Ativar som",
      deleteWerf: 'Excluir Werf',
      viewWerfAnalytics: 'Ver Werf Analytics',
      pintoYourProfile: 'Fixe no seu perfil',
      editWerf: 'Editar Werf',
      explore: "Explorar",

      blockedAccounts: 'Contas bloqueadas',
      translations: 'Traduções',
      viewListOfBlockedAccounts: 'Ver lista de contas bloqueadas',
      realTimePostTranslation: 'Pós-tradução em tempo real',
      selectLanguageTheTimeOfUploadingVideoOrAudio:
      'Selecione o idioma no momento de enviar um vídeo ou áudio',
      originalTranslatedScriptAudioPost:
      'Roteiro original ou traduzido da postagem de áudio',
      listenTranslatedScript: 'Ouça o roteiro traduzido',
      automaticallyTranslateMessagesChatUsersSelectedLanguage:
      'Traduzir mensagens automaticamente no bate-papo no idioma selecionado pelos usuários',
      postedUpdate: 'postou uma atualização.',
      peopleWhoReacted: 'Pessoas que reagiram',
      comments: 'Comentários',
      peopleWhoRetweeted: 'Pessoas que retuitaram',
      leaveAComment: 'Deixe um comentário',
      post: 'Publicar',
      cancel: 'Cancelar',
      savePost: 'Salvar postagem',
      report: 'Relatório',
      hide: 'Esconder',
      shareLinkVia: 'Compartilhar link via ...',
      copyLink: 'Link de cópia',
      fieldRequired: 'Campo requerido',
      enterDescription: 'Insira a descrição',
      selectCategory: 'Selecione a Categoria',
      okay: 'OK,',
      pleaseWait: 'Por favor, espere...',
      search: 'Procurar',
      logout: 'Sair',
      writeSomethingHere: 'Escreva algo aqui',
      addMore: 'Adicione mais',
      image: 'Imagem',
      video: 'Vídeo',
      videos: 'Vídeos',
      file: 'Arquivo',
      gif: 'GIF',
      audio: 'Áudio',
      live: 'Ao vivo',
      doNotHaveAnAccount: "Não tem uma conta? ",
      register: 'Registro',
      haveAnAccount: "Ter uma conta? ",
      login: 'Conecte-se',
      whoToFollow: 'Quem seguir',
      noSuggestion: 'Sem sugestão',
      follow: 'Seguir',
      unFollow: 'Deixar de seguir',
      seeMore: 'Ver mais',
      searchFilter: 'Filtro de Pesquisa',
      people: 'Pessoas',
      fromAnyone: 'De qualquer um',
      peopleYouFollow: 'Pessoas que você segue',
      location: 'Localização',
      anywhere: 'Em qualquer lugar',
      nearYou: 'Perto de você',
      advancedSearch: 'Busca Avançada',
      trendsForYou: 'Tendências para você',
      noTrending: 'Não há tendências em sua região',
      trendingIn: 'Tendências em',
      // tweets: 'Tweets',
      noNotification: 'Não há notificações para você',
      refresh: 'atualizar',
      edit: 'Editar',
      save: 'Salve ',
      cFollow: 'Seguir',
      addPeople: 'Adicionar pessoas',
      someText: 'algum texto',
      reportConversation: 'Reportar conversa',
      leaveConversation: 'Deixar conversa',
      enterYourMessage: 'Digite sua mensagem',
      showMoreComments: 'Mostrar mais comentários',
      reBuzz: 'Rebuzz',
      noPosts: 'Sem atualizações para você',
      emailFieldCannotBeEmpty: 'O campo do email não pode estar vazio',
      emailFormatIsInvalid: 'O formato do email é inválido',
      rememberMe: 'Lembre de mim',
      lostPassword: 'Senha perdida?',
      cLOGIN: 'CONECTE-SE',
      emailOrPasswordIsIncorrect: 'E-mail ou senha está incorreto',
      newsFeed: 'Notícias',
      trends: 'Tendências',
      profile: 'Perfil',
      newMessage: 'Nova mensagem',
      next: 'Próxima',
      searchPeople: 'Pesquisar Pessoas',
      saySomething: 'Diga algo',
      noSearchResult: 'Nenhum resultado de pesquisa',
      searchResult: 'Resultado da pesquisa',
      hidePost: 'Esconder publicação',
      showLess: 'Mostre menos',
      showMore: 'Mostre mais',
      nothingYet: 'Nada ainda!',
      savedPosts: 'Postagens salvas',
      enterYourFirstName: 'Digite seu primeiro nome',
      enterYourLastName: 'Digite seu sobrenome',
      enterYourUsername: 'entre com seu nome de usuário',
      signUp: 'Inscrever-se',
      pleaseChooseACountry: 'Por favor escolha um país',
      replied: 'respondeu',
      reply: 'Responder',
      delete: 'Excluir',
      replyToComment: 'Responder para comentar',
      noFollower: 'Sem seguidor',
      following: 'Seguindo',
      followBack: 'Seguir de volta',
      followers: 'Seguidoras',
      follower: 'Seguidora',
      noFollowings: 'Sem seguimentos',
      sendAMessageGetAMessage: 'Envie uma mensagem, receba uma mensagem',
      directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
      'Mensagens diretas são conversas privadas entre você e outras pessoas no Twitter. Compartilhe tweets, mídia e muito mais!',
      startAConversation: 'Inicie uma conversa',
      groupInfo: 'Informação do Grupo',
      chatInfo: 'Informações de bate-papo',
      youDoNotHaveAMessageSelected: 'Você não tem uma mensagem selecionada',
      chooseOneFromYourExistingMessagesOrStartANewOne:
      'Escolha uma das mensagens existentes ou inicie uma nova.',
      pleaseEnterVerificationCodeToVerifyYourEmail:
      'Por favor, insira o código de verificação para verificar seu e-mail',
      usernameOrEmail: 'Nome de usuário ou email',
      enterVerificationCode: 'Digite o código de verificação',
      confirmCode: 'Confirme o código',
      top: 'Principal',
      latest: 'Mais recentes',
      photos: 'Fotos',
      files: 'arquivos',
      noPeople: 'Ninguém',
      all: 'Tudo',
      mentions: 'Menções',
      replies: 'Respostas',
      // tweetsAndReplies: 'Tweets e Respostas',
      media: 'meios de comunicação',
      likes: 'Gosta',
      searchPost: 'Atualizações de pesquisa',
      lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
      'Perdeu sua senha? Por favor, digite seu nome de usuário ou endereço de e-mail. Você receberá um link para criar uma nova senha por e-mail.',
      resetYourPassword: 'Redefina sua senha',
      enterCode: 'Coloque o código',
      enterNewPassword: 'Insira a nova senha',
      reEnterPassword: 'Digite novamente a senha',
      passwordCannotBeEmpty: 'A senha não pode estar vazia',
      passwordShouldBeCharacter: 'A senha deve ter 8 caracteres',
      passwordShouldBeMatched: 'A senha deve ser correspondida',
      resetPassword: 'Redefinir senha',
      email: 'O email',
      blockUser: 'Bloquear usuário',
      public: 'Pública',
      mentionUsers: 'Mencionar usuários',
      editProfile: 'Configurar Perfil',
      yourProfileIsUpdated: 'Seu perfil está atualizado',
      seeProfile: 'Ver Perfil',
      skipForNow: 'Pular por agora',
      addBio: 'Adicionar Bio',
      profileUpdated: 'Perfil atualizado',
      upDate: 'Atualizar',
      goToProfile: 'Vá para o perfil',
      more: 'Mais',
      about: 'Cerca de',
      help: 'Ajuda',
      privacyPolicy: 'Política de Privacidade',
      blog: 'Blog',
      termsOfService: 'Termos de serviço',
      youMustSelectACountry: 'Você deve selecionar um país',
      usernameIsAlreadyTaken: 'O nome de usuário já está em uso',
      goBack: 'Volte',
      snAccountHasAlreadyBeenCreatedWithThisEmail:
      'Já foi criada uma conta com este e-mail',
      yourPasswordIsResetSuccessfully:
      'Sua senha foi redefinida com sucesso',
      returnToLogin: 'Retornar ao Login',
      youHaveEnteredAnInvalidCode: 'Você digitou um código inválido',
      thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
      'Obrigado por criar sua conta no BuzznBee. Nossa equipe entrará em contato com você em 24 horas. Fique seguro!',
      success: 'Sucesso',
      goBackToHomePage: 'Volte para a página inicial',
    },
        'cs': {
          theUsernameHasAlreadyBeenTaken : 'The username has already been taken.',
          thereWasAnErrorInSavingThisUsername : " There was an error in saving this Username!",
          showMenu : 'Show Menu',
          thisPollHasExpired : 'This poll has expired',
          youCannotVoteOnYourOwnPoll : 'You cannot vote on your own poll!',
          choice : "Choice",
          optionalPoll : "(Optional)",
          watchPartyLetGo :  "Watch party, let's go",
          createSpace :'Create Space',
          oopsSomethingWentWrongPleaseTryAgain : 'Oops…Something went wrong! Please try again',
          noSpacesAvailable : 'No spaces available',
          yourSpaceIsReady : "Your space is ready",
          spaceLinkCopiedSuccessfully : 'Space link copied successfully',
          instant : 'Instant',
          nameYourSpace : 'Name your space',
          whatDoYouWantToTalkAbout :'What do you want to talk about?',
          scheduleYourSpace : "Schedule your space",
          confirm : 'Confirm',
          selectTopic : 'Select Topic',
          momentDeleteSuccessfully : "Moment Deleted Successfully",
          createSpaceSuccessfully : "Create Space Successfully",
          pleaseEnterTheSpaceName : "Please enter the space name",
          spaces : 'Spaces',

          pleaseChooseEither1VideoOr1Pdf: "Please choose either 1 video or 1 Pdf at a time or up to 4 photos.",
          fileTypeIsNotAllowed:'File type is not allowed',
          thisPostIsScheduledFor: "This post is scheduled for",
          askAQuestion: 'Ask a question...',
          pollLength:'Poll length',
          hours: 'Hours',
          minutes:'Minutes',
          removePoll: 'Remove Poll',
          uploading: 'Uploading...',
          addDescription: "Add Description",
          willPostOn:  "Will Post on",
          date:'Date',
          youCannotScheduleAWerfInThePast: 'You cannot schedule a Werf in the past',
          time: 'Time',
          timeZone: 'Time zone',
          youHaveNoScheduledWerfs: 'You have no scheduled werfs',
          willSendOn:  "Will send on",
          selectAll: 'Select all',
          schedule: 'Schedule',
          scheduledWerfs: 'Scheduled Werfs',
          deselectAll: 'Deselect all',
          yourImageVideoWillBeAvailableInAMoment: 'Your image/video will be available in a moment.',
          pleaseEnterValidText: 'Please enter valid text',
          takeAPhoto: "Take a Photo",
          chooseFromGallery:  "Choose from Gallery",
          makeVideoWithPhoneCamera: "Make video with phone camera",
          unsentWerfs: 'Unsent Werfs',

          commentsHere:'comments here',
          ImageDescription : 'Image description',
          viewHiddenReplies: 'View Hidden Replies',
          undoRewerf: 'Undo Rewerf',
          share:  "Share",
          view:  "View",
          werfLinkCopiedSuccessfully: "Werf link copied successfully",
          addBookmark: "Add Bookmark",
          removeBookmark: "Remove Bookmark",
          werfSavedSuccessfully: 'Werf saved successfully!',
          werfUnsavedSuccessfully:  'Werf unsaved successfully!',
          thereWasAnErrorInUnSavingThisWerf: 'There was an error in unsaving this werf!',
          thereWasAnErrorInSavingThisWerf:'There was an error in saving this werf!',
          thereWasAnErrorInBlockingThisUser:'There was an error in blocking this user!',
          noEditHistory: 'No edit history',
          unPinFromProfile: "UnPin from Profile",
          saveWerf: 'Save Werf',
          linkCopiedToClipBoard:  'Link copied to clipboard!',
          removeFromBookmarks: 'Remove from bookmarks',
          thereWasAnErrorInReportingThisUser: 'There was an error in reporting this user!',
          viewOriginal: "Original",
          showThisThread:'Show this thread',
          rewerf : 'Rewerf',
          nothingFound:'Nothing found',
          year:'Year',
          day : 'Day',
          month : 'Month',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "This should be the date of birth of the person using the account. Even if you’re making an account for your business or event.",
          editDateOfBirth : 'Edit date of birth?',
          deletePhoto :"Delete photo",
          removePhoto : "Remove photo",
          addPhoto :"Add photo",
          discard : "Discard",
          removeWerfAlert :
          "This can't be undone and you'll lose your changes",
          discardChanges : "Discard changes?",
          youShouldBeAtLeast14YearsOld: 'You should be at least 14 years old',
          contentOfDialog :"Content of Dialog",
          pinnedWerf : "Pinned Werf",
          hiddenPost : "Hidden Werfs",
          thisCanBeOnlyChangedAFewTimes :" This can be only changed a few times. Make sure you enter the age of the person using the account",


          aboutHashTag : 'About hashtag',
          werfHashTag : 'Werf hashtag',
          messageRequests : 'Message requests',
          enterGroupChatTitle:  "Enter group chat title",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Choose one from your existing chats, or start a new one',
          snoozeNotificationsFrom :  "Snooze notifications from",
          snoozeNotificationsFromTheGroup : "Snooze notifications from the group",
          snoozeMentions : "Snooze mentions",
          disableNotificationsWhenPeoplemention:"Disable notifications when people mention you in this conversation.",
          trySearchingForPeopleGroupsOrMessages : "Try searching for people,groups, or messages",
          werfieUser :  "Werfie User",
          otherChat :"other...",
          photoChat : 'Photo',
          videoChat : 'Video',
          fileChat : 'File',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'Direct Messages are private conversations between you and other people on Twitter. Share Tweets, media, and more!',
          searchChats : "Search Chats",
          allTabChat : "All",
          peopleTabChat : "People",
          groupsTabChat :"Group",
          chatsTabChat :"Chats",
          noResultsFor : "No results for",
          theTermYouEnteredDidNotBring : "The term you entered did not bring up any results",
          message : "Message",
          addMembersToChat : 'Add members to chat',
          noMessagesYet : "No Messages Yet",
          doNotAllowMessages : "don't allow messages",
          notAllowedToMessage : "Not allowed to message.",
          youHaveBlockedThisUser : "You have blocked this user",
          startAMessage :  "Start a message",
          react :  "React",
          undo : "Undo",
          reactions : 'Reactions',
          messageRequestsFallHere :
          "Message requests from people you don't follow live here. To reply there message, you need to accept the request.",
          noMessageRequestAvailable : 'No Message Request Available',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'Depending on the setting you select,different people can send you a direct message.',

          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          otherControls : "Other controls",
          filterLowQualityMessages : "Filter low-quality messages",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",
          showReadReceipts : "Show read receipts",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",


          getPushNotificationsToFindOut :"Get push notifications to find out what’s going on when you’re not on Werfie. You can turn them off anytime.",
          relatedToYouAndYourWerfs :"Related to you and your Werfs",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "When you turn on Werf notifications from people you follow, you'll get push notifications about their Werfs.",
          topWerfs :"Top Werfs",
          tailoredForYou: "Tailored for you",
          rewerf : 'Rewerf',
          like : 'Like',
          photoTags : "Photo Tags",
          messageReactions : "Message Reactions",
          fromWerfie : "From Werfie",
          newsSports : "News / Sports",
          recommendations : "Recommendations",
          turnOnPush:"Turn on push\nnotifications",
          toReceiveNotificationsAsTheyHappen :"To receive notifications as they happen, turn on\npush notification, You'll also receive them when\nyou're not on Werfie. Turn them off anytime.",
          turnOn : "Turn on",
          newNotifications :  "New notifications",
          werfsEmailedToYou : "Werfs emailed to you",
          weekly : 'Weekly',
          newAboutWerfieProduct :"New about Werfie product and features updates",
          tipsOnGettingMoreOut: "Tips on getting more out of Werfie",
          thingsYouMissedSinceYou: "Things you missed since you last logged into Werfie",
          participationInWerfieResearchSurveys: "Participation in Werfie research surveys",
          suggestionsRorRecommendedAccounts: "Suggestions for recommended accounts",
          suggestionsBasedOnYourRecentFollows: "Suggestions based on your recent follows",
          qualityFilters : "Quality filters",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Choose to filter out content such as duplicate and automated Werfs. This doesn't apply to notifications from accounts you follow and have interacted with recently.",

          emailNotification : 'Email Notifications',
          filters : "Filters",
          chooseTheNotification : "Choose the notification you'd like to see and those you don't",
          preferences : "Preferences",
          selectYourPreferencesByNotificationType :"Select your preferences by notification type.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie always uses some information,like where you signed up and and your current location,to help show you more relevant content.when this setting is enabled,Werfie may also personalize your experience based on other places you have been.',

          personalizeBasedOnPlacesYouHaveBeen :
          'Personalize based on places you have been',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Manage the location information Werfie uses to personalize your experience.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",

          showReadReceipts : "Show read receipts",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",


          filterLowQualityMessages :"Filter low-quality messages",
          otherControls : "Other controls",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "People you follow will still be able to message you",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'Depending on the setting you select,different people can send you a direct message.',

          controlWhoCanMessageYou : 'Control who can message you',
          forever : " Forever",
          muteNotificationsFromPeople :"Mute notifications from people:",
          youDoNotFollow : "You don't follow",
          whoDoNotFollowYou : "Who don't follow you",
          withANewAccount : "With a new account",
          whoHaveDefaultProfilePhoto :"Who have default profile photo",
          whoHaveNotConfirmedTheirEmail : "Who haven't confirmed their email",
          whoHaveNotConfirmedTheirPhoneNumber :"Who haven't confirmed their phone number",
          duration : 'Duration',
          untilYouUnmuteTheWord : 'Until you unmute the word',
          hours24 : '24 hours',
          days7 : '7 days',
          days30 : '30 days',
          fromPeopleYouDontFollow : "From people you don't follow",
          homeTimeline : 'Home timeline',
          muteFrom : 'Mute from',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'You can mute one word,@username,or hashtag at a time.',
          enterWordOrPhrase : 'Enter word or phrase',
          mutedWord : 'Muted word',
          addMutedWords : 'Add muted words',
          youHaveNotMutedAnyWordYet : 'You have not muted any word yet',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "when you mute words,you won't get any new notification for Werfs that include them or see Werfs with those words in your Home timeline.",

          youHaveNotMutedAnyPersonYet :
          'You have not muted any person yet',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Here's everyone you muted.You can add remove them from this list.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "When you block someone,that person won't be able to follow or message you.and you won't see notification from them.",

          mutedNotification : 'Muted notifications',
          mutedWords: 'Muted words',
          mutedAccounts : 'Muted accounts',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Manage the accounts,word,and notification that you have muted or blocked.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'This prevents Werfs with potentially sensitive content displaying in your search results.',

          hideSensitiveContent: 'Hide sensitive content',
          removeBlockedAndMutedAccounts :
          'Remove blocked and muted accounts',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'Use this to eliminate search results from account you have blocked or muted',
          personalization : 'Personalization',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'you can personalize trends based on your location and who you follow',
          exploreLocation : 'Explore location',
          showContentInThisLocation : 'Show content in this location',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'When this is on, you will see what is happening around you right now.',
          searchSettings  :'Search settings',
          exploreSettings : 'Explore settings',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Decide what you see on werfie based on your preferences like Topics',
          displayMediaThatMayContainSensitiveContent :
          'Display media that may contain sensitive content',
          addLocationInformationToYourWerfs :'Add location information to your Werfs',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "When enabled,picture and videos you Werf will be marked as sensitive for people who don't want to see sensitive content.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'Mark media you Werf as having material that may be sensitive',
          manageTheInformationAssociatedWithYourWerfs :
          'Manage the information associated with your Werfs.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'if enabled,you will be able to attach location to your Werfs.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Remove all location information attached to your Werfs',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'Location labels you have added to your Werfs will no longer be visible on Werfie.com, Werfie for IOS, and Werfie for Android. These updates may take some time to go into effect.',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Manage what information you allow other people on Werfie.',
          protectYourTweets : 'Protect your Werfs',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'When selected, your werfie and account information are only visible to people who follow you',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'This will make them visible only to your werfie followers',
          protect : 'Protect',
          photoTagging : 'Photo tagging',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou:
          'Only people you follow can tag you',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Allow people to tag you in their photos and receive notifications when they do so',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou : 'Only people you follow can tag you',
          security : 'Security',
          manageYourAccountsSecurity : "Manage your accounts security",
          twoFactorAuthentication : "Two-factor authentication",
          manageYourAccountsSecurityKeepTrack : "Manage your accounts security and keep track of your account usage",
          helpProtectYourAccountFromUnauthorizedAccess :  "Help protect your account from unauthorized access by requiring a second authentication method in addition to your X password. You can choose a text message, authentication app, or security key.",
          verificationCodeSentToYourRegisteredEmail:"Enter 6-digits verification code Sent to your registered email",
          submit :'Submit',
          genderChangedSuccessfully : "Gender Changed Successfully",
          genderSettingTextDescription :"If you haven’t already specified a gender, this is the one associated with your account based on your profile and activity. This information won’t be displayed publicly.",
          male:  'Male',
          female : 'Female',
          other : 'Other',
          change:'Change',
          changeCountrySettings:'Change country',
          selectACountry:'Select a country',
          updateEmailAddress:'Update email address',
          current:'Current',
          changeEmailSetting:'Change email',
          gender:'Gender',
          accountCreation:'Account creation',
          Age:'Age',
          securityAndAccountAccess:'Security and account access',
          youHaveNotCreatedOrFollowedAnyLists: "You haven't created or followed any Lists. When you do, they'll show up here.",
          userCanPinnedOnly5  : 'User can pinned  only 5 ',
          pleaseEnterTheName  : 'Please enter the name ',
          list : 'Lists',
          listYouAre :"Lists you're on",
          listYouHave:"You haven't been added to any Lists yet",
          listAddedSomeOne:"When someone adds you to a List, it'll show up here",
          listMembers :'List Members',
          listFollowers  : 'List Followers',
          noMembers: 'No Members',
          noResults :'No results',
          noFollowers:'No Followers',
          YourAccount: 'Koontadaada',
          notificationsSettings: 'Dejinta Ogeysiinta',
          displaySettings: 'Muujinta Dejinta',
          moments: 'Daqiiqado',
          topic: 'mowduucyo',
          followings: 'Soo socda',
          popularUpdates: 'Cusboonaysiinta caanka ah',
          privacyAndSafety: 'Qarsoodinimada',
          createWerf: 'Abuur Werf',
          chats: 'sheekeysi',
          bookmarks: 'bookmarks',
          enterYourEmail: 'Geli emailkaaga',
          enterYourPassword: 'Gali eraygaaga sirta ah',
          languageSettings: 'Dejinta Luqadda',
          blockedAccountsSettings: 'Dejinta Xisaabaadka La Xannibay',
          selectYourPreferredLanguage: 'Dooro luqadda aad doorbidayso',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Hoyga',
          browse: 'Baadh',
          hotTrends: 'Isbeddellada kulul',
          saved: 'La keydiyay',
          messages: 'Farriimaha',
          myProfile: 'My profile',
          settings: 'Dejinta',
          notifications: 'Ogeysiisyada',
          settingsType: 'Nooca Dejinta',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'Maamul sida BuzzNBee loogu soo bandhigay',
          selectYourProfileLanguage: 'Dooro luqadda astaantaada',
          selectYourAppLanguage: 'Dooro luqadda abkaaga',
          enableDisableAutoTranslation:
              'Awood u yeelo / jooji turjumaadda baabuurka',
          language: 'Luqadda',

          ///  Shoomaali
          username: "Magaca isticmaale",
          snoozeNotification: "Ogeysiisyada hindhiso",
          version: "Nooca",
          appVersion: "Nooca App",
          lists: "Liisaska",
          deactivationAndDeletion: "Dejinta iyo Tirtirka",
          confirmYourPasswords: "Xaqiiji furahaaga sirta ah",
          deactivateAccount: 'Dami xisaabta',
          or: 'AMA',
          deleteAccount: "Tirtir Koontada",
          updateYourLanguageAndTranslation:
              "Cusbooneysii luqadaada iyo turjumaada",
          manageYourPrivacySettings: "Maamul habaynkaaga gaar ahaaneed",
          privacySettings: "Dejinta qarsoodiga",
          setYourPrivacySettings: 'Deji dejimahaaga gaarka ah',
          messageSettings: "Dejinta fariimaha",
          noOne: "Qofna",
          everyOne: 'QOF kasta',
          ChangeUsernameSettings: "Beddel habaynta magaca isticmaale",
          enterYourWerfieHandle: "Geli gacantaada werfie",
          youHaveNotBlockedAnyPersonYet: "Wali ma aadan xannibin qof",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "Haddii aad rabto in aad si joogto ah u tirtirto akoonkaaga Werfie,marka aad gujiso badhanka ok,ma awoodid in aad dib u kiciso akoonkaaga ama soo ceshato wax ka mid ah macluumaadka ama macluumaadka aad ku dartay.",
          permanentlyDeleteAccount: "Si joogta ah u tirtir Akoonka",
          whoCanMessageYou: 'Yaa fariin kuu diri kara',
          viewEditHistory: 'Daawo Tafatirka Taariikhda',
          reportWerf: 'Warbixinta werf',
          hideWerf: 'Qari werf',
          reportUser: 'Ka warbixi isticmaale',
          mute: 'aamus',
          unMute: "Ka aamus",
          deleteWerf: 'Tirtir Werf',
          viewWerfAnalytics: 'Fiiri Werf Analytics',
          pintoYourProfile: 'Ku dheji astaantaada',
          editWerf: 'Wax ka beddel Werf',
          explore: 'Baadh',

          blockedAccounts: 'Xisaabaadka la xanibay',
          translations: 'Tarjumaadaha',
          viewListOfBlockedAccounts: 'Arag liiska akoonada la xanibay',
          realTimePostTranslation: 'Waqtiga dhabta ah turjumaadda boostada',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'Dooro luqadda waqtiga fiidiyowga ama maqalka la soo gelinayo',
          originalTranslatedScriptAudioPost:
              'Qoraalka asalka ah ama la turjumay ee dhejiska maqalka',
          listenTranslatedScript: 'Dhageyso qoraalka la turjumay',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Si otomaatig ah ugu tarjun farriimaha wada sheekaysiga luqadaha la xushay ee adeegsadayaasha',
          postedUpdate: 'dhejiyay cusbooneysiin.',
          peopleWhoReacted: 'Dadka falceliyay',
          comments: 'Faallooyinka',
          peopleWhoRetweeted: 'Dadka dib u daabacay',
          leaveAComment: 'Ka tag faallo',
          post: 'Boostada',
          cancel: 'Jooji',
          savePost: 'Keydso Boostada',
          report: 'Warbixin',
          hide: 'Qari',
          shareLinkVia: 'La wadaag Linkiga adoo ...',
          copyLink: 'Nuqul Link',
          fieldRequired: 'Goobta Loo Baahan Yahay',
          enterDescription: 'Geli Sharaxaad',
          selectCategory: 'Dooro Qaybta',
          okay: 'Hagaag,',
          pleaseWait: 'Fadlan sug...',
          search: 'Raadi',
          logout: 'Ka bax',
          writeSomethingHere: 'Wax ku qor halkan',
          addMore: 'Ku dar Dheeraad',
          image: 'Sawirka',
          video: 'Fiidiyow',
          videos: 'Fiidiyowyo',
          file: 'Fayl',
          gif: 'GIF',
          audio: 'Maqal',
          live: 'Live',
          doNotHaveAnAccount: "Ma lihid xisaab? ",
          register: 'Diiwaangeli',
          haveAnAccount: "Ma leedahay xisaab? ",
          login: 'Gal',
          whoToFollow: 'Cidda la raacayo',
          noSuggestion: 'Talo soo jeedin ma leh',
          follow: 'Raac',
          unFollow: 'Jooji',
          seeMore: 'Arag Waxbadan',
          searchFilter: 'Raadi Shaandheyn',
          people: 'Dadka',
          fromAnyone: 'Qof Kasta',
          peopleYouFollow: 'Dadkaad Raacdo',
          location: 'Goobta',
          anywhere: 'Meel kasta',
          nearYou: 'Ku dhow',
          advancedSearch: 'Raadin Sare',
          trendsForYou: 'Isbeddellada Adiga',
          noTrending: 'Ma jiraan wax isbeddel ah oo ka jira Gobolkaaga',
          trendingIn: 'La daalacanayo',
          // tweets: 'Tweets',
          noNotification: 'Ma jiraan wax ogeysiisyo ah',
          edit: 'Tafatir',
          save: 'Badbaadi',
          cFollow: 'Raac',
          addPeople: 'Ku dar Dad',
          someText: 'qoraalka qaar',
          reportConversation: 'Sheekaysiga Sheekada',
          leaveConversation: 'Sheekada Ka Bax',
          enterYourMessage: 'Geli fariintaada',
          showMoreComments: 'Muuji faallooyin badan',
          reBuzz: 'Rebuzz',
          noPosts: 'Ma jiraan wax war ah oo kuu soo kordhay',
          emailFieldCannotBeEmpty: 'Goobta Email ma noqon karto mid madhan',
          emailFormatIsInvalid: 'Qaabka iimaylka ma xuma',
          rememberMe: 'I xasuuso',
          lostPassword: 'Furaha Lumiyay?',
          cLOGIN: 'Galitaan',
          emailOrPasswordIsIncorrect:
              'Iimaylka ama erayga sirta ahi waa khalad',
          newsFeed: 'News Feed',
          trends: 'Isbeddellada',
          profile: 'Astaanta',
          newMessage: 'Farriin Cusub',
          next: 'Xiga',
          searchPeople: 'Raadi Dadka',
          saySomething: 'Wax dheh',
          noSearchResult: 'Ma jirto Natiijo Raadin',
          searchResult: 'Natiijada Raadinta',
          hidePost: 'Qari Boostada',
          showLess: 'Muuji Wax Yar',
          showMore: 'Muuji Wax Badan',
          nothingYet: 'Waxba ma jiraan!',
          savedPosts: 'Qoraalada La Kaydiyay',
          enterYourFirstName: 'Ku qor magacaaga koowaad',
          enterYourLastName: 'Ku qor magacaaga dambe',
          enterYourUsername: 'Geli magacaaga isticmaalaha',
          signUp: 'Saxiix',
          pleaseChooseACountry: 'Fadlan dooro dal',
          replied: 'ayaa ku jawaabay',
          reply: 'Jawaab',
          delete: 'Tirtir',
          replyToComment: 'Ka jawaab faallooyinka',
          noFollower: 'No Raaca',
          following: 'Raacaya',
          followBack: 'Dib U Raac',
          followers: 'Raacayaasha',
          follower: 'Raad raac',
          noFollowings: "Raacid la'aan",
          sendAMessageGetAMessage: 'Fariin dir, farriin hel',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              'Fariimaha tooska ah waa wada sheekaysiga gaarka ah ee adiga iyo dadka kale ku leh Twitter. La wadaag Tweets, warbaahinta, iyo inbadan!',
          startAConversation: 'Bilow Wadahadal',
          groupInfo: 'Macluumaadka Kooxda',
          chatInfo: 'Macluumaadka Sheekaysiga',
          youDoNotHaveAMessageSelected: 'Ma lihid farriin la doortay',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Mid ka mid ah fariimahaaga jira ka dooro, ama mid cusub bilow.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'Fadlan geli koodka xaqiijinta si aad u xaqiijiso emaylkaaga',
          usernameOrEmail: 'Username ama Email',
          enterVerificationCode: 'Geli lambarka xaqiijinta',
          confirmCode: 'Xaqiiji Xeer',
          top: 'Sare',
          latest: 'Ugu dambeeyay',
          photos: 'Sawirada',
          files: 'Faylasha',
          noPeople: 'Maya Dad',
          all: 'Dhammaan',
          mentions: 'Xusid',
          replies: 'Jawaabaha',
          // tweetsAndReplies: 'Tweets & Jawaab',
          media: 'Warbaahinta',
          likes: 'Jecelyahay',
          searchPost: 'Cusbooneysiinta Raadinta',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'Lost your password? Fadlan geli magacaaga isticmaalaha ama cinwaanka emailkaaga. Waxaad heli doontaa xiriir si aad ugu sameysato erayga cusub e -mayl ahaan.',
          resetYourPassword: 'Dib u celi furahaaga sirta ah',
          enterCode: 'Geli Xeerka',
          enterNewPassword: 'Geli Furaha Cusub',
          reEnterPassword: 'Mar kale gali eraygaaga sir ta ah',
          passwordCannotBeEmpty: 'Furaha sirta ma noqon karo mid faaruq ah',
          passwordShouldBeCharacter: 'Furaha waa inuu ahaadaa 8 xaraf',
          passwordShouldBeMatched: 'Furaha waa in la is waafajiyaa',
          resetPassword: 'Dib u celi Password',
          email: 'Iimayl',
          blockUser: 'Isticmaalaha Xaniba',
          public: 'Dadweyne',
          mentionUsers: 'Sheeg Isticmaalayaasha',
          editProfile: 'Calan Profile',
          yourProfileIsUpdated: 'Macluumaadkaaga waa la cusbooneysiiyay',
          seeProfile: 'Eeg Profile',
          skipForNow: 'U bood hadda',
          addBio: 'Ku dar Biyo',
          profileUpdated: 'Xogta La Cusboonaysiiyay',
          upDate: 'Cusboonaysii',
          goToProfile: 'Tag Profile',
          more: 'Inbadan',
          about: 'Ku saabsan',
          help: 'I caawi',
          privacyPolicy: 'Qaanuunka Arrimaha Khaaska ah',
          blog: 'Blog',
          termsOfService: 'Shuruudaha Adeegga',
          youMustSelectACountry: 'Waa inaad doorataa waddan',
          usernameIsAlreadyTaken: 'Magaca hore waa la qaatay',
          goBack: 'Dib ugu noqo',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'Koonto ayaa mar hore lagu abuuray iimaylkan',
          yourPasswordIsResetSuccessfully:
              'Eraygaaga sirta ah si guul leh ayaa dib loo dhigay',
          returnToLogin: 'Ku noqo Galitaan',
          youHaveEnteredAnInvalidCode: 'Waxaad gelisay koodh aan ansax ahayn',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'Waad ku mahadsan tahay sameynta koontadaada BuzznBee.Our kooxdeena ayaa kula soo xiriiri doonta 24 saac gudahood. Nabadgalyo Sug!',
          success: 'Guul',
          goBackToHomePage: 'Ku noqo Bogga Guriga',
        },
        'ja': {
          theUsernameHasAlreadyBeenTaken : 'The username has already been taken.',
          thereWasAnErrorInSavingThisUsername : " There was an error in saving this Username!",
          showMenu : 'Show Menu',
          thisPollHasExpired : 'This poll has expired',
          youCannotVoteOnYourOwnPoll : 'You cannot vote on your own poll!',
          choice : "Choice",
          optionalPoll : "(Optional)",
          watchPartyLetGo :  "Watch party, let's go",
          createSpace :'Create Space',
          oopsSomethingWentWrongPleaseTryAgain : 'Oops…Something went wrong! Please try again',
          noSpacesAvailable : 'No spaces available',
          yourSpaceIsReady : "Your space is ready",
          spaceLinkCopiedSuccessfully : 'Space link copied successfully',
          instant : 'Instant',
          nameYourSpace : 'Name your space',
          whatDoYouWantToTalkAbout :'What do you want to talk about?',
          scheduleYourSpace : "Schedule your space",
          confirm : 'Confirm',
          selectTopic : 'Select Topic',
          momentDeleteSuccessfully : "Moment Deleted Successfully",
          createSpaceSuccessfully : "Create Space Successfully",
          pleaseEnterTheSpaceName : "Please enter the space name",
          spaces : 'Spaces',

          pleaseChooseEither1VideoOr1Pdf: "Please choose either 1 video or 1 Pdf at a time or up to 4 photos.",
          fileTypeIsNotAllowed:'File type is not allowed',
          thisPostIsScheduledFor: "This post is scheduled for",
          askAQuestion: 'Ask a question...',
          pollLength:'Poll length',
          hours: 'Hours',
          minutes:'Minutes',
          removePoll: 'Remove Poll',
          uploading: 'Uploading...',
          addDescription: "Add Description",
          willPostOn:  "Will Post on",
          date:'Date',
          youCannotScheduleAWerfInThePast: 'You cannot schedule a Werf in the past',
          time: 'Time',
          timeZone: 'Time zone',
          youHaveNoScheduledWerfs: 'You have no scheduled werfs',
          willSendOn:  "Will send on",
          selectAll: 'Select all',
          schedule: 'Schedule',
          scheduledWerfs: 'Scheduled Werfs',
          deselectAll: 'Deselect all',
          yourImageVideoWillBeAvailableInAMoment: 'Your image/video will be available in a moment.',
          pleaseEnterValidText: 'Please enter valid text',
          takeAPhoto: "Take a Photo",
          chooseFromGallery:  "Choose from Gallery",
          makeVideoWithPhoneCamera: "Make video with phone camera",
          unsentWerfs: 'Unsent Werfs',
          commentsHere:'comments here',
          ImageDescription : 'Image description',
          viewHiddenReplies: 'View Hidden Replies',
          undoRewerf: 'Undo Rewerf',
          share:  "Share",
          view:  "View",
          werfLinkCopiedSuccessfully: "Werf link copied successfully",
          addBookmark: "Add Bookmark",
          removeBookmark: "Remove Bookmark",
          werfSavedSuccessfully: 'Werf saved successfully!',
          werfUnsavedSuccessfully:  'Werf unsaved successfully!',
          thereWasAnErrorInUnSavingThisWerf: 'There was an error in unsaving this werf!',
          thereWasAnErrorInSavingThisWerf:'There was an error in saving this werf!',
          thereWasAnErrorInBlockingThisUser:'There was an error in blocking this user!',
          noEditHistory: 'No edit history',
          unPinFromProfile: "UnPin from Profile",
          saveWerf: 'Save Werf',
          linkCopiedToClipBoard:  'Link copied to clipboard!',
          removeFromBookmarks: 'Remove from bookmarks',
          thereWasAnErrorInReportingThisUser: 'There was an error in reporting this user!',
          viewOriginal: "Original",
          showThisThread:'Show this thread',
          rewerf : 'Rewerf',
          nothingFound:'Nothing found',
          year:'Year',
          day : 'Day',
          month : 'Month',
          thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount :
          "This should be the date of birth of the person using the account. Even if you’re making an account for your business or event.",
          editDateOfBirth : 'Edit date of birth?',
          deletePhoto :"Delete photo",
          removePhoto : "Remove photo",
          addPhoto :"Add photo",
          discard : "Discard",
          removeWerfAlert :
          "This can't be undone and you'll lose your changes",
          discardChanges : "Discard changes?",
          youShouldBeAtLeast14YearsOld: 'You should be at least 14 years old',
          contentOfDialog :"Content of Dialog",
          pinnedWerf : "Pinned Werf",
          hiddenPost : "Hidden Werfs",
          thisCanBeOnlyChangedAFewTimes :" This can be only changed a few times. Make sure you enter the age of the person using the account",


          aboutHashTag : 'About hashtag',
          werfHashTag : 'Werf hashtag',
          messageRequests : 'Message requests',
          enterGroupChatTitle:  "Enter group chat title",
          chooseOneFromYourExistingChatsOrStartANewOne:
          'Choose one from your existing chats, or start a new one',
          snoozeNotificationsFrom :  "Snooze notifications from",
          snoozeNotificationsFromTheGroup : "Snooze notifications from the group",
          snoozeMentions : "Snooze mentions",
          disableNotificationsWhenPeoplemention:"Disable notifications when people mention you in this conversation.",
          trySearchingForPeopleGroupsOrMessages : "Try searching for people,groups, or messages",
          werfieUser :  "Werfie User",
          otherChat :"other...",
          photoChat : 'Photo',
          videoChat : 'Video',
          fileChat : 'File',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore :
          'Direct Messages are private conversations between you and other people on Twitter. Share Tweets, media, and more!',
          searchChats : "Search Chats",
          allTabChat : "All",
          peopleTabChat : "People",
          groupsTabChat :"Group",
          chatsTabChat :"Chats",
          noResultsFor : "No results for",
          theTermYouEnteredDidNotBring : "The term you entered did not bring up any results",
          message : "Message",
          addMembersToChat : 'Add members to chat',
          noMessagesYet : "No Messages Yet",
          doNotAllowMessages : "don't allow messages",
          notAllowedToMessage : "Not allowed to message.",
          youHaveBlockedThisUser : "You have blocked this user",
          startAMessage :  "Start a message",
          react :  "React",
          undo : "Undo",
          reactions : 'Reactions',
          messageRequestsFallHere :
          "Message requests from people you don't follow live here. To reply there message, you need to accept the request.",
          noMessageRequestAvailable : 'No Message Request Available',
          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage:
          'Depending on the setting you select,different people can send you a direct message.',

          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          otherControls : "Other controls",
          filterLowQualityMessages : "Filter low-quality messages",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",
          showReadReceipts : "Show read receipts",
          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",


          getPushNotificationsToFindOut :"Get push notifications to find out what’s going on when you’re not on Werfie. You can turn them off anytime.",
          relatedToYouAndYourWerfs :"Related to you and your Werfs",
          whenYouTurnOnWerfNotificationsFromPeopleYouFollow : "When you turn on Werf notifications from people you follow, you'll get push notifications about their Werfs.",
          topWerfs :"Top Werfs",
          tailoredForYou: "Tailored for you",
          rewerf : 'Rewerf',
          like : 'Like',
          photoTags : "Photo Tags",
          messageReactions : "Message Reactions",
          fromWerfie : "From Werfie",
          newsSports : "News / Sports",
          recommendations : "Recommendations",
          turnOnPush:"Turn on push\nnotifications",
          toReceiveNotificationsAsTheyHappen :"To receive notifications as they happen, turn on\npush notification, You'll also receive them when\nyou're not on Werfie. Turn them off anytime.",
          turnOn : "Turn on",
          newNotifications :  "New notifications",
          werfsEmailedToYou : "Werfs emailed to you",
          weekly : 'Weekly',
          newAboutWerfieProduct :"New about Werfie product and features updates",
          tipsOnGettingMoreOut: "Tips on getting more out of Werfie",
          thingsYouMissedSinceYou: "Things you missed since you last logged into Werfie",
          participationInWerfieResearchSurveys: "Participation in Werfie research surveys",
          suggestionsRorRecommendedAccounts: "Suggestions for recommended accounts",
          suggestionsBasedOnYourRecentFollows: "Suggestions based on your recent follows",
          qualityFilters : "Quality filters",
          chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs :"Choose to filter out content such as duplicate and automated Werfs. This doesn't apply to notifications from accounts you follow and have interacted with recently.",

          emailNotification : 'Email Notifications',
          filters : "Filters",
          chooseTheNotification : "Choose the notification you'd like to see and those you don't",
          preferences : "Preferences",
          selectYourPreferencesByNotificationType :"Select your preferences by notification type.",
          werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen :
          'Werfie always uses some information,like where you signed up and and your current location,to help show you more relevant content.when this setting is enabled,Werfie may also personalize your experience based on other places you have been.',

          personalizeBasedOnPlacesYouHaveBeen :
          'Personalize based on places you have been',
          manageTheLocationInformationWerfieUsesToPersonalizeYourExperience :
          'Manage the location information Werfie uses to personalize your experience.',

          letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests :
          "Let people you're messaging with know when you've seen their messages.Read receipts are not shown on message requests",

          showReadReceipts : "Show read receipts",
          hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant :
          "Hide message requests that have been detected as being potentially span or low-quality.These will be sent to a separate inbox at the bottom of your message requests.You can still access them if you want",


          filterLowQualityMessages :"Filter low-quality messages",
          otherControls : "Other controls",
          peopleYouFollowWillStillBeAbleToMessageYou :
          "People you follow will still be able to message you",
          allowMessagesRequestsFromEveryone :
          'Allow messages requests from everyone',
          peopleYouFollowWillStillBeAbleToMessageYou:
          "People you follow will still be able to message you",
          allowMessageRequestsOnlyFromVerifiedUsers :
          "Allow message requests only from Verified users",
          youWontReceiveAnyMessageRequests :
          "You won't receive any message requests",
          allowMessagesOnlyFromPeopleYouFollow :
          'Allow messages only from people you follow',

          dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage :
          'Depending on the setting you select,different people can send you a direct message.',

          controlWhoCanMessageYou : 'Control who can message you',
          forever : " Forever",
          muteNotificationsFromPeople :"Mute notifications from people:",
          youDoNotFollow : "You don't follow",
          whoDoNotFollowYou : "Who don't follow you",
          withANewAccount : "With a new account",
          whoHaveDefaultProfilePhoto :"Who have default profile photo",
          whoHaveNotConfirmedTheirEmail : "Who haven't confirmed their email",
          whoHaveNotConfirmedTheirPhoneNumber :"Who haven't confirmed their phone number",
          duration : 'Duration',
          untilYouUnmuteTheWord : 'Until you unmute the word',
          hours24 : '24 hours',
          days7 : '7 days',
          days30 : '30 days',
          fromPeopleYouDontFollow : "From people you don't follow",
          homeTimeline : 'Home timeline',
          muteFrom : 'Mute from',
          youCanMuteOneWordUsernameOrHashtagAtATime :
          'You can mute one word,@username,or hashtag at a time.',
          enterWordOrPhrase : 'Enter word or phrase',
          mutedWord : 'Muted word',
          addMutedWords : 'Add muted words',
          youHaveNotMutedAnyWordYet : 'You have not muted any word yet',
          whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline :
          "when you mute words,you won't get any new notification for Werfs that include them or see Werfs with those words in your Home timeline.",

          youHaveNotMutedAnyPersonYet :
          'You have not muted any person yet',
          HereEveryoneYouMutedYouCanAddRemoveThemFromThisList :
          "Here's everyone you muted.You can add remove them from this list.",
          whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem :
          "When you block someone,that person won't be able to follow or message you.and you won't see notification from them.",

          mutedNotification : 'Muted notifications',
          mutedWords: 'Muted words',
          mutedAccounts : 'Muted accounts',
          ManageTheAccountsWordAndNotificationThatYouHaveMutedOrBlocked :
          'Manage the accounts,word,and notification that you have muted or blocked.',
          thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults :
          'This prevents Werfs with potentially sensitive content displaying in your search results.',

          hideSensitiveContent: 'Hide sensitive content',
          removeBlockedAndMutedAccounts :
          'Remove blocked and muted accounts',
          useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted :
          'Use this to eliminate search results from account you have blocked or muted',
          personalization : 'Personalization',
          youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow :
          'you can personalize trends based on your location and who you follow',
          exploreLocation : 'Explore location',
          showContentInThisLocation : 'Show content in this location',
          WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow :
          'When this is on, you will see what is happening around you right now.',
          searchSettings  :'Search settings',
          exploreSettings : 'Explore settings',
          decideWhatYouSeeOnWerfieBasedOnYourPreferencesLikeTopics :
          'Decide what you see on werfie based on your preferences like Topics',
          displayMediaThatMayContainSensitiveContent :
          'Display media that may contain sensitive content',
          addLocationInformationToYourWerfs :'Add location information to your Werfs',
          WhenEnabledPictureAndVideosYouWerfWillBeMarkedAsSensitiveForPeopleWhoDontWantToSeeSensitiveContent:
          "When enabled,picture and videos you Werf will be marked as sensitive for people who don't want to see sensitive content.",
          markMediaYouWerfAsHavingMaterialThatMayBeSensitive:
          'Mark media you Werf as having material that may be sensitive',
          manageTheInformationAssociatedWithYourWerfs :
          'Manage the information associated with your Werfs.',
          ifEnabledYouWillBeAbleToAttachLocationToYourWerfs:
          'if enabled,you will be able to attach location to your Werfs.',
          removeAllLocationInformationAttachedToYourWerfs :
          'Remove all location information attached to your Werfs',
          locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect:
          'Location labels you have added to your Werfs will no longer be visible on Werfie.com, Werfie for IOS, and Werfie for Android. These updates may take some time to go into effect.',

          manageWhatInformationYouAllowOtherPeopleOnWerfie : 'Manage what information you allow other people on Werfie.',
          protectYourTweets : 'Protect your Werfs',
          whenSelectedYourWerfieAndAccountInformationAreOnlyVisibleToPeopleWhoFollowYou :
          'When selected, your werfie and account information are only visible to people who follow you',
          thisWillMakeYourThemVisibleOnlyToYourTwitterFollowers : 'This will make them visible only to your werfie followers',
          protect : 'Protect',
          photoTagging : 'Photo tagging',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou:
          'Only people you follow can tag you',
          allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo:
          'Allow people to tag you in their photos and receive notifications when they do so',
          AnyoneCanTagYou : 'Anyone can tag you',
          onlyPeopleYouFollowCanTagYou : 'Only people you follow can tag you',
          security : 'Security',
          manageYourAccountsSecurity : "Manage your accounts security",
          twoFactorAuthentication : "Two-factor authentication",
          manageYourAccountsSecurityKeepTrack : "Manage your accounts security and keep track of your account usage",
          helpProtectYourAccountFromUnauthorizedAccess :  "Help protect your account from unauthorized access by requiring a second authentication method in addition to your X password. You can choose a text message, authentication app, or security key.",
          verificationCodeSentToYourRegisteredEmail:"Enter 6-digits verification code Sent to your registered email",
          submit :'Submit',
          genderChangedSuccessfully : "Gender Changed Successfully",
          genderSettingTextDescription :"If you haven’t already specified a gender, this is the one associated with your account based on your profile and activity. This information won’t be displayed publicly.",
          male:  'Male',
          female : 'Female',
          other : 'Other',
          change:'Change',
          changeCountrySettings:'Change country',
          selectACountry:'Select a country',
          updateEmailAddress:'Update email address',
          current:'Current',
          changeEmailSetting:'Change email',
          gender:'Gender',
          accountCreation:'Account creation',
          Age:'Age',
          securityAndAccountAccess:'Security and account access',
          youHaveNotCreatedOrFollowedAnyLists: "You haven't created or followed any Lists. When you do, they'll show up here.",
          userCanPinnedOnly5  : 'User can pinned  only 5 ',
          pleaseEnterTheName  : 'Please enter the name ',
          list : 'Lists',
          listYouAre :"Lists you're on",
          listYouHave:"You haven't been added to any Lists yet",
          listAddedSomeOne:"When someone adds you to a List, it'll show up here",
          listMembers :'List Members',
          listFollowers  : 'List Followers',
          noMembers: 'No Members',
          noResults :'No results',
          noFollowers:'No Followers',
          YourAccount: 'Hesabınız',
          notificationsSettings: 'Bildirim Ayarları',
          displaySettings: 'Görüntü ayarları',
          moments: 'anlar',
          topics: 'konular',
          followings: 'Takip edilenler',
          popularUpdates: 'Popüler Güncellemeler',
          privacyAndSafety: 'gizlilik ve Güvenlik',
          createWerf: 'Werf oluştur',
          chats: 'sohbetler',
          bookmarks: 'yer imleri',
          enterYourEmail: 'E-postanızı giriniz',
          enterYourPassword: 'Şifrenizi girin',
          languageSettings: 'Dil ayarları',
          blockedAccountsSettings: 'Engellenen Hesap Ayarları',
          selectYourPreferredLanguage: 'Tercih ettiğiniz dili seçin',
          english: 'English',
          arabic: 'عربي',
          french: 'Français',
          german: 'Deutsche',
          spanish: 'Española',
          hindi: 'हिंदी',
          indonesia: 'Bahasa Indonesia',
          portuguese: 'Português',
          turkish: 'Turca',
          somali: 'Shoomaali',
          persian: 'فارسی',
          home: 'Ev',
          browse: 'Araştır',
          hotTrends: 'Sıcak Trendler',
          saved: 'kaydedildi',
          messages: 'Mesajlar',
          myProfile: 'Benim profilim',
          settings: 'Ayarlar',
          notifications: 'Bildirimler',
          settingsType: 'Ayarlar Türü',
          manageHowBuzzNBeeContentIsDisplayedToYou:
              'BuzzNBee içeriğinin size nasıl görüntülendiğini yönetin',
          selectYourProfileLanguage: 'Profil dilinizi seçin',
          selectYourAppLanguage: 'Uygulama dilinizi seçin',
          enableDisableAutoTranslation:
              'Otomatik çeviriyi etkinleştir / devre dışı bırak',
          language: 'Dilim',

          /// Turkish
          username: "Kullanıcı adı",
          snoozeNotification: "Bildirimleri Ertele",
          version: "Sürüm",
          appVersion: "Uygulama sürümü",
          lists: "Listeler",
          deactivationAndDeletion: "Devre Dışı Bırakma ve Silme",
          confirmYourPasswords: "Parolalarınızı onaylayın",
          deactivateAccount: 'Aktif edilmemiş hesap',
          or: 'VEYA',
          deleteAccount: "Hesabı sil",
          updateYourLanguageAndTranslation:
              "Dilinizi ve çevirinizi güncelleyin",
          manageYourPrivacySettings: "Gizlilik Ayarlarınızı yönetin",
          privacySettings: "Gizlilik ayarları",
          setYourPrivacySettings: 'Gizlilik Ayarlarınızı belirleyin',
          messageSettings: "Mesaj ayarları",
          noOne: "Kimse",
          everyOne: 'Herkes',
          ChangeUsernameSettings: "Kullanıcı Adı Ayarlarını Değiştir",
          enterYourWerfieHandle: "Werfie tanıtıcınızı girin",
          youHaveNotBlockedAnyPersonYet: "Henüz kimseyi engellemedin",
          IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount:
              "Werfie hesabınızı kalıcı olarak silmek istiyorsanız, tamam düğmesini tıkladığınızda, hesabınızı yeniden etkinleştiremez veya eklediğiniz içerik veya bilgilerin hiçbirini geri alamazsınız.",
          permanentlyDeleteAccount: "Hesabı kalıcı olarak sil",
          whoCanMessageYou: 'sana kim mesaj atabilir',
          viewEditHistory: 'Düzenleme Geçmişini Görüntüle',
          reportWerf: 'werf bildir',
          hideWerf: "werf'i gizle",
          showMore:'Daha Fazla Göster',
          reportUser: 'Kullanıcıyı bildir',
          mute: 'Sesini kapatmak',
          unMute: "Sesini açmak",
          deleteWerf: "Werf'i Sil",
          viewWerfAnalytics: "Werf Analytics'i Görüntüle",
          pintoYourProfile: 'profiline sabitle',
          editWerf: "Werf'i Düzenle",
          explore: 'Keşfetmek',

          blockedAccounts: 'Engellenen hesaplar',
          translations: 'Çeviriler',
          viewListOfBlockedAccounts:
              'Engellenen hesapların listesini görüntüleyin',
          realTimePostTranslation: 'Gerçek zamanlı gönderi çevirisi',
          selectLanguageTheTimeOfUploadingVideoOrAudio:
              'Video veya ses yüklerken dili seçin',
          originalTranslatedScriptAudioPost:
              'Sesli gönderinin orijinal veya tercüme edilmiş komut dosyası',
          listenTranslatedScript: 'Çevrilmiş komut dosyasını dinle',
          automaticallyTranslateMessagesChatUsersSelectedLanguage:
              'Kullanıcıların seçtiği dilde sohbetteki mesajları otomatik olarak çevir',
          postedUpdate: 'bir güncelleme yayınladı.',
          peopleWhoReacted: 'Tepki veren insanlar',
          comments: 'Yorumlar',
          peopleWhoRetweeted: 'Retweet yapanlar',
          leaveAComment: 'yorum Yap',
          post: 'Postalamak',
          cancel: 'İptal',
          savePost: 'Gönderiyi Kaydet',
          report: 'Rapor',
          hide: 'Saklamak',
          shareLinkVia: 'Bağlantıyı şu şekilde paylaşın...',
          copyLink: 'Bağlantıyı kopyala',
          fieldRequired: 'Alan gerekli',
          enterDescription: 'Açıklama Girin',
          selectCategory: 'Kategori seç',
          okay: 'Peki,',
          pleaseWait: 'Lütfen bekle...',
          search: 'Arama',
          logout: 'Çıkış Yap',
          writeSomethingHere: 'Buraya Bir Şey Yaz',
          addMore: 'Daha ekle',
          image: 'resim',
          video: 'Video',
          videos: 'Videolar',
          file: 'Dosya',
          gif: 'GIF',
          audio: 'Ses',
          live: 'Canlı olarak',
          doNotHaveAnAccount: "Hesabınız yok mu? ",
          register: 'Kayıt olmak',
          haveAnAccount: "Bir hesabınız var mı? ",
          login: 'Giriş yapmak',
          whoToFollow: 'Kimi takip etmeli',
          noSuggestion: 'Öneri Yok',
          follow: 'Takip et',
          unFollow: 'Takibi bırak',
          seeMore: 'Daha fazla gör',
          searchFilter: 'Arama Filtresi',
          people: 'İnsanlar',
          fromAnyone: 'Herkesten',
          peopleYouFollow: 'Takip ettiğin insanlar',
          location: 'Konum',
          anywhere: 'Herhangi bir yere',
          nearYou: 'Sana yakın',
          advancedSearch: 'gelişmiş Arama',
          trendsForYou: 'Sizin İçin Trendler',
          noTrending: 'Bölgenizde trend yok',
          trendingIn: 'Trend olan',
          // tweets: 'Tweetler',
          noNotification: 'Senin için bildirim yok',
          edit: 'Düzenlemek',
          save: 'Kaydetmek',
          cFollow: 'Takip et',
          addPeople: 'İnsanları ekle',
          someText: 'Bazı metin',
          reportConversation: 'Görüşmeyi Bildir',
          leaveConversation: 'Görüşmeden Ayrıl',
          enterYourMessage: 'mesajınızı girin',
          showMoreComments: 'Daha fazla yorum göster',
          reBuzz: 'Rebuzz',
          noPosts: 'Sizin için güncelleme yok',
          emailFieldCannotBeEmpty: 'E-posta Alanı boş olamaz',
          emailFormatIsInvalid: 'E-posta Biçimi geçersiz',
          rememberMe: 'Beni hatırla',
          lostPassword: 'Kayıp Şifre?',
          cLOGIN: 'GİRİŞ YAPMAK',
          emailOrPasswordIsIncorrect: 'E-posta veya şifre yanlış',
          newsFeed: 'Haber akışı',
          trends: 'Trendler',
          profile: 'Profil',
          newMessage: 'Yeni Mesaj',
          next: 'Sonraki',
          searchPeople: 'Kişi Ara',
          saySomething: 'Bir şey söyle',
          noSearchResult: 'Arama Sonucu Yok',
          searchResult: 'Arama sonuçları',
          hidePost: 'Gönderiyi gizle',
          showLess: 'Daha az göster',
          showMore: 'Daha fazla göster',
          nothingYet: 'Henüz değil!',
          savedPosts: 'Kayıtlı Yazılar',
          enterYourFirstName: 'İlk adınızı girin',
          enterYourLastName: 'Soyadınızı giriniz',
          enterYourUsername: 'Kullanıcı adınızı giriniz',
          signUp: 'Üye olmak',
          pleaseChooseACountry: 'Lütfen bir ülke seçin',
          replied: 'cevap verdi',
          reply: 'Cevap vermek',
          delete: 'Silmek',
          replyToComment: 'yoruma cevap',
          noFollower: 'takipçi yok',
          following: 'Takip etme',
          followBack: 'Geri takip',
          followers: 'Takipçiler',
          follower: 'takipçi',
          noFollowings: 'Takip Yok',
          sendAMessageGetAMessage: 'Mesaj gönder, mesaj al',
          directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore:
              "Direkt Mesajlar, sizinle Twitter'daki diğer kişiler arasındaki özel konuşmalardır. Tweet'leri, medyayı ve daha fazlasını paylaşın!",
          startAConversation: 'Konuşma Başlat',
          groupInfo: 'Grup Bilgileri',
          chatInfo: 'Sohbet Bilgileri',
          youDoNotHaveAMessageSelected: 'Seçili bir mesajınız yok',
          chooseOneFromYourExistingMessagesOrStartANewOne:
              'Mevcut mesajlarınızdan birini seçin veya yeni bir tane başlatın.',
          pleaseEnterVerificationCodeToVerifyYourEmail:
              'E-postanızı doğrulamak için lütfen doğrulama kodunu girin',
          usernameOrEmail: 'Kullanıcı adı ya da email',
          enterVerificationCode: 'dogrulama kodunu giriniz',
          confirmCode: 'Kodu Onayla',
          top: 'Tepe',
          latest: 'En sonuncu',
          photos: 'Fotoğraflar',
          files: 'Dosyalar',
          noPeople: 'İnsansız',
          all: 'Tüm',
          mentions: 'Mansiyonlar',
          replies: 'Cevaplar',
          // tweetsAndReplies: 'Tweetler ve Yanıtlar',
          media: 'medya',
          likes: 'Seviyor',
          searchPost: 'Güncellemeleri Ara',
          lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail:
              'Şifreni mi unuttun? lütfen kullanıcı adınızı ya da e-posta adresinizi girin. E-posta yoluyla yeni bir şifre oluşturmak için bir bağlantı alacaksınız.',
          resetYourPassword: 'Parolanızı Sıfırlayın',
          enterCode: 'Kodu girin',
          enterNewPassword: 'Yeni Şifreyi Girin',
          reEnterPassword: 'Şifrenizi tekrar girin',
          passwordCannotBeEmpty: 'Şifre Boş olamaz',
          passwordShouldBeCharacter: 'Şifre 8 karakter olmalıdır',
          passwordShouldBeMatched: 'Şifre Eşleşmeli',
          resetPassword: 'Şifreyi yenile',
          email: 'E-posta',
          blockUser: 'Kullanıcıyı engelle',
          public: 'Halk',
          mentionUsers: 'Kullanıcılardan Bahsetme',
          editProfile: 'Profili Ayarla',
          yourProfileIsUpdated: 'Profiliniz Güncellendi',
          seeProfile: 'Profili Gör',
          skipForNow: 'Şimdilik geç',
          addBio: 'Biyo Ekle',
          profileUpdated: 'Profil güncellendi',
          upDate: 'Güncelleme',
          goToProfile: 'Profile git',
          more: 'Daha',
          about: 'Hakkında',
          help: 'Yardım',
          privacyPolicy: 'Gizlilik Politikası',
          blog: 'Blog',
          termsOfService: 'Kullanım Şartları',
          youMustSelectACountry: 'Bir ülke seçmelisiniz',
          usernameIsAlreadyTaken: 'Kullanıcı adı zaten alınmış',
          goBack: 'Geri gitmek',
          snAccountHasAlreadyBeenCreatedWithThisEmail:
              'Bu e-postayla zaten bir hesap oluşturuldu',
          yourPasswordIsResetSuccessfully: 'Şifreniz başarıyla sıfırlandı',
          returnToLogin: 'Girişe Dön',
          youHaveEnteredAnInvalidCode: 'Geçersiz bir kod girdiniz',
          thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe:
              'BuzznBee ile hesabınızı oluşturduğunuz için teşekkür ederiz. Ekibimiz 24 saat içinde sizinle iletişime geçecektir. Güvende kal!',
          success: 'Başarı',
          goBackToHomePage: 'Ana sayfaya geri dön',
        },
      };
}
