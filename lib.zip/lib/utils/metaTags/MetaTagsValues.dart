class MetaTagValues {

  static const String ogImage = 'https://werfie.com/Frame7.png';

  // Login and SignUp Meta and Og Tags
  static const String signUpAndLoginPageTitle = "Sign up / Login | Werfie";
  static const String signUpAndLoginMetaDescription =
      'werfie sign in, sign up, create account, werfie register, werfie login, werfie account, social media network, social, facebook alternative, twitter alternative, x alternative, watch videos, news, trends, hashtags, social media, social media for news and videos';
  static const String signUpAndLoginMetaKeywords =
      'werfie sign in, sign up, create account, werfie register, werfie login, werfie account, social media network, social, facebook alternative, twitter alternative, x alternative, watch videos, news, trends, hashtags, social media, social media for news and videos';
  static const String signUpAndLoginOGTitle = 'Sign up / Login | Werfie';
  static const String signUpAndLoginOGDescription =
      'Sign up or Sign in to your Werfie account. Werfie is a social media network that offers you a space to share your thoughts and engage in real-time conversations';

  // NewsFeed Meta and Og Tags
  static const String pageTitleHome = "Werfie Home / Newsfeed";
  static const String newsFeedMetaDescription =
      'View the latest updates from your connections and people you like, pages you have liked, groups you have joined and upcoming events near you etc.';
  static const String newsFeedMetaKeywords =
      'werfie newsfeed, werfie updates, werfie feed, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news';
  static const String newsFeedOGTitle =
      'Your personalised newsfeed on Werfie Social Media Network';
  static const String newsFeedOGDescription =
      'View the latest updates from your connections, trends in your region, and people you follow';

  // Explore Meta and Og Tags
  static const String pageTitleExplore = "Explore | Werfie";
  static const String exploreMetaDescription =
      'Explore trends and popular werfs on Werfie';
  static const String exploreMetaKeywords =
      'werfie trends, werfie updates, werfie explore, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular posts, popular werfs';
  static const String exploreOGTitle = 'Explore | Werfie';
  static const String exploreOGDescription =
      'Explore trends and popular werfs on Werfie';

  // Latest trends Meta and Og Tags
  static const String pageTitleTrending = "Latest trends | Werfie";
  static const String trendsMetaDescription =
      'Explore latest trends and updates on Werfie';
  static const String trendsMetaKeywords =
      'werfie trends, werfie updates, werfie explore, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular posts, popular werfs';
  static const String trendsOGTitle = 'Latest trends | Werfie';
  static const String trendsOGDescription =
      'Explore latest trends and updates on Werfie';

  // Bookmarks Meta and Og Tags
  static const String pageTitleBookmarks = "Bookmarks | Werfie";
  static const String bookmarksMetaDescription =
      'View werfs you saved on Werfie. You can save werfs as bookmarks on Werfie to view them later';
  static const String bookmarksMetaKeywords =
      'werfie bookmarks, werfie updates, saved werfs, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular posts, popular werfs';
  static const String bookmarksOGTitle = 'Your bookmarks on Werfie';
  static const String bookmarksOGDescription =
      'View werfs you saved on Werfie. You can save werfs as bookmarks on Werfie to view them later';

  // Spaces Meta and Og Tags
  static const String pageTitleSpaces = "Your spaces on Werfie";
  static const String spacesMetaDescription =
      'Go live on Werfie with Spaces. Enjoy high quality audio and video conferencing. Participate in live events and share your thoughts';
  static const String spacesMetaKeywords =
      'werfie spaces, werfie updates, go live, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular werfs, audio and video calling';
  static const String spacesOGTitle = 'Your spaces on Werfie';
  static const String spacesOGDescription =
      'Go live on Werfie with Spaces. Enjoy high quality audio and video conferencing. Participate in live events and share your thoughts';

  // Chats Meta and Og Tags
  static const String pageTitleChats = "Chats and high quality audio / video calls on Werfie";
  static const String chatsMetaDescription =
      'Messaging on Werfie are fun. Send text, photos, videos, files and documents to your contacts.';
  static const String chatsMetaKeywords =
      'werfie chats, werfie messages, go live, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular werfs, audio and video calling';
  static const String chatsOGTitle =
      'Chats and high quality audio / video calls on Werfie';
  static const String chatsOGDescription =
      'Messaging on Werfie are fun. Send text, photos, videos, files and documents to your contacts. ';

  // Profile Meta and Og Tags
  static const String pageTitleProfile = "profile on Werfie";
  static const String profileMetaDescription = ' on Werfie and never miss any updates from them';
  static const String profileMetaKeywords = ',werfie profile, werfie profile, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular werfs, audio and video calling';
  static const String profileOGTitle = 'profile on Werfie';
  static const String profileOGDescription = 'on Werfie and never miss any updates from them';

  // Settings Meta and Og Tags
  static const String pageTitleSettings = "Settings | Werfie";
  static const String settingsMetaDescription =
      'Customise Werfie according to your prefrences';
  static const String settingsMetaKeywords =
      'werfie settings, werfie prefrences, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular werfs, audio and video calling';
  static const String settingsOGTitle = 'Settings | Werfie';
  static const String settingsOGDescription =
      'Customise Werfie according to your prefrences';

  // Lists Meta and Og Tags
  static const String pageTitleLists = "Lists | Werfie";
  static const String listsMetaDescription =
      'Lists on Werfie are collection of werfs from people your follow or topics your like';
  static const String listsMetaKeywords =
      'werfie lists, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular werfs, audio and video calling';
  static const String listsOGTitle = 'Lists | Werfie';
  static const String listsOGDescription =
      'Lists on Werfie are collection of werfs from people your follow or topics your like';

  // Notifications Meta and Og Tags
  static const String pageTitleNotification = "Your notifications on Werfie";
  static const String notificationsMetaDescription =
      'Stay informed about new updates from people you follow and new connection requests';
  static const String notificationsMetaKeywords =
      'werfie notifications, social media network, social, twitter alternative, x alternative, watch videos, video sharing platform, social media, social media for news, popular werfs, audio and video calling, werfie alerts';
  static const String notificationsOGTitle = 'Your notifications on Werfie';
  static const String notificationsOGDescription =
      'Stay informed about new updates from people you follow and new connection requests';

// Spaces Meta and Og Tags Latest trends
  static const String MetaDescription = '';
  static const String MetaKeywords = '';
  static const String OGTitle = '';
  static const String OGDescription = '';
}
