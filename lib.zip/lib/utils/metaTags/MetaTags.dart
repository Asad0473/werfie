import 'package:flutter/foundation.dart';
import 'package:meta_seo/meta_seo.dart';
import 'package:universal_html/html.dart' as html;

class MetaTags {
  initMetaTags() {
    if (kIsWeb) {
      MetaSEO().config();
    }
  }

  addMetaTag(
  {String pageTitle,
    String metaTagDescription,
      String metaTagKeywords,
      String ogTitle,
      String ogDescription,
      String ogImage,}) {
    if (kIsWeb) {
      MetaSEO meta = MetaSEO();
      meta.description(description: metaTagDescription);
      meta.keywords(keywords: metaTagKeywords);
      meta.ogTitle(ogTitle: ogTitle);
      meta.ogDescription(ogDescription: ogDescription);
      meta.ogImage(ogImage: ogImage);
      setPageTitle(pageTitle);

    }
  }

  void setPageTitle(String newTitle) {
    html.document.title = newTitle;
  }

  addOgTag() {}
}
