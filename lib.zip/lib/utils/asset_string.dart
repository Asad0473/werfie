class AppImages {
  static const String logo = "assets/images/werfie_new_large.png";
  static const String logoPng = "assets/images/werfie_new_large.png";
  static const String home = "assets/svg_drawer_icons/Home.svg";
  static const String explore = "assets/svg_drawer_icons/browse.svg";
  static const String chat = "assets/svg_drawer_icons/messages.svg";
  static const String notification =
      "assets/svg_drawer_icons/notifications.svg";
  static const String news = "assets/drawer_icons/news_icon.svg";
  static const String whoToFollow = "assets/svg_drawer_icons/who_to_follow.svg";
  static const String hashTag = "assets/svg_drawer_icons/Hashtag.svg";
  static const String personPlaceHolder =
      'assets/images/person_placeholder.png';
  static const String logout = 'assets/svg_drawer_icons/log_out.svg';
  static const String privacyPolicy = 'assets/svg_drawer_icons/privacy.svg';
  static const String more = 'assets/svg_drawer_icons/more.svg';
  static const String settings = 'assets/svg_drawer_icons/setting.svg';
  static const String profile = 'assets/svg_drawer_icons/profile.svg';
  static const String saved = 'assets/svg_drawer_icons/saved.svg';
  static const String termsAndConditions =
      'assets/svg_drawer_icons/termofservice.svg';
  static const String locationIconPost = 'assets/post_icons/location.svg';
  static const String list = 'assets/svg_drawer_icons/list.svg';
  static const String topic = 'assets/svg_drawer_icons/topic.svg';
  static const String momentsIcon = 'assets/svg_drawer_icons/moment.svg';

  static const String analytics = 'assets/images/analytics.png';

  static const String share = 'assets/images/share.png';

  static const String copylink = 'assets/images/copylink.png';
  static const String createWerf = 'assets/images/create_icon.png';

  static const String crossXImage='assets/images/XIcon.png';
  static const String newWerfieLogoSvg='assets/images/werfie_new_logo.svg';
  static const String newWerfieLogoPng='assets/images/werfie_new_large.png';
  static const String appleImageLogo='assets/images/apple_image_logo.png';
  static const String worldNoorImageLogo='assets/images/world_noor_image_logo.png';
  static const String googleImageLogo='assets/images/new_google_image.png';
  static const String appleSvgLogo='assets/images/apple_svg_logo.svg';
  static const String worldNoorSvgLogo='assets/images/world_noor_svg_logo.svg';
  static const String googleSvgLogo='assets/images/google_logo.svg';
  static const String authSvgBackGround='assets/images/auth_svg_background.svg';
  static const String authPngBackGround='assets/images/auth_back_ground.png';
  static const String loginWebPagePngPic='assets/images/login_web_page.png';
  static const String loginWebPageSvgPic='assets/images/login_web_page_svg_pic.svg';
  static const String loginWebPageLeftBackGround='assets/images/web_login_page_left_background.png';
  static const String simpleWhiteWLogo='assets/images/white_simple_w.png';
  static const String simpleBlackWLogo='assets/images/black_simple_w.png';

  static const String uploadImage='assets/create_post_icons/upload_image.svg';
  static const String uploadVideo="assets/create_post_icons/upload_video.svg";
  static const String uploadFile="assets/create_post_icons/upload_file.svg";
  static const String uploadPoll="assets/create_post_icons/create_poll.svg";
  static const String uploadSchedulePost="assets/create_post_icons/schedule_post.svg";
  static const String uploadLocation="assets/create_post_icons/location_pin.svg";
  static const String uploadEmojis='assets/create_post_icons/smile_emoji.svg';
  static const String uploadThread="assets/create_post_icons/add.svg";
  static const String uploadImagePNG='assets/create_post_icons/upload_image.png';
  static const String uploadVideoPNG="assets/create_post_icons/upload_video.png";
  static const String uploadFilePNG="assets/create_post_icons/upload_file.png";
  static const String uploadPollPNG="assets/create_post_icons/create_poll.png";
  static const String uploadSchedulePostPNG="assets/create_post_icons/schedule_post.png";
  static const String uploadLocationPNG="assets/create_post_icons/location_pin.png";
  static const String uploadEmojisPNG='assets/create_post_icons/smile_emoji.png';
  static const String uploadThreadPNG="assets/create_post_icons/add.png";
  ///reactions
  static const String like = 'assets/reaction_gif/like-min.png';

  static const String love = 'assets/reaction_gif/love-min.png';

  static const String lough = 'assets/reaction_gif/laugh-min.png';

  static const String excited = 'assets/reaction_gif/excited-min.png';

  static const String thanks = 'assets/reaction_gif/thanks-min.png';

  static const String cry = 'assets/reaction_gif/cry-min.png';

  static const String smile = 'assets/reaction_gif/smile-min.png';

  /// language icon

  static const String languageIcon = 'assets/images/language_icon.svg';

  ///imagePlaceHolder

  static const String imagePlaceHolder = 'assets/images/imagePlaceHolder.png';

// static const String logo = "assets/images/calendar.svg";
}

// 5f6368
// 9aa0a6
