/*
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/font.dart';
import 'package:werfieapp/utils/strings.dart';

import '../models/hashtag/hashtag_details_response_model.dart';
import '../network/apis/hashtag_detail_api.dart';

class HashtagDialog extends StatelessWidget {
  String hashTag;
  HashtagDialog(this.hashTag);
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<HashtagDetailAPIRes>(
        future: HashtagDetailAPI().hashtagDetail(hashTag),
        builder: (context, dataSnapshot) {
      if (dataSnapshot.connectionState == ConnectionState.waiting) {
        return Center(
          child: CircularProgressIndicator(),
        );
      } else {
        if (dataSnapshot.error != null) {
          return Center(
            child: Text('Oops…Something went wrong! Please try again'),
          );
        } else {

          HashtagDetailAPIRes model= dataSnapshot.data;
          if (dataSnapshot.data.data==null ) {
    return Center(
    child: Text(dataSnapshot.data.message),
    );
    } else if (dataSnapshot.hasData) {

          return Dialog(
      child: Container(
        width: 400.0, // Set the width
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "About hashtag",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 22.0,
              ),
            ),
            SizedBox(height: 40.0),

            Text(
              model.data.title,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 20.0,
              ),
            ),
            SizedBox(height: 30.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Text('Total post:',style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14.0,
                      )),
                      Text(
                        model.data.postCount.toString(),
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14.0,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Text('Total contributors:',style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14.0,
                      )),
                      Text(
                        model.data.contributers.toString(),
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14.0,
                        ),
                      ),
                    ],
                  ),
                ),

              ],
            ),
            SizedBox(height: 30.0),

            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Text('Created on:',style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14.0,
                      )),
                      Text(
                      DateFormat('MMM dd, yyyy').format(DateTime.parse(model.data.createdAt)),

                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14.0,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,

                    children: [
                      Text('Started trending on:',style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14.0,
                      )),
                      Text(
                        DateFormat('MMM dd, yyyy HH:mm a').format(DateTime.parse(model.data.createdAt)),

                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14.0,
                        ),
                      ),
                    ],
                  ),
                ),

              ],
            ),
            SizedBox(height: 30.0),

            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Country:' ,style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14.0,
                      ),),
                      Text(
                        model.data.country,
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20,),
           */
/* Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: ElevatedButton(
                    onPressed:
                         () {},

                    child: Text(
                       Strings.viewWerfs,

                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      primary: MyColors.werfieBlue,
                      // padding: EdgeInsets.symmetric(vertical: 16),
                      minimumSize: Size(150, 40),
                      shape: StadiumBorder(),
                    ),
                  ),
                ),
              ],
            ),*//*


          ],
        ),
      ),
    );
          } else {
            return Center(
              child: Text(dataSnapshot.data.message),
            );
          }

          }}});
  }
}
*/
