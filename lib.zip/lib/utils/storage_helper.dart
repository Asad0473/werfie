import 'package:flutter/foundation.dart';
import 'package:get_storage/get_storage.dart';

class Storage {
  static GetStorage box = GetStorage();
  static String userKey = "userKey";
  static String jwt = "jwt";
  static String firebase_token = "firebase_token";
  static String is_first_run = "is_first_run";
  static String mentorship_requests = "mentorship_requests";

  static String getJWT() {
    return box.read(jwt) ?? "";
  }

  static String getFirebaseToken() {
    return box.read(firebase_token) ?? "";
  }

  static String getMentorshipRequests() {
    return box.read(mentorship_requests) ?? "";
  }

  static bool getIsMentorTutorialComplete() {
    return box.read(is_first_run) ?? true;
  }

  static saveIsMentorTutorialComplete(bool isFirstRun) {
    if (kDebugMode) {
      // print("** SAVE ISFIRSTRUN");
    }

    box.write(is_first_run, isFirstRun);
    if (kDebugMode) {
      // print("** SAVED ISFIRSTRUN");
    }
  }

  static saveJWT(String data) {
    box.write(jwt, data);
    // print("jwt saved" + data);
  }
}
