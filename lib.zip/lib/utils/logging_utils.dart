import 'package:flutter/material.dart';

class LoggingUtils {
  static printValue(String message, var value) {
    // debugPrint('<==================== $message ====================>');
    // debugPrint(value);
  }
}
