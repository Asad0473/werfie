class AppLanguage {
  int id;
  String code;
  String name;

  AppLanguage({this.id, this.code, this.name});

  List languagesList = [
    {
      "id": 1,
      "name": "English",
      "code": "en",
    },
    {
      "id": 2,
      "name": "Arabic",
      "code": "ar",
    },
    {
      "id": 3,
      "name": "French",
      "code": "fr",
    },
    {
      "id": 4,
      "name": "German",
      "code": "de",
    },
    {
      "id": 5,
      "name": "Italian",
      "code": "it",
    },
    {
      "id": 6,
      "name": "Japanese",
      "code": "so",
    },
    {
      "id": 7,
      "name": "Russian",
      "code": "ru",
    },
    {
      "id": 8,
      "name": "Spanish",
      "code": "es",
    },
    {
      "id": 9,
      "name": "Hindi",
      "code": "hi",
    },
  ];
}

class Language {
  final int id;
  final String code;
  final String name;

  const Language({this.id, this.code, this.name});
}

class User {
  const User(this.id, this.name);

  final String name;
  final int id;
}
