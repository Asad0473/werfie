import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../models/category.dart';
import '../models/chatUserModel.dart';
import '../network/controller/news_feed_controller.dart';

class ChatUtils {
  static showReportUserDialog(context, String userId, NewsfeedController controller) {
    final reportText = TextEditingController();
    bool isCategory = false;
    final _formKey = GlobalKey<FormState>();
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
            child: StatefulBuilder(builder: (BuildContext context, StateSetter setState) {
              return Container(
                width: Get.width / 4.5,
                height: kIsWeb ? Get.width / 8 : 300,
                padding: EdgeInsets.all(10),
                child: Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          margin: const EdgeInsets.only(left: 10, right: 10, top: 0, bottom: 25),
                          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                          decoration: BoxDecoration(
                              border: Border.all(
                                color: isCategory ? Colors.red : Colors.grey[200],
                              ),
                              borderRadius: BorderRadius.circular(10)),
                          width: Get.width,
                          height: 55,
                          child: DropdownButton<CategoryModel>(
                            isExpanded: true,
                            underline: Container(
                              height: 0.0,
                            ),
                            hint: Text(controller.selectedCategory == null || controller.selectedCategory == ""
                                ? Strings.selectCategory
                                : controller.selectedCategory),
                            items: controller.categoryList.map((CategoryModel value) {
                              return DropdownMenuItem<CategoryModel>(
                                value: value,
                                child: Text(
                                  value.name,
                                  style: TextStyle(
                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                  ),
                                ),
                              );
                            }).toList(),
                            onChanged: (CategoryModel _) {
                              setState(() {
                                controller.selectedCategory = _.name;
                                controller.selectcategoryId = _.id;
                              });
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              MaterialButton(
                                  color: Colors.grey,
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  //
                                  child: Text(
                                    Strings.cancel,
                                    style: TextStyle(
                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      fontSize: 14,
                                    ),
                                  )),
                              MaterialButton(
                                  color: Colors.blueAccent,
                                  onPressed: () async {
                                    if (_formKey.currentState.validate()) {
                                      if (controller.selectcategoryId != null) {
                                        Navigator.of(context).pop();
                                        if (!kIsWeb) {
                                          Navigator.of(context).pop();
                                        }
                                        controller.isDeletingConversation = true;
                                        controller.update();
                                        isCategory = false;
                                        // setState(() {
                                        //
                                        // });
                                        await controller.blockUserFromChat(userId);
                                        int response = await controller.reportUser(
                                          userId,
                                          controller.selectcategoryId,
                                        );
                                        if (response == 200) {
                                          await ChatUtils.deleteConversation(controller);

                                          if (!kIsWeb) {
                                            Get.back();
                                            // Navigator.pop(context);
                                            // Navigator.pop(this.context);
                                          }

                                          // postChangeStatus(true);
                                          UtilsMethods.toastMessageShow(
                                              controller.displayColor, controller.displayColor, controller.displayColor,
                                              message: Strings.userReportedSuccessfully);
                                        }
                                        if (response == 400) {
                                          Navigator.of(context).pop();
                                          UtilsMethods.toastMessageShow(
                                              controller.displayColor, controller.displayColor, controller.displayColor,
                                              message: 'There was an error in reporting this user!');
                                        }
                                        controller.isDeletingConversation = false;
                                        controller.update();
                                      } else {
                                        setState(() {
                                          isCategory = true;
                                        });
                                      }
                                    }
                                  },
                                  child: Text(
                                    Strings.report,
                                    style: TextStyle(
                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      fontSize: 14,
                                    ),
                                  )),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              );
            }),
          );
        });
  }

  static deleteConversation(NewsfeedController controller) async {
    await controller.deleteConversation(controller.chatName.conversationId);
    controller.chatUserList = await controller.getChat();
    controller.chatRequestUserList = await controller.getMessageRequest();
    controller.chatIndex = 0;
    controller.showOverlay = false;
    controller.infoChatInfo = false;
    controller.isChatScreenWeb = false;
    controller.update();
  }

  static String getGroupChatName(List<Member> members){
    if (members != null && members.isNotEmpty){

      // Extract first names from the list of Member objects
      List<String> firstNames = members.map((member) => member.firstname).toList();

      // Sort the first names in ascending order
      firstNames.sort();

      // Initialize variables to keep track of names to display and count
      List<String> displayedNames = [];
      int othersCount = 0;

      // Iterate through each first name
      for (String name in firstNames) {
        // Truncate names longer than ten characters and add '...' at the end
        String formattedName = name.length > 10 ? '${name.substring(0, 10)}...' : name;

        // If the name is one of the first two, add it to the displayed names list
        if (displayedNames.length < 2) {
          displayedNames.add(formattedName);
        } else {
          // Otherwise, increment the count of others
          othersCount++;
        }
      }

      // Join the displayed names list with commas and return as a single string
      String output = displayedNames.join(', ');

      // If there are more than two names, add '& X others' to the displayed names list
      if (othersCount > 0) {
        String otherText = othersCount == 1 ? 'other' : 'others';
        output = '$output & $othersCount $otherText ';
      }


      return output;

    } else {
      return Strings.werfieUser;
    }
  }
}
