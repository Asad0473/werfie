import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'colors.dart';

class Styles {
  static final appTheme = _baseTheme.copyWith(
    iconTheme: const IconThemeData(
      color: Colors.black,
      // size: Dimens.size20,
    ),
    textTheme: baseTextTheme,
    accentTextTheme: accentTextTheme,
    cardTheme: _baseTheme.cardTheme.copyWith(
      margin: EdgeInsets.zero,
    ),
    textSelectionTheme: _baseTheme.textSelectionTheme.copyWith(
      cursorColor: colorScheme.secondary,
      selectionHandleColor: colorScheme.secondary,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        primary: MyColors.yellow, // background (button) color
        onPrimary: Colors.white, // foreground (text) color
      ),
    ),

    appBarTheme: AppBarTheme(backgroundColor: colorScheme.primary),
    // primaryTextTheme: ,
    scrollbarTheme: ScrollbarThemeData(
        isAlwaysShown: true,
        showTrackOnHover: true,
        interactive: true,
        trackVisibility: MaterialStateProperty.all(true),
        trackColor: MaterialStateProperty.all(Colors.white12),
        trackBorderColor: MaterialStateProperty.all(Colors.transparent),
        thickness: MaterialStateProperty.all(5),
        thumbColor: MaterialStateProperty.all(Colors.white70),
        radius: Radius.circular(10),
        minThumbLength: 10),
  );

  static final secondaryTextTheme = baseTextTheme.apply(
      // displayColor: Colors.white70,
      // bodyColor: Colors.white70,
      // fontFamily: MyFonts.roboto,

      );

  static final onSecondaryTextTheme = baseTextTheme.apply(
    displayColor: Colors.black,
    bodyColor: Colors.black,
    // fontFamily: MyFonts.roboto,
  );
  GetStorage localStor = GetStorage();

  static const colorScheme =
      // localStor.read("mode") == true?
      ColorScheme.dark(
    primary: MyColors.werfieNewColor,
    primaryVariant: Colors.blue,
    secondary: Colors.black,
    secondaryVariant: Colors.grey,
    onPrimary: Colors.white,
    onSecondary: Colors.blueAccent,
    onBackground: Colors.blueGrey,
  );

  //     :ColorScheme.light(
  //   primary: Colors.blueAccent,
  //   primaryVariant: Colors.blue,
  //   secondary: Colors.black,
  //   secondaryVariant: Colors.grey,
  //   onPrimary: Colors.white70,
  //   onSecondary: Colors.greenAccent,
  //   onBackground: Colors.blueGrey,
  // );

  static final _baseTheme = ThemeData.from(
      colorScheme: colorScheme,
      textTheme: Typography.material2018().black.apply(
            // fontFamily: MyFonts.roboto,
            displayColor: colorScheme.secondary,
            bodyColor: colorScheme.secondary,
          ));

  static final baseTextTheme = _baseTheme.textTheme.copyWith(
    headline1: _baseTheme.textTheme.headline1.copyWith(
      color: Colors.black,
      fontSize: kIsWeb ? 20 : 18,
      fontWeight: FontWeight.bold,
      // fontFamily: MyFonts.roboto,
    ),
    headline2: _baseTheme.textTheme.headline2.copyWith(
      color: Color(0xFF586976),
      fontSize: kIsWeb ? 18 : 16,
      fontWeight: FontWeight.w400,
      // fontFamily: MyFonts.roboto,
    ),
    headline3: _baseTheme.textTheme.headline3.copyWith(
      color: Colors.black,
      fontSize: 14,
      // height: 1.5,
      fontWeight: FontWeight.w700,
      // fontFamily: MyFonts.roboto,
    ),
    headline4: _baseTheme.textTheme.headline4.copyWith(
      color: Color(0xFF586976),
      fontSize: 16,
      //  height: 1.5,
      // fontWeight: FontWeight.w700,
      // fontFamily: MyFonts.roboto,
    ),
    headline5: _baseTheme.textTheme.headline5.copyWith(
      fontSize: kIsWeb ? 16 : 14,
      color: Color(0xFF586976),
      // height: 1.5,
      fontWeight: FontWeight.w700,
      // fontFamily: MyFonts.roboto,
    ),
    headline6: _baseTheme.textTheme.headline6.copyWith(
      fontSize: 14,
      color: Colors.yellow,
      height: 1.5,
      fontWeight: FontWeight.w700,
      // fontFamily: MyFonts.roboto,
    ),
    bodyText1: _baseTheme.textTheme.bodyText1.copyWith(
      fontSize: 16,
      color: Colors.black,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    bodyText2: _baseTheme.textTheme.bodyText2.copyWith(
      fontSize: 14,
      color: Colors.black,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    subtitle1: _baseTheme.textTheme.subtitle1.copyWith(
      fontSize: 12,
      color: Colors.black,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    subtitle2: _baseTheme.textTheme.subtitle2.copyWith(
      fontSize: 12,
      color: Colors.black,
      //  decoration: TextDecoration.underline,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    caption: _baseTheme.textTheme.caption.copyWith(
      fontSize: 10,
      // color: Colors.grey,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    overline: _baseTheme.textTheme.overline.copyWith(
      fontSize: 8,
      // fontFamily: MyFonts.roboto,
      // color: Colors.grey,
      height: 1.5,
    ),
  );
  static final accentTextTheme = baseTextTheme.apply(
    displayColor: colorScheme.secondary,
    bodyColor: colorScheme.secondary,
  );

  Styles._();
}

class LightStyles {
  static final appTheme = _baseTheme.copyWith(
    iconTheme: const IconThemeData(
      color: Colors.black,
      // size: Dimens.size20,
    ),
    textTheme: baseTextTheme,
    accentTextTheme: accentTextTheme,
    cardTheme: _baseTheme.cardTheme.copyWith(
      margin: EdgeInsets.zero,
    ),
    textSelectionTheme: _baseTheme.textSelectionTheme.copyWith(
      cursorColor: colorScheme.secondary,
      selectionHandleColor: colorScheme.secondary,
    ),

    appBarTheme: AppBarTheme(backgroundColor: colorScheme.primary),
    // primaryTextTheme: ,
    scrollbarTheme: ScrollbarThemeData(
        isAlwaysShown: true,
        showTrackOnHover: true,
        interactive: true,
        trackColor: MaterialStateProperty.all(Colors.transparent),
        trackBorderColor: MaterialStateProperty.all(Colors.transparent),
        thickness: MaterialStateProperty.all(5),
        thumbColor: MaterialStateProperty.all(Colors.transparent),
        radius: const Radius.circular(10),
        minThumbLength: 10),
  );

  static final secondaryTextTheme = baseTextTheme.apply(
    displayColor: Colors.white70,
    bodyColor: Colors.white70,
    // fontFamily: MyFonts.roboto,
  );

  static final onSecondaryTextTheme = baseTextTheme.apply(
    displayColor: Colors.black,
    bodyColor: Colors.black,
    // fontFamily: MyFonts.roboto,
  );

  static const colorScheme =
      // localStor.read("mode") == true?
      // ColorScheme.dark(
      //   primary: Colors.blueAccent,
      //   primaryVariant: Colors.blue,
      //   secondary: Colors.black,
      //   secondaryVariant: Colors.grey,
      //   onPrimary: Colors.white70,
      //   onSecondary: Colors.greenAccent,
      //   onBackground: Colors.blueGrey,
      // );
      //     :
      ColorScheme.light(
    primary: MyColors.werfieNewColor,
    primaryVariant: Colors.blue,
    secondary: Colors.black,
    secondaryVariant: Colors.grey,
    onPrimary: Colors.white,
    onSecondary: Colors.blueAccent,
    onBackground: Colors.blueGrey,
  );

  static final _baseTheme = ThemeData.from(
    colorScheme: colorScheme,
    textTheme: Typography.material2018().black.apply(
          // fontFamily: MyFonts.roboto,
          displayColor: colorScheme.secondary,
          bodyColor: colorScheme.secondary,
        ),
  );

  static final baseTextTheme = _baseTheme.textTheme.copyWith(
    headline1: _baseTheme.textTheme.headline1.copyWith(
      color: colorScheme.secondary,
      fontSize: 20,
      height: 1.5,
      fontWeight: FontWeight.w700,
      // fontFamily: MyFonts.roboto,
    ),
    headline2: _baseTheme.textTheme.headline2.copyWith(
      color: const Color(0xFF586976),
      fontSize: 14,
      // height: 1.5,
      fontWeight: FontWeight.w500,
      // fontFamily: MyFonts.roboto,
    ),
    headline3: _baseTheme.textTheme.headline3.copyWith(
      color: const Color(0xFF586976),
      fontSize: 14,
      // height: 1.5,
      fontWeight: FontWeight.w400,
      // fontFamily: MyFonts.roboto,
    ),
    headline4: _baseTheme.textTheme.headline4.copyWith(
      color: Colors.black,
      fontSize: 18,
      height: 1.5,
      fontWeight: FontWeight.w500,
      // fontFamily: MyFonts.roboto,
    ),
    headline5: _baseTheme.textTheme.headline5.copyWith(
      fontSize: 16,
      color: Colors.black,
      height: 1.5,
      fontWeight: FontWeight.w700,
      // fontFamily: MyFonts.roboto,
    ),
    headline6: _baseTheme.textTheme.headline6.copyWith(
      fontSize: 14,
      color: Colors.black,
      height: 1.5,
      fontWeight: FontWeight.w700,
      // fontFamily: MyFonts.roboto,
    ),
    bodyText1: _baseTheme.textTheme.bodyText1.copyWith(
      fontSize: 16,
      color: Colors.black,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    bodyText2: _baseTheme.textTheme.bodyText2.copyWith(
      fontSize: 14,
      color: Colors.black,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    subtitle1: _baseTheme.textTheme.subtitle1.copyWith(
      fontSize: 12,
      color: Colors.black,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    subtitle2: _baseTheme.textTheme.subtitle2.copyWith(
      fontSize: 12,
      color: Colors.black,
      //  decoration: TextDecoration.underline,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    caption: _baseTheme.textTheme.caption.copyWith(
      fontSize: 10,
      color: Colors.grey,
      height: 1.5,
      // fontFamily: MyFonts.roboto,
    ),
    overline: _baseTheme.textTheme.overline.copyWith(
      fontSize: 8,
      // fontFamily: MyFonts.roboto,
      color: Colors.grey,
      height: 1.5,
    ),
  );
  static final accentTextTheme = baseTextTheme.apply(
    displayColor: colorScheme.secondary,
    bodyColor: colorScheme.secondary,
  );

  LightStyles._();
}

