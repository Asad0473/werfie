class Url {
  // static const baseUrl = 'http://54.215.53.4/api/';
  // static const baseUrl = 'http://54.215.53.4/api/';
// static const laravelBaseUrl = 'https://api.werfie.com';
 static const laravelBaseUrl = 'https://api-staging.werfie.com';
  static const baseUrl = laravelBaseUrl + '/api/';

  // static const chatBaseUrl = 'http://54.215.53.4:9002/api/';

// static const nodeBaseUrl = 'https://nodeapi.werfie.com';
 static const nodeBaseUrl = 'https://nodeapi-staging.werfie.com';

   static const spaceStagingUrl = 'https://spaces.werfie.com/';
  ///
  static const viewEditHistory = baseUrl + 'post/edit_history';

  static const deleteProfile = baseUrl + 'profile/delete_profile';

  static const permanentDeleteProfile = baseUrl + 'profile/hard_delete_profile';

  static const muteUnMute = baseUrl + 'profile/mute_un_mute_users';

  static const unMuteWord = baseUrl + 'privacy-and-safety/mute-word-delete';

  static const hideUnHideReply = baseUrl + 'comment/hide_unHide';

  static const allHiddenComment = baseUrl + 'comment/hidden';

  static const verificationAccount = baseUrl + 'profile/account_verification';
  static const chatBaseUrl = nodeBaseUrl + '/api/';
  static const webAPIKey = 'e06b4395-4411-4c2c-9585-952900e5ba25';
  static const androidAPIKey = 'e06b4395-4411-4c2c-9585-952900e5ba15';
  static const iOSAPIKey = 'e06b4395-4411-4c2c-9585-952900eh5ba45';
  static const registerationUrl = baseUrl + 'register';
  static const login = baseUrl + 'login';
  static const poshLogin = baseUrl + 'posh-login';
 static const accountLockoutUrl = nodeBaseUrl + '/api/invalid-attempt-block';
  static const loginVerify = baseUrl + 'login-verify';
  static const forgotPassword = baseUrl + 'user/resend-email';
  static const renewPassword = baseUrl + 'user/reset-password';

  static const verificationCode = baseUrl + 'user/verify-verification-code';

  static const usernameSuggestion = baseUrl + 'username-suggestion';
  static const searchUsers = baseUrl + 'search/users';
  static const searchPosts = baseUrl + 'search/posts';
  static const searchSuggestions = baseUrl + 'search/suggestions';
  static const getCountries = baseUrl + 'countries';
  static const newsfeedUrl = baseUrl + 'newsfeed';
   static const newsfeedRedisUrl = nodeBaseUrl + '/api/newsFeed';


   static const getLanguageUrl = baseUrl + 'get-my-language';

  static const languageRequestUrl = baseUrl + 'save-language-settings';
  static const createPostUrl = baseUrl + 'post/create';
  static const likePostUrl = baseUrl + 'react';
  static const createCommentUrl = baseUrl + 'comment';
  static const savePostUrl = baseUrl + 'post/save';

  static const saveUsernameUrl = baseUrl + 'profile/update_username';
  static const changeCountryUrl = baseUrl + 'profile/update-country';

  static const verifyPassword =
      baseUrl + 'change-email-address/verify-current-password';

  static const emailTakenOrNot =
      baseUrl + 'change-email-address/check-email-if-taken';

  static const sendEmailVerification =
      baseUrl + 'change-email-address/send-verification-email';

  static const sendCodeResetEmail =
      baseUrl + 'change-email-address/verify-email-reset-code';

  static const getTopicPostUrl = baseUrl + 'trending-post';
  static const unSavePostUrl = baseUrl + 'saved/unsave';
  static const getSavedPostUrl = baseUrl + 'saved/newsfeed';
  static const getBrowsePostUrl = baseUrl + 'search/popular_posts';
  static const hidePostUrl = baseUrl + 'post/hide';
  static const unhidePostUrl = baseUrl + 'post/unhide';
  static const followSuggestions = nodeBaseUrl + '/api/follow_suggestions';
  static const urlScraping = baseUrl + 'fetch-link-info';
  static const getList = baseUrl + 'list';
  static const getDelete = baseUrl + 'list/delete';
  static const getPinUnPin = baseUrl + 'list/pin_unpin_list';
  static const getCreateList = baseUrl + 'list/create_update_list';
  static const getSuggestedUser = baseUrl + 'list/suggested_users';
  static const getAddMemberFollower = baseUrl + 'list/add_member_followers';
  static const getFollowers = baseUrl + 'list/get_followers';
  static const getListDetail = baseUrl + 'list/get_list';
  static const getMemberList= baseUrl + 'list/members';

   static const getGooglePlaceAutocomplete = baseUrl + 'place_autocomplete';

  static const getTrendings = nodeBaseUrl + '/api/trending';
  static const getReportCategory = baseUrl + 'report_categories';
  static const followUser = baseUrl + 'follow';
  static const unFollowUser = baseUrl + 'unfollow';
  static const getFollower = baseUrl + 'followers';
  static const getFollowing = baseUrl + 'followings';
  static const reportPost = baseUrl + 'post/report';
  static const reportUser = baseUrl + 'profile/report_user';
  static const likeDislikeCommentUrl = baseUrl + 'comment/like_dislike';
  static const deleteCommentUrl = baseUrl + 'comment';
  static const sharePostUrl = baseUrl + 'post/share_post';
  static const getSharedPostUrl = baseUrl + 'post/shares';
  static const getSingleNewsFeedItemUrl =
      baseUrl + 'post/get-single-newsfeed-item';
  static const getNotificationsUrl = baseUrl + 'profile/notifications';
  static const getMentionedNotificationsUrl =
      baseUrl + 'profile/mention_notifications';
  static const getVerifiedNotificationsUrl =
      baseUrl + 'profile/verified-notifications';
  static const getProfileUrl = baseUrl + 'profile/basic';
  static const whoReactedUrl = baseUrl + 'post/who_reacted';

  static const whoReactedForCommentUrl = baseUrl + 'comment/get_likes_dislikes';
  static const getCommentsListPosts = baseUrl + 'getComments';





  //topic
  static const followedTabUrl = baseUrl + 'topics?type=both';
  static const topicsDetails = baseUrl + 'topics/topic_detail';


   static const hiddenComments = baseUrl + 'posts/hidden_comments';

  static const removeLocation = baseUrl + 'privacy-and-safety/remove-location';

  static const privacyAndSafety =
      baseUrl + 'privacy-and-safety/read-update-settings';

  static const addMuteWord = baseUrl + 'privacy-and-safety/mute-word';

  static const followUnFollowTopic = baseUrl + 'topics/follow_un_follow';
  static const notInterestTopic = baseUrl + 'topics/not_interested_topics';
  static const addRemoveNotInterested =
      baseUrl + 'topics/add_remove_not_interested';

  static const othersUserTopics = baseUrl + 'topics/other_topics';

  ///moments url
  static const searchMomentsPosts = baseUrl + 'moments/search_post_for_moment';
  static const createMoments = baseUrl + 'moments/create_update';
  static const addMomentsPost = baseUrl + 'moments/add_post_to_moment';
  static const getMomentsPostList = baseUrl + 'moments/';
  static const momentsDetails = baseUrl + 'moments/detail';
  static const deleteMoments = baseUrl + 'moments/delete';
  static const removePostFromMoments = baseUrl + 'moments/remove_post';
  static const otherUserMoments = baseUrl + "moments/other_user_moments";

  /// list url
  static const createList = baseUrl + "list/create_update_list";

  /// guestuser url
  static const guestUserTopicData = baseUrl + "guest-newsfeed";

  static const socialLogin = baseUrl + "social_login";
  static const guestSearch = baseUrl + 'guest-search';
  static const guestSearchResult = baseUrl + 'guest-search-get';

  static const whoRetweetedUrl = baseUrl + 'retweet/who_retweeted';
  static const addRetweetUrl = baseUrl + 'retweet/create';
  static const undoRetweetUrl = baseUrl + 'retweet/undo';
  static const updateProfileUrl = baseUrl + 'profile/update';
  static const profileNewsFeedUrl = baseUrl + 'profile/newsfeed';
  static const blockUserUrl = baseUrl + 'profile/block_un_block_users';
  static const blockedUsersList = baseUrl + 'profile/blocked';

  static const muteWordsList = baseUrl + 'privacy-and-safety/mute-words-list';

  static const muteUsersList = baseUrl + 'privacy-and-safety/muted-users-list';

  static const checkUsername = baseUrl + 'profile/check_username';
  static const pollRespond = baseUrl + 'post/poll_responed';
  static const searchTags = baseUrl + 'search/tags';
  static const snoozeNotification =
      baseUrl + 'profile/change_notification_status';

  //Chat
  static const chatPrivacyUrl = baseUrl + 'profile/message_privacy';
  static const getChatPrivacyUrl = baseUrl + 'profile/get_message_privacy';
  static const createChatUrl = chatBaseUrl + 'conversation/create';
  static const getSnoozeNotificationUrl = chatBaseUrl + 'conversation/get_snooze_notification';
  static const snoozeNotificationUrl = chatBaseUrl + 'conversation/snooze_notification';
  static const getChatUrl = chatBaseUrl + 'conversations';
  static const getChatRequestUrl = nodeBaseUrl + '/api/' + 'message-requests';
  static const updateGroupNameUrl = chatBaseUrl + 'update-group-chat-name';
  static const updateGroupImageUrl = chatBaseUrl + 'update-group-chat-image';
  static const messageUrl = chatBaseUrl + 'messages';
  static const createMessageImage = chatBaseUrl + 'upload-file';
  static const leaveConversation = chatBaseUrl + 'conversation/leave';
  static const deleteConversation = chatBaseUrl + 'conversation/delete';
  static const deletePost = baseUrl + 'post';
  static const deleteMessageForMe = chatBaseUrl + 'message/delete-for-me';

   static const hideUnhideComments = baseUrl + 'posts/hide_unhide_comments';


   static const UnhidePost = baseUrl + 'post/unhide';

  static const schedulePost = baseUrl + 'post/scheduled_post';
  static const getScheduledPosts = baseUrl + 'post/schedules';
  static const deleteScheduledPosts = baseUrl + 'post/delete_schedules';
  static const testAuth = baseUrl + 'test';
  static const uploadMedia = baseUrl + 'post/upload';
  static const werfAnalytics = baseUrl + 'post/activities';
  static const addMemberChat = chatBaseUrl + 'conversation/add_member';
  static const chatSearchUrl = chatBaseUrl + "search-all/";

  static const sharePostViaDirectMessage =
      chatBaseUrl + 'post/send_post_in_message';

  //FCM
  static const fcmUrl = baseUrl + 'fcm/store';
  static const werfiePrivacyUrl = "https://api.werfie.com/privacy";
  static const werfieTermsUrl = "https://api.werfie.com/terms";

  //Digest
  static const digestSettings = baseUrl + 'profile/digest-setting';

  //Notifications
  static const mutedNotifications = baseUrl + 'profile/muted-notifications';
  static const pushNotifications =
      baseUrl + 'profile/push-notifications-settings';
  static const emailNotifications =
      baseUrl + 'profile/email-notification-settings';
  static const callNotification = chatBaseUrl + "call/notification";

  // 2FA
   static const send2FA = baseUrl + 'profile/enable-two-factor-authentication';
   static const verify2FACode = baseUrl + 'profile/alter-two-factor-authentication';
   static const captchaVerifyVThree = baseUrl + 'captcha_curl';
   static const hashtagDetail = baseUrl + 'hashtagDetail';

   // spaces api
   static const createSpace = chatBaseUrl + 'spaces/create';
   static const joinSpace = chatBaseUrl + 'spaces/join';
   static const getSpaces = chatBaseUrl + 'spaces/';

   // Werfie Handle Suggestions
 static const getWerfieHandleSuggestions = baseUrl + 'username-suggestion';
 static const checkEmail = baseUrl + 'check-email';

 // AWS Signed URL
 static const awsSignedUrl = nodeBaseUrl + '/api/aws-signed-url';

 // LOGOUT
 static const logout = baseUrl + 'logout';

 // REPORT
 static const reportUserAndWerf = nodeBaseUrl + '/api/report';



}
