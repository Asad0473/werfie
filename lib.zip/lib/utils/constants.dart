class Constants {
  static final int homeScreenId = 0;
  static final int browseScreenId = 1;
  static final int chatsScreenId = 2;
  static final int notificationsScreenId = 3;
  static final int newsScreenId = 4;

  static final int hotTrendsScreenId = 5;
  static final int whoToFollowScreenId = 6;

  static final int bookMarkScreenId = 7;

  static final int profileScreenId = 8;
  static final int settingScreenId = 9;
  static final int listScreenId = 10;
  static final int topicScreenId = 11;
  static final int momentsScreenId = 12;
  static final int communitiesScreenId = 13;
  static final int displayScreenId = 14;
}
