import 'package:flutter/cupertino.dart';

class MyColors {
   static const Color blue = Color(0xFF1D9BF0);
 // static const Color blue = Color(0xFF1967d8);
  static const Color yellow = Color(0xFFedab30);
  static const Color grey = Color(0xFF55636f);
  static const Color pink = Color(0xFFFFC0CB);
  static const Color teal = Color(0xFF008080);
  static const Color liteDark = Color(0xff232526);
  static const Color black = Color(0xff232526);

  // static  Color werfieBlue  = newsfeedController.displayColor;
  static Color werfieBlue = const Color(0xFF1D9BF0);
  static const Color lightColor = Color(0xFF586976);
  static const Color werfieNewColor=Color(0xFF1D9BF0);
 // static const Color BlueColor = Color(0xFF2769d9);
   static const Color BlueColor = Color(0xFF1D9BF0);
  static const Color yellowColor = Color(0xFFffd400);
  static const Color pinkColor = Color(0xFFf91880);
  static const Color purpleColor = Color(0xFF7856ff);
  static const Color orangeColor = Color(0xFFff7a00);
  static const Color greenColor = Color(0xFF00ba7c);

  static const Color hoverCommentColor = Color(0xFFe1eef6);
  static const Color hoverRetweetColor = Color(0xFFdef1eb);
  static const Color retweetColor = Color(0xFF2bc491);
  static const Color hoverReactionColor = Color(0xFFf7e0eb);
  static const Color reactionColor = Color(0xFFf9318d);
  static const Color imagePlaceHolderBackgroundColor = Color(0xFFf7f9f9);

  static const Color HighlightedColor = Color(0xFFeff3f4);
  static const Color greyFill = Color(0xfff5f5f5);
  static const Color worldNoorBlue = Color(0xff019ed9);
  static const Color loginWhiteColor=Color(0xffF6F6F6);
}
