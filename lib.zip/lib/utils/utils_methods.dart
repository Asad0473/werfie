import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:werfieapp/utils/strings.dart';

import '../models/GetCountriesResponse.dart' as cr;
import 'logging_utils.dart';

class UtilsMethods {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn();

  static Future<void> share(dynamic link, String title) async {
    await FlutterShare.share(
        title: link, text: title, linkUrl: link, chooserTitle: title);
  }

  static String validateEmail(String value) {
    return value.isEmpty
        ? Strings.emailFieldCannotBeEmpty
        : !RegExp(r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
                .hasMatch(value)
            ? Strings.pleaseProvideAValidEmail
            : null;
  }

  static String validatePassword(String value) {
    return value.isEmpty
        ? Strings.passwordCannotBeEmpty
        : value.length < 8
            ? Strings.passwordShouldBeCharacter
            : null;
  }

  static String validateField(String value, String message) {
    return value.isEmpty ? '$message is required' :
    null;
  }

  static String validateName(String value, ) {
    return value.isEmpty ? 'Name is required' :
   ! RegExp('[a-zA-Z]+[ a-zA-Z]*').hasMatch(value)?
    "Name start with must be Alphabets ":null;
  }


  static String validateCountryField(cr.Data value, String message) {
    return value == null ? '$message is required' : null;
  }

  static Future<bool> checkInternet() async {
    try {
      final result = await InternetAddress.lookup('www.google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        // print('connected');
        return true;
      }
    } on SocketException catch (_) {
      // print('not connected');
      return false;
    }
    return false;
  }

  Widget getBoldText(String value) {
    return Text(
      value,
      style: TextStyle(
        fontSize: 15.0,
        fontFamily: 'sfui_text',
        fontWeight: FontWeight.w700,
      ),
    );
  }

  static String getDate(DateTime date) {
    var dateTime =
        DateFormat("yyyy-MM-dd HH:mm:ss").parse(date.toString(), true);
    //  print('dateTime:$dateTime');
    var dateLocal = dateTime.toLocal();
//print('localTime$dateTime');
// print('localTime$dateTime');
    String dateNow = dateLocal.toString();
    var currentDate = DateTime.now();
//print('currentDate:$currentDate');
// print('currentDate:$currentDate');

    var showDays = currentDate.difference(dateLocal).inDays;
    if (showDays < 1) {
      var showHour = currentDate.difference(dateLocal).inHours;
      if (showHour < 1) {
        var showMint = currentDate.difference(dateLocal).inMinutes;
        if (showMint < 1) {
          String justNow = 'Just now';
          return justNow;
        } else {
          String showMintDetails = showMint.toString();
          return showMintDetails + 'm';
        }
      } else {
        String showHourDetails = showHour.toString();
        return showHourDetails + 'h';
      }
    } else if (showDays <= 2) {
      var showDays2 = currentDate.difference(dateLocal).inDays;

      String showDaysDetails = showDays2.toString();
      return showDaysDetails + 'd';
    } else {
      var dateTime = DateFormat("d MMM").format(date);
      var dateLocal = dateTime.toString();
      return dateLocal + '.';
    }
  }

  static String getWerfDetailDate(DateTime date) {
    // Define the date format
    final dateFormat = DateFormat('h:mm a · MMM d, yyyy');

    // Format the DateTime object
    String formattedDate = dateFormat.format(date.toLocal());

    return formattedDate;
  }

  static String getLeftDate(DateTime date) {
    var dateTime =
    DateFormat("yyyy-MM-dd HH:mm:ss").parse(date.toString(), true);
    var dateLocal = dateTime.toLocal();
    var expiryDate = DateTime.now();

    var showDays = dateLocal.difference(expiryDate).inDays;
    // print("showDays : $showDays");
    if (showDays < 1) {
      var showHour = dateLocal.difference(expiryDate).inHours;
      if (showHour < 1) {
        var showMint = dateLocal.difference(expiryDate).inMinutes;
        if (showMint < 1) {
          String justNow = '1 minute left';
          return justNow;
        } else {
          String showMintDetails = showMint.toString();
          return showMintDetails + ' minutes left';
        }
      } else {
        String showHourDetails = showHour.toString();
        if (showHour == 1){
          return showHourDetails + ' hour  left';
        } else {
          return showHourDetails + ' hours  left';
        }

      }
    } else if (showDays >= 1) {
      var showDays2 = dateLocal.difference(expiryDate).inDays;

      String showDaysDetails = showDays2.toString();
      if (showDays == 1){
        return showDaysDetails + ' day left';
      } else {
        return showDaysDetails + ' days left';
      }
    } else {
      var dateTime = DateFormat("d MMM").format(date);
      var dateLocal = dateTime.toString();
      return "Expires on " + dateLocal + '.';
    }
  }

  static String getChatDate(String date) {
    var str = date;
    DateTime time =
        DateTime.parse(str.substring(0, 10) + ' ' + str.substring(11, 19));

    String a = getDate(time);

    return a;
  }

//   static String getMessageDate(DateTime date) {
//
//     var dateTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(date.toString(), true);
//     //  print('dateTime:$dateTime');
//     var dateLocal = dateTime.toLocal();
// //print('localTime$dateTime');
// // print('localTime$dateTime');
//     String dateNow=dateLocal.toString();
//     var currentDate=DateTime.now();
// //print('currentDate:$currentDate');
// // print('currentDate:$currentDate');
//
//     var showDays=currentDate.difference(dateLocal).inDays;
//     if(showDays<1){
//       var showHour=currentDate.difference(dateLocal).inHours;
//       if(showHour<1){
//         var showMint=currentDate.difference(dateLocal).inMinutes;
//         if(showMint<1){
//           String justNow='Just now';
//           return justNow;
//         }
//         else {
//           String showMintDetails= showMint.toString() ;
//           return showMintDetails +'m';
//         }
//
//       }
//       else{
//         String showHourDetails= showHour.toString() ;
//         return showHourDetails +'h';
//       }
//
//     }
//     else if(showDays<=2) {
//       var showDays2=currentDate.difference(dateLocal).inDays;
//
//       String showDaysDetails= showDays2.toString() ;
//       return showDaysDetails +'d';
//
//     }
//
//     else{
//       var dateTime = DateFormat("d MMM").format(date);
//       var dateLocal = dateTime.toString();
//       return dateLocal +'.'  ;
//
//     }
//
//
//   }

  final storage = GetStorage();






  static Future<PickedFile> getImageFromCamera() async {
    try {
      final picker = ImagePicker();

      final pickedFile = await picker.getImage(source: ImageSource.camera);

      if (pickedFile != null) {
        return pickedFile;
      }
      else {
        // print(pickedFile.path);
        return null;
      }
    } catch (e) {
      debugPrint("getImageFromCamera Error: $e");
      return null;
      // print("errrrrrrrrrrrrrrrrrrrr$e");
    }
  }


  static toastMessageShow(Color mobileColor, Color web1Color, Color web2Color,
      {String message, int toastDuration}) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: toastDuration??2,
        backgroundColor: mobileColor,
        textColor: Colors.white,
        webPosition: "center",
        webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
        //  webBgColor: "linear-gradient(to right, #${web1Color}, #${web2Color})",
        fontSize: 16.0);
  }
  static String dateTimeFormat(String value,String format) {
    // var dateFormat = DateFormat("MMM dd, yyyy | hh:mm:ss"); // you can change the format here
    var dateFormat = DateFormat(format); // you can change the format here
    var utcDate = dateFormat.format(DateTime.parse(value)); // pass the UTC time here
    var localDate = dateFormat.parse(utcDate, true).toLocal().toString();
    String createdDate = dateFormat.format(DateTime.parse(localDate));
    return createdDate;
  }
  static Future<AuthorizationCredentialAppleID> signInWithApple() async {
    final appleProvider = AppleAuthProvider();
    // return await FirebaseAuth.instance.signInWithProvider(appleProvider);

    /*AuthorizationCredentialAppleID credential =
        await SignInWithApple.getAppleIDCredential(
      scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ],
    );*/
    AuthorizationCredentialAppleID credential;
    try {
      credential  = await SignInWithApple
          .getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
        webAuthenticationOptions: WebAuthenticationOptions(
          // TODO: Set the `clientId` and `redirectUri` arguments to the values you entered in the Apple Developer portal during the setup
          clientId:
          // 'com.ogoul.werfieapp',
          'com.ogoul.applesignin',

          redirectUri:
          // For web your redirect URI needs to be the host of the "current page",
          // while for Android you will be using the API server that redirects back into your app via a deep link
          kIsWeb
              ? Uri.parse('https://www.werfie.com')
              : Uri.parse(
            'https://flutter-sign-in-with-apple-example.glitch.me/callbacks/sign_in_with_apple',
          ),
        ),
      );

    }catch(e){
      LoggingUtils.printValue("sign in with apple", e);
    }
    // print(credential);
    LoggingUtils.printValue("sign in with apple", credential);

    return credential;
  }

  Future<User> signInWithGoogle() async {
    User user;

    if (kIsWeb) {
      GoogleAuthProvider authProvider = GoogleAuthProvider();

      try {
        final UserCredential userCredential =
            await auth.signInWithPopup(authProvider);
        user = userCredential.user;
        // print('webuserInfo token:${user.refreshToken}');
        // print('webuserEmail:${user.email}');
        // print('webuserName:${user.displayName}');
        // print('webuserId:${user.uid}');
      } on FirebaseAuthException catch (e) {
        if (e.code == 'account-exists-with-different-credential') {
          // print('The account already exists with a different credential.');
        } else if (e.code == 'invalid-credential') {
          // print('Error occurred while accessing credentials. Try again.');
        }
      } catch (e) {
        // print(e);
      }
    } else {
      final GoogleSignIn googleSignIn = GoogleSignIn();

      final GoogleSignInAccount googleSignInAccount =
          await googleSignIn.signIn();

      if (googleSignInAccount != null) {
        final GoogleSignInAuthentication googleSignInAuthentication =
            await googleSignInAccount.authentication;
        final AuthCredential credential = GoogleAuthProvider.credential(
          accessToken: googleSignInAuthentication.accessToken,
          idToken: googleSignInAuthentication.idToken,
        );

        try {
          final UserCredential userCredential =
              await auth.signInWithCredential(credential);

          user = userCredential.user;
          // print('userInfo token:${user.refreshToken}');
          // print('userEmail:${user.email}');
          // print('userName:${user.displayName}');
          // print('userId:${user.uid}');
        } on FirebaseAuthException catch (e) {
          if (e.code == 'account-exists-with-different-credential') {
            // print('The account already exists with a different credential.');
          } else if (e.code == 'invalid-credential') {
            // print('Error occurred while accessing credentials. Try again.');
          }
        } catch (e) {
          // print(e);
        }
      }
    }

    return user;
  }

  /// For signing out of their Google account
  void signOutGoogle() async {
    if (kIsWeb) {
      await FirebaseAuth.instance.signOut();
      // print("User signed out of Google account for web");
    } else {
      await googleSignIn.signOut();
      // print("User signed out of Google account");
    }
  }

}
