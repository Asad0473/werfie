import 'dart:convert';

import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/login_screen.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/screens/re_new_password.dart';
import 'package:werfieapp/screens/reset_password_screen.dart';
import 'package:werfieapp/web_views/web_guest_user/web_guest_user_main.dart';
import 'package:werfieapp/web_views/web_main_screen.dart';

import '../screens/Forget_password_verification_screen.dart';
import '../screens/other_users_profile.dart';
import '../screens/post_detail.dart';
import 'metaTags/MetaTags.dart';
import 'metaTags/MetaTagsValues.dart';

class FluroRouters {
  static const sessionScreen = 'sessionScreen';
  static const loginScreen = 'login';
  static const root = '/';
  static const rootWN = '/?wntoken';
  static const mainScreen = '/home';
  static const otherUserScreen = '/otherUserScreen';
  static const userProfileScreen = '/profile';
  static const resetPasswordScreen = '/resetPassword';
  static const werfDetailScreen = '/werfDetail';
  static const newPasswordScreen = '/newPassword';

  static const passwordVerificationScreen = '/passwordVerification';

  static const guestUserMainScreen = '/guestUserScreen';

  static FluroRouter router = FluroRouter();

  static addNewsFeedMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleHome,
        metaTagDescription: MetaTagValues.newsFeedMetaDescription,
        metaTagKeywords: MetaTagValues.newsFeedMetaKeywords,
        ogTitle: MetaTagValues.newsFeedOGTitle,
        ogDescription: MetaTagValues.newsFeedOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }
  static addLoginSignUpMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.signUpAndLoginPageTitle,
        metaTagDescription: MetaTagValues.signUpAndLoginMetaDescription,
        metaTagKeywords: MetaTagValues.signUpAndLoginMetaKeywords,
        ogTitle: MetaTagValues.signUpAndLoginOGTitle,
        ogDescription: MetaTagValues.signUpAndLoginMetaDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  // static Handler _sessionHandler = Handler(handlerFunc: (BuildContext context, Map<String, dynamic> params) => Session());
  static Handler _loginHandler = Handler(
      handlerFunc: (BuildContext context, Map<String, dynamic> params) =>
          LoginScreen());

  static Handler _mainHandlerWN =
  Handler(handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    print("MAIN HANDLER FLURO ROUTE");
    // print(params);
    // print("WN KEY");
    // print(params['wntoken'][0]);
    // print("POSH ID");
    // print(params['poshid'][0]);

    return prefs == null || prefs.getString("token") == null
        ? GuestUserMainScreen(isFromPosh:true,poshID: params != null  && params.isNotEmpty ? params['poshid'][0].toString() : "",WNToken: params != null && params.isNotEmpty  ?params['wntoken'][0].toString() : "",)
        : MainScreen(isFromPosh:true,poshID: params != null && params.isNotEmpty ? params['poshid'][0].toString() : "",WNToken: params != null && params.isNotEmpty ? params['wntoken'][0].toString() :"" );
  });

  static Handler _mainHandler =
      Handler(handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    // print("handlerss1");
        prefs == null || prefs.getString("token") == null
            ? addLoginSignUpMetaTags()
            : addNewsFeedMetaTags();
    return prefs == null || prefs.getString("token") == null
        ? GuestUserMainScreen()
        : MainScreen();
  });
  static Handler _mainHandler2 =
      Handler(handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    // print("handlerss2" + params['page'][0].toString());
    /*    NewsfeedController controller;
        if (Get.isRegistered<NewsfeedController>()) {
          controller = Get.find<NewsfeedController>();
        } else {
          controller = Get.put(NewsfeedController());
        }*/
    return prefs == null || prefs.getString("token") == null
        ? GuestUserMainScreen()
        /*   : MainScreen(
            page: params['page'][0],

        );*/
        : GetBuilder<NewsfeedController>(builder: (controller) {
            return WebMainScreen(
              page: params['page'][0],
              controller: controller,
            );
          });
  });

  static Handler _mainHandler3 =
      Handler(handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    // print("handlerss3" + jsonEncode(params));

    return prefs == null || prefs.getString("token") == null
        ? GuestUserMainScreen()
        : MainScreen(
            page: params['page'][0],
            postId: params['postId'][0],
            params: params,
          );
    /* :WebMainScreen(
        page: params['page'][0],
        params: params,
        controller: controller,
        );*/
    // GetBuilder<NewsfeedController>(
    //         builder:(controller){ return

    // });
  });
  static Handler _userProfileHandler =
      Handler(handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    NewsfeedController controller;
    if (Get.isRegistered<NewsfeedController>()) {
      controller = Get.find<NewsfeedController>();
    } else {
      controller = Get.put(NewsfeedController());
    }
    return prefs == null || prefs.getString("token") == null
        ? GuestUserMainScreen()
        : MainScreen(
            page: params['page'][0],
            postId: params['postId'][0],
          );
  });
  static Handler _resetPasswordHandler = Handler(
      handlerFunc: (BuildContext context, Map<String, dynamic> params) =>
          ResetPasswordScreen());
  static Handler _passwordVerificationHandler = Handler(
      handlerFunc: (BuildContext context, Map<String, dynamic> params) =>
          ForgetPasswordVerification());

  static Handler _newPasswordHandler = Handler(
      handlerFunc: (BuildContext context, Map<String, dynamic> params) =>
          NewPasswordScreen());
  static Handler _guestUserMainScreen = Handler(
      handlerFunc: (BuildContext context, Map<String, dynamic> params) =>
          GuestUserMainScreen());
  static Handler _homeHandler = Handler(
      handlerFunc: (BuildContext context, Map<String, dynamic> params) =>
          OtherUsersProfile(
            controller: params['controller'][0],
            userInfo: params['user_info'][0],
          ));
  static Handler _werfDetailHandler =
      Handler(handlerFunc: (BuildContext context, Map<String, dynamic> params) {
    int postId = int.parse(params['postId'][0]);

    // print("post id is " + params['postId'][0]);
    NewsfeedController controller;
    if (Get.isRegistered<NewsfeedController>()) {
      controller = Get.find<NewsfeedController>();
    } else {
      controller = Get.find<NewsfeedController>();
    }
    return PostDetail(
      controller: controller,
      // post: controller.postDetail,
    );
    /*        CommentsScreen(
postId: postId,
          );*/
  });
  static SharedPreferences prefs;

  // static NewsfeedController controller;
  static Future<void> getSharePreference() async {
    prefs = await SharedPreferences.getInstance();
    // print('the token is ${prefs.getString("token")} and pref is ${prefs} ');

    /* if (Get.isRegistered<NewsfeedController>()) {
      controller = Get.find<NewsfeedController>();
    } else {
      controller = await Get.put(NewsfeedController());
    }*/
  }

  static void setupRouter() {
    getSharePreference();

    router.notFoundHandler = Handler(
        handlerFunc: (BuildContext context, Map<String, List<String>> params) {
       print("ROUTE WAS NOT FOUND !!!");
      return;
    });


    //router.define(rootWN, handler:_mainHandlerWN);

    router.define(
      root,
      handler: _mainHandler,
      transitionType: TransitionType.fadeIn,
    );
    router.define(
      mainScreen,
      handler: _mainHandler,
      transitionType: TransitionType.fadeIn,
    );
    /* router.define(
      mainScreen,
      handler: _mainHandler3,
      transitionType: TransitionType.fadeIn,
    );*/
    /* router.define('${root}/:page',
      handler: _mainHandler2,
      transitionType: TransitionType.fadeIn,
    );*/


    router.define(
      '${mainScreen}/:page',
      handler: _mainHandler2,
      transitionType: TransitionType.fadeIn,
    );
    router.define(
      '${mainScreen}/:page/:postId',
      handler: _mainHandler3,
      transitionType: TransitionType.fadeIn,
    );
    router.define(
      loginScreen,
      handler: _loginHandler,
      transitionType: TransitionType.fadeIn,
    );

    router.define(
      // mainScreen + "?page=/:page&postId=/:postId",
      mainScreen + "/page/:search",
      handler: _mainHandler3,
      transitionType: TransitionType.fadeIn,
    );
    /*router.define(
      mainScreen + "?page=/:page",
      handler: _mainHandler2,
      transitionType: TransitionType.fadeIn,
    );*/
    router.define(
      '${otherUserScreen}/:controller/:user_info',
      handler: _homeHandler,
      transitionType: TransitionType.fadeIn,
    );
    router.define(
      '${userProfileScreen}/:profileId',
      handler: _userProfileHandler,
      transitionType: TransitionType.fadeIn,
    );
    router.define(
      resetPasswordScreen,
      handler: _resetPasswordHandler,
      transitionType: TransitionType.fadeIn,
    );

    router.define(
      passwordVerificationScreen,
      handler: _passwordVerificationHandler,
      transitionType: TransitionType.fadeIn,
    );

    router.define(
      guestUserMainScreen,
      handler: _guestUserMainScreen,
      transitionType: TransitionType.fadeIn,
    );
    router.define(
      newPasswordScreen,
      handler: _newPasswordHandler,
      transitionType: TransitionType.fadeIn,
    );

    router.define(
      werfDetailScreen + "/:postId",
      handler: _werfDetailHandler,
      transitionType: TransitionType.fadeIn,
    );

    router.define(
      '${root}:?wntoken',
      handler: _mainHandlerWN,
      transitionType: TransitionType.fadeIn,
    );
  }

  static generateDetailRouterPath({String page = "", String id = ""}) =>
      page.isEmpty ? '$mainScreen' : '$mainScreen?page=$page&postId=$id';
// static generateSideNavPath({String page=""}) => page.isEmpty ?'$root':'$mainScreen?page=$page';


}
