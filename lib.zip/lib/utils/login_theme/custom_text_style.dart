import 'package:flutter/material.dart';
import 'package:werfieapp/utils/login_theme/theme_helper.dart';

class CustomTextStyles {
  // Headline text style
  static get headlineMediumPoppinsSecondaryContainer =>
      theme.textTheme.headlineMedium.poppins.copyWith(
        color: theme.colorScheme.secondaryContainer,
        fontSize: 27,
          fontFamily: 'Poppins'
      );
  // Title text style
  static get titleLargeGilroySecondaryContainer =>
      theme.textTheme.titleLarge.gilroy.copyWith(
        color: theme.colorScheme.secondaryContainer,
      );
  static get titleLargeff4461f2 => theme.textTheme.titleLarge.copyWith(
        color: Color(0XFF4461F2),
      );
  static get titleMediumSecondaryContainer =>
      theme.textTheme.titleMedium.copyWith(
        color: theme.colorScheme.secondaryContainer,
        fontSize: 17,
        fontWeight: FontWeight.w400,
        fontFamily: 'Poppins'
      );
}

extension on TextStyle {
  TextStyle get inter {
    return copyWith(
      fontFamily: 'Inter',
    );
  }

  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
  }

  TextStyle get gilroy {
    return copyWith(
      fontFamily: 'Gilroy',
    );
  }
}
