import 'dart:async';
import 'dart:io';
import 'dart:ui';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:g_recaptcha_v3/g_recaptcha_v3.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_strategy/url_strategy.dart';
import 'package:werfieapp/network/controller/account_lockout_controller.dart';
import 'package:werfieapp/network/controller/signup_controller.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/services/captcha_service.dart';
import 'package:werfieapp/utils/metaTags/MetaTags.dart';
import 'package:werfieapp/utils/fluro_router.dart';
import 'package:werfieapp/utils/font.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/video_call/utilities/video_call_utilities.dart';

 import 'helper/world_noor_helper/MethodChannelWorldNoor.dart';
import 'network/controller/login_controller.dart';
import 'notification/app_notification.dart';
//import 'dart:html' as html;
//import 'dart:ui' as ui;


/// Define a top-level named handler which background/terminated messages will
/// call.
///
/// To verify things are working, check out the native platform logs.
RxInt notifi = 0.obs;
RxInt messageNotifications = 0.obs;
final _navKey = GlobalKey<NavigatorState>();
final GlobalKey<NavigatorState> mainNavigatorKey = GlobalKey<NavigatorState>();

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  print('_firebaseMessagingBackgroundHandler: notification Recieved : $message}');
  // FirebaseNotifications.instance.initLocalNotification();
  // return;
  // Fluttertoast.showToast(msg: "Background Message: $message");
  await Firebase.initializeApp();
  final sharedPrefs = await SharedPreferences.getInstance();
  var type = message.data['type'];
  FirebaseNotifications.instance.initLocalNotification();
  // if (!kIsWeb) VideoCallUtilities.listenCallKitEvent();
  VideoCallUtilities().checkVideoCall(message);
  if (type == 'new_message') {
    if (sharedPrefs.containsKey('messageCount')) {
      messageNotifications.value = await sharedPrefs.getInt('messageCount');
      messageNotifications.value++;
      await sharedPrefs.setInt('messageCount', messageNotifications.value);
    } else {
      messageNotifications.value = 1;
      await sharedPrefs.setInt('messageCount', messageNotifications.value);
    }
  } else {
    notifi.value++;
    notifi.refresh();
  }
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.
  // await Firebase.initializeApp();
  // print('Handling a background message ${message.messageId}');
}

Future<void> main() async {
  HttpOverrides.global = new MyHttpOverrides();
  await GetStorage.init();
  WidgetsFlutterBinding.ensureInitialized();

  // if(!kIsWeb) {
  //   // await Permission.camera.request();
  //   // await Permission.microphone.request();
  //   // await Permission.speech.request();
  // }
  //
  MetaTags().initMetaTags();
  if (kIsWeb) {
    await Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: "AIzaSyC0lIkjxgGAoMTQFPQTnv6pSbaDKjkwN18",
          authDomain: "buzznbee.firebaseapp.com",
          projectId: "buzznbee",
          storageBucket: "buzznbee.appspot.com",
          messagingSenderId: "160115881618",
          appId: "1:160115881618:web:5cd18e4fe28a911383184b",
          measurementId: "G-8KBVF6067E"),
    );
if(kIsWeb){
  await RecaptchaService.initiate();

}




  }else {
    await Firebase.initializeApp();
  }
  FirebaseNotifications.instance.takeFCMTokenWhenAppLaunch();

  /// firebase
  //final PendingDynamicLinkData initialLink = await FirebaseDynamicLinks.instance.getInitialLink();

  //await Firebase.initializeApp();
  FirebaseNotifications.instance.initLocalNotification();
  // FirebaseNotifications.instance.takeFCMTokenWhenAppLaunch();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  if (!kIsWeb) {
    // VideoCallUtilities.listenCallKitEvent();
    MobileAds.instance.initialize();
  }
  /*final SharedPreferences prefs = await SharedPreferences.getInstance();
   isLoggedIn = (prefs.getString('token') == null) ? false : true;*/

  // FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

//FirebaseMessaging.instance.getInitialMessage();

  /* await flutterLocalNotificationsPlugin.initialize(initializationSettings,
      onSelectNotification: _selectNotification);*/

  ///origin here
  /* if (!kIsWeb) {
    channel = const AndroidNotificationChannel(
      'high_importance_channel', // id
      'High Importance Notifications',
      // title
      // 'This channel is used for important notifications.', // description
      importance: Importance.high,
    );
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    /// Create an Android Notification Channel.
    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    /// Update the iOS foreground notification presentation options to allow
    /// heads up notifications.
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }*/

  /// origin end
  /* await flutterLocalNotificationsPlugin.initialize(initializationSettings,
      onDidReceiveNotificationResponse: onDidReceiveNotificationResponse);*/
  /*final DarwinInitializationSettings initializationSettingsDarwin =
  DarwinInitializationSettings(
      onDidReceiveLocalNotification: onDidReceiveLocalNotification);*/
/*
  await flutterLocalNotificationsPlugin.initialize(

onDidReceiveNotificationResponse:onDidReceiveNotificationResponse
  );
*/

  handleClickNotification(String payload) {
    //your code
  }

  ///origin code start
/*  FirebaseMessaging messaging = FirebaseMessaging.instance;

  NotificationSettings settings = await messaging.requestPermission(
    alert: true,
    announcement: false,
    badge: true,
    carPlay: false,
    criticalAlert: false,
    provisional: false,
    sound: true,
  );*/

  /// origin code end
  // print('User granted permission: ${settings.authorizationStatus}');
  setPathUrlStrategy();
  FluroRouters.setupRouter();

  // Get any initial links
  if(!kIsWeb) {
    if (Platform.isAndroid) {
      MethodChannelWorldNoor.instance.configureChannel();
    }
  }

  /*ui.platformViewRegistry.registerViewFactory(
    'iframe-element',
        (int viewId) => html.IFrameElement()
      ..width = '100%'
      ..height = '100%'
      ..style.border = 'none',
  );*/

  runApp(MyApp());
}

final darkTheme = ThemeData(
  primarySwatch: Colors.grey,
  primaryColor: Colors.black,
  brightness: Brightness.dark,
  backgroundColor: const Color(0xFF212121),
  // accentColor: Colors.white,
  // accentIconTheme: IconThemeData(color: Colors.black),
  dividerColor: Colors.black12,
  highlightColor: Colors.white,
  scrollbarTheme: ScrollbarThemeData()
      .copyWith(thumbColor: MaterialStateProperty.all(Colors.white)),
);

final lightTheme = ThemeData(
    primarySwatch: Colors.grey,
    primaryColor: Colors.white,
    brightness: Brightness.light,
    backgroundColor: const Color(0xFFE5E5E5),
    // accentColor: Colors.black,
    // accentIconTheme: IconThemeData(color: Colors.white),
    dividerColor: Colors.white54,
    highlightColor: Colors.grey[400]);

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
class MyApp extends StatefulWidget {

  MyApp();

  static rebirth(BuildContext context) {
    context.findAncestorStateOfType<_MyAppState>().restartApp();
  }

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // Future<InitializationStatus> _initGoogleMobileAds() {
  //   // TODO: Initialize Google Mobile Ads SDK
  //   return MobileAds.instance.initialize();
  // }

  Key _key = UniqueKey();

  void restartApp() {
    setState(() {
      _key = UniqueKey();
    });
  }

//FirebaseDeepLink firebaseDeepLink=FirebaseDeepLink();
  // ignore: unused_field
  bool _initialized = false;

  // ignore: unused_field
  bool _error = false;
  static FirebaseAnalytics analytics = FirebaseAnalytics.instance;
  static FirebaseAnalyticsObserver observer =
  FirebaseAnalyticsObserver(analytics: analytics);

  @override
  void initState() {
    //  initializeFlutterFire();

    // print("initialized");
    super.initState();

    getSharePreference();
    _getThemeStatus();
    if (!kIsWeb) VideoCallUtilities.checkBackgroundCall();
    // FirebaseDeepLink().initDynamicLinks(context);
  }

  /// origin code  start
  /* void initializeFlutterFire() async {
    try {
      notifi.value = 0;
      FirebaseMessaging messaging = FirebaseMessaging.instance;

      String token = await messaging.getToken(
        vapidKey: "BGpdLRs......",
      );
      print("fcm token"+token);
      FirebaseMessaging.instance
          .getInitialMessage()
          .then((RemoteMessage message) {
        if (message != null) {

           message.toString();
           print(message.toString());
        }
      });


      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        print('Notification Data here' +
            message.data.toString());

        notifi.value++;
        notifi.refresh();
        print('data in notification ');
        print('notification is here');
        var jsonDataEncode=jsonEncode(message.data.toString());
        print('jason data response$jsonDataEncode');
        var jasonDecodeData =jsonDecode(jsonDataEncode);
        print('jason Decode data $jasonDecodeData');
        // var jsonResponse = jsonDecode(message.data.toString());
        // print('Notification jason response :$jsonResponse');
        // if(jsonResponse['tittle']=="Liked Buzz"){
        //   print('jasondata Notification');
        // }
*/ /*
if(message.notification.title=='Liked Buzz')
  {
    print(' with out data jasondata Notification');
   // print(int.parse(jasonDecodeData['payload']['post_id'].toString()));

  }*/ /*



        RemoteNotification notification = message.notification;
        AndroidNotification android = message.notification?.android;
        if (notification != null && android != null) {
          flutterLocalNotificationsPlugin.show(
              notification.hashCode,
              notification.title,
              notification.body,
              NotificationDetails(
                android: AndroidNotificationDetails(
                  channel.id,
                  channel.name,
                  // channel.description,
                  // ignore: todo
                  // TODO add a proper drawable resource to android, for now using
                  //      one that already exists in ogoul app.
                  icon: 'werfielogo',
                ),
              ));
        }

        FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
          print ( 'app is open ');
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (BuildContext context) => NewsFeedMobile()));

        });
      });

      setState(() {
        _initialized = true;
      });
    } catch (e) {
      setState(() {
        _error = true;
      });
    }
  }*/

  /// origin code end
// use the returned token to send messages to users from your custom server
//   GetStorage localStor = GetStorage();
  SharedPreferences prefs;

  Future<void> getSharePreference() async {
    prefs = await SharedPreferences.getInstance();
    //print('the token is ${prefs.getString("token")} and pref is ${prefs} ');
  }

  _getThemeStatus() async {
    GetStorage getStorage = GetStorage();
    bool isDarkTheme = await getStorage.read("mode");
    // mode will be null when there is no theme is selected.
    if (isDarkTheme != null) {
      Get.changeThemeMode(isDarkTheme ? ThemeMode.dark : ThemeMode.light);
    }
  }

  @override
  Widget build(BuildContext context) {
    // print("local data" + localStor.read("mode").toString());
    getSharePreference();
    // retrieveDynamicLink(context);
    return KeyedSubtree(
      key: _key,
      child: !kIsWeb
          ? GetMaterialApp(
              navigatorKey: navigatorKey,
              navigatorObservers: <NavigatorObserver>[observer],
              builder: (BuildContext context, Widget child) {
                final mediaQueryData = MediaQuery.of(context);
                final scale = mediaQueryData.textScaleFactor.clamp(1.0, 1.5);

                return MediaQuery(
                  data: MediaQuery.of(context).copyWith(textScaleFactor: scale),
                  child: child,
                );
              },
              shortcuts: <LogicalKeySet, Intent>{
                LogicalKeySet(LogicalKeyboardKey.space): ActivateIntent(),
                LogicalKeySet(LogicalKeyboardKey.escape): const ClearIntent(),
              },
              title: 'Home / Werfie',

              translations: Strings(),
              fallbackLocale: Locale('en'),
              debugShowCheckedModeBanner: false,
              // theme: ThemeData(
              //   scaffoldBackgroundColor: Color.fromARGB(255, 255, 255, 255),
              //   primaryColor: Color(0xFF0157d3),
              //   fontFamily: 'OpenSans',
              //   textTheme: TextTheme(
              //     bodyText2: TextStyle(
              //       fontSize: 14,
              //       color: Color(0xFF626c72),
              //     ),
              //     bodyText1: TextStyle(
              //       fontSize: 15,
              //       color: Color(0xFF4f515b),
              //     ),
              //     headline3: TextStyle(
              //       fontSize: 15,
              //       color: Color(0xFF4f515b),
              //       fontWeight: FontWeight.bold,
              //     ),
              //     headline5: TextStyle(
              //       fontSize: 36,
              //       fontWeight: FontWeight.w900,
              //       color: Color(0xFF4f515b),
              //     ),
              //     headline4: TextStyle(
              //       fontSize: 28,
              //       fontWeight: FontWeight.w600,
              //       color: Color(0xFF4f515b),
              //     ),
              //     headline6: TextStyle(
              //       fontSize: 20,
              //       fontWeight: FontWeight.w400,
              //       color: Color(0xFF4f515b),
              //     ),
              //   ),
              //   iconTheme: IconThemeData(
              //     color: Color(0xFFedab30),
              //   ),
              //   colorScheme: ColorScheme.fromSwatch()
              //       .copyWith(secondary: Color(0xFFedab30)),
              // ),

              // getPages: AppRoute.navMain,
              home: Session(),
              theme: LightStyles.appTheme,
              darkTheme: Styles.appTheme,
              themeMode: ThemeMode.light,
        initialBinding: InitialBinding(),

        //ThemeMode.system,
              //       darkTheme: darkTheme,
              //       theme: localStor.read("mode") == null
              //           ? LightStyles.appTheme
              //           : localStor.read("mode")
              //               ? Styles.appTheme
              //               : LightStyles.appTheme,
              //
              //       // lightTheme,
              //       themeMode: localStor.read("mode") == null
              //           ? ThemeMode.light
              //           : localStor.read("mode")
              //               ? ThemeMode.dark
              //               : ThemeMode.light,
              // initialRoute: AppRoute.routeMain,
              // onUnknownRoute: (RouteSettings setting) {
              //   String unknownRoute = setting.name ;
              //   return new MaterialPageRoute(
              //       builder: (context) => Session()
              //   );
              // }
              // routes: {
              //   AppRoute.mobileCommentRoute: (context) => CommentsScreen(),
              //   AppRoute.loginScreen: (context) => LoginScreen(),
              //   AppRoute.postScreen: (context) { return SearchScreen();},
              // },
              // home: Session(),
            )
          : GetMaterialApp(
              navigatorKey: mainNavigatorKey,
              navigatorObservers: <NavigatorObserver>[observer],
        // theme: ThemeData(
              //   //main color
              //     primaryColor: const Color(0xffFFC600),
              //     //main font
              //     fontFamily: 'Roboto-Medium',
              //     //swatch stretching
              //     visualDensity: VisualDensity.adaptivePlatformDensity,
              //
              //     splashColor:  const Color(0xffFFC600),
              //
              //     //color for scrollbar
              //     highlightColor: Color(0xffffc600),
              //
              // ),
              scrollBehavior: MyCustomScrollBehavior(),
              builder: (BuildContext context, Widget child) {
                final mediaQueryData = MediaQuery.of(context);
                final scale = mediaQueryData.textScaleFactor.clamp(1.0, 1.5);

                return MediaQuery(
                  data: MediaQuery.of(context).copyWith(textScaleFactor: scale),
                  child: child,
                );
              },
              shortcuts: <LogicalKeySet, Intent>{
                LogicalKeySet(LogicalKeyboardKey.space): ActivateIntent(),
                LogicalKeySet(LogicalKeyboardKey.escape): const ClearIntent(),
              },
              title: 'Home / Werfie',
              translations: Strings(),
              fallbackLocale: Locale('en'),
              debugShowCheckedModeBanner: false,
              initialBinding: InitialBinding(),

        // theme: ThemeData(
              //   scaffoldBackgroundColor: Color.fromARGB(255, 255, 255, 255),
              //   primaryColor: Color(0xFF0157d3),
              //   fontFamily: 'OpenSans',
              //   textTheme: TextTheme(
              //     bodyText2: TextStyle(
              //       fontSize: 14,
              //       color: Color(0xFF626c72),
              //     ),
              //     bodyText1: TextStyle(
              //       fontSize: 16,
              //       color: Color(0xFF4f515b),
              //     ),
              //     headline3: TextStyle(
              //       fontSize: 16,
              //       color: Color(0xFF4f515b),
              //       fontWeight: FontWeight.bold,
              //     ),
              //     headline5: TextStyle(
              //       fontSize: 36,
              //       fontWeight: FontWeight.w900,
              //       color: Color(0xFF4f515b),
              //     ),
              //     headline4: TextStyle(
              //       fontSize: 28,
              //       fontWeight: FontWeight.w600,
              //       color: Color(0xFF4f515b),
              //     ),
              //     headline6: TextStyle(
              //       fontSize: 20,
              //       fontWeight: FontWeight.w400,
              //       color: Color(0xFF4f515b),
              //     ),
              //   ),
              //   iconTheme: IconThemeData(
              //     color: Color(0xFFedab30),
              //   ),
              //   colorScheme: ColorScheme.fromSwatch()
              //       .copyWith(secondary: Color(0xFFedab30)),
              // ),

// themeMode:  ThemeMode.dark,
// darkTheme:  ThemeData.dark(),
//         theme: localStor.read("mode")==null?ThemeData(
//           primarySwatch: Colors.grey,
//           primaryColor: Colors.white,
//
//           scaffoldBackgroundColor: Colors.white,
//           brightness: Brightness.light,
//           backgroundColor: const Color(0xFFE5E5E5),
//           accentColor: Colors.black,
//           accentIconTheme: IconThemeData(color: Colors.white),
//           dividerColor: Colors.white54,
//         ):localStor.read("mode")?
//         ThemeData(
//           primarySwatch: Colors.grey,
//           primaryColor: Colors.black,
//
//           scaffoldBackgroundColor: Colors.black,
//           brightness: Brightness.dark,
//           backgroundColor: const Color(0xFF212121),
//           accentColor: Colors.white,
//           accentIconTheme: IconThemeData(color: Colors.black),
//           dividerColor: Colors.black12,
//         ):ThemeData(
//           scaffoldBackgroundColor: Colors.white,
//           primarySwatch: Colors.grey,
//           primaryColor: Colors.white,
//           brightness: Brightness.light,
//           backgroundColor: const Color(0xFFE5E5E5),
//           accentColor: Colors.black,
//           accentIconTheme: IconThemeData(color: Colors.white),
//           dividerColor: Colors.white54,
//         ),
//
//               theme: localStor.read("mode") == null
//                   ? LightStyles.appTheme
//                   : localStor.read("mode")
//                       ? Styles.appTheme
//                       : LightStyles.appTheme,
              theme: LightStyles.appTheme,
              darkTheme: Styles.appTheme,
              themeMode: ThemeMode.light,
              //ThemeMode.system,
//         theme: _lightTheme,
              // darkTheme: _darkTheme,
              // themeMode: ThemeMode.system,

              // getPages: AppRoute.navMain,
              /*     routerDelegate: RoutemasterDelegate(routesBuilder: (_) => routes),
            routeInformationParser: RoutemasterParser(),*/
              /*   routeInformationProvider: AppRoute.returnRouter(prefs).routeInformationProvider,
      routeInformationParser: AppRoute.returnRouter(prefs).routeInformationParser,
      routerDelegate: AppRoute.returnRouter(prefs).routerDelegate,*/
              // Initial Page set to Login Page
              // initialRoute: prefs == null || prefs.getString("token") == null
              //     ? FluroRouters.loginScreen
              //     : FluroRouters.root,
              // Use the generator provided by Fluro package
              // initialRoute: FluroRouters.root,
              onGenerateRoute: FluroRouters.router.generator,
              // initialRoute: prefs == null || prefs.getString("token") == null ? FluroRouters.loginScreen:FluroRouters.root,
              // initialRoute: FluroRouters.sessionScreen,
              // home: Session(),
              //onGenerateRoute: FluroRouters.router.generator

              // initialRoute: AppRoute.routeMain,
              // onUnknownRoute: (RouteSettings setting) {
              //   String unknownRoute = setting.name ;
              //   return new MaterialPageRoute(
              //       builder: (context) => Session()
              //   );
              // }
              // routes: {
              //   AppRoute.mobileCommentRoute: (context) => CommentsScreen(),
              //   AppRoute.loginScreen: (context) => LoginScreen(),
              //   AppRoute.postScreen: (context) { return SearchScreen();},
              // },
              // home: Session(),
            ),
    );
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

/*final routes = RouteMap(
  routes: {
    // AppRoute.routeMain: (_) => CupertinoTabPage(
    //   child: HomePage(),
    //   paths: ['feed', 'settings'],
    // ),
    AppRoute.routeMain: (_) => MaterialPage(child: Session(), arguments: {
          "postId": Get.parameters['postId'],
          "profileId": Get.parameters['profileId'],
        }),
    AppRoute.postScreen: (_) => MaterialPage(
            child: Session(
          postId: Get.parameters['postId'],
          profileId: null,
        )),
    AppRoute.profileScreen: (_) => MaterialPage(
            child: Session(
          postId: null,
          profileId: Get.parameters['profileId'],
        )),
    // AppRoute.mobileCommentRoute: (_) => MaterialPage(child: CommentsScreen()),
    AppRoute.loginScreen: (_) => MaterialPage(
            child: LoginScreen(
          postId: null,
          profileId: null,
        )),
    AppRoute.mainScreen: (_) => MaterialPage(child: MainScreen()),
    AppRoute.resetPasswordScreen: (_) =>
        MaterialPage(child: ResetPasswordScreen()),
    AppRoute.guestUserMainScreen: (_) =>
        MaterialPage(child: GuestUserMainScreen()),
    AppRoute.newPasswordScreen: (_) => MaterialPage(child: NewPasswordScreen()),
  },
  onUnknownRoute: (_) => MaterialPage(child: Session()),
);*/

class MyCustomScrollBehavior extends MaterialScrollBehavior {
  // Override behavior methods and getters like dragDevices
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
      };
}

class InitialBinding implements Bindings {
  @override
  void dependencies() {
    Get.put(LoginController());
    Get.put(SignupController());// Register LoginController
    Get.put(AccountLockoutController());// Register LoginController
  }
}

class ClearIntent extends Intent {
  const ClearIntent();
}
