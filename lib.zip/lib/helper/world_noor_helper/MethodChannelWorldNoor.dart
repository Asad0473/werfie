import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/main.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/services/navigation_service.dart';

import '../../network/controller/browse_controller.dart';
import '../../network/controller/login_controller.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../network/controller/notification_controller.dart';
import '../../network/controller/profile_controller.dart';
import '../../network/singleTone.dart';
import '../../screens/login_screen.dart';
import '../../utils/fluro_router.dart';
import '../../utils/loading_dialog_builder.dart';
import '../../utils/urls.dart';
import '../../utils/utils_methods.dart';

class MethodChannelWorldNoor {
  static const channelName = 'CHANNEL_READ_DATA_FROM_WORLD_NOOR'; // this channel name needs to match the one in Native method channel
  MethodChannel methodChannel;
  SharedPreferences sharedPrefs;
  final storage = GetStorage();
  LoginController controller;


  static final MethodChannelWorldNoor instance = MethodChannelWorldNoor._init();
  MethodChannelWorldNoor._init();

  Future<void> configureChannel() {
    methodChannel = MethodChannel(channelName);
    methodChannel.setMethodCallHandler(this.methodHandler);

  }

  Future<void> methodHandler(MethodCall call) async {
    final String idea = call.arguments;

    switch (call.method) {
      case "loginWithWorldNoor": // this method name needs to be the same from invokeMethod in Android
        //print("<============== METHOD CALLED FROM NATIVE ANDROID ================>");
        //print(call.arguments);// you can handle the data here. In this example, we will simply update the view via a data service
        Map<String, dynamic> map = json.decode(call.arguments);
        checkIsUserLoggedIn(map);
        break;
      default:
        print('no method handler for method ${call.method}');
    }
  }

  checkIsUserLoggedIn(Map<String, dynamic> map) async {
    //print("<========= SHARED PREF =============>");
    sharedPrefs = await SharedPreferences.getInstance();
    controller = Get.find<LoginController>();
    //print(sharedPrefs.getString("token"));
    //print(Get.context);


    if (sharedPrefs.getString("token") != null){

      print("<=========== FLUTTER METHOD CHANNEL CLASS ==============>");
      print(map);
      print("<======================USER EMAIL AND NAME===============>");
      print(sharedPrefs.getString("userName") );
      print(storage.read("email"));

      if(sharedPrefs.getString("userName") != map['email'] && (storage.read("email") as String ?? "") != map['email'])
        showDialogLoginWithPosh( Get.context,map["name"],map["profilePic"],map["isAutoLogin"]);
    }else{

      socialLoginWithPosh(map,Get.context);

    }

  }

  showDialogLoginWithPosh(BuildContext context,String poshName, String profilePicUrl,bool isAutoLogin){
    showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Login with Worldnoor', style: TextStyle(fontSize: 18,color: Colors.black,fontWeight: FontWeight.bold),),
          content: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(35),
                child: FadeInImage(
                  fit: BoxFit.cover,
                  width: 50,
                  height: 50,
                  placeholder: AssetImage(
                      'assets/images/person_placeholder.png'),
                  image: NetworkImage(profilePicUrl !=
                      null
                      ? profilePicUrl
                      : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Expanded(child: RichText(
                text: TextSpan(
                  text: 'You are currently logged in with ',
                  style: TextStyle(fontSize: 14,color: Colors.black),
                  children: <TextSpan>[
                    TextSpan(text: sharedPrefs.getString("userName"), style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16)),
                    TextSpan(text: ". Do you want to stay logged in with this account or switch to WorldNoor Account ",style: TextStyle(fontSize: 14),),
                    TextSpan(text: poshName, style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16)),
                    TextSpan(text: " ?",style: TextStyle(fontSize: 14),),

                  ],
                ),
              )),
              //Expanded(child: Text('You are currently logged in with ${userName} account. Do you want to stay logged in with this account or switch to WorldNoor Account :  $poshName?')),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                // Close the dialog
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();

                SharedPreferences preferences =
                await SharedPreferences.getInstance();
                if (preferences.getBool('socialLogin') == true) {
                  print('social logout');
                  UtilsMethods utils = UtilsMethods();
                  utils.signOutGoogle();

                  await preferences.clear();
                  await preferences.remove("userName");
                  await preferences.remove("id");
                  await Get.find<NewsfeedController>().storage.erase();

                  Get.delete<SessionController>();
                  Get.delete<NewsfeedController>();
                  Get.delete<ProfileController>();
                  Get.delete<BrowseController>();
                  Get.delete<NotificationController>();
                  preferences.setBool('guestUser', true);
                  SingleTone.instance.socialLogin = false;

                  Get.offUntil(
                      MaterialPageRoute(
                          builder: (context) => LoginScreen(isFromWorldNoorApp: 1,isAutoLogin: isAutoLogin,)),
                          (route) => false);

                } else {
                  print('else logout');

                  await preferences.clear();
                  await preferences.remove("userName");
                  await preferences.remove("id");
                  await Get.find<NewsfeedController>().storage.erase();

                  Get.delete<SessionController>();
                  Get.delete<NewsfeedController>();
                  Get.delete<ProfileController>();
                  Get.delete<BrowseController>();
                  Get.delete<NotificationController>();

                  preferences.setBool('guestUser', true);
                  SingleTone.instance.socialLogin = false;

                  Get.offUntil(
                      MaterialPageRoute(
                          builder: (context) => LoginScreen(isFromWorldNoorApp: 1,isAutoLogin: isAutoLogin,)),
                          (route) => false);

                }


              },
              child: Text('Login with Worldnoor'),
            ),
          ],
        );
      },
    );
  }

  socialLoginWithPosh(Map<String, dynamic> map, BuildContext context) async {
    var response;

    try {
      DialogBuilder(context).showLoadingIndicator();
      response = await controller.SocialLogin(queryParameters: {
        "login_type": 'posh',
        "social_id": map["poshId"],
        "wntoken": map["token"]
      }, token: {
        "Authorization": " Bearer ${Url.webAPIKey}"
      });
      var jsonResponse = jsonDecode(response.toString());
      // print("jsonResponse $jsonResponse");
      // storage.write("email", value.email.toString());
      // shared.setString("email", value.email.toString());

      var responseCode = jsonResponse['meta']['code'];
      var userName = jsonResponse['data']['username'];
      var token = jsonResponse['data']['token'];
      var userId = jsonResponse['data']['id'];
      var email = jsonResponse['data']['email'];
      if (responseCode == 200) {
        storage.write("email", email.toString());

        sharedPrefs.setString("token", token.toString());
        sharedPrefs.setString("userName", userName.toString());
        storage.write('id', userId);
        storage.write("token", token.toString());
        sharedPrefs.setBool('guestUser', true);
        sharedPrefs.setBool('socialLogin', true);
        storage.write("userName", userName.toString());

        storage.write("remember", false);

        controller.generateFCMToken(context);
        controller.updateInitialWelcomeMsg(true);

        if (Get.isRegistered<NewsfeedController>()) {
          Get.delete<NewsfeedController>();

          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
            controller.profileId != null ? controller.profileId : null,
          ));
        } else {
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
            controller.profileId != null ? controller.profileId : null,
          ));
        }

        Get.find<NewsfeedController>().languageData =
        await Get.find<NewsfeedController>().getLanguages();
        Get.find<NewsfeedController>().selectedAppLanguageInfoId =
            Get.find<NewsfeedController>().languageData.appLang.id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>().languageData.appLang.code);
        Get.find<NewsfeedController>().update();
        {
            {
            SingleTone.instance.socialLogin = true;
            Get.back();
            DialogBuilder(context).hideOpenDialog();

            Get.offAll(
                MainScreen(
                  isLoggedInFromPosh: true,
                ),
                arguments: {
                  "userName": sharedPrefs.getString("userName"),
                  "postId":
                  controller.postId != null ? controller.postId : null,
                  "profileId":
                  controller.profileId != null ? controller.profileId : null
                });
          }
        }
      } else {
        Fluttertoast.showToast(
          msg: jsonResponse['meta']['message'].toString(),
          toastLength: Toast.LENGTH_SHORT,
          // or Toast.LENGTH_LONG
          gravity: ToastGravity.BOTTOM,
          // Location of the toast message
          timeInSecForIosWeb: 1,
          // Time duration for which the message will be displayed
          backgroundColor: Colors.grey,
          textColor: Colors.white,
          fontSize: 16.0,
        );
        DialogBuilder(context).hideOpenDialog();
      }
    } catch (e) {
      print("EXCEPTION SOCIAL LOGIN WITH POSH MOBILE");
      Fluttertoast.showToast(
        msg: "Sorry for the inconvenience. Please try again later.",
        toastLength: Toast.LENGTH_SHORT,
        // or Toast.LENGTH_LONG
        gravity: ToastGravity.BOTTOM,
        // Location of the toast message
        timeInSecForIosWeb: 1,
        // Time duration for which the message will be displayed
        backgroundColor: Colors.grey,
        textColor: Colors.white,
        fontSize: 16.0,
      );
      DialogBuilder(context).hideOpenDialog();
    }

    // }
  }



}