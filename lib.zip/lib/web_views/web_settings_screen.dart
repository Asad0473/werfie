import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/language_settings.dart';
import 'package:werfieapp/screens/privacy_and_safety/direct_messages/direct_messages_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/location_information/location_information_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/location_information/see_places_you_have_been_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/mute_and_block/add_mute_word_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/mute_and_block/mobile_blocked_accounts_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/audience_and_tagging/audience_and_tagging_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/content_you_see/content_you_see_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/mute_and_block/mute_accounts_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/mute_and_block/mute_and_block_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/mute_and_block/muted_words_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/privacy_and_safety_setting_screen.dart';
import 'package:werfieapp/screens/notifications/filters_screen.dart';
import 'package:werfieapp/screens/notifications/muted_notifications.dart';
import 'package:werfieapp/screens/notifications/notification_prefrences_screen.dart';
import 'package:werfieapp/screens/notifications/push_notifications_screen.dart';
import 'package:werfieapp/screens/security_and_account_access/security_and_account_access_screen.dart';
import 'package:werfieapp/screens/security_and_account_access/security_screen.dart';
import 'package:werfieapp/screens/settings_detail_screen.dart';
import 'package:werfieapp/screens/settings_screen.dart';
import 'package:flutter/material.dart';

import '../screens/account_info_setting_screen.dart';
import '../screens/change_email_screen.dart';
import '../screens/change_password_screen.dart';
import '../screens/gender_setting_screen.dart';
import '../screens/notifications/email_notifications_screen.dart';
import '../screens/notifications/notifications_screen.dart';
import '../screens/privacy_and_safety/audience_and_tagging/photo_tagging_setting_screen.dart';
import '../screens/privacy_and_safety/your_werfs/add_location_information_to_your_werfs_setting_screen.dart';
import '../screens/privacy_and_safety/your_werfs/your_werfs_setting_screen.dart';
import '../screens/select_country_screen.dart';
import '../screens/username_setting_screen.dart';
import '../screens/web_email_setting_screen.dart';
import '../screens/your_account_screen.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';

// ignore: must_be_immutable
class WebSettingsScreen extends StatefulWidget {
  NewsfeedController controller;

  WebSettingsScreen({this.controller});

  @override
  State<WebSettingsScreen> createState() => _WebSettingsScreenState();
}

class _WebSettingsScreenState extends State<WebSettingsScreen> {
  addSettingsMetaTags(){

    MetaTags().addMetaTag(
      pageTitle: MetaTagValues.pageTitleSettings,
        metaTagDescription:MetaTagValues.settingsMetaDescription,
        metaTagKeywords: MetaTagValues.settingsMetaKeywords,
        ogTitle: MetaTagValues.settingsOGTitle,
        ogDescription: MetaTagValues.settingsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  @override
  void initState() {
    addSettingsMetaTags();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {

    return MediaQuery.of(context).size.width >= 1050
        ? Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Expanded(
                child: SettingsScreen(),
              ),
              Container(
                width: 1,
                color: Colors.grey[300],
              ),
              Expanded(
                  child: widget.controller.isLanguageType ||
                          widget.controller.isAccountPrivacySettings ||
                          widget.controller.isProfileLanguagetype
                      ? LanguageSettings()
                      : widget.controller.isListOfBlockedAccounts
                          ? MobileBlockedAccountsScreen()
                          : widget.controller.isChangeUserName
                              ? UserNameSettingScreen()
                              : widget.controller.isYourAccount
                                  ? YourAccount()
                                  : widget.controller.isAccountInformation
                                      ? accountInformationSettingScreen()
                                      : widget.controller.isChangeEmail
                                          ? WebEmailSettingScreen()
                                          : widget.controller.isChangeCountry
                                              ? selectCountrySettingScreen()
                                              : widget.controller.isSettinggender
                                                  ? GenderSettingScreen()
                                                  : widget.controller.isChangePassword
                                                      ? ChangePassword()
                                                      : widget.controller
                                                              .isNotificationsSettings
                                                          ? NotificationsScreen()
                                                          : widget.controller
                                                                  .isAccountPrivacy
                                                              ? PrivacyAndSafety()
                                                              : widget.controller
                                                                      .isAudienceTagging
                                                                  ? AudienceAndTaggingSettingScreen()
                                                                  : widget.controller
                                                                          .isPhotoTagging
                                                                      ? PhotoTaggingSettingScreen()
                                                                      : widget.controller
                                                                              .isYourWerfs
                                                                          ? YourWerfsSettingScreen()
                                                                          : widget.controller.isAddLocationInformationToYourWerfs
                                                                              ? AddLocationInformationToYourWerfsSettingScreen()
                                                                              : widget.controller.isContentYouSee
                                                                                  ? ContentYouSeeSettingScreen()
                                                                                  : widget.controller.isMuteAndBlock
                                                                                      ? MuteAndBlockSettingScreen()
                                                                                      : widget.controller.isMutedAccounts
                                                                                          ? MuteAccountsSettingScreen()
                                                                                          : widget.controller.isMuteWords
                                                                                              ? MutedWordsSettingScreen()
                                                                                              : widget.controller.isAddMuteWords
                                                                                                  ? AddMutedWordsSettingScreen()
                                                                                                  : widget.controller.isDirectMessage
                                                                                                      ? DirectMessageSettingScreen()
                                                                                                      : widget.controller.isSeePlacesYouHaveBeen
                                                                                                          ? SeePlacesYouHaveBeenSettingScreen()
                                                                                                          : widget.controller.isLocationInformation
                                                                                                              ? LocationInformationSettingScreen()
                                                                                                              : widget.controller.isNotificationsFiltersScreen
                                                                                                                  ? FiltersScreen()
                                                                                                                  : widget.controller.isMutedNotificationsScreen
                                                                                                                      ? MutedNotificationsScreen()
                                                                                                                      : widget.controller.isNotificationPreferencesScreen
                                                                                                                          ? NotificationPreferencesScreen()
                                                                                                                          : widget.controller.isPushNotificationScreen
                                                                                                                              ? PushNotificationsScreen()
                                                                                                                              : widget.controller.isEmailNotificationScreen
                                                                                                                                  ? EmailNotificationsScreen()
                                                                                                                                  : widget.controller.isSecurityAndAccountAccess
                                                                                                                                      ? SecurityAndAccountAccessScreen()
                                                                                                                                      : widget.controller.isSecurity
                                                                                                                                          ? SecurityScreen()
                                                                                                                                          : SettingsDetailScreen()),
            ],
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              widget.controller.isSettingDetail == false
                  ? SizedBox()
                  : Expanded(
                      child: SettingsScreen(),
                    ),
              Container(
                width: 1,
                color: Colors.grey[300],
              ),
              widget.controller.isSettingDetail == true
                  ? SizedBox()
                  : Expanded(
                      child: widget.controller.isLanguageType ||
                              widget.controller.isAccountPrivacySettings ||
                              widget.controller.isProfileLanguagetype
                          ? LanguageSettings()
                          : widget.controller.isListOfBlockedAccounts
                              ? MobileBlockedAccountsScreen()
                              : widget.controller.isChangeUserName
                                  ? UserNameSettingScreen()
                                  : widget.controller.isYourAccount
                                      ? YourAccount()
                                      : widget.controller.isAccountInformation
                                          ? accountInformationSettingScreen()
                                          : widget.controller.isChangeEmail
                                              ? WebEmailSettingScreen()
                                              : widget.controller.isChangeCountry
                                                  ? selectCountrySettingScreen()
                                                  : widget.controller.isSettinggender
                                                      ? GenderSettingScreen()
                                                      : widget.controller
                                                              .isChangePassword
                                                          ? ChangePassword()
                                                          : widget.controller
                                                                  .isNotificationsSettings
                                                              ? NotificationsScreen()
                                                              : widget.controller
                                                                      .isAccountPrivacy
                                                                  ? PrivacyAndSafety()
                                                                  : widget.controller
                                                                          .isAudienceTagging
                                                                      ? AudienceAndTaggingSettingScreen()
                                                                      : widget.controller
                                                                              .isPhotoTagging
                                                                          ? PhotoTaggingSettingScreen()
                                                                          : widget.controller.isYourWerfs
                                                                              ? YourWerfsSettingScreen()
                                                                              : widget.controller.isAddLocationInformationToYourWerfs
                                                                                  ? AddLocationInformationToYourWerfsSettingScreen()
                                                                                  : widget.controller.isContentYouSee
                                                                                      ? ContentYouSeeSettingScreen()
                                                                                      : widget.controller.isMuteAndBlock
                                                                                          ? MuteAndBlockSettingScreen()
                                                                                          : widget.controller.isMutedAccounts
                                                                                              ? MuteAccountsSettingScreen()
                                                                                              : widget.controller.isMuteWords
                                                                                                  ? MutedWordsSettingScreen()
                                                                                                  : widget.controller.isAddMuteWords
                                                                                                      ? AddMutedWordsSettingScreen()
                                                                                                      : widget.controller.isDirectMessage
                                                                                                          ? DirectMessageSettingScreen()
                                                                                                          : widget.controller.isLocationInformation
                                                                                                              ? LocationInformationSettingScreen()
                                                                                                              : widget.controller.isSeePlacesYouHaveBeen
                                                                                                                  ? SeePlacesYouHaveBeenSettingScreen()
                                                                                                                  : widget.controller.isNotificationsFiltersScreen
                                                                                                                      ? FiltersScreen()
                                                                                                                      : widget.controller.isMutedNotificationsScreen
                                                                                                                          ? MutedNotificationsScreen()
                                                                                                                          : widget.controller.isNotificationPreferencesScreen
                                                                                                                              ? NotificationPreferencesScreen()
                                                                                                                              : widget.controller.isPushNotificationScreen
                                                                                                                                  ? PushNotificationsScreen()
                                                                                                                                  : widget.controller.isEmailNotificationScreen
                                                                                                                                      ? EmailNotificationsScreen()
                                                                                                                                      : widget.controller.isSecurityAndAccountAccess
                                                                                                                                          ? SecurityAndAccountAccessScreen()
                                                                                                                                          : widget.controller.isSecurity
                                                                                                                                              ? SecurityScreen()
                                                                                                                                              : SettingsDetailScreen()),
            ],
          );
  }
}
