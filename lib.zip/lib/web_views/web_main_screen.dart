import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:routemaster/routemaster.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/main.dart';
import 'package:werfieapp/network/controller/List_controller.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/saved_post_controller.dart';
import 'package:werfieapp/network/controller/topic_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/browse_screen.dart';
import 'package:werfieapp/screens/chat_screen.dart';
import 'package:werfieapp/screens/dicover_list_post_screen.dart';
import 'package:werfieapp/screens/filter_screen.dart';
import 'package:werfieapp/screens/follower_following/follower_following_tab.dart';
import 'package:werfieapp/screens/list_screen.dart';
import 'package:werfieapp/screens/login_screen.dart';
import 'package:werfieapp/screens/moments_screen/edit_moments_screen.dart';
import 'package:werfieapp/screens/notification_screen.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/screens/post_detail.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/screens/suggested_list_screen.dart';
import 'package:werfieapp/screens/topic_screens/topic_tab_screen.dart';
import 'package:werfieapp/screens/trends_screen.dart';
import 'package:werfieapp/screens/user_profile.dart';
import 'package:werfieapp/screens/who_to_follow_screen.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/hashtag_dialog.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/web_views/dialogbox_web.dart';
import 'package:werfieapp/web_views/web_guest_user/web_guest_user_main.dart';
import 'package:werfieapp/web_views/web_newsfeed_right_section.dart';
import 'package:werfieapp/web_views/web_settings_screen.dart';
import 'package:werfieapp/widgets/newsfeed_mobile.dart';
import 'package:werfieapp/widgets/saved_post_mobile.dart';

import '../models/profile.dart';
import '../network/apis/logout/logout.dart';
import '../network/controller/add_moment_controller.dart';
import '../network/controller/follower_following_controller.dart';
import '../network/controller/login_controller.dart';
import '../network/controller/mobile_comments_controller.dart';
import '../network/controller/notification_controller.dart';
import '../network/controller/profile_controller.dart';
import '../news_feed/newsfeed.dart';
import '../screens/Communites/all_group_screen.dart';
import '../screens/Communites/community_screen.dart';
import '../screens/Communites/main_communites_screen.dart';
import '../screens/hash_taga_details_screen.dart';
import '../screens/hash_taga_werfs_screen.dart';
import '../screens/hidden_replay.dart';
import '../screens/list_as_member_screen.dart';
import '../screens/moments_screen/add_moments_screen.dart';
import '../screens/moments_screen/get_moments_list.dart';
import '../screens/moments_screen/moments_create_screen.dart';
import '../screens/moments_screen/show_moments_screen.dart';
import '../screens/spaces/spaces_main_screen.dart';
import '../screens/topic_screens/Categories_detail_screen.dart';
import '../screens/topic_screens/main_topic_screen.dart';
import '../screens/topic_screens/other_main_topic_screen.dart';
import '../screens/topic_screens/other_topic_tab_screen.dart';
import '../screens/topic_screens/topic_trending_user_list.dart';
import '../utils/asset_string.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../utils/routes.dart';
import '../utils/utils_methods.dart';
import '../video_call/controller/video_call_controller.dart';
import '../video_call/video_call_home.dart';
import '../widgets/blue_tick.dart';

bool onHomeChange = true;
bool onBrowsChange = false;
bool onTrendsChange = false;
bool onBookMarksChange = false;
bool onSpacesScreen = false;
bool onVideoCallChange = false;
bool onChatsChange = false;
bool onProfileChange = false;
bool onSettingChange = false;
bool onListChange = false;
bool onNotificationChange = false;
bool onMoreChange = false;
bool onMomentChange = false;

class WebMainScreen extends StatefulWidget {
  final userName;
  final NewsfeedController controller;
  String page;
  String extra;
  Map<String, dynamic> params;
  bool isFromPosh = false;
  String poshID;
  String WNToken;

  WebMainScreen(
      {Key key, this.userName, this.controller, this.page, this.extra, this.params,this.isFromPosh = false, this.poshID, this.WNToken}) : super(key: key) {}

  @override
  State<WebMainScreen> createState() => _WebMainScreenState();
}

class _WebMainScreenState extends State<WebMainScreen> {
  final storage = GetStorage();

  SharedPreferences shared;

  var loginController=Get.put(LoginController());

  bool isFromPoshDialogShown = true;

//
  final GlobalKey<ScaffoldState> _scaffoldKey =  GlobalKey<ScaffoldState>();

  Future<void> setPageSelected(
      String page, String extra, Map<String, dynamic> params,
      {bool isBack = false}) async {
    // print("setPageSelected");
    SavedPostController savedController;
    BrowseController browseController;
    TopicController topicController;

    // print("this page is " + page);
    /*if(isBack){
      widget.controller.update();
    }*/

    widget.controller.isFilter = false;
    widget.controller.isFilterScreen = false;
    widget.controller.isTrendsScreen = false;
    widget.controller.isWhoToFollowScreen = false;
    widget.controller.isBrowseScreen = false;
    widget.controller.isNotificationScreen = false;
    widget.controller.isListScreen = false;
    widget.controller.isChatScreen = false;
    widget.controller.isSavedPostScreen = false;
    widget.controller.isListDetailScreen = false;
    widget.controller.isPostDetails = false;
    widget.controller.isProfileScreen = false;
    widget.controller.isSettingDetail = false;
    widget.controller.isFollwerScreen = false;
    widget.controller.isSettingsScreen = false;
    widget.controller.isTopicScreen = false;
    widget.controller.isCommunitesScreen = false;
    widget.controller.getListMomentScreen = false;
    widget.controller.drawerLeftMoment = false;
    widget.controller.isNewsFeedScreen = false;
    if (page != null && extra != null) {
      // call();
      if (page == "postDetail") {
        if(widget.controller.isComingBackFromPostDetail){
          widget.controller.isNewsFeedScreen = true;
          widget.controller.isComingBackFromPostDetail = false;
          return;
        }
        // controller.postDetail2 = await controller
        //           //     .getSingleNewsFeedItem(
        //           //     int.parse(extra));
        //           // controller.selectedPost = post;
        onHomeChange = false;
        onBrowsChange = false;
        onSpacesScreen = false;
        onTrendsChange = false;
        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        onMomentChange = false;
        widget.controller.postId = int.parse(extra);
        // controller.threadNumber = null;
        widget.controller.isHiddenReplay = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.navRoute = "isNewsFeedScreen";
        widget.controller.isPostDetails = true;
     //   print(widget.controller.threadNumber);

        //  controller.selectedPost = post;
        if (widget.controller.isSavedPostScreen) {
          savedController.update();
        }
        if (widget.controller.isBrowseScreen) {
          browseController.update();
        }
      }
      else   if (page == "tagInfo") {

        onHomeChange = false;
        onBrowsChange = false;
        onSpacesScreen=false;
        onTrendsChange = false;
        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        onMomentChange = false;
        widget.controller.hashTag = extra;
        widget.controller.threadNumber = null;
        widget.controller.isHiddenReplay = false;
        widget.controller.isPostDetails = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.navRoute = "isTagInfoScreen";
        widget.controller.isTagInfoScreen = true;

      }
      else   if (page == "tagWerfs") {

        onHomeChange = false;
        onBrowsChange = false;
        onTrendsChange = false;
        onSpacesScreen=false;

        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        onMomentChange = false;
        widget.controller.hashTag = extra;
        widget.controller.threadNumber = null;
        widget.controller.isHiddenReplay = false;
        widget.controller.isPostDetails = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.navRoute = "isTagWerfsScreen";
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = true;

      }
      else if (page == "profile") {
       // print("userid " + GetStorage().read('id').toString() + " : " + extra);
        if (GetStorage().read('id').toString() == extra.toString()) {
          onHomeChange = false;
          onBrowsChange = false;
          onTrendsChange = false;
          onBookMarksChange = false;
          onSpacesScreen=false;
          onVideoCallChange = false;
          onChatsChange = false;
          onProfileChange = true;
          onSettingChange = false;
          onListChange = false;
          onNotificationChange = false;
          onMoreChange = false;
          onMomentChange = false;

          // print("widget.newsfeedController.userInfo.userId " + extra);

          widget.controller.isTrendsScreen = false;
          widget.controller.isNewsFeedScreen = false;
          widget.controller.isBrowseScreen = false;
          widget.controller.isSpacesScreen = false;

          widget.controller.isNotificationScreen = false;
          widget.controller.isChatScreen = false;
          widget.controller.isSavedPostScreen = false;
          widget.controller.isPostDetails = false;
          widget.controller.isProfileScreen = true;

          widget.controller.isOtherUserProfileScreen = false;
          widget.controller.navRoute = 'isProfileScreen';

          // controller.update();
        }
        else {
          onHomeChange = false;
          onBrowsChange = false;
          onTrendsChange = false;
          onBookMarksChange = false;
          onChatsChange = false;
          onSpacesScreen=false;
          onVideoCallChange = false;
          onProfileChange = false;
          onSettingChange = false;
          onListChange = false;
          onNotificationChange = false;
          onMoreChange = false;
          onMomentChange = false;
          // controller
          //     .otherUserName =
          //     post.username;

          // controller.otherUserId = int.parse(extra);
          //print(" web controller.otherUserId ${ controller.otherUserId}");
          // SingleTone.instance.userId = extra;
          // controller.update();

          // if (Get.isRegistered<OtherUserController>()) {
          //   Get.delete<OtherUserController>();
          // }

          widget.controller.isFilterScreen = false;
          widget.controller.isTrendsScreen = false;
          widget.controller.isNewsFeedScreen = false;
          widget.controller.isBrowseScreen = false;
          widget.controller.isWhoToFollowScreen = false;
          widget.controller.isNotificationScreen = false;
          widget.controller.isChatScreen = false;
          widget.controller.isSavedPostScreen = false;
          widget.controller.isPostDetails = false;
          widget.controller.isSpacesScreen = false;

          widget.controller.isProfileScreen = false;
          widget.controller.isLoading = false;
          widget.controller.navRoute = 'isOtherUserScreen';
          widget.controller.isTagInfoScreen = false;
          widget.controller.isTagWerfsScreen = false;
          widget.controller.isOtherUserProfileScreen = true;




          // controller.otherProfileScreen=false;

// controller.update();
        }
      }
      else if (page == "followers" || page == "followings") {
        Get.put(FollowerController());
        // print("userid " + GetStorage().read('id').toString() + " : " + extra);

        if (GetStorage().read('id').toString() == extra.toString()) {
          onProfileChange = false;

          widget.controller.isSearch = false;
          widget.controller.isFilter = false;
          widget.controller.isFilterScreen = false;
          widget.controller.isTrendsScreen = false;
          widget.controller.isNewsFeedScreen = false;
          widget.controller.isSpacesScreen = false;

          widget.controller.isBrowseScreen = false;
          widget.controller.isNotificationScreen = false;
          widget.controller.isSavedPostScreen = false;
          widget.controller.isChatScreen = false;
          widget.controller.isPostDetails = false;
          widget.controller.isProfileScreen = false;
          widget.controller.isOtherUserProfileScreen = false;
          widget.controller.isFollwerScreen = true;
          widget.controller.navRoute = "isProfileScreen";
          widget.controller.isTagInfoScreen = false;
          widget.controller.isTagWerfsScreen = false;
          // newsFeedcontroller.update();

          // controller.otherProfileScreen=false;

// controller.update();}
        } else {
          /* Get.put(FollowerController());
          Get.find<FollowerController>().getFollower(userId: controller.userId);
          Get.find<FollowerController>().getFollowing(userId: controller.userId);
          Get.find<FollowerController>().followingCheck = 1;
          Get.find<FollowerController>().update();*/
          widget.controller.isSearch = false;
          widget.controller.isFilter = false;
          widget.controller.isFilterScreen = false;
          widget.controller.isTrendsScreen = false;
          widget.controller.isNewsFeedScreen = false;
          widget.controller.isBrowseScreen = false;
          widget.controller.isNotificationScreen = false;
          widget.controller.isWhoToFollowScreen = false;
          widget.controller.isSpacesScreen = false;

          widget.controller.isSavedPostScreen = false;
          widget.controller.isChatScreen = false;
          widget.controller.isPostDetails = false;
          widget.controller.isProfileScreen = false;
          widget.controller.isOtherUserProfileScreen = false;
          widget.controller.isFollwerScreen = true;
          widget.controller.navRoute = "isOtherUserScreen";

          // controller.update();
        }
      }
      else if (page == "filters") {
        SingleTone.instance.searchId = params['id'][0] ?? 0;
        SingleTone.instance.searchTag = params['tag'][0];
        SingleTone.instance.searchType = params['type'][0] ?? "tag";
        SingleTone.instance.isSearch = params['isSearch'][0];

        // print("filters " + params['id'][0].toString());
        // print("filters " + params['tag'][0].toString());
        // print("filters " + params['type'][0].toString());
        // print("filters " + SingleTone.instance.isSearch.toString());

        // controller.update();

        // await controller.onSearchTextChanged(extra,isSearchBar: false,isFromRoute: true);
        //  controller.searchSelected = controller.searchResult[0];
        // controller.searchSelected.id = 0;
        // controller.searchSelected.type = "tag";

/*    await controller.filterUsers(
            id: 0.toString(),
            type: "tag",
            tag: extra, isFromRoute: true
            // id: id,
            // type: controller.searchResult[0].type,
          );*/

        widget.controller.isProfileScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isOtherUserProfileScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isChatScreenWeb = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isBrowseScreen = false;
        widget.controller.isClickWhoToFollow = false;

        widget.controller.isWhoToFollow = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.postUserId = int.parse(SingleTone.instance.searchId ?? 0);
        // controller.isSearch = true;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isFilterScreen = true;

        // controller.searchText.text = SingleTone.instance.searchTag.trim();

        // controller.tagText = SingleTone.instance.searchTag;

        // SingleTone.instance.searchId=0.toString();
        // SingleTone.instance.searchType="tag";
        // SingleTone.instance.searchTag=controller.tagText;

        //  controller.wait = true;
        // controller.isSearch = false;
        // controller.searchResult = [];
        // print("%%%%%%%%$extra");

// if(controller.filteredPost.isNotEmpty) {
//   controller.update();
// }
      }
      else if (page == "listDetail") {
// print("listdetails navigation");
// print("list detail extra$extra");

        onHomeChange = false;
        onBrowsChange = false;
        onTrendsChange = false;
        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        onMomentChange = false;

        widget.controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.navRoute = "isListDetailScreen";
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isListDetailScreen = true;


      }


      else if (page == "mainTopics") {
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isOtherUserProfileScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isMainTopicScreen = true;

        // controller.update();

        //
        // topicController.screenCheck =1;
        // // topicController.update();
        // //
        // await topicController.topicPost(topicId: topicController.notInterestedTopic.data[int.parse(extra)].id, pageNO: 1,isFromRoute: true);
      }
      else if (page == "moment") {
        //
        // Get.find<AddMomentsController>().momentsDetailsApi(
        //     pageNo: 1,
        //     momentId:    SingleTone.instance.momentId
        // );

        // print("extra uper ${extra}");
        widget.controller.drawerLeftMoment = true;
        widget.controller.editMomentScreen = true;
        widget.controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.addMomentsScreen = false;
        widget.controller.getListMomentScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.showMomentsScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isListDetailScreen = false;
        // controller.update();
      }
      else if (page == "HiddenReplies") {

        // print("extra uper ${extra}");

        widget.controller.postId = int.parse(extra);
        widget.controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.addMomentsScreen = false;
        widget.controller.getListMomentScreen = false;
        widget.controller.showMomentsScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isNotificationScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isHiddenReplay = true;


        // controller.update();
      }


      else {
        onHomeChange = true;
        onBrowsChange = false;
        onTrendsChange = false;
        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;

        widget.controller.getListMomentScreen = false;
        widget.controller.drawerLeftMoment = false;
        widget.controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = true;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isListScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.navRoute = "isNewsFeedScreen";
        widget.controller.searchText.text = '';

      }
    }
    else if (page != null) {

      if (page == "feeds" || page == "home") {
        // print("sdfsdfsdfsdfsdwerwerw");

        onHomeChange = true;
        onBrowsChange = false;
        onTrendsChange = false;
        onBookMarksChange = false;
        onSpacesScreen=false;

        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;

        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSpacesScreen=false;
        widget.controller.isVideoCallScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isSettingDetail = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.getListMomentScreen = false;
        widget.controller.drawerLeftMoment = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.navRoute = "isNewsFeedScreen";
        widget.controller.isNewsFeedScreen = true;
        addNewsFeedMetaTags();
        // controller.searchText.text = '';

        // controller.getNewsFeed(shouldUpdate: true, reload: true);
        // await controller.getNewsFeed(shouldUpdate: true, reload: true);
      }
      else if (page == "browse") {

        if (Get.isRegistered<BrowseController>()) {
          browseController = Get.find<BrowseController>();
        } else {
          browseController = Get.put(BrowseController());
        }
        onHomeChange = false;
        onBrowsChange = true;
        onTrendsChange = false;
        onSpacesScreen=false;
        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = true;
        widget.controller.isSpacesScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        //controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.navRoute = "isQuestScreen";
      }
      else if(page=="ListMemberships"){
        // print('ismembership');
        onHomeChange = false;
        onBrowsChange = false;
        onTrendsChange = false;
        onBookMarksChange = false;
        onChatsChange = false;
        onSpacesScreen=false;

        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        onMomentChange = false;

        widget.controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isSpacesScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.navRoute = "isListMemberships";
        widget.controller.isListDetailScreen = false;
        widget.controller.isListMemberShipScreen=true;

      }
      else if (page == "trends") {

        onTrendsChange = true;
        onHomeChange = false;
        onBookMarksChange = false;
        onSpacesScreen=false;

        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;
        onSettingChange = false;
        onProfileChange = false;
        onChatsChange = false;
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = true;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        // controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.navRoute = "isTrendsScreen";
      }
      else if (page == "savedPost") {

        if (Get.isRegistered<SavedPostController>()) {
          savedController = Get.find<SavedPostController>();
        } else {
          savedController = Get.put(SavedPostController());
        }
        onBookMarksChange = true;
        onTrendsChange = false;
        onHomeChange = false;
        onBrowsChange = false;
        onSpacesScreen=false;

        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;
        onSettingChange = false;
        onProfileChange = false;
        onChatsChange = false;
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSavedPostScreen = true;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSpacesScreen = false;
        widget.controller.isVideoCallScreen = false;

        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;
        // controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.navRoute = "isSavedPostScreen";
      }
      else if (page == "spaces") {
        // if (Get.isRegistered<SavedPostController>()) {
        //   savedController = Get.find<SavedPostController>();
        // } else {
        //   savedController = Get.put(SavedPostController());
        // }
        onBookMarksChange = false;
        onSpacesScreen = true;
        onTrendsChange = false;

        onHomeChange = false;
        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;
        onSettingChange = false;
        onProfileChange = false;
        onChatsChange = false;
        onVideoCallChange = false;
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isSpacesScreen = true;
        widget.controller.isVideoCallScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;
        // controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.navRoute = "isSpacesScreen";
      }
      else if (page == "videocall") {
        // if (Get.isRegistered<SavedPostController>()) {
        //   savedController = Get.find<SavedPostController>();
        // } else {
        //   savedController = Get.put(SavedPostController());
        // }
        onBookMarksChange = false;
        onSpacesScreen = false;
        onTrendsChange = false;

        onHomeChange = false;
        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;
        onSettingChange = false;
        onProfileChange = false;
        onChatsChange = false;
        onVideoCallChange = true;
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isSpacesScreen = false;
        widget.controller.isVideoCallScreen = true;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;
        // controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.navRoute = "isVideoCallScreen";
      }
      else if (page == "chats") {
        onChatsChange = true;
        onBookMarksChange = false;
        onTrendsChange = false;
        onHomeChange = false;
        onSpacesScreen=false;

        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;
        onSettingChange = false;
        onProfileChange = false;

        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSpacesScreen = false;
        widget.controller.isVideoCallScreen = false;

        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = true;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        // controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.navRoute = "isChatScreen";
        // controller.chatUserList = await controller.getChat();
        // print("controller.chatUserList ${controller.chatUserList}");
        // print("preesssseddd");
      }
      else if (page == "profile") {
        onProfileChange = true;
        onChatsChange = false;
        onBookMarksChange = false;
        onTrendsChange = false;
        onHomeChange = false;
        onSpacesScreen=false;

        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;
        onSettingChange = false;
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = false;
        // controller.searchText.text = '';
        widget.controller.isPostDetails = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isProfileScreen = true;
        widget.controller.isSettingsScreen = false;
        widget.controller.isCommunitesScreen = false;

        widget.controller.isTopicScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.navRoute = "isProfileScreen";

        if (Get.isRegistered<ProfileController>()) {

          Get.find<ProfileController>().selectedTab == "isTweets";


          Get.find<ProfileController>().isHiddenPost = false;
          Get.find<ProfileController>().isTweets = true;
          Get.find<ProfileController>().isTweetsReply = false;
          Get.find<ProfileController>().isMedia = false;
          Get.find<ProfileController>().isLikes = false;

          // Get.find<ProfileController>().userProfile = await controller.getUserProfile(isFromRoute: true);

          await Get.find<ProfileController>().filterUsersPost("posts", isFromRoute: true);
          Get.find<ProfileController>().userPosts.forEach((element) {
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });
            element.reactionType.refresh();

            // if (element.isLiked == true) {
            //   element.like.value = true;
            //   element.like.refresh();
            // }
          });
          Get.find<ProfileController>().update();
        } else {

          Get.put(ProfileController());
          Get.find<ProfileController>().selectedTab == "isTweets";
          Get.find<ProfileController>().isHiddenPost = false;
          Get.find<ProfileController>().isTweets = true;
          Get.find<ProfileController>().isTweetsReply = false;
          Get.find<ProfileController>().isMedia = false;
          Get.find<ProfileController>().isLikes = false;
          Get.find<ProfileController>().userProfile =
              await widget.controller.getUserProfile();

          await Get.find<ProfileController>().filterUsersPost("posts");
          Get.find<ProfileController>().userPosts.forEach((element) {
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });
            element.reactionType.refresh();

            // if (element.isLiked == true) {
            //   element.like.value = true;
            //   element.like.refresh();
            // }
          });
          Get.find<ProfileController>().update();
        }
        // controller.update();
      }
      else if (page == "settings") {
        onSettingChange = true;
        onProfileChange = false;
        onChatsChange = false;
        onBookMarksChange = false;
        onSpacesScreen=false;

        onTrendsChange = false;
        onHomeChange = false;
        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;

        // print("click hua");
        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isOtherUserProfileScreen = false;
        // controller.searchText.text = '';
        widget.controller.isSettingsScreen = true;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.navRoute = "isSettingsScreen";

        await widget.controller
            .getOtherUserProfile(GetStorage().read('id'), isFromRoute: true)
            .whenComplete(() {
          // print("whencomplete called");
          widget.controller.verification = widget.controller.otherUserProfile.accountVerified;
        });
      }
      else if (page == "list") {
        onListChange = true;
        onSettingChange = false;
        onProfileChange = false;
        onSpacesScreen=false;

        onChatsChange = false;
        onBookMarksChange = false;
        onTrendsChange = false;
        onHomeChange = false;

        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;

        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isPostDetails = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isListScreen = true;
        widget.controller.isListDetailScreen = false;
        widget.controller.isTopicScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.isOtherUserProfileScreen = false;
        // controller.searchText.text = '';

        widget.controller.isSettingsScreen = false;
        widget.controller.navRoute = "isListScreen";
        // controller.update();
      }
      else if (page == "notifications") {
        onNotificationChange = true;
        onListChange = false;
        onSettingChange = false;
        onSpacesScreen=false;

        onProfileChange = false;
        onChatsChange = false;
        onBookMarksChange = false;
        onTrendsChange = false;
        onHomeChange = false;

        onBrowsChange = false;
        onMoreChange = false;

        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = true;
        widget.controller.isSpacesScreen = false;

        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isPostDetails = false;
        // controller.searchText.text = '';
        widget.controller.isCommunitesScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.navRoute = "isNotificationScreen";
        notifi.value = 0;
        // if (Get.isRegistered<NotificationController>()) {
        //   Get.find<NotificationController>().getNotifications();
        // }
        // controller.update();
      }
      else if (page == "moments") {
        // print("nnnnnnn");

        // controller.isSearch = false;

        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.addMomentsScreen = false;
        widget.controller.getListMomentScreen = true;
        widget.controller.isCreateMomentsScreen = true;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isSavedPostScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.addMomentsScreen = false;
        widget.controller.editMomentScreen = false;
        widget.controller.isCommunitesScreen = false;
        widget.controller.showMomentsScreen = false;
        widget.controller.drawerLeftMoment = true;
        SingleTone.instance.buttonDisable == false;
        // SingleTone.instance.momentId = null;

        //  controller.navRoute = "isQuestScreen";

        // controller.update();
      }
      else if (page == "CreateMoment") {
        widget.controller.disableButton = false;
        widget.controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.getListMomentScreen = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.addMomentsScreen = true;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isSavedPostScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.drawerLeftMoment = true;
        widget.controller.editMomentScreen = false;
        widget.controller.addMomentsScreen = false;
        widget.controller.showMomentsScreen = true;
        widget.controller.isCreateMomentsScreen = false;
      }
      else if (page == "topics") {
        onMoreChange = true;
        onNotificationChange = false;
        onListChange = false;
        onSpacesScreen=false;

        onSettingChange = false;
        onProfileChange = false;
        onChatsChange = false;
        onBookMarksChange = false;
        onTrendsChange = false;
        onHomeChange = false;

        onBrowsChange = false;

        // controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isTopWerfsScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isPostDetails = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.drawerLeftMoment = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.isListDetailScreen = false;
        widget.controller.isOtherUserProfileScreen = false;
        // controller.searchText.text = '';
        widget.controller.isSettingsScreen = false;
        widget.controller.isTopicScreen = true;
        widget.controller.isCommunitesScreen = false;
        widget.controller.navRoute = "isTopicScreen";
        // controller.update();
      }
      else if (page == "whoToFollowScreen")
      {
        onHomeChange = false;
        onBrowsChange = false;
        onTrendsChange = false;
        onSpacesScreen=false;

        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;

        // print(" who to profile screen");
        widget.controller.isWhoToFollowScreen = true;
        widget.controller.isTrendsScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isOtherUserProfileScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isNotificationScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.isListScreen = false;
        widget.controller.isProfileScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;

        // controller.update();
        // controller.update();
      }

      else if (page == "logout") {
        // print("logout user");
        onHomeChange = true;
        onBrowsChange = false;
        onTrendsChange = false;
        onSpacesScreen=false;

        onBookMarksChange = false;
        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        onMomentChange = false;
        SharedPreferences preferences = await SharedPreferences.getInstance();

        if (preferences.getBool('socialLogin') == true) {
          // print('social logout');
          UtilsMethods utils = UtilsMethods();
          await utils.signOutGoogle();

          await preferences.clear();
          // await preferences.remove("userName");
          // await preferences.remove("id");
          await widget.controller.storage.erase();
          Get.delete<SessionController>();
          Get.delete<ProfileController>();
          Get.delete<NewsfeedController>();
          // controller.update();
          preferences.setBool('guestUser', true);
          /*   Routemaster.of(context).replace(
                            AppRoute.guestUserMainScreen);*/
          // Get.offNamed(FluroRouters.guestUserMainScreen);
          Get.offAll(GuestUserMainScreen(isFromPosh: false,),routeName: FluroRouters.guestUserMainScreen);

        } else {
          await preferences.clear();
          // await preferences.remove("userName");
          // await preferences.remove("id");
          await widget.controller.storage.erase();
          Get.delete<SessionController>();
          Get.delete<ProfileController>();
          Get.delete<NewsfeedController>();
          // controller.update();
          preferences.setBool('guestUser', true);
          /*        Routemaster.of(context).replace(
                            AppRoute.guestUserMainScreen);*/
          // Get.offNamed(FluroRouters.guestUserMainScreen);
          Get.offAll(GuestUserMainScreen(isFromPosh: false,),routeName: FluroRouters.guestUserMainScreen);

        }
      }
      else if (page == "SuggestList") {
        onHomeChange = true;
        onBrowsChange = false;
        onTrendsChange = false;
        onBookMarksChange = false;
        onSpacesScreen=false;

        onChatsChange = false;
        onProfileChange = false;
        onSettingChange = false;
        onListChange = false;
        onNotificationChange = false;
        onMoreChange = false;
        onMomentChange = false;
        widget.controller.isSuggestedListScreen = true;
        widget.controller.isListDetailScreen = false;
        widget.controller.isSearch = false;
        widget.controller.isFilter = false;
        widget.controller.isFilterScreen = false;
        widget.controller.isTagInfoScreen = false;
        widget.controller.isTagWerfsScreen = false;
        widget.controller.isTrendsScreen = false;
        widget.controller.isNewsFeedScreen = false;
        widget.controller.isBrowseScreen = false;
        widget.controller.isSpacesScreen = false;

        widget.controller.isNotificationScreen = false;
        widget.controller.isWhoToFollowScreen = false;
        widget.controller.isSavedPostScreen = false;
        widget.controller.isChatScreen = false;
        widget.controller.isPostDetails = false;
        widget.controller.isProfileScreen = false;
        widget.controller.searchText.text = '';
        widget.controller.isListScreen = false;
        widget.controller.isFollwerScreen = false;
        widget.controller.isSettingsScreen = false;
        widget.controller.navRoute = "isChatScreen";
      }
    }
    else {

      onHomeChange = true;
      onBrowsChange = false;
      onTrendsChange = false;
      onBookMarksChange = false;
      onSpacesScreen=false;

      onChatsChange = false;
      onProfileChange = false;
      onSettingChange = false;
      onListChange = false;
      onNotificationChange = false;
      onMoreChange = false;
      widget.controller.isSearch = false;
      widget.controller.isFilter = false;
      widget.controller.isFilterScreen = false;
      widget.controller.isTrendsScreen = false;
      widget.controller.isNewsFeedScreen = true;
      widget.controller.isWhoToFollowScreen = false;
      widget.controller.isBrowseScreen = false;
      widget.controller.isNotificationScreen = false;
      widget.controller.isSpacesScreen = false;

      widget.controller.isListScreen = false;
      widget.controller.isChatScreen = false;
      widget.controller.isSavedPostScreen = false;
      widget.controller.isListDetailScreen = false;
      widget.controller.isPostDetails = false;
      widget.controller.isProfileScreen = false;
      widget.controller.isFollwerScreen = false;
      widget.controller.isSettingsScreen = false;
      widget.controller.isTopicScreen = false;
      widget.controller.isCommunitesScreen = false;
      widget.controller.isTagInfoScreen = false;
      widget.controller.isTagWerfsScreen = false;
      widget.controller.getListMomentScreen = false;
      widget.controller.drawerLeftMoment = false;
      widget.controller.navRoute = "isNewsFeedScreen";
      widget.controller.searchText.text = '';

    }
  }

  Future<void> call() async {
    shared = await SharedPreferences.getInstance();
    // print("yes token print");
    Future.delayed(const Duration(milliseconds: 1000), () async {
      await Get.put(NewsfeedController());
      // print("put end");
      String userData = storage.read("user_profile");
      // print(storage.read('token')+" user data"+userData);
      Get.find<NewsfeedController>().userProfile =
          await UserProfile.fromJson(jsonDecode(userData));
      Get.find<NewsfeedController>().userProfile.username =
          storage.read("user_name");
      Get.find<NewsfeedController>().userProfile.notificationAllowed =
          storage.read("notificationAllowed");
      if (Get.find<NewsfeedController>().userProfile.notificationAllowed == 1) {
        Get.find<NewsfeedController>().notificationStatus = true;
      } else {
        Get.find<NewsfeedController>().notificationStatus = false;
      }
      Get.find<NewsfeedController>().update();
      Get.find<NewsfeedController>().languageData =
          await Get.find<NewsfeedController>().getLanguages();

      Get.find<NewsfeedController>().selectedAppLanguageInfoId =
          await Get.find<NewsfeedController>().languageData.appLang.id;

      Get.find<NewsfeedController>().upDateLocale(
          Get.find<NewsfeedController>().languageData.appLang.code);

      int index =
          Get.find<NewsfeedController>().languagesList.indexWhere((element) {
        return Get.find<NewsfeedController>().languageData.appLang.id ==
            element.id;
      });

      int index2 = Get.find<NewsfeedController>()
          .translationLanguage
          .indexWhere((element) {
        return Get.find<NewsfeedController>().languageData.myLang.id ==
            element.id;
      });

      Get.find<NewsfeedController>().dropdownValue =
          Get.find<NewsfeedController>().languagesList[index];

      Get.find<NewsfeedController>().dropdownValue1 =
          Get.find<NewsfeedController>().translationLanguage[index2];

      // Get.find<NewsfeedController>().update();
      if (Get.find<NewsfeedController>().languageData != null) {
        Get.find<NewsfeedController>().isAutoTranslate =
            Get.find<NewsfeedController>()
                        .languageData
                        .autoTranslateSettings
                        .autoTranslate ==
                    1
                ? true
                : false;
        Get.find<NewsfeedController>().selectedLanguage =
            Get.find<NewsfeedController>().languageData.myLang;
      }
      // print('CALL SHARED INIT WITH ID');
      // });

      // Get.delete<SessionController>();
      // });
    });
  }

  void showInitialWelcomeMsg(BuildContext context)async{
    Future.delayed(const Duration(seconds: 3), () async {
      if(loginController.isShowWelcomeMsg==true){
        await UtilsMethods.toastMessageShow(
            const Color(0xFF2769d9),
            const Color(0xFF2769d9),
            const Color(0xFF2769d9),
            toastDuration: 4,
            message:Get.find<NewsfeedController>().userName!=null? "${Strings.welcomeToWerfie} '${Get.find<NewsfeedController>().userName}'":Strings.welcomeToWerfie);
        loginController.isShowWelcomeMsg(false);
        // debugPrint('Welcome Message Showing 22 ${loginController.isShowWelcomeMsg}');
      }
      shared = await SharedPreferences.getInstance();


      if(widget.isFromPosh){
        if(loginController.isLoginWithPoshDialogShown == false) {
          loginController.isLoginWithPoshDialogShown(true);
          //if(shared.getString("poshID")== null || shared.getString("poshID").isEmpty ){
            if(shared.getString("poshID") != widget.poshID){
              showDialogLoginWithPosh(context);
            }
          //}


      }

    }});

  }

  addNewsFeedMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleHome,
        metaTagDescription: MetaTagValues.newsFeedMetaDescription,
        metaTagKeywords: MetaTagValues.newsFeedMetaKeywords,
        ogTitle: MetaTagValues.newsFeedOGTitle,
        ogDescription: MetaTagValues.newsFeedOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addExploreMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleExplore,
        metaTagDescription: MetaTagValues.exploreMetaDescription,
        metaTagKeywords: MetaTagValues.exploreMetaKeywords,
        ogTitle: MetaTagValues.exploreOGTitle,
        ogDescription: MetaTagValues.exploreOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addTrendsMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleTrending,
        metaTagDescription: MetaTagValues.trendsMetaDescription,
        metaTagKeywords: MetaTagValues.trendsMetaKeywords,
        ogTitle: MetaTagValues.trendsOGTitle,
        ogDescription: MetaTagValues.trendsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addBookmarksMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleBookmarks,
        metaTagDescription: MetaTagValues.bookmarksMetaDescription,
        metaTagKeywords: MetaTagValues.bookmarksMetaKeywords,
        ogTitle: MetaTagValues.bookmarksOGTitle,
        ogDescription: MetaTagValues.bookmarksOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addSpacesMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleSpaces,
        metaTagDescription: MetaTagValues.spacesMetaDescription,
        metaTagKeywords: MetaTagValues.spacesMetaKeywords,
        ogTitle: MetaTagValues.spacesOGTitle,
        ogDescription: MetaTagValues.spacesOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addChatsMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleChats,
        metaTagDescription: MetaTagValues.chatsMetaDescription,
        metaTagKeywords: MetaTagValues.chatsMetaKeywords,
        ogTitle: MetaTagValues.chatsOGTitle,
        ogDescription: MetaTagValues.chatsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addSettingsMetaTags(){

    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleSettings,
        metaTagDescription:MetaTagValues.settingsMetaDescription,
        metaTagKeywords: MetaTagValues.settingsMetaKeywords,
        ogTitle: MetaTagValues.settingsOGTitle,
        ogDescription: MetaTagValues.settingsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addListMetaTags(){

    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleLists,
        metaTagDescription:MetaTagValues.listsMetaDescription,
        metaTagKeywords: MetaTagValues.listsMetaKeywords,
        ogTitle: MetaTagValues.listsOGTitle,
        ogDescription: MetaTagValues.listsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addNotificationsMetaTags(){

    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleNotification,
        metaTagDescription:MetaTagValues.notificationsMetaDescription,
        metaTagKeywords: MetaTagValues.notificationsMetaKeywords,
        ogTitle: MetaTagValues.notificationsOGTitle,
        ogDescription: MetaTagValues.notificationsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  addLoginSignUpMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.signUpAndLoginPageTitle,
        metaTagDescription: MetaTagValues.signUpAndLoginMetaDescription,
        metaTagKeywords: MetaTagValues.signUpAndLoginMetaKeywords,
        ogTitle: MetaTagValues.signUpAndLoginOGTitle,
        ogDescription: MetaTagValues.signUpAndLoginMetaDescription,
        ogImage: MetaTagValues.ogImage
    );
  }


  @override
  void initState() {

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    // debugPrint('Welcome Message Showing 2 ${loginController.isShowWelcomeMsg}');
    showInitialWelcomeMsg(context);

    if (widget.page != null || widget.extra != null) {
      // print("ppppage: " + page);
      setPageSelected(widget.page, widget.extra, widget.params);
    }
    WidgetsBinding.instance
        .addPostFrameCallback((_) {

    });
    // else {
    //   print("ppppage: ");
    //
    //   onHomeChange = true;
    //   onBrowsChange = false;
    //   onTrendsChange = false;
    //   onBookMarksChange = false;
    //   onChatsChange = false;
    //   onProfileChange = false;
    //   onSettingChange = false;
    //   onListChange = false;
    //   onNotificationChange = false;
    //   onMoreChange = false;
    //   controller.isSearch = false;
    //   controller.isFilter = false;
    //   controller.isFilterScreen = false;
    //   controller.isTrendsScreen = false;
    //   controller.isNewsFeedScreen = true;
    //   controller.isWhoToFollowScreen = false;
    //   controller.isBrowseScreen = false;
    //   controller.isNotificationScreen = false;
    //   controller.isListScreen = false;
    //   controller.isChatScreen = false;
    //   controller.isSavedPostScreen = false;
    //   controller.isListDetailScreen = false;
    //   controller.isPostDetails = false;
    //   controller.isProfileScreen = false;
    //   controller.isFollwerScreen = false;
    //   controller.isSettingsScreen = false;
    //   controller.isTopicScreen = false;
    //   controller.isCommunitesScreen = false;
    //   controller.navRoute = "isNewsFeedScreen";
    //   // controller.searchText.text = '';
    // }
    return WillPopScope(
        onWillPop: () => _onBackPressed(widget.controller, context),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            // print("yahan pr laga hai ");

            widget.controller.isSearch = false;
            // controller.searchResult = [];
            if (widget.controller.isBrowseScreen) {
              Get.find<BrowseController>().isSearch = false;
              Get.find<BrowseController>().searchResult = [];
              Get.find<BrowseController>().searchField = false;
              Get.find<BrowseController>().update();
            }
            // controller.update();
          },
          child: Scaffold(
            body: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // WebAppBar(
                //   userName:userName,
                //   controller: controller,
                // ),
                // Container(
                //   height: 2,
                //   color: Colors.grey[200],
                // ),
                // Divider(
                //   thickness: 0,
                //   height: 2,
                // ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      widget.controller.drawerLeftMoment == true
                          ? momentsLeftSection(context, widget.controller)
                          : webLeftSection(context, widget.controller),
                      Container(
                        width: 0.5,
                        color:Colors.black12,
                      ),
                      widget.controller.drawerLeftMoment == true
                          ? widget.controller.momentCreateScreen == false
                              ? SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width >= 720
                                          ? 550
                                          : Get.width / 1.2,
                                  child:
                                      widget.controller.getListMomentScreen == true &&
                                              widget.controller.drawerLeftMoment
                                          ? MomentListScreen()
                                          : AddMomentsScreen(
                                              momentid: widget.extra,
                                            ))
                              : SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width >= 720
                                          ? 550
                                          : Get.width / 1.2,
                                  child: widget.controller.drawerLeftMoment == true &&
                                          widget.controller.editMomentScreen == true
                                      ? EditMomentsScreen(
                                          momentid: widget.extra,
                                        )
                                      : widget.controller.drawerLeftMoment == true &&
                                              widget.controller.showMomentsScreen ==
                                                  true
                                          ? ShowMomentsScreen()
                                          : MomentsCreateScreen())
                          : SizedBox(
                              width: MediaQuery.of(context).size.width >= 720
                                  ? widget.controller.isChatScreen || widget.controller.isVideoCallScreen
                                      ? MediaQuery.of(context).size.width >=
                                              1050
                                          ? 952
                                          : MediaQuery.of(context).size.width >=
                                                  700
                                              ? 600
                                              : MediaQuery.of(context)
                                                      .size
                                                      .width /
                                                  1.3
                                      : widget.controller.isSettingsScreen
                                          ? MediaQuery.of(context).size.width >=
                                                  1050
                                              ? 950
                                              : MediaQuery.of(context)
                                                          .size
                                                          .width >=
                                                      700
                                                  ? 600
                                                  : MediaQuery.of(context)
                                                          .size
                                                          .width /
                                                      1.3
                                          : 600
                                  : Get.width / 1.2,
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: widget.controller.isSavedPostScreen ||
                                            widget.controller.isChatScreen
                                        ? 0
                                        : 0),
                                child: widget.controller.isNewsFeedScreen
                                    ? NewsFeed(
                                        controller: widget.controller,
                                        postId: widget.controller.linkId,
                                      )
                                    : widget.controller.isTopWerfsScreen
                                        ? NewsFeed(
                                            controller: widget.controller,
                                            postId: widget.controller.linkId,
                                          )
                                        : widget.controller.isTrendsScreen
                                            ? MobileTrendsScreen(
                                                controller: widget.controller)
                                            : widget.controller.isWhoToFollowScreen
                                                ? WhoToFollow(
                                                    controller: widget.controller)
                                                : widget.controller.isProfileScreen
                                                    ? ProfileScreen(
                                                        controller: widget.controller)
                                                    : widget.controller.isBrowseScreen
                                                        ? BrowseScreen(
                                                            controller:
                                                                widget.controller)
                                                        // ? MobileQuestScreen(controller: controller)
                                                        : widget.controller
                                                                .isNotificationScreen
                                                            ? NotificationScreen()
                                                            : widget.controller
                                                                    .isSavedPostScreen
                                                                ? MobileSavedPost(
                                                                    newsFeedController:
                                                                        widget.controller,
                                                                  )
                                :widget.controller.isTagInfoScreen? HashTagDetailsScreen(controller: widget.controller,tag: widget.controller.hashTag,)
                                :widget.controller.isTagWerfsScreen? HashTagWerfsScreen(controller: widget.controller,tag: widget.controller.hashTag,)
                                                                : widget.controller
                                                                        .isSpacesScreen
                                                                            ? const SpacesMainScreen()
                                                                            : widget.controller.isVideoCallScreen
                                                                                ? const VideoCallHome()
                                                                                : widget.controller
                                                                            .isChatScreen
                                                                        ? const MobileChatScreen()
                                                                        : widget.controller.isPostDetails
                                                                            ?
                                                                            //     controller.threadNumber==null?
                                                                            //     CommentsScreen(thread_no: null,postId: controller.postId,)
                                                                            // :CommentsScreen(thread_no: controller.threadNumber,postId: null,)
                                                                            PostDetail(
                                                                                controller: widget.controller,
                                                                                post: widget.controller.selectedPost,
                                                                              )
                                                                            : widget.controller.isFilterScreen
                                                                                ? FilteredScreen(newsfeedController: widget.controller)
                                                                                : widget.controller.isOtherUserProfileScreen
                                                                                    ? OtherUsersProfile(
                                                                                        controller: widget.controller,
                                                                                        userId: widget.extra.toString(),
                                                                                      )
                                                                                    : widget.controller.isClickWhoToFollow
                                                                                        ? OtherUsersProfile(
                                                                                            controller: widget.controller,
                                                                                            userId: widget.extra.toString(),
                                                                                          )
                                                                                        : widget.controller.isFollwerScreen
                                                                                            ? FollowerScreen(
                                                                                                controller: widget.controller,
                                                                                                id: widget.extra,
                                                                                                page: widget.page,
                                                                                              )
                                                                                            : widget.controller.isSettingsScreen
                                                                                                ? WebSettingsScreen(controller: widget.controller)
                                                                                                : widget.controller.isListScreen
                                                                                                    ? ListScreen(
                                                                                                        controller: widget.controller,
                                                                                                      )
                                                                                                    : widget.controller.isListDetailScreen
                                                                                                        ? DiscoverListScreen(
                                                                                                            controller: widget.controller,
                                                                                                            index: widget.extra,
                                                                                                          )
                                                                                                        : widget.controller.isSuggestedListScreen
                                                                                                            ? SuggestedListScreen(controller: widget.controller)
                                                                                                            : widget.controller.isSuggestedListScreen
                                                                                                                ? SuggestedListScreen(controller: widget.controller)
                                                                                                                : widget.controller.isListMemberShipScreen
                                                                                                                    ? ListAsMemberScreen()
                                                                                                                    : widget.controller.isHiddenReplay
                                                                                                                        ? HiddenReplay()
                                                                                                                        : widget.controller.isTopicScreen
                                                                                                                            ? Topic_Tab_Screen()
                                                                                                                            : widget.controller.isTopicsCategoriesDetailsScreen
                                                                                                                                ? TopicsCategoriesDetailsScreen()
                                                                                                                                : widget.controller.isMainTopicScreen
                                                                                                                                    ? MainTopicScreen(index: widget.extra)
                                                                                                                                    : widget.controller.isTopicTrendingUserList
                                                                                                                                        ? TopicTrendingUserList()
                                                                                                                                        : widget.controller.isOtherTopicTabScreen
                                                                                                                                            ? OtherTopicTabScreen()
                                                                                                                                            : widget.controller.isOtherMainTopicScreen == true
                                                                                                                                                ? OtherMainTopicScreen()
                                                                                                                                                : widget.controller.isCommunitesScreen
                                                                                                                                                    ? MainCommunitiesScreen()
                                                                                                                                                    : widget.controller.isCommunityScreen
                                                                                                                                                        ? CommunityScreen()
                                                                                                                                                        : widget.controller.isAllGroupScreen
                                                                                                                                                            ? AllGroupScreen()
                                                                                                                                                            : NewsFeed(
                                                                                                                                                                controller: widget.controller,
                                                                                                                                                              ),
                              ),
                            ),
                      widget.controller.isChatScreen
                          ? const SizedBox()
                          : Container(
                              width: 0.5,
                              color: Colors.black12,
                            ),
                      widget.controller.drawerLeftMoment == true
                          ? MediaQuery.of(context).size.width >= 1050
                              ? SizedBox(
                                  width: 400,
                                  child: widget.controller.drawerLeftMoment == true &&
                                          widget.controller.editMomentScreen == true
                                      ? EditMomentsScreen(
                                          momentid: widget.extra,
                                        )
                                      : widget.controller.drawerLeftMoment == true &&
                                              widget.controller.showMomentsScreen ==
                                                  true
                                          ? ShowMomentsScreen()
                                          : MomentsCreateScreen())
                              : const SizedBox()
                          : !widget.controller.isChatScreen && !widget.controller.isVideoCallScreen &&
                                  !widget.controller.isSettingsScreen
                              ? MediaQuery.of(context).size.width >= 1050
                                  ? WebNewsfeedRightSection(widget.controller)
                                  : const SizedBox()
                              : Container(),
                    ],
                  ),
                )
                // Expanded(
                //   child: LayoutBuilder(
                //     builder: (context, constraints) {
                //       if (constraints.maxWidth >= 1100) {
                //         return Row(
                //           children: [
                //             controller.drawerLeftMoment == true
                //                 ? momentsLeftSection(context, controller)
                //                 : webLeftSection(context, controller),
                //             Container(
                //               width: 2,
                //               color: Colors.grey[200],
                //             ),
                //             controller.drawerLeftMoment == true
                //                 ? Container(
                //                     width: Get.width * 0.45,
                //                     child: controller.getListMomentScreen == true &&
                //                             controller.drawerLeftMoment
                //                         ? MomentListScreen()
                //                         : AddMomentsScreen())
                //                 : Expanded(
                //                     child: Padding(
                //                       padding: EdgeInsets.symmetric(
                //                           horizontal:
                //                               controller.isSavedPostScreen ||
                //                                       controller.isChatScreen
                //                                   ? 0
                //                                   : 0),
                //                       child: controller.isNewsFeedScreen
                //                           ? NewsFeedMobile(
                //                               widget.controller: widget.controller,
                //                               postId: controller.linkId,
                //                             )
                //                           : controller.isTopWerfsScreen
                //                               ? NewsFeedMobile(
                //                                   widget.controller: widget.controller,
                //                                   postId: controller.linkId,
                //                                 )
                //                               : controller.isTrendsScreen
                //                                   ? MobileTrendsScreen(
                //                                       widget.controller: widget.controller)
                //                                   : controller.isWhoToFollowScreen
                //                                       ? WhoToFollow(
                //                                           controller: controller)
                //                                       : controller.isProfileScreen
                //                                           ? ProfileScreen(
                //                                               controller:
                //                                                   controller)
                //                                           : controller
                //                                                   .isBrowseScreen
                //                                               ? BrowseScreen(
                //                                                   controller:
                //                                                       controller)
                //                                               // ? MobileQuestScreen(controller: controller)
                //                                               : controller
                //                                                       .isNotificationScreen
                //                                                   ? NotificationScreen()
                //                                                   : controller
                //                                                           .isSavedPostScreen
                //                                                       ? MobileSavedPost(
                //                                                           newsFeedController:
                //                                                               controller,
                //                                                         )
                //                                                       : controller
                //                                                               .isChatScreen
                //                                                           ? MobileChatScreen()
                //                                                           : controller
                //                                                                   .isPostDetails
                //                                                               ?
                //                                                               //     controller.threadNumber==null?
                //                                                               //     CommentsScreen(thread_no: null,postId: controller.postId,)
                //                                                               // :CommentsScreen(thread_no: controller.threadNumber,postId: null,)
                //                                                               PostDetail(
                //                                                                   controller: controller,
                //                                                                   post: controller.postDetail,
                //                                                                 )
                //                                                               : controller.isFilterScreen
                //                                                                   ? FilteredScreen(newsfeedController: controller)
                //                                                                   : controller.isOtherUserProfileScreen
                //                                                                       ? OtherUsersProfile(
                //                                                                           controller: controller,
                //                                                                         )
                //                                                                       : controller.isClickWhoToFollow
                //                                                                           ? OtherUsersProfile(
                //                                                                               controller: controller,
                //                                                                             )
                //                                                                           : controller.isFollwerScreen
                //                                                                               ? FollowerScreen(controller: controller)
                //                                                                               : controller.isSettingsScreen
                //                                                                                   ? WebSettingsScreen(controller: controller)
                //                                                                                   : controller.isListScreen
                //                                                                                       ? ListScreen(
                //                                                                                           controller: controller,
                //                                                                                         )
                //                                                                                       : controller.isListDetailScreen
                //                                                                                           ? DiscoverListScreen(controller: controller)
                //                                                                                           : controller.isSuggestedListScreen
                //                                                                                               ? SuggestedListScreen(controller: controller)
                //                                                                                               : controller.isSuggestedListScreen
                //                                                                                                   ? SuggestedListScreen(controller: controller)
                //                                                                                                   : controller.isHiddenReplay
                //                                                                                                       ? HiddenReplay()
                //                                                                                                       : controller.isTopicScreen
                //                                                                                                           ? Topic_Tab_Screen()
                //                                                                                                           : controller.isTopicsCategoriesDetailsScreen
                //                                                                                                               ? TopicsCategoriesDetailsScreen()
                //                                                                                                               : controller.isMainTopicScreen
                //                                                                                                                   ? MainTopicScreen()
                //                                                                                                                   : controller.isTopicTrendingUserList
                //                                                                                                                       ? TopicTrendingUserList()
                //                                                                                                                       : controller.isOtherTopicTabScreen
                //                                                                                                                           ? OtherTopicTabScreen()
                //                                                                                                                           : controller.isOtherMainTopicScreen == true
                //                                                                                                                               ? OtherMainTopicScreen()
                //                                                                                                                               : controller.isCommunitesScreen
                //                                                                                                                                   ? MainCommunitiesScreen()
                //                                                                                                                                   : controller.isCommunityScreen
                //                                                                                                                                       ? CommunityScreen()
                //                                                                                                                                       : controller.isAllGroupScreen
                //                                                                                                                                           ? AllGroupScreen()
                //                                                                                                                                           : NewsFeedMobile(
                //                                                                                                                                               controller: controller,
                //                                                                                                                                             ),
                //                     ),
                //                   ),
                //             Container(
                //               width: 2,
                //               color: Colors.grey[200],
                //             ),
                //             controller.drawerLeftMoment == true
                //                 ? Container(
                //                     width: Get.width * 0.25,
                //                     child: controller.drawerLeftMoment == true &&
                //                             controller.editMomentScreen == true
                //                         ? EditMomentsScreen()
                //                         : controller.drawerLeftMoment == true &&
                //                                 controller.showMomentsScreen == true
                //                             ? ShowMomentsScreen()
                //                             : MomentsCreateScreen())
                //                 : !controller.isChatScreen &&
                //                         !controller.isSettingsScreen
                //                     ? WebNewsfeedRightSection(controller)
                //                     : Container(),
                //           ],
                //         );
                //       } else {
                //         return Row(
                //           children: [
                //             controller.drawerLeftMoment == true
                //                 ? momentsLeftSection(context, controller)
                //                 : webLeftSection(context, controller),
                //             Container(
                //               width: 2,
                //               color: Colors.grey[200],
                //             ),
                //             controller.drawerLeftMoment == true
                //                 ? Container(
                //                     width: Get.width * 0.45,
                //                     child: controller.getListMomentScreen == true &&
                //                             controller.drawerLeftMoment
                //                         ? MomentListScreen()
                //                         : AddMomentsScreen())
                //                 : Expanded(
                //                     child: Padding(
                //                       padding: EdgeInsets.symmetric(
                //                           horizontal:
                //                               controller.isSavedPostScreen ||
                //                                       controller.isChatScreen
                //                                   ? 0
                //                                   : 0),
                //                       child: controller.isNewsFeedScreen
                //                           ? NewsFeedMobile(
                //                               controller: controller,
                //                               postId: controller.linkId,
                //                             )
                //                           : controller.isTopWerfsScreen
                //                               ? NewsFeedMobile(
                //                                   controller: controller,
                //                                   postId: controller.linkId,
                //                                 )
                //                               : controller.isTrendsScreen
                //                                   ? MobileTrendsScreen(
                //                                       controller: controller)
                //                                   : controller.isWhoToFollowScreen
                //                                       ? WhoToFollow(
                //                                           controller: controller)
                //                                       : controller.isProfileScreen
                //                                           ? ProfileScreen(
                //                                               controller:
                //                                                   controller)
                //                                           : controller
                //                                                   .isBrowseScreen
                //                                               ? BrowseScreen(
                //                                                   controller:
                //                                                       controller)
                //                                               // ? MobileQuestScreen(controller: controller)
                //                                               : controller
                //                                                       .isNotificationScreen
                //                                                   ? NotificationScreen()
                //                                                   : controller
                //                                                           .isSavedPostScreen
                //                                                       ? MobileSavedPost(
                //                                                           newsFeedController:
                //                                                               controller,
                //                                                         )
                //                                                       : controller
                //                                                               .isChatScreen
                //                                                           ? MobileChatScreen()
                //                                                           : controller
                //                                                                   .isPostDetails
                //                                                               ?
                //                                                               //     controller.threadNumber==null?
                //                                                               //     CommentsScreen(thread_no: null,postId: controller.postId,)
                //                                                               // :CommentsScreen(thread_no: controller.threadNumber,postId: null,)
                //                                                               PostDetail(
                //                                                                   controller: controller,
                //                                                                   post: controller.postDetail,
                //                                                                 )
                //                                                               : controller.isFilterScreen
                //                                                                   ? FilteredScreen(newsfeedController: controller)
                //                                                                   : controller.isOtherUserProfileScreen
                //                                                                       ? OtherUsersProfile(
                //                                                                           controller: controller,
                //                                                                         )
                //                                                                       : controller.isClickWhoToFollow
                //                                                                           ? OtherUsersProfile(
                //                                                                               controller: controller,
                //                                                                             )
                //                                                                           : controller.isFollwerScreen
                //                                                                               ? FollowerScreen(controller: controller)
                //                                                                               : controller.isSettingsScreen
                //                                                                                   ? WebSettingsScreen(controller: controller)
                //                                                                                   : controller.isListScreen
                //                                                                                       ? ListScreen(
                //                                                                                           controller: controller,
                //                                                                                         )
                //                                                                                       : controller.isListDetailScreen
                //                                                                                           ? DiscoverListScreen(controller: controller)
                //                                                                                           : controller.isSuggestedListScreen
                //                                                                                               ? SuggestedListScreen(controller: controller)
                //                                                                                               : controller.isSuggestedListScreen
                //                                                                                                   ? SuggestedListScreen(controller: controller)
                //                                                                                                   : controller.isHiddenReplay
                //                                                                                                       ? HiddenReplay()
                //                                                                                                       : controller.isTopicScreen
                //                                                                                                           ? Topic_Tab_Screen()
                //                                                                                                           : controller.isTopicsCategoriesDetailsScreen
                //                                                                                                               ? TopicsCategoriesDetailsScreen()
                //                                                                                                               : controller.isMainTopicScreen
                //                                                                                                                   ? MainTopicScreen()
                //                                                                                                                   : controller.isTopicTrendingUserList
                //                                                                                                                       ? TopicTrendingUserList()
                //                                                                                                                       : controller.isOtherTopicTabScreen
                //                                                                                                                           ? OtherTopicTabScreen()
                //                                                                                                                           : controller.isOtherMainTopicScreen == true
                //                                                                                                                               ? OtherMainTopicScreen()
                //                                                                                                                               : controller.isCommunitesScreen
                //                                                                                                                                   ? MainCommunitiesScreen()
                //                                                                                                                                   : controller.isCommunityScreen
                //                                                                                                                                       ? CommunityScreen()
                //                                                                                                                                       : controller.isAllGroupScreen
                //                                                                                                                                           ? AllGroupScreen()
                //                                                                                                                                           : NewsFeedMobile(
                //                                                                                                                                               controller: controller,
                //                                                                                                                                             ),
                //                     ),
                //                   ),
                //             // Container(
                //             //   width: 2,
                //             //   color: Colors.grey[200],
                //             // ),
                //             // controller.drawerLeftMoment==true
                //             //     ? Container(
                //             //     width:Get.width*0.25 ,
                //             //     child:
                //             //     controller.drawerLeftMoment==true &&
                //             //         controller.editMomentScreen==true?
                //             //     EditMomentsScreen()
                //             //         : controller.drawerLeftMoment==true &&
                //             //         controller.showMomentsScreen==true?
                //             //     ShowMomentsScreen()
                //             //         :MomentsCreateScreen())
                //             //     : !controller.isChatScreen && !controller.isSettingsScreen
                //             //     ? WebNewsfeedRightSection(controller)
                //             //     : Container(),
                //           ],
                //         );
                //       }
                //     },
                //   ),
                // )
              ],
            ),
          ),
        ));
  }

  showDialogLoginWithPosh(BuildContext context){
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Login with WorldNoor'),
          content: Text('You are currently logged in with "${Get.find<NewsfeedController>().userName}" account. Do you want to stay logged in with this account or switch to WorldNoor?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                // Close the dialog
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();

                {
                  SharedPreferences preferences =
                      await SharedPreferences.getInstance();

                  await preferences.clear();
                  // await preferences.remove("userName");
                  // await preferences.remove("id");
                  await widget.controller.storage.erase();
                 await Get.delete<SessionController>();
                  await Get.delete<ProfileController>();
                  await Get.delete<NewsfeedController>();
                  widget.controller.update();
                  preferences.setBool('guestUser', true);
                  /*   Routemaster.of(context).replace(
                              AppRoute.guestUserMainScreen);*/
                  //Get.offNamed(FluroRouters.guestUserMainScreen);
                    if (kIsWeb) {
                      Get.offAll(GuestUserMainScreen(isFromPosh: widget.isFromPosh,poshID: widget.poshID,WNToken: widget.WNToken,),routeName: FluroRouters.guestUserMainScreen);
                      // context.pushReplacement(AppRoute.loginScreen);

                      // Routemaster.of(context).replace(AppRoute.guestUserMainScreen,);
                    } else {
                      Get.offUntil(
                          MaterialPageRoute(
                              builder: (context) => LoginScreen()),
                              (route) => false);
                    }

                }

              },
              child: Text('Switch to Worldnoor'),
            ),
          ],
        );
      },
    );
  }

  Future<bool> _onBackPressed(
      NewsfeedController controller, BuildContext context) async {
    // print("backpressed");

    if (kIsWeb) {
      if (controller.fromNotificationsScreen) {
        controller.isPostDetails = false;
        controller.isNewsFeedScreen = true;
        controller.fromNotificationsScreen = false;
        controller.isProfileScreen = false;

        controller.commentController.clear();
        controller.update();
        // Navigator.of(context).pop();
      } else {
        controller.isPostDetails = false;
        // print("backpressed");

        switch (controller.navRoute) {
          /*  case "isPostDetail":
            {
              onHomeChange = true;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = true;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
              controller.update();

              // controller.navRoute = "isNewsFeedScreen";
              */ /*  controller.searchText.text = '';
                controller.getNewsFeed(reload: false,isLoading:true);
                // controller.postList = await controller.getNewsFeed(reload: false);


                controller.
                postList.forEach((element) {
                  print('first screen2');
                  controller.threadNumber = element.thread_no;


                  element.rebuzz.value   = element.isRetweeted;
                  element.likeCount.value = element.simpleLikeCount;
                  element.rebuzzCount.value = element.retweetCount;
                  element.commentCount.value = element.commentsCount;
                  element.reactionType.value = element.isLiked;

                  element.comments.forEach((element) {
                    element.reactionType.value = element.isLiked;
                    element.commentCount.value = element.simpleLikeCount;
                  });

                  element.reactionType.refresh();
                  // if (element.isLiked == nul) {
                  //   element.like.value = true;
                  //
                  // }
                });
                print(controller.isPostDetails.toString()+"  postdetailvalue");
                // controller.update();*/ /*

              // Navigator.of(context).pop();
            }
            break;*/
          case "isNewsFeedScreen":
            {
              onHomeChange = true;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = true;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
              controller.update();

              // controller.navRoute = "isNewsFeedScreen";
              /*  controller.searchText.text = '';
                controller.getNewsFeed(reload: false,isLoading:true);
                // controller.postList = await controller.getNewsFeed(reload: false);


                controller.
                postList.forEach((element) {
                  print('first screen2');
                  controller.threadNumber = element.thread_no;


                  element.rebuzz.value   = element.isRetweeted;
                  element.likeCount.value = element.simpleLikeCount;
                  element.rebuzzCount.value = element.retweetCount;
                  element.commentCount.value = element.commentsCount;
                  element.reactionType.value = element.isLiked;

                  element.comments.forEach((element) {
                    element.reactionType.value = element.isLiked;
                    element.commentCount.value = element.simpleLikeCount;
                  });

                  element.reactionType.refresh();
                  // if (element.isLiked == nul) {
                  //   element.like.value = true;
                  //
                  // }
                });
                print(controller.isPostDetails.toString()+"  postdetailvalue");
                // controller.update();*/

              // Navigator.of(context).pop();
            }
            break;

          case "isTrendsScreen":
            {
              onTrendsChange = true;
              // controller.update();
              onHomeChange = false;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.isTrendsScreen = true;
              controller.isNewsFeedScreen = false;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
              // controller.update();
            }
            break;

          case "isQuestScreen":
            {
              onHomeChange = false;
              onBrowsChange = true;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = false;
              controller.isBrowseScreen = true;
              controller.isNotificationScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
              // controller.update();
            }
            break;

          case "isSavedPostScreen":
            {
              onHomeChange = false;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = true;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = false;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = true;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
              // controller.update();
            }
            break;
          case "isNotificationScreen":
            {
              onHomeChange = false;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = true;
              onMoreChange = false;

              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = false;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = true;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
            }
            break;
          case "isChatScreen":
            {
              onHomeChange = false;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = true;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = false;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = false;
              controller.isChatScreen = true;
              controller.isSavedPostScreen = false;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
              // controller.update();
            }
            break;

          default:
            {
              onHomeChange = true;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = true;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;
              controller.isPostDetails = false;
              controller.isProfileScreen = false;
              controller.isOtherUserProfileScreen = false;
              print("Invalid choice");
            }
            break;
        }
        int counter = controller.detailPageCounter;
        controller.detailPageCounter = 0;
        if (counter == 0) {
          Get.back();
        } else {
          for (int i = 0; i < counter; i++) {
            print("counter: " + i.toString());
            Get.back();
          }
        }
        // Get.back();

        // Get.offNamed(FluroRouters.mainScreen);

        // Navigator.of(context).pop();
        //
      }
    } else {
      controller.commentController.clear();
      controller.update();
      Navigator.of(context).pop();
    }
    return Future.value(true);
  }

  Container webLeftSection(
      BuildContext context, NewsfeedController controller) {
    String userFirstName = controller.userProfile != null
        ? controller.userProfile.username != null
            ? '${controller.userProfile.firstname} ' +
                '${controller.userProfile.lastname == null ? '' : controller.userProfile.lastname}'
            : ''
        : '';
    String userName = controller.userProfile != null
        ? controller.userProfile.username != null
            ? '@${controller.userProfile.username}'
            : ''
        : '';
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width < 1212 ? 70 : 230,
      child: SingleChildScrollView(
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.only(left: 1),
              child: GestureDetector(
                onTap: () async {
                  if (widget.page != "feeds" || widget.page != "home") {
                    controller.getNewsFeed(shouldUpdate: true, reload: true);

                    Get.toNamed(FluroRouters.mainScreen + "/feeds");
                  } else {
                    controller.getNewsFeed(shouldUpdate: true, reload: true);
                  }

                  /* onProfileChange = false;
                  onChatsChange = false;
                  onBookMarksChange = false;
                  onTrendsChange = false;
                  onHomeChange = true;
                  onBrowsChange = false;
                  onMoreChange = false;
                  onNotificationChange = false;
                  onListChange = false;
                  onSettingChange = false;

                  controller.drawerLeftMoment = false;
                  controller.isSearch = false;
                  controller.isFilter = false;
                  controller.isFilterScreen = false;
                  controller.isTrendsScreen = false;
                  controller.isNewsFeedScreen = true;
                  controller.isWhoToFollowScreen = false;
                  controller.isBrowseScreen = false;
                  controller.isNotificationScreen = false;
                  controller.isChatScreen = false;
                  controller.isSavedPostScreen = false;
                  controller.isPostDetails = false;
                  controller.isProfileScreen = false;
                  controller.isFollwerScreen = false;
                  controller.isSettingsScreen = false;

                  // controller.i = false;
                  controller.navRoute = "isNewsFeedScreen";
                  controller.searchText.text = '';

                  controller.postList = await controller.getNewsFeed(
                      reload: true, shouldUpdate: true);
                  controller.postList.forEach((element) {
                    print('first screen1');
                    controller.threadNumber = element.thread_no;
                    print('thread number:${ controller.threadNumber}');
                    element.rebuzz.value = element.isRetweeted;
                    element.likeCount.value = element.simpleLikeCount;
                    element.rebuzzCount.value = element.retweetCount;
                    element.commentCount.value = element.commentsCount;

                    element.reactionType.value = element.isLiked;

                    // element.comments.forEach((element) {
                    //   element.reactionType.value = element.isLiked;
                    //   element.commentCount.value = element.simpleLikeCount;
                    // });

                    element.reactionCheck.refresh();

                    controller.update();

                    // element.reactionCheck.value = false;
                    // if (element.isLiked == true) {
                    //   element.like.value = true;
                    //   element.like.refresh();
                    // }
                  });

                  if (Get.isRegistered<MomentsListController>()) {
                    Get.delete<MomentsListController>();
                  }
                  if (Get.isRegistered<AddMomentsController>()) {
                    Get.delete<AddMomentsController>();
                  }*/
                },
                child: MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: Container(
                    alignment: controller.languageData.appLang.id == 2
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 15),
                      child: Image.asset(
                        Theme.of(context).brightness == Brightness.dark?
                        AppImages.simpleWhiteWLogo:AppImages.simpleBlackWLogo,
                        width: 55,
                        height: 30,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // MediaQuery.of(context).size.width < 1370
            //     ? SizedBox()
            //     : MouseRegion(
            //         cursor: SystemMouseCursors.click,
            //         child: GestureDetector(
            //           onTap: () async{
            //             onHomeChange = false;
            //             onBrowsChange = false;
            //             onTrendsChange = false;
            //             onBookMarksChange = false;
            //             onChatsChange = false;
            //             onProfileChange = true;
            //             onSettingChange = false;
            //             onListChange = false;
            //             onNotificationChange = false;
            //             onMoreChange = false;
            //
            //             controller.isSearch = false;
            //             controller.isFilter = false;
            //             controller.isFilterScreen = false;
            //             controller.isTrendsScreen = false;
            //             controller.isNewsFeedScreen = false;
            //             controller.isTopWerfsScreen = false;
            //             controller.isListScreen = false;
            //             controller.isBrowseScreen = false;
            //             controller.isNotificationScreen = false;
            //             controller.isSavedPostScreen = false;
            //             controller.isChatScreen = false;
            //             controller.isPostDetails = false;
            //             controller.isFollwerScreen = false;
            //             controller.isProfileScreen = true;
            //             controller.isSettingsScreen = false;
            //             controller.isListDetailScreen = false;
            //             controller.isTopicScreen = false;
            //             controller.isCommunitesScreen = false;
            //             controller.isWhoToFollowScreen = false;
            //             controller.navRoute = "isProfileScreen";
            //
            //
            //             if (Get.isRegistered<ProfileController>()) {
            //
            //
            //               Get.find<ProfileController>().userProfile = await controller.getUserProfile();
            //
            //               await Get.find<ProfileController>().filterUsersPost("posts");
            //               Get.find<ProfileController>().userPosts.forEach((element) {
            //                 element.likeCount.value = element.simpleLikeCount;
            //                 element.rebuzzCount.value = element.retweetCount;
            //                 element.commentCount.value = element.commentsCount;
            //                 element.reactionType.value = element.isLiked;
            //                 element.comments.forEach((element) {
            //                   element.reactionType.value = element.isLiked;
            //                   element.commentCount.value  = element.simpleLikeCount;
            //                 });
            //                 element.reactionType.refresh();
            //
            //                 // if (element.isLiked == true) {
            //                 //   element.like.value = true;
            //                 //   element.like.refresh();
            //                 // }
            //               });
            //               Get.find<ProfileController>().update();
            //
            //
            //             }else{
            //
            //
            //               print("vvvvv");
            //               Get.put(ProfileController());
            //               Get.find<ProfileController>().userProfile = await controller.getUserProfile();
            //
            //
            //               await Get.find<ProfileController>().filterUsersPost("posts");
            //               Get.find<ProfileController>().userPosts.forEach((element) {
            //                 element.likeCount.value = element.simpleLikeCount;
            //                 element.rebuzzCount.value = element.retweetCount;
            //                 element.commentCount.value = element.commentsCount;
            //                 element.reactionType.value = element.isLiked;
            //                 element.comments.forEach((element) {
            //                   element.reactionType.value = element.isLiked;
            //                   element.commentCount.value  = element.simpleLikeCount;
            //                 });
            //                 element.reactionType.refresh();
            //
            //                 // if (element.isLiked == true) {
            //                 //   element.like.value = true;
            //                 //   element.like.refresh();
            //                 // }
            //               });
            //               Get.find<ProfileController>().update();
            //
            //
            //             }
            //
            //
            //             controller.update();
            //           },
            //           child: Align(
            //               alignment: Alignment.center,
            //               child: controller.userProfile == null
            //                   ? Container(
            //                       width: 24,
            //                       child: Center(
            //                         child: SpinKitCircle(
            //                           color: Colors.grey,
            //                           size: 40,
            //                         ),
            //                       ))
            //                   : controller.userProfile.profileImage == null
            //                       ? CircleAvatar(
            //                           radius: 36,
            //                           backgroundImage: AssetImage(
            //                               "assets/images/person_placeholder.png"))
            //                       : ClipRRect(
            //                           borderRadius: BorderRadius.circular(50),
            //                           child: FadeInImage(
            //                               fit: BoxFit.cover,
            //                               width: 80,
            //                               height: 80,
            //                               placeholder: AssetImage(
            //                                   'assets/images/person_placeholder.png'),
            //                               image: NetworkImage(controller
            //                                           .userProfile
            //                                           .profileImage !=
            //                                       null
            //                                   ? controller
            //                                       .userProfile.profileImage
            //                                   : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
            //                         )),
            //         ),
            //       ),
            // SizedBox(height: 6),
            // MediaQuery.of(context).size.width < 1370
            //     ? SizedBox()
            //     : controller.userProfile == null
            //         ? SizedBox()
            //         : MouseRegion(
            //   cursor: SystemMouseCursors.click,
            //
            //   child: GestureDetector(
            //               onTap: () async {
            //                 onHomeChange = false;
            //                 onBrowsChange = false;
            //                 onTrendsChange = false;
            //                 onBookMarksChange = false;
            //                 onChatsChange = false;
            //                 onProfileChange = true;
            //                 onSettingChange = false;
            //                 onListChange = false;
            //                 onNotificationChange = false;
            //                 onMoreChange = false;
            //
            //                 controller.isSearch = false;
            //                 controller.isFilter = false;
            //                 controller.isFilterScreen = false;
            //                 controller.isTrendsScreen = false;
            //                 controller.isNewsFeedScreen = false;
            //                 controller.isTopWerfsScreen = false;
            //                 controller.isBrowseScreen = false;
            //                 controller.isNotificationScreen = false;
            //                 controller.isSavedPostScreen = false;
            //                 controller.isChatScreen = false;
            //                 controller.isListScreen = false;
            //                 controller.isPostDetails = false;
            //                 controller.isFollwerScreen = false;
            //                 controller.isProfileScreen = true;
            //                 controller.isSettingsScreen = false;
            //                 controller.isListDetailScreen = false;
            //                 controller.isTopicScreen = false;
            //                 controller.isWhoToFollowScreen = false;
            //                 controller.navRoute = "isProfileScreen";
            //                 if (Get.isRegistered<ProfileController>()) {
            //
            //
            //                   Get.find<ProfileController>().userProfile = await controller.getUserProfile();
            //
            //                   await Get.find<ProfileController>().filterUsersPost("posts");
            //                   Get.find<ProfileController>().userPosts.forEach((element) {
            //                     element.likeCount.value = element.simpleLikeCount;
            //                     element.rebuzzCount.value = element.retweetCount;
            //                     element.commentCount.value = element.commentsCount;
            //                     element.reactionType.value = element.isLiked;
            //                     element.comments.forEach((element) {
            //                       element.reactionType.value = element.isLiked;
            //                       element.commentCount.value  = element.simpleLikeCount;
            //                     });
            //                     element.reactionType.refresh();
            //
            //                     // if (element.isLiked == true) {
            //                     //   element.like.value = true;
            //                     //   element.like.refresh();
            //                     // }
            //                   });
            //                   Get.find<ProfileController>().update();
            //
            //
            //                 }else{
            //
            //
            //                   print("vvvvv");
            //                   Get.put(ProfileController());
            //                   Get.find<ProfileController>().userProfile = await controller.getUserProfile();
            //
            //
            //                   await Get.find<ProfileController>().filterUsersPost("posts");
            //                   Get.find<ProfileController>().userPosts.forEach((element) {
            //                     element.likeCount.value = element.simpleLikeCount;
            //                     element.rebuzzCount.value = element.retweetCount;
            //                     element.commentCount.value = element.commentsCount;
            //                     element.reactionType.value = element.isLiked;
            //                     element.comments.forEach((element) {
            //                       element.reactionType.value = element.isLiked;
            //                       element.commentCount.value  = element.simpleLikeCount;
            //                     });
            //                     element.reactionType.refresh();
            //
            //                     // if (element.isLiked == true) {
            //                     //   element.like.value = true;
            //                     //   element.like.refresh();
            //                     // }
            //                   });
            //                   Get.find<ProfileController>().update();
            //
            //
            //                 }
            //                 controller.update();
            //               },
            //               child: Align(
            //                 alignment: Alignment.center,
            //                 child: Padding(
            //                   padding: controller.userProfile.accountVerified ==
            //                           "verified"
            //                       ? const EdgeInsets.only(left: 20)
            //                       : EdgeInsets.zero,
            //                   child: Row(
            //                     mainAxisAlignment: MainAxisAlignment.center,
            //                     children: [
            //                       Text(
            //                           controller.userProfile != null
            //                               ? controller.userProfile.username !=
            //                                       null
            //                                   ? '${controller.userProfile.firstname} ' +
            //                                       '${controller.userProfile.lastname == null ? '' : controller.userProfile.lastname}'
            //                                   : ''
            //                               : '',
            //                           style:
            //                               Styles.baseTextTheme.headline1.copyWith(
            //                             color: Theme.of(context).brightness ==
            //                                     Brightness.dark
            //                                 ? Colors.white
            //                                 : Colors.black,
            //                             fontSize: 18,
            //                             height: 1.5,
            //                           )
            //                           // TextStyle(
            //                           //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
            //                           //   fontWeight: FontWeight.bold,
            //                           //   fontSize: 18,
            //                           //   height: 1.5,
            //                           // ),
            //                           ),
            //                       controller.userProfile.accountVerified ==
            //                               "verified"
            //                           ? BlueTick(
            //                               height: 16,
            //                               width: 16,
            //                               iconSize: 10,
            //                             )
            //                           : SizedBox(),
            //                     ],
            //                   ),
            //                 ),
            //               ),
            //             ),
            //         ),
            // // SizedBox(height: 2),
            // MediaQuery.of(context).size.width < 1370
            //     ? SizedBox()
            //     : MouseRegion(
            //   cursor: SystemMouseCursors.click,
            //   child: MouseRegion(
            //
            //   child: GestureDetector(
            //             onTap: () async {
            //               onHomeChange = false;
            //               onBrowsChange = false;
            //               onTrendsChange = false;
            //               onBookMarksChange = false;
            //               onChatsChange = false;
            //               onProfileChange = true;
            //               onSettingChange = false;
            //               onListChange = false;
            //               onNotificationChange = false;
            //               onMoreChange = false;
            //
            //               controller.isSearch = false;
            //               controller.isFilter = false;
            //               controller.isFilterScreen = false;
            //               controller.isTrendsScreen = false;
            //               controller.isNewsFeedScreen = false;
            //               controller.isTopWerfsScreen = false;
            //               controller.isBrowseScreen = false;
            //               controller.isNotificationScreen = false;
            //               controller.isSavedPostScreen = false;
            //               controller.isChatScreen = false;
            //               controller.isPostDetails = false;
            //               controller.isFollwerScreen = false;
            //               controller.isListScreen = false;
            //               controller.isListDetailScreen = false;
            //               controller.isProfileScreen = true;
            //               controller.isSettingsScreen = false;
            //               controller.isTopicScreen = false;
            //               controller.isWhoToFollowScreen = false;
            //               controller.isCommunitesScreen = false;
            //               controller.navRoute = "isProfileScreen";
            //               if (Get.isRegistered<ProfileController>()) {
            //
            //
            //                 Get.find<ProfileController>().userProfile = await controller.getUserProfile();
            //
            //                 await Get.find<ProfileController>().filterUsersPost("posts");
            //                 Get.find<ProfileController>().userPosts.forEach((element) {
            //                   element.likeCount.value = element.simpleLikeCount;
            //                   element.rebuzzCount.value = element.retweetCount;
            //                   element.commentCount.value = element.commentsCount;
            //                   element.reactionType.value = element.isLiked;
            //                   element.comments.forEach((element) {
            //                     element.reactionType.value = element.isLiked;
            //                     element.commentCount.value  = element.simpleLikeCount;
            //                   });
            //                   element.reactionType.refresh();
            //
            //                   // if (element.isLiked == true) {
            //                   //   element.like.value = true;
            //                   //   element.like.refresh();
            //                   // }
            //                 });
            //                 Get.find<ProfileController>().update();
            //
            //
            //               }else{
            //
            //
            //                 print("vvvvv");
            //                 Get.put(ProfileController());
            //                 Get.find<ProfileController>().userProfile = await controller.getUserProfile();
            //
            //
            //                 await Get.find<ProfileController>().filterUsersPost("posts");
            //                 Get.find<ProfileController>().userPosts.forEach((element) {
            //                   element.likeCount.value = element.simpleLikeCount;
            //                   element.rebuzzCount.value = element.retweetCount;
            //                   element.commentCount.value = element.commentsCount;
            //                   element.reactionType.value = element.isLiked;
            //                   element.comments.forEach((element) {
            //                     element.reactionType.value = element.isLiked;
            //                     element.commentCount.value  = element.simpleLikeCount;
            //                   });
            //                   element.reactionType.refresh();
            //
            //                   // if (element.isLiked == true) {
            //                   //   element.like.value = true;
            //                   //   element.like.refresh();
            //                   // }
            //                 });
            //                 Get.find<ProfileController>().update();
            //
            //
            //               }
            //               controller.update();
            //             },
            //             child: Align(
            //               alignment: Alignment.center,
            //               child: Row(
            //                 mainAxisAlignment: MainAxisAlignment.center,
            //                 children: [
            //                   Text(
            //                       controller.userProfile != null
            //                           ? controller.userProfile.username != null
            //                               ? '@${controller.userProfile.username}'
            //                               : ''
            //                           : '',
            //                       style: Styles.baseTextTheme.headline2.copyWith(
            //                         fontSize: 16,
            //                       )
            //                       // TextStyle(
            //                       //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
            //                       //   fontWeight: FontWeight.w400,
            //                       //   fontSize: 16,
            //                       // ),
            //                       ),
            //                   !kIsWeb
            //                       ?
            //                       // controller.userProfile.accountVerified =="verified"?
            //                       BlueTick(
            //                           height: 16,
            //                           width: 16,
            //                           iconSize: 10,
            //                         ) /*:SizedBox()*/ : SizedBox(),
            //                 ],
            //               ),
            //             ),
            //           ),
            //       ),
            //     ),
            ////left options
            videoCallWidget(context),
            Tooltip(
              message:
                  MediaQuery.of(context).size.width < 1280 ? Strings.home : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading:  WebSideDrawersIcons(controller.isNewsFeedScreen
                    ?"assets/drawer_icons_new/home_fill.png":"assets/drawer_icons_new/home.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.home,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onHomeChange == false ? 18 : 20,
                          fontWeight: onHomeChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                      ),
                onTap: () {
                  onHomeChange = true;
                  onBrowsChange = false;
                  onTrendsChange = false;
                  onBookMarksChange = false;
                  onChatsChange = false;
                  onProfileChange = false;
                  onSettingChange = false;
                  onListChange = false;
                  onNotificationChange = false;
                  onMoreChange = false;
                  if (Get.isRegistered<MobileCommentsController>()) {

                    // print("delete hua hai");
                    Get.delete<MobileCommentsController>();
                  }

                  controller.navRoute = "isNewsFeedScreen";
                  Get.toNamed(FluroRouters.mainScreen + "/feeds");
                  // Get.toNamed(FluroRouters.generateSideNavPath(page: "feeds"));
                  // Get.toNamed(FluroRouters.root+"?page=feeds");

                  // controller.update();
                },
              ),

              // SizedBox(height: 10),
              // ListTile(
              //   contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              //   shape: RoundedRectangleBorder(
              //     borderRadius: BorderRadius.circular(4),
              //   ),
              //   horizontalTitleGap: 18,
              //   leading: !controller.isNewsFeedScreen
              //       ? Container(
              //           width: 24,
              //           height: 24,
              //           child: Image.asset('assets/drawer_icons/Home.png'),
              //         )
              //       : Container(
              //           width: 24,
              //           height: 24,
              //           child: Image.asset('assets/drawer_icons/Home.png'),
              //         ),
              //   title: MediaQuery.of(context).size.width < 1370
              //       ? SizedBox()
              //       : Text(
              //           "Top Werfs",
              //     style: Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,  fontSize: 18,
              //       fontWeight: FontWeight.w700,) : TextStyle(color: Colors.black,  fontSize: 18,
              //       ),
              //           // style: TextStyle(
              //           //   // fontWeight: controller.isNewsFeedScreen,
              //           //   // ? FontWeight.bold
              //           //   // : FontWeight.normal,
              //           //   fontSize: 18,
              //           //   color: controller.isNewsFeedScreen
              //           //       ? Color(0xFFedab30)
              //           //       : Colors.black,
              //           //   // fontWeight: FontWeight.w900,
              //           // ),
              //         ),
              //   onTap: () {
              //     controller.isSearch = false;
              //     controller.isFilter = false;
              //     controller.isFilterScreen = false;
              //     controller.isTrendsScreen = false;
              //     controller.isNewsFeedScreen = false;
              //     controller.isTopWerfsScreen = true;
              //     controller.isWhoToFollowScreen = false;
              //     controller.isBrowseScreen = false;
              //     controller.isNotificationScreen = false;
              //     controller.isListScreen = false;
              //     controller.isChatScreen = false;
              //     controller.isSavedPostScreen = false;
              //     controller.isListDetailScreen = false;
              //     controller.isPostDetails = false;
              //     controller.isProfileScreen = false;
              //     controller.isFollwerScreen = false;
              //     controller.isSettingsScreen = false;
              //     controller.isTopicScreen = false;
              //     controller.navRoute = "isNewsFeedScreen";
              //     controller.searchText.text = '';
              //     controller.getNewsFeed(shouldUpdate: true, reload: true);
              //     // controller.update();
              //   },
              // ),
            ),
            SizedBox(height: 10),
            Tooltip(
              message: MediaQuery.of(context).size.width < 1280
                  ? Strings.explore
                  : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal:12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading: WebSideDrawersIcons(controller.isBrowseScreen
                    ?"assets/drawer_icons_new/explore_fill.png":"assets/drawer_icons_new/explore.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.explore,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onBrowsChange == false ? 18 : 20,
                          fontWeight: onBrowsChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                      ),
                onTap: () {
                  onBrowsChange == true;
                  controller.navRoute = "isQuestScreen";
                  Get.toNamed(FluroRouters.mainScreen + '/browse');


                },
              ),
            ),
               SizedBox(height: 10),
            Tooltip(
              message:MediaQuery.of(context).size.width < 1280? Strings.hotTrends:"",

              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading: WebSideDrawersIcons(controller.isTrendsScreen
                    ?"assets/drawer_icons_new/hashtag_fill.png":"assets/drawer_icons_new/hashtag.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),

                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                  Strings.hotTrends,
                  style: TextStyle(
                    color:
                    Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: onTrendsChange == false ? 18 : 20,
                    fontWeight: onTrendsChange == false
                        ? FontWeight.w400
                        : FontWeight.bold,
                  ),
                ),
                onTap: () {
                  onTrendsChange = true;

                  controller.navRoute = "isTrendsScreen";

                  Get.toNamed(FluroRouters.mainScreen + '/trends');
                },
              ),
            ),
            SizedBox(height: 10),
            Tooltip(
              message: MediaQuery.of(context).size.width < 1280
                  ? Strings.bookmarks
                  : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading: WebSideDrawersIcons(controller.isSavedPostScreen
                    ?"assets/drawer_icons_new/bookmark_fill.png":"assets/drawer_icons_new/bookmark.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.bookmarks,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onBookMarksChange == false ? 18 : 20,
                          fontWeight: onBookMarksChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                      ),
                onTap: () {
                  //  onBookMarksChange = true;
                  /*     onTrendsChange = false;
                      onHomeChange = false;
                      onBrowsChange = false;
                      onMoreChange = false;
                      onNotificationChange = false;
                      onListChange = false;
                      onSettingChange = false;
                      onProfileChange = false;
                      onChatsChange = false;
                      controller.isSearch = false;
                      controller.isFilter = false;
                      controller.isFilterScreen = false;
                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = false;
                      controller.isTopWerfsScreen = false;
                      controller.isBrowseScreen = false;
                      controller.isNotificationScreen = false;
                      controller.isSavedPostScreen = true;
                      controller.isWhoToFollowScreen = false;
                      controller.isChatScreen = false;
                      controller.isPostDetails = false;
                      controller.searchText.text = '';
                      controller.isListScreen = false;
                      controller.isListDetailScreen = false;
                      controller.isProfileScreen = false;
                      controller.isFollwerScreen = false;
                      controller.isSettingsScreen = false;
                      controller.isTopicScreen = false;
                      controller.isCommunitesScreen = false;
                      controller.navRoute = "isSavedPostScreen";
                      controller.update();*/
                  // Get.toNamed(FluroRouters.mainScreen +"/savedPost");
                  controller.navRoute = "isSavedPostScreen";

                  Get.toNamed(FluroRouters.mainScreen + '/savedPost');
                },
              ),
            ),
            SizedBox(height: 10),
            Tooltip(
              message: MediaQuery.of(context).size.width < 1280
                  ? Strings.spaces
                  : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading: WebSideDrawersIcons(controller.isSpacesScreen
                    ?"assets/drawer_icons_new/spaces_fill.png":"assets/drawer_icons_new/spaces.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.spaces,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onSpacesScreen == false ? 18 : 20,
                          fontWeight: onSpacesScreen == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                      ),
                onTap: () {

                  controller.navRoute = "isSpacesScreen";

                  Get.toNamed(FluroRouters.mainScreen + '/spaces');
                },
              ),
            ),
            // SizedBox(height: 10),
            // ListTile(
            //   contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
            //   shape: RoundedRectangleBorder(
            //     borderRadius: BorderRadius.circular(4),
            //   ),
            //   horizontalTitleGap: 18,
            //   leading: !controller.isCommunitesScreen
            //       ? Container(
            //     width: 24,
            //     height: 24,
            //     child: Image.asset('assets/drawer_icons/saved.png'),
            //   )
            //       : Container(
            //     width: 24,
            //     height: 24,
            //     child: Image.asset('assets/drawer_icons/saved.png'),
            //   ),
            //   title: MediaQuery.of(context).size.width < 1370
            //       ? SizedBox()
            //       : Text(
            //     Strings.communities,
            //
            //     style: Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,  fontSize: 18,
            //       fontWeight: FontWeight.w700,) : TextStyle(color: Colors.black,  fontSize: 18,
            //     // style: TextStyle(
            //     //   color: controller.isCommunitesScreen,
            //     //
            //     // ),
            //       // fontWeight: FontWeight.w900,
            //       // fontWeight: controller.isSavedPostScreen
            //       //     ? FontWeight.bold
            //       //     : FontWeight.normal,
            //     ),
            //   ),
            //   onTap: () {
            //
            //
            //     if (Get.isRegistered<CommunitiesController>()) {
            //        Get.delete<CommunitiesController>();
            //        Get.put(CommunitiesController());
            //     }
            //     // else
            //     // {
            //     //   final addMomentController =Get.put(AddMomentsController());
            //     //   addMomentController.addId=[];
            //     //   SingleTone.instance.momentId=null;
            //     //   addMomentController.update();
            //     //
            //     // }
            //
            //     controller.isSearch = false;
            //     controller.isFilter = false;
            //     controller.isFilterScreen = false;
            //     controller.isTrendsScreen = false;
            //     controller.isNewsFeedScreen = false;
            //     controller.isTopWerfsScreen = false;
            //     controller.isBrowseScreen = false;
            //     controller.isNotificationScreen = false;
            //     controller.isSavedPostScreen = false;
            //     controller.isWhoToFollowScreen = false;
            //     controller.isChatScreen = false;
            //     controller.isPostDetails = false;
            //     controller.searchText.text = '';
            //     controller.isListScreen = false;
            //     controller.isListDetailScreen = false;
            //     controller.isProfileScreen = false;
            //     controller.isFollwerScreen = false;
            //     controller.isSettingsScreen = false;
            //     controller.isTopicScreen = false;
            //     controller.isOtherUserProfileScreen = false;
            //     controller.isTopicsCategoriesDetailsScreen = false;
            //     controller.isMainTopicScreen = false;
            //
            //
            //
            //     controller.isCommunitesScreen = true;
            //
            //
            //
            //
            //
            //     controller.navRoute = "isCommunitiesScreen";
            //     controller.update();
            //   },
            // ),

            const SizedBox(height: 10),
            Tooltip(
              message:
                  MediaQuery.of(context).size.width < 1280 ? Strings.chats : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal:12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading: WebSideDrawersIcons(controller.isChatScreen
                    ?"assets/drawer_icons_new/chat_fill.png":"assets/drawer_icons_new/chat.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.chats,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onChatsChange == false ? 18 : 20,
                          fontWeight: onChatsChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                      ),
                onTap: () async {
                  onChatsChange = true;
                  /* onBookMarksChange = false;
                      onTrendsChange = false;
                      onHomeChange = false;

                  onBrowsChange = false;
                  onMoreChange = false;
                  onNotificationChange = false;
                  onListChange = false;
                  onSettingChange = false;
                  onProfileChange = false;

                      controller.isSearch = false;
                      controller.isFilter = false;
                      controller.isFilterScreen = false;
                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = false;
                      controller.isTopWerfsScreen = false;
                      controller.isBrowseScreen = false;
                      controller.isNotificationScreen = false;
                      controller.isWhoToFollowScreen = false;
                      controller.isSavedPostScreen = false;
                      controller.isChatScreen = true;
                      controller.isPostDetails = false;
                      controller.isProfileScreen = false;
                      controller.searchText.text = '';
                      controller.isListScreen = false;
                      controller.isListDetailScreen = false;
                      controller.isFollwerScreen = false;
                      controller.isSettingsScreen = false;
                      controller.isCommunitesScreen = false;
                      controller.isTopicScreen = false;
                      controller.navRoute = "isChatScreen";
                      controller.chatUserList = await controller.getChat();
                      print(
                          " controller.chatUserList ${controller.chatUserList}");
                      // print("preesssseddd");
                      controller.update();*/
                  controller.navRoute = "isChatScreen";

                  Get.toNamed(FluroRouters.mainScreen + '/chats');
                },
              ),
            ),
            SizedBox(height: 10),
            Tooltip(
              message: MediaQuery.of(context).size.width < 1280
                  ? Strings.myProfile
                  : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading:WebSideDrawersIcons(controller.isProfileScreen
                    ?"assets/drawer_icons_new/profile_fill.png":"assets/drawer_icons_new/profile.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.myProfile,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onProfileChange == false ? 18 : 20,
                          fontWeight: onProfileChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                      ),
                onTap: () async {
                  onProfileChange = true;
                  controller.navRoute = "isProfileScreen";
                  //
                  Get.toNamed(FluroRouters.mainScreen + '/profile');

                  // SingleTone.instance.userId = GetStorage().read('id').toString();

                  // Get.toNamed(FluroRouters.mainScreen + "/profile/" + GetStorage().read('id').toString());

                  /* onChatsChange = false;
                      onBookMarksChange = false;
                      onTrendsChange = false;
                      onHomeChange = false;
                      onBrowsChange = false;
                      onMoreChange = false;
                      onNotificationChange = false;
                      onListChange = false;
                      onSettingChange = false;
                      controller.isSearch = false;
                      controller.isFilter = false;
                      controller.isFilterScreen = false;
                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = false;
                      controller.isTopWerfsScreen = false;
                      controller.isBrowseScreen = false;
                      controller.isNotificationScreen = false;
                      controller.isWhoToFollowScreen = false;
                      controller.isSavedPostScreen = false;
                      controller.isChatScreen = false;
                      controller.searchText.text = '';
                      controller.isPostDetails = false;
                      controller.isFollwerScreen = false;
                      controller.isProfileScreen = true;
                      controller.isSettingsScreen = false;
                      controller.isCommunitesScreen = false;
                      controller.isTopicScreen = false;
                      controller.isListScreen = false;
                      controller.navRoute = "isProfileScreen";


                  if (Get.isRegistered<ProfileController>()) {



                    print("agiya");

                    Get.find<ProfileController>().userProfile = await controller.getUserProfile();

                    Get.find<ProfileController>(). isHiddenPost = false;
                    Get.find<ProfileController>().isTweets = true;
                    Get.find<ProfileController>().isTweetsReply = false;
                    Get.find<ProfileController>().isMedia = false;
                    Get.find<ProfileController>().isLikes = false;

                    Get.find<ProfileController>().selectedTab = "isTweets";

                    await Get.find<ProfileController>().filterUsersPost("posts");
                    Get.find<ProfileController>().userPosts.forEach((element) {
                      element.likeCount.value = element.simpleLikeCount;
                      element.rebuzzCount.value = element.retweetCount;
                      element.commentCount.value = element.commentsCount;
                      element.reactionType.value = element.isLiked;
                      element.comments.forEach((element) {
                        element.reactionType.value = element.isLiked;
                        element.commentCount.value  = element.simpleLikeCount;
                      });
                      element.reactionType.refresh();

                      // if (element.isLiked == true) {
                      //   element.like.value = true;
                      //   element.like.refresh();
                      // }
                    });
                    Get.find<ProfileController>().update();


                  }
                  else{


                    print("vvvvv");
                    Get.put(ProfileController());
                    Get.find<ProfileController>().userProfile = await controller.getUserProfile();


                    await Get.find<ProfileController>().filterUsersPost("posts");
                    Get.find<ProfileController>().userPosts.forEach((element) {
                      element.likeCount.value = element.simpleLikeCount;
                      element.rebuzzCount.value = element.retweetCount;
                      element.commentCount.value = element.commentsCount;
                      element.reactionType.value = element.isLiked;
                      element.comments.forEach((element) {
                        element.reactionType.value = element.isLiked;
                        element.commentCount.value  = element.simpleLikeCount;
                      });
                      element.reactionType.refresh();

                      // if (element.isLiked == true) {
                      //   element.like.value = true;
                      //   element.like.refresh();
                      // }
                    });
                    Get.find<ProfileController>().update();


                  }

                      controller.update();*/
                },
              ),
            ),
            SizedBox(height: 10),
            Tooltip(
              message: MediaQuery.of(context).size.width < 1280
                  ? Strings.settings
                  : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading:WebSideDrawersIcons(controller.isSettingsScreen
                    ?"assets/drawer_icons_new/settings_fill.png":"assets/drawer_icons_new/settings.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.settings,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onSettingChange == false ? 18 : 20,
                          fontWeight: onSettingChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                      ),
                onTap: () {
                  onSettingChange = true;
                  controller.navRoute = "isSettingsScreen";

                  Get.toNamed(FluroRouters.mainScreen + '/settings');

                  /* onProfileChange = false;
                      onChatsChange = false;
                      onBookMarksChange = false;
                      onTrendsChange = false;
                      onHomeChange = false;
                      onBrowsChange = false;
                      onMoreChange = false;
                      onNotificationChange = false;
                      onListChange = false;

                  print("click hua");
                  controller.isSearch = false;
                  controller.isFilter = false;
                  controller.isFilterScreen = false;
                  controller.isTrendsScreen = false;
                  controller.isNewsFeedScreen = false;
                  controller.isTopWerfsScreen = false;
                  controller.isBrowseScreen = false;
                  controller.isNotificationScreen = false;
                  controller.isWhoToFollowScreen = false;
                  controller.isSavedPostScreen = false;
                  controller.isChatScreen = false;
                  controller.isPostDetails = false;
                  controller.isFollwerScreen = false;
                  controller.isProfileScreen = false;
                  controller.isOtherUserProfileScreen = false;
                  controller.searchText.text = '';
                  controller.isSettingsScreen = true;
                  controller.isSettingDetail = true;
                  controller.isSettingTypeDetail = false;
                  controller.isTopicScreen = false;
                  controller.isCommunitesScreen = false;
                  controller.isListScreen = false;
                  controller.navRoute = "isSettingsScreen";

                  controller
                      .getOtherUserProfile(GetStorage().read('id'))
                      .whenComplete(() {
                    controller.verification =
                        controller.otherUserProfile.accountVerified;
                  });

                      controller.update();*/
                },
              ),
            ),

            ///list pr ana
            Tooltip(
              message:
                  MediaQuery.of(context).size.width < 1280 ? Strings.lists : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading:WebSideDrawersIcons(controller.isListScreen
                    ?"assets/drawer_icons_new/list_fill.png":"assets/drawer_icons_new/list.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.lists,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onListChange == false ? 18 : 20,
                          fontWeight: onListChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                        // style: TextStyle(
                        //   color: controller.isListScreen
                        //       ? Color(0xFFedab30)
                        //       : Colors.black,
                        //   fontSize: 18,
                        //   // fontWeight: FontWeight.w900,
                        //   // fontWeight: controller.isSettingsScreen
                        //   //     ? FontWeight.bold
                        //   //     : FontWeight.normal,
                        // ),
                      ),
                onTap: () {
                  onListChange = true;
                  controller.navRoute = "isListScreen";

                  Get.toNamed(FluroRouters.mainScreen + '/list');

                  /* onSettingChange = false;
                      onProfileChange = false;
                      onChatsChange = false;
                      onBookMarksChange = false;
                      onTrendsChange = false;
                      onHomeChange = false;

                  onBrowsChange = false;
                  onMoreChange = false;
                  onNotificationChange = false;

                  controller.isSearch = false;
                  controller.isFilter = false;
                  controller.isFilterScreen = false;
                  controller.isTrendsScreen = false;
                  controller.isNewsFeedScreen = false;
                  controller.isTopWerfsScreen = false;
                  controller.isBrowseScreen = false;
                  controller.isNotificationScreen = false;
                  controller.isWhoToFollowScreen = false;
                  controller.isSavedPostScreen = false;
                  controller.isChatScreen = false;
                  controller.isPostDetails = false;
                  controller.isFollwerScreen = false;
                  controller.isProfileScreen = false;
                  controller.isListScreen = true;
                  controller.isListDetailScreen = false;
                  controller.isTopicScreen = false;
                  controller.isCommunitesScreen = false;
                  controller.isOtherUserProfileScreen = false;
                  controller.searchText.text = '';

                      controller.isSettingsScreen = false;
                      controller.navRoute = "isListScreen";
                      controller.update();*/
                },
              ),
            ),
            Tooltip(
              message: MediaQuery.of(context).size.width < 1280
                  ? Strings.notifications
                  : "",
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading:WebSideDrawersIcons(controller.isNotificationScreen
                    ?"assets/drawer_icons_new/notifications_fill.png":"assets/drawer_icons_new/notifications.png", Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,),
                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : Text(
                        Strings.notifications,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: onNotificationChange == false ? 18 : 20,
                          fontWeight: onNotificationChange == false
                              ? FontWeight.w400
                              : FontWeight.bold,
                        ),
                        // style: TextStyle(
                        //   color: controller.isNotificationScreen
                        //       ? Color(0xFFedab30)
                        //       : Colors.black,
                        //   fontSize: 18,
                        //   // fontWeight: FontWeight.w900,
                        //   // fontWeight: controller.isNotificationScreen
                        //   //     ? FontWeight.bold
                        //   //     : FontWeight.normal,
                        // ),
                      ),
                onTap: () {
                  onNotificationChange = true;
                  controller.navRoute = "isNotificationScreen";

                  Get.toNamed(FluroRouters.mainScreen + '/notifications');

                  /*   onListChange = false;
                      onSettingChange = false;
                      onProfileChange = false;
                      onChatsChange = false;
                      onBookMarksChange = false;
                      onTrendsChange = false;
                      onHomeChange = false;

                  onBrowsChange = false;
                  onMoreChange = false;

                      controller.isSearch = false;
                      controller.isFilter = false;
                      controller.isFilterScreen = false;
                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = false;
                      controller.isTopWerfsScreen = false;
                      controller.isBrowseScreen = false;
                      controller.isNotificationScreen = true;
                      controller.isSavedPostScreen = false;
                      controller.isChatScreen = false;
                      controller.isWhoToFollowScreen = false;
                      controller.isPostDetails = false;
                      controller.searchText.text = '';
                      controller.isCommunitesScreen = false;
                      controller.isProfileScreen = false;
                      controller.isFollwerScreen = false;
                      controller.isSettingsScreen = false;
                      controller.isListScreen = false;
                      controller.navRoute = "isNotificationScreen";
                      notifi.value = 0;
                      if (Get.isRegistered<NotificationController>()) {
                        Get.find<NotificationController>().getNotifications();
                      }
                      controller.update();*/
                },
                trailing: Obx(() {
                  return notifi.value == 0 || notifi.value == null
                      ? SizedBox()
                      : Container(
                          width: 20,
                          // padding: const EdgeInsets.symmetric(horizontal: 10, vertical:10),
                          decoration: const BoxDecoration(
                              shape: BoxShape.circle, color: Color(0xFF0157d3)),
                          alignment: Alignment.center,
                          child: Text(
                            notifi.value > 99 ? '+99' : '${notifi.value}',
                            style: TextStyle(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                            ),
                            // /* style: const TextStyle(
                            //      fontSize: 10, color: Colors.white),*/
                          ),
                        );
                }),
              ),
            ),
            PopupMenuButton(
              padding: EdgeInsets.zero,
              offset: Offset(6, -100),
              onSelected: (value) {
                print(value);
              },
              child: ListTile(
                // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 8,
                leading: MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: WebSideDrawersIcons(onMoreChange
                        ?"assets/drawer_icons_new/more_fill.png":"assets/drawer_icons_new/more.png", Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,),
                  ),

                title: MediaQuery.of(context).size.width < 1212
                    ? SizedBox()
                    : MouseRegion(
                        cursor: SystemMouseCursors.click,
                        child: Text(
                          Strings.more,
                          style: TextStyle(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            fontSize: onMoreChange == false ? 18 : 20,
                            fontWeight: onMoreChange == false
                                ? FontWeight.w400
                                : FontWeight.bold,
                          ),
                          // style: TextStyle(
                          //   color:
                          //
                          //       //  controller.isNotificationScreen
                          //       //     ? Color(0xFFedab30)
                          //       //     :
                          //       Colors.black,
                          //   fontSize: 18,
                          //   // fontWeight: FontWeight.w900,
                          // ),
                        ),
                      ),
              ),
              itemBuilder: (BuildContext context) => <PopupMenuEntry>[
                // popUpMenuItem(
                //     'assets/drawer_icons/about.png', Strings.about, 1, () {}),
                // popUpMenuItem(
                //     'assets/drawer_icons/help.png', Strings.help, 2, () {}),

                // ListTile(
                //   contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
                //   shape: RoundedRectangleBorder(
                //     borderRadius: BorderRadius.circular(4),
                //   ),
                //   horizontalTitleGap: 18,
                //   leading: !controller.isTopicScreen
                //       ? Container(
                //     width: 24,
                //     height: 24,
                //     child: Image.asset('assets/drawer_icons/topic.png'),
                //   )
                //       : Container(
                //     width: 24,
                //     height: 24,
                //     child: Image.asset('assets/drawer_icons/topic.png'),
                //   ),
                //   title: MediaQuery.of(context).size.width < 1370
                //       ? SizedBox()
                //       : Text(
                //     Strings.topic,
                //     style: TextStyle(
                //       color: controller.isTopicScreen
                //           ? Color(0xFFedab30)
                //           : Colors.black,
                //       fontSize: 18,
                //       // fontWeight: FontWeight.w900,
                //       // fontWeight: controller.isSettingsScreen
                //       //     ? FontWeight.bold
                //       //     : FontWeight.normal,
                //     ),
                //   ),
                //   onTap: () {
                //
                //   },
                // ),
                //

                popUpMenuItem(
                    'assets/drawer_icons_new/topics.png', Strings.topic, 3,
                    () async {
                  onMoreChange = true;
                  /*onNotificationChange = false;
                      onListChange = false;
                      onSettingChange = false;
                      onProfileChange = false;
                      onChatsChange = false;
                      onBookMarksChange = false;
                      onTrendsChange = false;
                      onHomeChange = false;

                onBrowsChange = false;

                      controller.isSearch = false;
                      controller.isFilter = false;
                      controller.isFilterScreen = false;
                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = false;
                      controller.isTopWerfsScreen = false;
                      controller.isBrowseScreen = false;
                      controller.isNotificationScreen = false;
                      controller.isWhoToFollowScreen = false;
                      controller.isSavedPostScreen = false;
                      controller.isChatScreen = false;
                      controller.isPostDetails = false;
                      controller.isFollwerScreen = false;
                      controller.isProfileScreen = false;
                      controller.isListScreen = false;
                      controller.isListDetailScreen = false;
                      controller.isOtherUserProfileScreen = false;
                      controller.searchText.text = '';
                      controller.isSettingsScreen = false;
                      controller.isTopicScreen = true;
                      controller.isCommunitesScreen = false;
                      controller.navRoute = "isTopicScreen";
                      controller.update();*/
                  Navigator.pop(context);
                  Get.toNamed(FluroRouters.mainScreen + '/topics');

                  // Navigator.pop(context);
                }, context: context),

                popUpMenuItem( 'assets/drawer_icons_new/privacy_policy.png',
                    Strings.privacyPolicy, 3, () async {
                  try {
                    var url = "https://api.werfie.com/privacy";
                    // if (await canLaunch(url))
                    await launch(url);
                    // else
                    // can't launch url, there is some error
                    // throw "Could not launch $url";
                    Navigator.pop(context);
                  } catch (e) {
                    print(e.toString());
                  }
                }, context: context),

                popUpMenuItem( 'assets/drawer_icons_new/terms_of_service.png',
                    Strings.termsOfService, 5, () async {
                  try {
                    var url = "https://api.werfie.com/terms";

                    await launch(url);
                    Navigator.pop(context);
                  } catch (e) {
                    print(e.toString());
                  }
                }, context: context),
                popUpMenuItem(
                    'assets/drawer_icons_new/moments.png', Strings.moments, 1, () {
                  onMomentChange = true;
                  /* if (Get.isRegistered<MomentsListController>()) {
                        Get.find<MomentsListController>().getMomentsList();
                      } else {
                        Get.put(MomentsListController());
                        Get.put(AddMomentsController());
                      }
                      controller.drawerLeftMoment = true;
                      controller.isSearch = false;
                      controller.isFilter = false;
                      controller.isFilterScreen = false;
                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = false;
                      controller.isTopWerfsScreen = false;
                      controller.addMomentsScreen = false;
                      controller.getListMomentScreen = true;
                      controller.isCreateMomentsScreen = true;
                      controller.isWhoToFollowScreen = false;
                      controller.isNotificationScreen = false;
                      controller.isChatScreen = false;
                      controller.isSavedPostScreen = false;
                      controller.isPostDetails = false;
                      controller.isProfileScreen = false;
                      controller.isFollwerScreen = false;
                      controller.isSettingsScreen = false;

                controller.searchText.text = '';
                controller.isListScreen = false;
                controller.isListDetailScreen = false;
                controller.addMomentsScreen = false;
                controller.editMomentScreen = false;
                controller.isCommunitesScreen = false;
                controller.showMomentsScreen = false;
                //  controller.navRoute = "isQuestScreen";

                      controller.update();
                      Navigator.pop(context);
*/

                  Navigator.pop(context);
                  Get.toNamed(FluroRouters.mainScreen + "/moments");
                }, context: context),
                popUpMenuItem( 'assets/drawer_icons_new/display_settings.png',
                    Strings.displaySettings, 3, () async {
                  Navigator.pop(context);
                  showDialog<String>(
                      context: context,
                      builder: (BuildContext context) => AlertDialog(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          backgroundColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? Color(0xff15202b)
                                  : Colors.white,
                          content: StatefulBuilder(
                              builder: (context, StateSetter setState) {
                            return Container(
                              height: 380,
                              width: 500,
                              decoration: BoxDecoration(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Color(0xff15202b)
                                    : Colors.white,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20.0)),
                              ),
                              child:
                                  CustomDisplayWidgets(controller: controller),
                            );
                          })));
                  controller.update();
                  // Navigator.pop(context);
                }, context: context),
              ],
            ),
            SizedBox(height: 20),
            MediaQuery.of(context).size.width < 1280
                ? Padding(
                    padding: EdgeInsets.only(
                      left: 8,
                      right: controller.languageData.appLang.id == 2 ? 15 : 0,
                    ),
                    child: Align(
                      alignment: controller.languageData.appLang.id == 2
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: FloatingActionButton(
                        heroTag: UniqueKey(),
                        onPressed: () async {
                          showDialog(
                              barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding:
                                        EdgeInsets.symmetric(horizontal: 12),
                                    content: DialogboxWeb(
                                      controller,
                                      controller.userProfile.profileImage,
                                      true,
                                      ShowPolls: false,
                                    ));
                              });
                        },
                        backgroundColor: controller.displayColor,
                        child: Icon(
                          Icons.add,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  )
                : Container(
                    alignment: controller.languageData.appLang.id == 2
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    //  width: 50,
                    // padding: const EdgeInsets.only(right: 10),
                    // margin: EdgeInsets.only(right:  20, left: 30 ),
                    // width: 40,
                    // height: 60,
                    // color: Colors.green,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: ElevatedButton(
                        onPressed: controller.userProfile == null
                            ? () {}
                            : () async {
                                controller.mediaApiCheck = false;
                                SingleTone.instance.selectedLocation = null;

                                controller.writeSomethingHere[0].clear();
                                controller.postHideModel3 = false;
                                controller.showPolls[0] = false;
                                // controller.modelList3[0].poll_ques_first.clear();
                                // widget.controller.modelList3[0].mediaData2.clear();
                                //  widget.controller.modelList2[controller.currentIndexText].mediaData2.clear();
                                // controller.modelList2 = [];
                                controller.modelList3[0].mediaData2 = [];
                                controller.isWebWebWerfDialogOpen = true;
                                // controller.modelList3=[];
                                // controller.update();
                                showDialog(
                                    barrierDismissible: false,
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(10.0))),
                                          insetPadding: EdgeInsets.symmetric(
                                              horizontal: 0, vertical: 0),
                                          contentPadding: EdgeInsets.symmetric(
                                              horizontal: 12),
                                          content: DialogboxWeb(
                                            controller,
                                            controller.userProfile.profileImage,
                                            true,
                                            ShowPolls: false,
                                          ));
                                    }).then((value){
                                  controller.isWebWebWerfDialogOpen = false;
                                });
                              },
                        child: Text(
                          controller.languageData.appLang.id == 2
                              ? "يخلق ورف"
                              : Strings.createWerf,

                          // style: Theme.of(context).textTheme.headline6.copyWith(
                          //     color: Colors.white,
                          //     fontWeight: FontWeight.bold,
                          //     fontSize: 18),
                          style: Styles.baseTextTheme.headline2.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          primary: controller.displayColor,
                          // padding: EdgeInsets.symmetric(vertical: 16),
                          minimumSize: Size(220, 60),
                          shape: StadiumBorder(),
                        ),
                      ),
                    ),
                  ),

            SizedBox(
              height: MediaQuery.of(context).size.height * 0.16,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 15,right: 10),
              child: PopupMenuButton(
                onSelected: (value) async {


                  if (value == 1) {

                    final storage = GetStorage();
                    String token = storage.read("token");
                    String fcmToken = storage.read("fcm_token");
                    LogoutAPI().logout(token,fcmToken);
                    //print("asdadsadads");
                    //print("Singleton value${SingleTone.instance.socialLogin}");

                    onHomeChange = true;
                    onBrowsChange = false;
                    onTrendsChange = false;
                    onBookMarksChange = false;
                    onChatsChange = false;
                    onProfileChange = false;
                    onSettingChange = false;
                    onListChange = false;
                    onNotificationChange = false;
                    onMoreChange = false;
                    onMomentChange = false;
                    SharedPreferences preferences =
                        await SharedPreferences.getInstance();

                    if (preferences.getBool('socialLogin') == true) {
                      print('social logout');
                      UtilsMethods utils = UtilsMethods();
                      utils.signOutGoogle();

                      await preferences.clear();
                      // await preferences.remove("userName");
                      // await preferences.remove("id");
                      await controller.storage.erase();
                      Get.delete<SessionController>();
                      Get.delete<ProfileController>();
                      Get.delete<NewsfeedController>();
                      controller.update();
                      preferences.setBool('guestUser', true);
                      /*   Routemaster.of(context).replace(
                              AppRoute.guestUserMainScreen);*/
                      //Get.offNamed(FluroRouters.guestUserMainScreen);
                      Get.offAll(GuestUserMainScreen(isFromPosh: false,),routeName: FluroRouters.guestUserMainScreen);

                    } else {
                      await preferences.clear();
                      // await preferences.remove("userName");
                      // await preferences.remove("id");
                      await controller.storage.erase();
                      Get.delete<SessionController>();
                      Get.delete<ProfileController>();
                      Get.delete<NewsfeedController>();
                      controller.update();
                      preferences.setBool('guestUser', true);
                      /*        Routemaster.of(context).replace(
                              AppRoute.guestUserMainScreen);*/
                      // Get.offNamed(FluroRouters.guestUserMainScreen);
                      Get.offAll(GuestUserMainScreen(isFromPosh: false,),routeName: FluroRouters.guestUserMainScreen);

                    }
                  }
                },
                offset: const Offset(0, -80),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                itemBuilder: (BuildContext context) => [
                  PopupMenuItem(
                      value: 1,
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              "Log out @${controller.userName}",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                          ),
                        ],
                      )),
                ],
                child: Row(
                  children: [
                    // MouseRegion(
                    //   cursor: SystemMouseCursors.click,
                    //   child: GestureDetector(
                    //     onTap: () async{
                    //       onHomeChange = false;
                    //       onBrowsChange = false;
                    //       onTrendsChange = false;
                    //       onBookMarksChange = false;
                    //       onChatsChange = false;
                    //       onProfileChange = true;
                    //       onSettingChange = false;
                    //       onListChange = false;
                    //       onNotificationChange = false;
                    //       onMoreChange = false;
                    //
                    //       controller.isSearch = false;
                    //       controller.isFilter = false;
                    //       controller.isFilterScreen = false;
                    //       controller.isTrendsScreen = false;
                    //       controller.isNewsFeedScreen = false;
                    //       controller.isTopWerfsScreen = false;
                    //       controller.isListScreen = false;
                    //       controller.isBrowseScreen = false;
                    //       controller.isNotificationScreen = false;
                    //       controller.isSavedPostScreen = false;
                    //       controller.isChatScreen = false;
                    //       controller.isPostDetails = false;
                    //       controller.isFollwerScreen = false;
                    //       controller.isProfileScreen = true;
                    //       controller.isSettingsScreen = false;
                    //       controller.isListDetailScreen = false;
                    //       controller.isTopicScreen = false;
                    //       controller.isCommunitesScreen = false;
                    //       controller.isWhoToFollowScreen = false;
                    //       controller.navRoute = "isProfileScreen";
                    //
                    //
                    //       if (Get.isRegistered<ProfileController>()) {
                    //         Get.find<ProfileController>(). isHiddenPost = false;
                    //         Get.find<ProfileController>().isTweets = true;
                    //         Get.find<ProfileController>().isTweetsReply = false;
                    //         Get.find<ProfileController>().isMedia = false;
                    //         Get.find<ProfileController>().isLikes = false;
                    //
                    //         Get.find<ProfileController>().selectedTab = "isTweets";
                    //
                    //         Get.find<ProfileController>().userProfile = await controller.getUserProfile();
                    //
                    //         await Get.find<ProfileController>().filterUsersPost("posts");
                    //         Get.find<ProfileController>().userPosts.forEach((element) {
                    //           element.likeCount.value = element.simpleLikeCount;
                    //           element.rebuzzCount.value = element.retweetCount;
                    //           element.commentCount.value = element.commentsCount;
                    //           element.reactionType.value = element.isLiked;
                    //           // element.comments.forEach((element) {
                    //           //   element.reactionType.value = element.isLiked;
                    //           //   element.commentCount.value  = element.simpleLikeCount;
                    //           // });
                    //           element.reactionType.refresh();
                    //
                    //           // if (element.isLiked == true) {
                    //           //   element.like.value = true;
                    //           //   element.like.refresh();
                    //           // }
                    //         });
                    //         Get.find<ProfileController>().update();
                    //
                    //
                    //       }else{
                    //
                    //
                    //         print("vvvvv");
                    //         Get.put(ProfileController());
                    //         Get.find<ProfileController>().userProfile = await controller.getUserProfile();
                    //
                    //         Get.find<ProfileController>(). isHiddenPost = false;
                    //         Get.find<ProfileController>().isTweets = true;
                    //         Get.find<ProfileController>().isTweetsReply = false;
                    //         Get.find<ProfileController>().isMedia = false;
                    //         Get.find<ProfileController>().isLikes = false;
                    //
                    //         Get.find<ProfileController>().selectedTab = "isTweets";
                    //         await Get.find<ProfileController>().filterUsersPost("posts");
                    //         Get.find<ProfileController>().userPosts.forEach((element) {
                    //           element.likeCount.value = element.simpleLikeCount;
                    //           element.rebuzzCount.value = element.retweetCount;
                    //           element.commentCount.value = element.commentsCount;
                    //           element.reactionType.value = element.isLiked;
                    //           // element.comments.forEach((element) {
                    //           //   element.reactionType.value = element.isLiked;
                    //           //   element.commentCount.value  = element.simpleLikeCount;
                    //           // });
                    //           element.reactionType.refresh();
                    //
                    //           // if (element.isLiked == true) {
                    //           //   element.like.value = true;
                    //           //   element.like.refresh();
                    //           // }
                    //         });
                    //         Get.find<ProfileController>().update();
                    //
                    //
                    //       }
                    //
                    //
                    //       controller.update();
                    //     },
                    //     child: Tooltip(
                    //       message:MediaQuery.of(context).size.width < 1280? Strings.account:"",
                    //       child: Align(
                    //           alignment: Alignment.center,
                    //           child: controller.userProfile == null
                    //               ? Container(
                    //               width: 24,
                    //               child: Center(
                    //                 child: SpinKitCircle(
                    //                   color: Colors.grey,
                    //                   size: 40,
                    //                 ),
                    //               ))
                    //               : controller.userProfile.profileImage == null
                    //               ? CircleAvatar(
                    //               radius: 40,
                    //               backgroundImage: AssetImage(
                    //                   "assets/images/person_placeholder.png"))
                    //               : ClipRRect(
                    //             borderRadius: BorderRadius.circular(50),
                    //             child: FadeInImage(
                    //                 fit: BoxFit.cover,
                    //                 width: 40,
                    //                 height: 40,
                    //                 placeholder: AssetImage(
                    //                     'assets/images/person_placeholder.png'),
                    //                 image: NetworkImage(controller
                    //                     .userProfile
                    //                     .profileImage !=
                    //                     null
                    //                     ? controller
                    //                     .userProfile.profileImage
                    //                     : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                    //           )),
                    //     ),
                    //   ),
                    // ),
                    Tooltip(
                      message: MediaQuery.of(context).size.width < 1280
                          ? Strings.account
                          : "",
                      child: Align(
                          alignment: Alignment.center,
                          child: controller.userProfile == null
                              ? Container(
                                  width: 24,
                                  child: Center(
                                    child: SpinKitCircle(
                                      color: Colors.grey,
                                      size: 40,
                                    ),
                                  ))
                              : controller.userProfile.profileImage == null
                                  ? CircleAvatar(
                                      radius: 20,
                                      backgroundImage: AssetImage(
                                          "assets/images/person_placeholder.png"))
                                  : ClipRRect(
                                      borderRadius: BorderRadius.circular(50),
                                      child: FadeInImage(
                                          fit: BoxFit.cover,
                                          width: 40,
                                          height: 40,
                                          placeholder: AssetImage(
                                              'assets/images/person_placeholder.png'),
                                          image: NetworkImage(controller
                                                      .userProfile
                                                      .profileImage !=
                                                  null
                                              ? controller
                                                  .userProfile.profileImage
                                              : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                    )),
                    ),
                    SizedBox(
                      width: 7,
                    ),
                    Expanded(
                      child: Column(
                        // mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          MediaQuery.of(context).size.width < 1280
                              ? SizedBox()
                              : controller.userProfile == null
                                  ? SizedBox()
                                  : MouseRegion(
                                      cursor: SystemMouseCursors.click,

                                      child: Padding(
                                        padding: controller.userProfile
                                                    .accountVerified ==
                                                "verified"
                                            ? EdgeInsets.zero
                                            : EdgeInsets.zero,
                                        child: Row(
                                          children: [
                                            Container(
                                              width: userFirstName.length > 15
                                                  ? 130
                                                  : null,
                                              child: Text(userFirstName,
                                                  overflow:
                                                      userFirstName.length > 15
                                                          ? TextOverflow
                                                              .ellipsis
                                                          : null,
                                                  softWrap: false,
                                                  maxLines: 1,
                                                  style: Styles
                                                      .baseTextTheme.headline1
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: 15,
                                                  )
                                                  // TextStyle(
                                                  //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                  //   fontWeight: FontWeight.bold,
                                                  //   fontSize: 18,
                                                  //   height: 1.5,
                                                  // ),
                                                  ),
                                            ),
                                            controller.userProfile
                                                        .accountVerified ==
                                                    "verified"
                                                ? BlueTick(
                                                    height: 16,
                                                    width: 16,
                                                    iconSize: 10,
                                                  )
                                                : SizedBox(),
                                          ],
                                        ),
                                      ),
                                      // GestureDetector(
                                      //   onTap: () async {
                                      //     onHomeChange = false;
                                      //     onBrowsChange = false;
                                      //     onTrendsChange = false;
                                      //     onBookMarksChange = false;
                                      //     onChatsChange = false;
                                      //     onProfileChange = true;
                                      //     onSettingChange = false;
                                      //     onListChange = false;
                                      //     onNotificationChange = false;
                                      //     onMoreChange = false;
                                      //
                                      //     controller.isSearch = false;
                                      //     controller.isFilter = false;
                                      //     controller.isFilterScreen = false;
                                      //     controller.isTrendsScreen = false;
                                      //     controller.isNewsFeedScreen = false;
                                      //     controller.isTopWerfsScreen = false;
                                      //     controller.isBrowseScreen = false;
                                      //     controller.isNotificationScreen = false;
                                      //     controller.isSavedPostScreen = false;
                                      //     controller.isChatScreen = false;
                                      //     controller.isListScreen = false;
                                      //     controller.isPostDetails = false;
                                      //     controller.isFollwerScreen = false;
                                      //     controller.isProfileScreen = true;
                                      //     controller.isSettingsScreen = false;
                                      //     controller.isListDetailScreen = false;
                                      //     controller.isTopicScreen = false;
                                      //     controller.isWhoToFollowScreen = false;
                                      //     controller.navRoute = "isProfileScreen";
                                      //     if (Get.isRegistered<ProfileController>()) {
                                      //
                                      //       ///
                                      //       Get.find<ProfileController>(). isHiddenPost = false;
                                      //       Get.find<ProfileController>().isTweets = true;
                                      //       Get.find<ProfileController>().isTweetsReply = false;
                                      //       Get.find<ProfileController>().isMedia = false;
                                      //       Get.find<ProfileController>().isLikes = false;
                                      //
                                      //       Get.find<ProfileController>().selectedTab = "isTweets";
                                      //       Get.find<ProfileController>().userProfile = await controller.getUserProfile();
                                      //
                                      //       await Get.find<ProfileController>().filterUsersPost("posts");
                                      //       Get.find<ProfileController>().userPosts.forEach((element) {
                                      //         element.likeCount.value = element.simpleLikeCount;
                                      //         element.rebuzzCount.value = element.retweetCount;
                                      //         element.commentCount.value = element.commentsCount;
                                      //         element.reactionType.value = element.isLiked;
                                      //         // element.comments.forEach((element) {
                                      //         //   element.reactionType.value = element.isLiked;
                                      //         //   element.commentCount.value  = element.simpleLikeCount;
                                      //         // });
                                      //         element.reactionType.refresh();
                                      //
                                      //         // if (element.isLiked == true) {
                                      //         //   element.like.value = true;
                                      //         //   element.like.refresh();
                                      //         // }
                                      //       });
                                      //       Get.find<ProfileController>().update();
                                      //
                                      //
                                      //     }else{
                                      //
                                      //
                                      //       print("vvvvv");
                                      //       Get.put(ProfileController());
                                      //       ///
                                      //       Get.find<ProfileController>(). isHiddenPost = false;
                                      //       Get.find<ProfileController>().isTweets = true;
                                      //       Get.find<ProfileController>().isTweetsReply = false;
                                      //       Get.find<ProfileController>().isMedia = false;
                                      //       Get.find<ProfileController>().isLikes = false;
                                      //       Get.find<ProfileController>().selectedTab = "isTweets";
                                      //
                                      //       Get.find<ProfileController>().userProfile = await controller.getUserProfile();
                                      //
                                      //
                                      //       await Get.find<ProfileController>().filterUsersPost("posts");
                                      //       Get.find<ProfileController>().userPosts.forEach((element) {
                                      //         element.likeCount.value = element.simpleLikeCount;
                                      //         element.rebuzzCount.value = element.retweetCount;
                                      //         element.commentCount.value = element.commentsCount;
                                      //         element.reactionType.value = element.isLiked;
                                      //         // element.comments.forEach((element) {
                                      //         //   element.reactionType.value = element.isLiked;
                                      //         //   element.commentCount.value  = element.simpleLikeCount;
                                      //         // });
                                      //         element.reactionType.refresh();
                                      //
                                      //         // if (element.isLiked == true) {
                                      //         //   element.like.value = true;
                                      //         //   element.like.refresh();
                                      //         // }
                                      //       });
                                      //       Get.find<ProfileController>().update();
                                      //
                                      //
                                      //     }
                                      //     controller.update();
                                      //   },
                                      //   child: Padding(
                                      //     padding: controller.userProfile.accountVerified ==
                                      //         "verified"
                                      //         ? EdgeInsets.zero
                                      //         : EdgeInsets.zero,
                                      //     child: Row(
                                      //       children: [
                                      //         Container(
                                      //           width: userFirstName.length>15 ? 120: null,
                                      //           child: Text(
                                      //
                                      //               userFirstName,
                                      //               overflow: userFirstName.length>15 ? TextOverflow.ellipsis : null,
                                      //               softWrap: false,
                                      //               maxLines: 1,
                                      //               style:
                                      //               Styles.baseTextTheme.headline1.copyWith(
                                      //                 color: Theme.of(context).brightness ==
                                      //                     Brightness.dark
                                      //                     ? Colors.white
                                      //                     : Colors.black,
                                      //                 fontSize: 15,
                                      //               )
                                      //             // TextStyle(
                                      //             //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      //             //   fontWeight: FontWeight.bold,
                                      //             //   fontSize: 18,
                                      //             //   height: 1.5,
                                      //             // ),
                                      //           ),
                                      //         ),
                                      //         controller.userProfile.accountVerified ==
                                      //             "verified"
                                      //             ? BlueTick(
                                      //           height: 16,
                                      //           width: 16,
                                      //           iconSize: 10,
                                      //         )
                                      //             : SizedBox(),
                                      //       ],
                                      //     ),
                                      //   ),
                                      // ),
                                    ),
                          MediaQuery.of(context).size.width < 1280
                              ? SizedBox()
                              : MouseRegion(
                                  cursor: SystemMouseCursors.click,
                                  child: MouseRegion(
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: userName.length > 15
                                                  ? 130
                                                  : null,
                                              child: Text(userName,
                                                  overflow: userName.length > 15
                                                      ? TextOverflow.ellipsis
                                                      : null,
                                                  maxLines: 1,
                                                  style: Styles
                                                      .baseTextTheme.headline2
                                                      .copyWith(
                                                    fontSize: 15,
                                                  )
                                                  // TextStyle(
                                                  //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                                                  //   fontWeight: FontWeight.w400,
                                                  //   fontSize: 16,
                                                  // ),
                                                  ),
                                            ),
                                          ),
                                          !kIsWeb
                                              ?
                                              // controller.userProfile.accountVerified =="verified"?
                                              BlueTick(
                                                  height: 16,
                                                  width: 16,
                                                  iconSize: 10,
                                                ) /*:SizedBox()*/
                                              : SizedBox(),
                                        ],
                                      ),
                                    ),
                                    // GestureDetector(
                                    //   onTap: () async {
                                    //     onHomeChange = false;
                                    //     onBrowsChange = false;
                                    //     onTrendsChange = false;
                                    //     onBookMarksChange = false;
                                    //     onChatsChange = false;
                                    //     onProfileChange = true;
                                    //     onSettingChange = false;
                                    //     onListChange = false;
                                    //     onNotificationChange = false;
                                    //     onMoreChange = false;
                                    //
                                    //     controller.isSearch = false;
                                    //     controller.isFilter = false;
                                    //     controller.isFilterScreen = false;
                                    //     controller.isTrendsScreen = false;
                                    //     controller.isNewsFeedScreen = false;
                                    //     controller.isTopWerfsScreen = false;
                                    //     controller.isBrowseScreen = false;
                                    //     controller.isNotificationScreen = false;
                                    //     controller.isSavedPostScreen = false;
                                    //     controller.isChatScreen = false;
                                    //     controller.isPostDetails = false;
                                    //     controller.isFollwerScreen = false;
                                    //     controller.isListScreen = false;
                                    //     controller.isListDetailScreen = false;
                                    //     controller.isProfileScreen = true;
                                    //     controller.isSettingsScreen = false;
                                    //     controller.isTopicScreen = false;
                                    //     controller.isWhoToFollowScreen = false;
                                    //     controller.isCommunitesScreen = false;
                                    //     controller.navRoute = "isProfileScreen";
                                    //     if (Get.isRegistered<ProfileController>()) {
                                    //
                                    //       ///
                                    //       Get.find<ProfileController>().userProfile = await controller.getUserProfile();
                                    //       Get.find<ProfileController>(). isHiddenPost = false;
                                    //       Get.find<ProfileController>().isTweets = true;
                                    //       Get.find<ProfileController>().isTweetsReply = false;
                                    //       Get.find<ProfileController>().isMedia = false;
                                    //       Get.find<ProfileController>().isLikes = false;
                                    //
                                    //       Get.find<ProfileController>().selectedTab = "isTweets";
                                    //       await Get.find<ProfileController>().filterUsersPost("posts");
                                    //       Get.find<ProfileController>().userPosts.forEach((element) {
                                    //         element.likeCount.value = element.simpleLikeCount;
                                    //         element.rebuzzCount.value = element.retweetCount;
                                    //         element.commentCount.value = element.commentsCount;
                                    //         element.reactionType.value = element.isLiked;
                                    //         // element.comments.forEach((element) {
                                    //         //   element.reactionType.value = element.isLiked;
                                    //         //   element.commentCount.value  = element.simpleLikeCount;
                                    //         // });
                                    //         element.reactionType.refresh();
                                    //
                                    //         // if (element.isLiked == true) {
                                    //         //   element.like.value = true;
                                    //         //   element.like.refresh();
                                    //         // }
                                    //       });
                                    //       Get.find<ProfileController>().update();
                                    //
                                    //
                                    //     }else{
                                    //
                                    //
                                    //       print("vvvvv");
                                    //       Get.put(ProfileController());
                                    //       Get.find<ProfileController>().userProfile = await controller.getUserProfile();
                                    //
                                    //       ///
                                    //       Get.find<ProfileController>(). isHiddenPost = false;
                                    //       Get.find<ProfileController>().isTweets = true;
                                    //       Get.find<ProfileController>().isTweetsReply = false;
                                    //       Get.find<ProfileController>().isMedia = false;
                                    //       Get.find<ProfileController>().isLikes = false;
                                    //
                                    //       Get.find<ProfileController>().selectedTab = "isTweets";
                                    //       await Get.find<ProfileController>().filterUsersPost("posts");
                                    //       Get.find<ProfileController>().userPosts.forEach((element) {
                                    //         element.likeCount.value = element.simpleLikeCount;
                                    //         element.rebuzzCount.value = element.retweetCount;
                                    //         element.commentCount.value = element.commentsCount;
                                    //         element.reactionType.value = element.isLiked;
                                    //         // element.comments.forEach((element) {
                                    //         //   element.reactionType.value = element.isLiked;
                                    //         //   element.commentCount.value  = element.simpleLikeCount;
                                    //         // });
                                    //         element.reactionType.refresh();
                                    //
                                    //         // if (element.isLiked == true) {
                                    //         //   element.like.value = true;
                                    //         //   element.like.refresh();
                                    //         // }
                                    //       });
                                    //       Get.find<ProfileController>().update();
                                    //
                                    //
                                    //     }
                                    //     controller.update();
                                    //   },
                                    //   child: Align(
                                    //     alignment: Alignment.center,
                                    //     child: Row(
                                    //       mainAxisAlignment: MainAxisAlignment.center,
                                    //       children: [
                                    //         Container(
                                    //           width: userName.length > 15 ? 120 : null,
                                    //           child: Text(
                                    //               userName,
                                    //               overflow: userName.length > 15 ? TextOverflow.ellipsis : null,
                                    //               maxLines: 1,
                                    //               style: Styles.baseTextTheme.headline2.copyWith(
                                    //                 fontSize: 15,
                                    //               )
                                    //             // TextStyle(
                                    //             //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                                    //             //   fontWeight: FontWeight.w400,
                                    //             //   fontSize: 16,
                                    //             // ),
                                    //           ),
                                    //         ),
                                    //         !kIsWeb
                                    //             ?
                                    //         // controller.userProfile.accountVerified =="verified"?
                                    //         BlueTick(
                                    //           height: 16,
                                    //           width: 16,
                                    //           iconSize: 10,
                                    //         ) /*:SizedBox()*/ : SizedBox(),
                                    //       ],
                                    //     ),
                                    //   ),
                                    // ),
                                  ),
                                ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 7,
                    ),
                    MediaQuery.of(context).size.width < 1280
                        ? SizedBox()
                        : controller.userProfile == null
                            ? SizedBox()
                            : Icon(
                                Icons.more_horiz,
                                size: 20,
                              ),
                  ],
                ),
              ),
            ),
            //SizedBox(height: 10,),
          ],
        ),
      ),
    );
  }

  Widget videoCallWidget(context){
    VideoCallController videoCallController;
    if (Get.isRegistered<VideoCallController>()) {
      videoCallController = Get.find<VideoCallController>();
    } else {
      videoCallController = Get.put(VideoCallController());
    }
    return GetBuilder<VideoCallController>(builder: (videoController) {
      return videoController.conversationID != null && videoController.conversationID.isNotEmpty
          ? InkWell(
        onTap: () {
          if (kIsWeb) {
            // onVideoCallChange = true;
            widget.controller.navRoute = "isVideoCallScreen";

            Get.toNamed(FluroRouters.mainScreen + '/videocall', arguments: null);
          } else {
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => VideoCallHome()));
          }
        },
        child: MediaQuery.of(context).size.width < 1280
            ? Padding(
          padding: EdgeInsets.only(
            left: 8,
            right: widget.controller.languageData.appLang.id == 2 ? 15 : 0,
          ),
          child: Align(
            alignment: widget.controller.languageData.appLang.id == 2 ? Alignment.centerRight : Alignment.centerLeft,
            child: FloatingActionButton(
              heroTag: UniqueKey(),
              onPressed: () async {},
              backgroundColor: widget.controller.displayColor,
              child: Icon(
                Icons.videocam_rounded,
                color: Colors.white,
              ),
            ),
          ),
        )
            : Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(right: 70, left: 20.0, bottom: 20, top: 20),
          padding: EdgeInsets.symmetric(vertical: 5.0),
          decoration: BoxDecoration(
              border: Border.all(color: Colors.blueAccent),
              // color: controller.displayColor,
              borderRadius: BorderRadius.circular(20.0)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              //
              // Icon(
              //   Icons.videocam_rounded,
              //   color: Colors.grey,
              //   size: 20.0,
              // ),
              Center(
                child: Container(
                  width: 15,
                  height: 15,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.red,
                      width: 1,
                    ),
                    color: Colors.transparent, // Set inner color as transparent
                  ),
                  padding: EdgeInsets.all(2),
                  // Adjust padding for the gap
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.red, // Inner circle color
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10.0),
              Text(
                "Ongoing Call",
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Colors.blueAccent,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
              // SizedBox(width:10.0),
            ],
          ),
        ),
      )
          : SizedBox();
    });

    if (Get.isRegistered<VideoCallController>() && videoCallController.conversationID.isNotEmpty){

    } else {
      return SizedBox();
    }
  }

  ///ye hai pop
  Widget popUpMenuItem(String iconImage, String s, int value, Function function,
      {BuildContext context}) {
    return PopupMenuItem(
      value: value,
      child: ListTile(
        // hoverColor: Colors.blueAccent,
        leading: Container(
            width: 22,
            height: 22,
            child:

                // Image.asset(
                //   iconImage,
                //   // color:Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                //
                // )

                Image.asset(
              iconImage,
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
            )),
        title: Text(s,
            style: Styles.baseTextTheme.headline3.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.bold)
            // TextStyle(color: Colorss.yellow, fontWeight: FontWeight.bold),
            ),
        onTap: function,
      ),
    );
  }

  Container momentsLeftSection(
      BuildContext context, NewsfeedController controller) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width < 1280 ? 70 : 250,
      child: ListView(
        controller: ScrollController(),
        children: [
          // Image.asset('assets/images/werfielogo.png',
          // height: 20,
          //   width: 20,
          // ),
          const SizedBox(
            height: 30,
          ),
          ListTile(
            // contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
            horizontalTitleGap: 18,
            leading: !controller.isNewsFeedScreen
                ? WebSideDrawersIcons("assets/drawer_icons_new/home_fill.png", Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,)
                : Container(
                    width: 24,
                    height: 24,
                    child: SvgPicture.asset(
                      'assets/svg_drawer_icons/HomeFill.svg',
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    )),
            title: MediaQuery.of(context).size.width < 1280
                ? SizedBox()
                : Text(
                    Strings.home,
                    style: TextStyle(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
            onTap: () {
              onHomeChange = true;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;

              controller.navRoute = "isNewsFeedScreen";
              Get.toNamed(FluroRouters.mainScreen + "/feeds");
            },
          ),
          const SizedBox(height: 10),
          ListTile(
            //  contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
            horizontalTitleGap: 18,
            leading: !controller.addMomentsScreen
                ? Container(
                    width: 30,
                    height: 30,
                    child: SvgPicture.asset(
                      'assets/svg_drawer_icons/momentFill.svg',
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  )
                : Container(
                    width: 30,
                    height: 30,
                    child: SvgPicture.asset(
                      'assets/svg_drawer_icons/momentFill.svg',
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
            title: MediaQuery.of(context).size.width < 1280
                ? SizedBox()
                : Text(
                    Strings.moments,
                    style: TextStyle(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: onMomentChange == false ? 18 : 20,
                      fontWeight: onMomentChange == false
                          ? FontWeight.w400
                          : FontWeight.bold,
                    ),
                  ),
            onTap: () {
              Get.toNamed(FluroRouters.mainScreen + "/moments");
            },
          ),

          ///create button
          const SizedBox(height: 20),
          controller.disableButton == false
              ? Padding(
                  padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width < 1280 ? 8 : 10,
                      right: MediaQuery.of(context).size.width < 1280 ? 0 : 10),
                  child: MediaQuery.of(context).size.width < 1280
                      ? Align(
                          alignment: Alignment.centerLeft,
                          child: FloatingActionButton(
                            heroTag: UniqueKey(),
                            onPressed: () {
                              controller.isSearch = false;
                              controller.isFilter = false;
                              controller.getListMomentScreen = false;
                              controller.isFilterScreen = false;
                              controller.isTrendsScreen = false;
                              controller.isNewsFeedScreen = false;
                              controller.isTopWerfsScreen = false;
                              controller.addMomentsScreen = true;
                              controller.isWhoToFollowScreen = false;
                              controller.isNotificationScreen = false;
                              controller.isChatScreen = false;
                              controller.isSavedPostScreen = false;
                              controller.isPostDetails = false;
                              controller.isProfileScreen = false;
                              controller.isFollwerScreen = false;
                              controller.isSettingsScreen = false;
                              controller.searchText.text = '';
                              controller.isListScreen = false;
                              controller.isListDetailScreen = false;
                              controller.drawerLeftMoment = true;
                              controller.editMomentScreen = false;
                              controller.addMomentsScreen = false;
                              controller.isCommunitesScreen = false;
                              controller.showMomentsScreen = true;
                              controller.isCreateMomentsScreen = false;
                              SingleTone.instance.momentId = null;

                              if (Get.isRegistered<AddMomentsController>()) {
                                Get.delete<AddMomentsController>();
                                final addMomentController =
                                    Get.put(AddMomentsController());
                                addMomentController.addId = [];
                                SingleTone.instance.momentId = null;
                                addMomentController.momentEdit = false;
                                addMomentController.update();
                              } else {
                                final addMomentController =
                                    Get.put(AddMomentsController());
                                addMomentController.addId = [];
                                SingleTone.instance.momentId = null;
                                addMomentController.momentEdit = false;
                                // SingleTone.instance.buttonDisable=true;
                                addMomentController.update();
                              }
                              controller.disableButton = true;
                              //  controller.navRoute = "isQuestScreen";
                              controller.update();
                            },
                            backgroundColor: controller.displayColor,
                            child: Container(
                              height: 25,
                              width: 25,
                              child: SvgPicture.asset(
                                'assets/svg_drawer_icons/momentFill.svg',
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                          ),
                        )
                      : Container(
                          height: 50,
                          width: 100,
                          child: MaterialButton(
                            height: 50,
                            minWidth: 100,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30.0))),
                            color: controller.displayColor,
                            onPressed: () {
                              if (Get.isRegistered<AddMomentsController>()) {
                                Get.delete<AddMomentsController>();

                                final addMomentController =
                                    Get.put(AddMomentsController());
                                addMomentController.addId = [];
                                addMomentController.momentEdit = false;
                                addMomentController.update();
                                SingleTone.instance.momentId = null;
                              } else {
                                final addMomentController =
                                    Get.put(AddMomentsController());
                                addMomentController.addId = [];
                                addMomentController.momentEdit = false;
                                addMomentController.update();
                                SingleTone.instance.momentId = null;
                              }
                              SingleTone.instance.momentId = null;
                              controller.disableButton = true;

                              //  controller.navRoute = "isQuestScreen";

                              Get.toNamed(
                                  FluroRouters.mainScreen + "/CreateMoment");
                              // controller.isSearch = false;
                              // controller.isFilter = false;
                              // controller.getListMomentScreen = false;
                              // controller.isFilterScreen = false;
                              // controller.isTrendsScreen = false;
                              // controller.isNewsFeedScreen = false;
                              // controller.isTopWerfsScreen = false;
                              // controller.addMomentsScreen = true;
                              // controller.isWhoToFollowScreen = false;
                              // controller.isNotificationScreen = false;
                              // controller.isChatScreen = false;
                              // controller.isSavedPostScreen = false;
                              // controller.isPostDetails = false;
                              // controller.isProfileScreen = false;
                              // controller.isFollwerScreen = false;
                              // controller.isSettingsScreen = false;
                              // controller.searchText.text = '';
                              // controller.isListScreen = false;
                              // controller.isListDetailScreen = false;
                              // controller.drawerLeftMoment = true;
                              // controller.editMomentScreen = false;
                              // controller.addMomentsScreen = false;
                              // controller.isCommunitesScreen = false;
                              // controller.showMomentsScreen = true;
                              // controller.isCreateMomentsScreen = false;
                              // SingleTone.instance.momentId = null;
                              //
                              // if (Get.isRegistered<AddMomentsController>()) {
                              //   Get.delete<AddMomentsController>();
                              //   final addMomentController =
                              //   Get.put(AddMomentsController());
                              //   addMomentController.addId = [];
                              //   SingleTone.instance.momentId = null;
                              //   addMomentController.momentEdit = false;
                              //   addMomentController.update();
                              // } else {
                              //   final addMomentController =
                              //   Get.put(AddMomentsController());
                              //   addMomentController.addId = [];
                              //   SingleTone.instance.momentId = null;
                              //   addMomentController.momentEdit = false;
                              //   // SingleTone.instance.buttonDisable=true;
                              //   addMomentController.update();
                              // }
                              // controller.disableButton = true;
                              // //  controller.navRoute = "isQuestScreen";
                              // controller.update();
                            },
                            child: Text(
                              Strings.createMoment,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                )
              : Padding(
                  padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width < 1280 ? 8 : 10,
                      right: MediaQuery.of(context).size.width < 1280 ? 0 : 10),
                  child: MediaQuery.of(context).size.width < 1280
                      ? Align(
                          alignment: Alignment.centerLeft,
                          child: FloatingActionButton(
                              heroTag: UniqueKey(),
                              onPressed: () {},
                              backgroundColor: Colors.amber.shade50,
                              child: Container(
                                height: 25,
                                width: 25,
                                child: SvgPicture.asset(
                                  'assets/svg_drawer_icons/momentFill.svg',
                                  width: 25,
                                  height: 25,
                                  color: Colors.black,
                                ),
                              )),
                        )
                      : Container(
                          height: 50,
                          width: 100,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(25),
                              color: Colors.amber.shade50),
                          child: Center(
                            child: Text(
                              Strings.createMoment,
                              style: TextStyle(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                )
        ],
      ),
    );
  }
}

class CustomDisplayWidgets extends StatefulWidget {
  const CustomDisplayWidgets({Key key, this.controller}) : super(key: key);
  final NewsfeedController controller;

  @override
  State<CustomDisplayWidgets> createState() => _CustomDisplayWidgetsState();
}

class _CustomDisplayWidgetsState extends State<CustomDisplayWidgets> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).brightness == Brightness.dark
          ? const Color(0xff15202b)
          : Colors.white,
      body: SingleChildScrollView(
        child: Column(children: [
          Text(
            Strings.customizeView,
            style: Styles.baseTextTheme.headline2.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          Text(
            Strings.theseSettingsAffect,
            style: Styles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              // fontWeight: FontWeight.bold,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  Strings.colors,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  width: Get.width,
                  height: 60,
                  decoration: BoxDecoration(
                    border: Border.all(
                        width: 2, color: widget.controller.displayColor),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: () {

                          widget.controller.displayColor = MyColors.BlueColor;
                          widget.controller.storage.write("color", 0xFF2769d9);

                          NewsfeedController();
                          ListController();
                          setState(() {});
                          widget.controller.update();
                        },
                        child: CircleAvatar(
                          backgroundColor: MyColors.BlueColor,
                          radius: 20,
                          child: Visibility(
                              visible: widget.controller.storage
                                          .read("color") ==
                                      null
                                  ? true
                                  : widget.controller.storage.read("color") ==
                                          0xFF2769d9
                                      ? true
                                      : false,
                              child: const Icon(
                                Icons.check,
                                color: Colors.white,
                              )),
                        ),
                      ),
                      InkWell(
                          onTap: () {
                            widget.controller.displayColor =
                                MyColors.yellowColor;
                            widget.controller.storage
                                .write("color", 0xFFffd400);

                            NewsfeedController();
                            ListController();
                            setState(() {});

                            widget.controller.update();
                          },
                          child: CircleAvatar(
                            backgroundColor: MyColors.yellowColor,
                            radius: 20,
                            child: Visibility(
                                visible:
                                    widget.controller.storage.read("color") ==
                                            0xFFffd400
                                        ? true
                                        : false,
                                child: const Icon(
                                  Icons.check,
                                  color: Colors.white,
                                )),
                          )),
                      InkWell(
                          onTap: () {

                            widget.controller.displayColor = MyColors.pinkColor;
                            widget.controller.storage
                                .write("color", 0xFFf91880);
                            NewsfeedController();

                            ListController();
                            setState(() {});

                            widget.controller.update();
                          },
                          child: CircleAvatar(
                            backgroundColor: MyColors.pinkColor,
                            radius: 20,
                            child: Visibility(
                                visible:
                                    widget.controller.storage.read("color") ==
                                            0xFFf91880
                                        ? true
                                        : false,
                                child: const Icon(
                                  Icons.check,
                                  color: Colors.white,
                                )),
                          )),
                      InkWell(
                          onTap: () {

                            widget.controller.displayColor =
                                MyColors.purpleColor;
                            widget.controller.storage
                                .write("color", 0xFF7856ff);
                            NewsfeedController();

                            ListController();
                            setState(() {});
                            widget.controller.update();
                          },
                          child: CircleAvatar(
                            backgroundColor: MyColors.purpleColor,
                            radius: 20,
                            child: Visibility(
                                visible:
                                    widget.controller.storage.read("color") ==
                                            0xFF7856ff
                                        ? true
                                        : false,
                                child: const Icon(
                                  Icons.check,
                                  color: Colors.white,
                                )),
                          )),
                      InkWell(
                          onTap: () {

                            widget.controller.displayColor =
                                MyColors.orangeColor;
                            widget.controller.storage
                                .write("color", 0xFFff7a00);
                            NewsfeedController();
                            ListController();
                            setState(() {});
                            widget.controller.update();
                          },
                          child: CircleAvatar(
                            backgroundColor: MyColors.orangeColor,
                            radius: 20,
                            child: Visibility(
                                visible:
                                    widget.controller.storage.read("color") ==
                                            0xFFff7a00
                                        ? true
                                        : false,
                                child: const Icon(
                                  Icons.check,
                                  color: Colors.white,
                                )),
                          )),
                      InkWell(
                        onTap: () {

                          widget.controller.displayColor = MyColors.greenColor;
                          widget.controller.storage.write("color", 0xFF00ba7c);
                          NewsfeedController();
                          ListController();
                          setState(() {});
                          widget.controller.update();
                        },
                        child: CircleAvatar(
                          backgroundColor: MyColors.greenColor,
                          radius: 20,
                          child: Visibility(
                              visible:
                                  widget.controller.storage.read("color") ==
                                          0xFF00ba7c
                                      ? true
                                      : false,
                              child: const Icon(
                                Icons.check,
                                color: Colors.white,
                              )),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                //         Column(crossAxisAlignment: CrossAxisAlignment.start,children: [
                //           Text("Background Color",
                //               style:
                //               TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w900
                //               )),
                //           Container(width: Get.width,height: 100,decoration: BoxDecoration(color: Colors.grey[200],border: Border.all(width: 1,color: Colors.black
                //           )),child:
                //             Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,crossAxisAlignment: CrossAxisAlignment.center,children: [
                //               Container(height: 80,width: 80,decoration: BoxDecoration(color: Colors.white,border: Border.all(width: 2,color: Colors.black))),
                //               Container(height: 80,width: 80,decoration: BoxDecoration(color: Colors.black,border: Border.all(width: 2,color: Colors.white)),)
                //             ],),),
                //
                // ]),

                // Center(
                //   child: ElevatedButton(
                //       style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                //           // primary:  Colorss.yellow
                //           primary: controller.displayColor
                //       ),
                //
                //       onPressed: (){
                //         Get.back();
                //         controller.update();
                //       },
                //       child:
                //
                //       Text(
                //         "Done",
                //         style: Theme.of(context).brightness == Brightness.dark ?
                //         TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.w700
                //         )
                //             : TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w700
                //         ),
                //         // style: Theme.of(context).textTheme.headline6.copyWith(
                //         //   fontSize: 14,
                //         //   fontWeight: FontWeight.w700,
                //         //   color: Colors.white,
                //         // ),
                //       )),
                // )
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                        height: 60,
                        width: 160,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          border: widget.controller.storage.read("mode") == null
                              ? Border.all(
                                  color: Colors.grey,
                                  width: 1,
                                )
                              : widget.controller.storage.read("mode")
                                  ? Border.all(
                                      color: widget.controller.displayColor,
                                      width: 2,
                                    )
                                  : Border.all(
                                      color: Colors.grey,
                                      width: 1,
                                    ),
                        ),
                        padding: const EdgeInsets.all(10.0),
                        child: InkWell(
                            onTap: () {
                              Get.changeThemeMode(
                                ThemeMode.dark,
                              );
                              widget.controller.storage.write("mode", true);
                              widget.controller.update();

                              // widget.controller.storage.write("mode", true);
                              // widget.controller.update();
                              //  Get.delete<NewsfeedController>();
                              // if (kIsWeb) {
                              //   Get.offAllNamed(FluroRouters.mainScreen);
                              //  // Get.offNamed(FluroRouters.mainScreen);
                              // } else {
                              //   Get.offUntil(
                              //       MaterialPageRoute(
                              //         builder: (context) => Session(),
                              //       ),
                              //           (route) => false);
                              // }
                            },
                            child: Row(
                              children: [
                                Text(
                                  Strings.dark,
                                  style:
                                      Styles.baseTextTheme.headline2.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                // Icon(
                                //     widget.controller.storage.read("mode") == null
                                //     ? Icons.radio_button_off
                                //     : widget.controller.storage.read("mode")
                                //         ? Icons.check_circle
                                //         : Icons.radio_button_off,
                                // ),
                                const Spacer(),
                                widget.controller.storage.read("mode") == null
                                    ? Container(
                                        height: 25,
                                        width: 25,
                                        decoration: BoxDecoration(
                                          color: Colors.black,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              color: Colors.grey, width: 1),
                                        ),
                                      )
                                    : widget.controller.storage.read("mode")
                                        ? Container(
                                            height: 25,
                                            width: 25,
                                            decoration: BoxDecoration(
                                              color: widget
                                                  .controller.displayColor,
                                              shape: BoxShape.circle,
                                            ),
                                            child: const Icon(
                                              Icons.check,
                                              color: Colors.white,
                                            ),
                                          )
                                        : Container(
                                            height: 25,
                                            width: 25,
                                            decoration: BoxDecoration(
                                              color: Colors.black,
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                  color: Colors.grey, width: 1),
                                            ),
                                          )
                              ],
                            ))),
                    Container(
                        height: 60,
                        width: 160,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: widget.controller.storage.read("mode") == null
                              ? Border.all(
                                  color: widget.controller.displayColor,
                                  width: 2,
                                )
                              : !widget.controller.storage.read("mode")
                                  ? Border.all(
                                      color: widget.controller.displayColor,
                                      width: 2,
                                    )
                                  : Border.all(
                                      color: Colors.grey,
                                      width: 1,
                                    ),
                        ),
                        padding: const EdgeInsets.all(10.0),
                        child: InkWell(
                            onTap: () {
                              Get.changeThemeMode(
                                ThemeMode.light,
                              );
                              widget.controller.storage.write("mode", false);
                              widget.controller.update();

                              // widget.controller.storage.write("mode", false);
                              // widget.controller.update();
                              //  Get.delete<NewsfeedController>();
                              // if (kIsWeb) {
                              //   Get.offAllNamed(FluroRouters.mainScreen);
                              //  // Get.offNamed(FluroRouters.mainScreen);
                              // } else {
                              //   Get.offUntil(
                              //       MaterialPageRoute(
                              //         builder: (context) => Session(),
                              //       ),
                              //           (route) => false);
                              // }
                            },
                            child: Row(
                              children: [
                                Text(
                                  Strings.light,
                                  style: Styles.baseTextTheme.headline2
                                      .copyWith(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                ),
                                // Icon(
                                //     widget.controller.storage.read("mode") == null
                                //     ? Icons.check_circle
                                //     : !widget.controller.storage.read("mode")
                                //         ? Icons.check_circle
                                //         : Icons.radio_button_off
                                // ),
                                const Spacer(),
                                widget.controller.storage.read("mode") == null
                                    ? Container(
                                        height: 25,
                                        width: 25,
                                        decoration: BoxDecoration(
                                          color: widget.controller.displayColor,
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(
                                          Icons.check,
                                          color: Colors.white,
                                        ),
                                      )
                                    : !widget.controller.storage.read("mode")
                                        ? Container(
                                            height: 25,
                                            width: 25,
                                            decoration: BoxDecoration(
                                              color: widget
                                                  .controller.displayColor,
                                              shape: BoxShape.circle,
                                            ),
                                            child: const Icon(
                                              Icons.check,
                                              color: Colors.white,
                                            ),
                                          )
                                        : Container(
                                            height: 25,
                                            width: 25,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                  color: Colors.grey, width: 1),
                                            ),
                                          ),
                              ],
                            )))
                  ],
                ),
                const SizedBox(
                  height: 30,
                ),
                Center(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.only(
                          left: 20, right: 20, top: 5, bottom: 5),
                      backgroundColor: widget.controller.displayColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Text(
                      Strings.done,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ]),
      ),
    );
  }
}

class WebSideDrawersIcons extends StatelessWidget {
  const WebSideDrawersIcons(this.image,this.color,
      {Key key, this.width = 22, this.height = 22,}) : super(key: key);

  final String image;
  final double width;
  final double height;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Image.asset(
        image,
        width: width,
        height: height,
        color: color,
      )

    );
  }
}