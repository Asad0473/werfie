import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
// #docregion platform_imports
// Import for Android features.
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:werfieapp/utils/asset_string.dart';
// #enddocregion platform_imports

class WebViewScreen extends StatefulWidget {
  final webUrl;

  const WebViewScreen({
    Key key,
    this.webUrl,
  }) : super(key: key);

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  var loadingPercentage = 0;
  WebViewController controller;

  @override
  void initState() {
    super.initState();
    debugPrint("WebUrl: ${widget.webUrl}");
    controller = WebViewController();

    controller = WebViewController()
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (url) {
          if (mounted) {
            setState(() {
              loadingPercentage = 0;
            });
          }
        },
        onProgress: (progress) {
          if (mounted) {
            setState(() {
              loadingPercentage = progress;
            });
          }
        },
        onPageFinished: (url) {
          if (mounted) {
            setState(() {
              loadingPercentage = 100;
            });
          }
        },

        // onNavigationRequest: (NavigationRequest request) {
        //   if (request.url.startsWith('https://www.youtube.com/')) {
        //     return NavigationDecision.prevent;
        //   }
        //   return NavigationDecision.navigate;
        // },
      ))
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.webUrl.trim()),
      );

    if (controller.platform is AndroidWebViewController) {
      AndroidWebViewController.enableDebugging(true);
      (controller.platform as AndroidWebViewController)
          .setMediaPlaybackRequiresUserGesture(false);
    }

    // widget.controller.loadRequest(
    //     Uri.parse(widget.String.trim()),
    //   );
  }

  @override
  void dispose() {
    // TODO: implement dispose

    _WebViewScreenState;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading:  IconButton(
          //splashColor: Colors.white,
          // hoverColor: Colors.grey[100],
          icon: Icon(
            Icons.arrow_back,
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
          ),
          onPressed: _exitApp,
        ),
        automaticallyImplyLeading: false,
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? Colors.black
            : Colors.white,
        centerTitle: true,
        title: Container(
          height: 40,
          width: 100,
          child: Image.asset(
            Theme.of(context).brightness == Brightness.dark?
            AppImages.simpleWhiteWLogo:AppImages.simpleBlackWLogo,

            // color: Color((0xFF47b867)),
          ),
        ),
        iconTheme: IconThemeData(
          color: Color(0xFF4f515b),
        ),
      ),
      body: Stack(
        children: [
          WebViewWidget(
            controller: controller,
          ),
          if (loadingPercentage < 100)
            LinearProgressIndicator(
              value: loadingPercentage / 100.0,
            ),
        ],
      ),
    );
  }
  _exitApp() async {
    Navigator.pop(context);

  /*  debugPrint("001");
    if ( controller!=null) {
      debugPrint("002");
      print("onwill goback");
      if ( await controller.canGoBack()){
        print("onwill goback 002");
        controller.goBack();
      } else {
        if (mounted) Navigator.pop(context);
      }
    } else {
      debugPrint("003");
      // Scaffold.of(context).showSnackBar(
      //   const SnackBar(content: Text("No back history item")),
      // );
      if (mounted) Navigator.pop(context);
    }*/
  }
}
