import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/get_follower.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/blue_tick.dart';

import '../components/rounded_button.dart';
import '../models/profile.dart';
import '../network/singleTone.dart';
import '../screens/hash_taga_werfs_screen.dart';
import '../screens/message_request_screen.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import '../widgets/chat_screen_mobile.dart';
import '../widgets/new_message_dialog.dart';
import 'web_main_screen.dart';

// ignore: must_be_immutable
class WebNewsfeedRightSection extends StatelessWidget {
  final NewsfeedController controller;

  WebNewsfeedRightSection(this.controller, {Key key}) : super(key: key);

  String radioItem = '';
  RxDouble size = 47.0.obs;

  RxBool checkIcon = false.obs;

  @override
  Widget build(BuildContext context) {
    // Locale myLocale = Localizations.localeOf(context);
    if (controller.messagePopupSize == 500.0) {
      checkIcon.value = true;
    } else {
      checkIcon.value = false;
    }
    return Container(
      padding: EdgeInsets.only(
          left: controller.isChatScreen ? 0 : 20,
          right: controller.isChatScreen ? 0 : 0),
      // width: MediaQuery.of(context).size.width * 0.26,
    //  width: MediaQuery.of(context).size.width <= 1100 ? 290 : 350,
      child: Stack(
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width <= 1100 ? 290 : 350,
            child: Column(
              children: [
                const SizedBox(height: 20),
                controller.isBrowseScreen == true
                    ? const SizedBox()
                    : SizedBox(
                        height: 45,
                        width: 350,
                        child: TextField(
                          style: LightStyles.baseTextTheme.headline4.copyWith(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            //fontWeight: FontWeight.w500,
                            // fontSize: 14,
                          ),
                          cursorColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                          onTap: () {
                            // print("search tap called");
                            if (controller.isFilterScreen) {
                              // print("search tap called if");

                              controller.isProfileScreen = false;
                              controller.isSettingsScreen = false;
                              controller.isSavedPostScreen = false;
                              controller.isNewsFeedScreen = false;
                              controller.isOtherUserProfileScreen = false;
                              controller.isChatScreen = false;
                              controller.isChatScreenWeb = false;
                              controller.isBrowseScreen = false;
                              controller.isClickWhoToFollow = false;
                              controller.isFollwerScreen = false;
                              controller.isPostDetails = false;
                              controller.isFilterScreen = true;

                              controller.isSearch = false;
                              controller.isFilter = false;

                              controller.update();
                            }
                            else {
                              // print("search tap called else");

                              controller.isSearch = true;
                              controller.isPostDetails = false;
                              controller.isFilter = true;
                              controller.isFilterScreen = false;
                              controller.update();
                            }
                          },
                          controller: controller.searchText,
                          onChanged: (val) async {
                            await controller.onSearchTextChanged(val);

                            if (controller.isFilterScreen) {
                              controller.isFilterScreen = true;

                              controller.isSearch = true;
                              controller.isFilter = false;

                              controller.update();
                            } else {
                              controller.isSearch = true;
                              controller.update();
                            }
                          },
                          textAlignVertical: TextAlignVertical.center,
                          decoration: InputDecoration(
                            filled: true,
                            hintText: Strings.search,
                            // border: InputBorder.none,
                            contentPadding: const EdgeInsets.only(
                                left: 0, bottom: 13, top: 0, right: 0),
                            hintStyle: LightStyles.baseTextTheme.headline3,
                            prefixIcon: Icon(
                              Icons.search,
                              size: 20,
                              color:
                                  Theme.of(context).brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(40),
                              borderSide:
                                  const BorderSide(color: Colors.grey, width: 1),
                            ),
                            //
                            // enabledBorder: OutlineInputBorder(
                            //   borderRadius: BorderRadius.circular(40),
                            //   borderSide: BorderSide(color: Colors.grey, width: 1),
                            // ),
                            fillColor:
                                Theme.of(context).brightness == Brightness.dark
                                    ? const Color(0xFF16181c)
                                    : const Color(0XFFeff3f4),
                          ),
                        ),
                      ),
                const SizedBox(height: 10),
                const SizedBox(height: 10),
                controller.isWhoToFollowScreen == true
                    ? const SizedBox()
                    : !controller.isFilterScreen
                        ? Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                  // color: Colors.grey.withOpacity(0.06),
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? const Color(0xFF16181c)
                                      : const Color(0XFFeff3f4),
                                  borderRadius: BorderRadius.circular(15)),
                              child: SingleChildScrollView(
                                child: Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                            padding: EdgeInsets.only(
                                                left: 4,
                                                top: 10,
                                                bottom: 10,
                                                right: MediaQuery.of(context)
                                                            .size
                                                            .width <=
                                                        1250
                                                    ? 4
                                                    : 4),
                                            child: Align(
                                                alignment: Alignment.topLeft,
                                                child: SizedBox(
                                                  child: Text(
                                                    Strings.whoToFollow,
                                                    // style: Theme.of(context).brightness == Brightness.dark
                                                    //     ? TextStyle(
                                                    //   color: Colors.white,
                                                    //   fontSize: MediaQuery.of(context).size.width <= 1280 ? 14 : 20,
                                                    //   fontWeight: MediaQuery.of(context).size.width <= 1280 ? FontWeight.w600 : FontWeight.bold,
                                                    // )
                                                    //     : TextStyle(
                                                    //   color: Colors.black,
                                                    //   fontSize: MediaQuery.of(context).size.width <= 1280 ? 14: 20,
                                                    //   fontWeight: MediaQuery.of(context).size.width <= 1280 ? FontWeight.w600 : FontWeight.bold,
                                                    //   ),

                                                    // Color(0xff9aa0a6),

                                                    style: TextStyle(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: controller
                                                                  .languageData
                                                                  .appLang
                                                                  .id ==
                                                              2
                                                          ? 20
                                                          : MediaQuery.of(context)
                                                                      .size
                                                                      .width <=
                                                                  1280
                                                              ? 16
                                                              : 18,
                                                      fontWeight:
                                                          MediaQuery.of(context)
                                                                      .size
                                                                      .width <=
                                                                  1280
                                                              ? FontWeight.bold
                                                              : FontWeight.bold,
                                                    ),
                                                    // style: Theme
                                                    //     .of(context)
                                                    //     .textTheme
                                                    //     .headline6
                                                    //     .copyWith(
                                                    //   fontSize: MediaQuery
                                                    //       .of(context)
                                                    //       .size
                                                    //       .width <=
                                                    //       1250
                                                    //       ? 14
                                                    //       : 18,
                                                    //   fontWeight: FontWeight.w700,
                                                    //   color: Colors.black,
                                                    // ),
                                                  ),
                                                )),
                                          ),
                                          // Spacer(),
                                          controller.followSuggestionsList
                                                  .isNotEmpty
                                              ? controller.followSuggestionsList
                                                          .length >=
                                                      3
                                                  ? Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 10,
                                                              top: 10,
                                                              bottom: 10,
                                                              left: 10),
                                                      child: Align(
                                                          alignment:
                                                              Alignment.topRight,
                                                          child: InkWell(
                                                            onTap: () {
                                                              Get.toNamed("${FluroRouters.mainScreen}/whoToFollowScreen");
                                                            },
                                                            child: Text(
                                                              Strings.seeMore,
                                                              // style: Theme.of(context).brightness == Brightness.dark
                                                              //     ? TextStyle(
                                                              //   color: Theme.of(context).brightness == Brightness.dark ? controller.displayColor : controller.displayColor,
                                                              //   fontSize: MediaQuery.of(context).size.width <= 1280 ? 14 : 16,
                                                              //   fontWeight: MediaQuery.of(context).size.width <= 1280 ? FontWeight.w400 : FontWeight.w400,
                                                              // )
                                                              //     : TextStyle(
                                                              //   color: controller.displayColor,
                                                              //   fontSize: MediaQuery.of(context).size.width <= 1280 ? 14 : 16,
                                                              //   fontWeight: MediaQuery.of(context).size.width <= 1280 ? FontWeight.w400 : FontWeight.w400,
                                                              //   ),

                                                              style: TextStyle(
                                                                color: controller
                                                                    .displayColor,
                                                                fontSize: controller
                                                                            .languageData
                                                                            .appLang
                                                                            .id ==
                                                                        2
                                                                    ? 18
                                                                    : MediaQuery.of(context)
                                                                                .size
                                                                                .width <=
                                                                            1280
                                                                        ? 14
                                                                        : 14,
                                                                fontWeight: MediaQuery.of(
                                                                                context)
                                                                            .size
                                                                            .width <=
                                                                        1280
                                                                    ? FontWeight
                                                                        .w400
                                                                    : FontWeight
                                                                        .w400,
                                                              ),

                                                              // style: Theme
                                                              //     .of(context)
                                                              //     .textTheme
                                                              //     .headline6
                                                              //     .copyWith(
                                                              //   // myLocale.toString() == 'fe' ? fontSize: 14 :
                                                              //   fontSize: MediaQuery
                                                              //       .of(
                                                              //       context)
                                                              //       .size
                                                              //       .width <=
                                                              //       1250
                                                              //       ? 10
                                                              //       : 14,
                                                              //
                                                              //   color:
                                                              //   Colors.blueAccent,
                                                              // ),
                                                            ),
                                                          )),
                                                    )
                                                  : const SizedBox()
                                              : const SizedBox(),
                                        ],
                                      ),
                                      // Container(
                                      //   height:0.1,
                                      //   width: MediaQuery
                                      //       .of(context)
                                      //       .size
                                      //       .width * 0.25,
                                      //   color: Colors.white.withOpacity(0.2),
                                      // ),
                                      controller.isWhoToFollow == true
                                          ? const Center(
                                              child: CircularProgressIndicator(
                                                color: MyColors.BlueColor,
                                              ),
                                            )
                                          : controller.followSuggestionsList == null ||
                                                  controller.followSuggestionsList.isEmpty
                                              ? Center(
                                                  child:
                                                      Text(Strings.noSuggestion))
                                              : SingleChildScrollView(
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: List.generate(
                                                        controller.followSuggestionsList
                                                                    .length >=
                                                                4
                                                            ? 4
                                                            : controller
                                                                .followSuggestionsList
                                                                .length, (index) {
                                                      return InkWell(
                                                        hoverColor: Colors.grey
                                                            .withOpacity(0.1),
                                                        onTap: () {
                                                          onHomeChange = false;
                                                          onBrowsChange = false;
                                                          onTrendsChange = false;
                                                          onBookMarksChange = false;
                                                          onChatsChange = false;
                                                          onProfileChange = false;
                                                          onSettingChange = false;
                                                          onListChange = false;
                                                          onNotificationChange = false;
                                                          onMoreChange = false;

                                                          if (kIsWeb) {
                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                UserProfile();
                                                            Get.find<
                                                                    NewsfeedController>()
                                                                .update();

                                                            _clickWho(controller
                                                                    .followSuggestionsList[
                                                                index]);
                                                          }
                                                        },
                                                        child: Column(
                                                          children: [

                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 20,
                                                                      left: 2,
                                                                      right: 2),
                                                              child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  controller.userProfile ==
                                                                          null
                                                                      ? SizedBox(
                                                                          width:
                                                                              24,
                                                                          child:
                                                                              Center(
                                                                            child:
                                                                                SpinKitCircle(
                                                                              color:
                                                                                  Colors.grey,
                                                                              size:
                                                                                  40,
                                                                            ),
                                                                          ))
                                                                      : controller.followSuggestionsList[index].profileImage ==
                                                                              null
                                                                          ? const CircleAvatar(
                                                                              radius:
                                                                                  18,
                                                                              backgroundImage:
                                                                                  AssetImage("assets/images/person_placeholder.png"))
                                                                          : ClipRRect(
                                                                              borderRadius:
                                                                                  BorderRadius.circular(30),
                                                                              child: FadeInImage(
                                                                                  fit: BoxFit.cover,
                                                                                  width: 38,
                                                                                  height: 38,
                                                                                  placeholder: const AssetImage('assets/images/person_placeholder.png'),
                                                                                  image: NetworkImage(controller.followSuggestionsList[index].profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                                            ),
                                                                  const SizedBox(
                                                                      width: 12),
                                                                  Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      const SizedBox(
                                                                          height:
                                                                              8),
                                                                      Row(
                                                                        children: [
                                                                          SizedBox(
                                                                            width: MediaQuery.of(context).size.width <= 1100
                                                                                ? 80
                                                                                : controller.followSuggestionsList[index].name.length > 15
                                                                                    ? 130
                                                                                    : null,
                                                                            child:
                                                                                Text(
                                                                              controller.followSuggestionsList[index].name,
                                                                              // style: Theme.of(context).brightness == Brightness.dark
                                                                              //     ? TextStyle(
                                                                              //     color: Colors.white,
                                                                              //     fontWeight: FontWeight.bold
                                                                              // )
                                                                              //     : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                                                              //
                                                                              //
                                                                              // ),
                                                                              softWrap:
                                                                                  false,
                                                                              maxLines:
                                                                                  1,
                                                                              overflow: MediaQuery.of(context).size.width <= 1100
                                                                                  ? TextOverflow.ellipsis
                                                                                  : controller.followSuggestionsList[index].name.length > 15
                                                                                      ? TextOverflow.ellipsis
                                                                                      : null,
                                                                              style:
                                                                                  TextStyle(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontWeight: FontWeight.bold,
                                                                                fontSize: 14,
                                                                              ),

                                                                              // style: Theme
                                                                              //     .of(
                                                                              //     context)
                                                                              //     .textTheme
                                                                              //     .bodyText2
                                                                              //     .copyWith(
                                                                              //     height:
                                                                              //     1.2,
                                                                              //     fontWeight:
                                                                              //     FontWeight.bold),
                                                                            ),
                                                                          ),
                                                                          controller.followSuggestionsList[index].accountVerified ==
                                                                                  "verified"
                                                                              ? Row(
                                                                                  children: [
                                                                                    const SizedBox(
                                                                                      width: 5,
                                                                                    ),
                                                                                    BlueTick(
                                                                                      height: 15,
                                                                                      width: 15,
                                                                                      iconSize: 10,
                                                                                    ),
                                                                                  ],
                                                                                )
                                                                              : const SizedBox(),
                                                                        ],
                                                                      ),
                                                                      Padding(
                                                                        padding: const EdgeInsets
                                                                                .only(
                                                                            bottom:
                                                                                5.0),
                                                                        child:
                                                                            SizedBox(
                                                                          width:
                                                                              100,
                                                                          child:
                                                                              Text(
                                                                            '@${controller.followSuggestionsList[index].username}',
                                                                            // style: Theme.of(context).brightness == Brightness.dark
                                                                            //     ? TextStyle(
                                                                            //   color: Colors.white,
                                                                            // )
                                                                            //     : TextStyle(
                                                                            //   color: Colors.black,
                                                                            // ),
                                                                            softWrap:
                                                                                false,
                                                                            maxLines:
                                                                                1,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline4
                                                                                .copyWith(
                                                                              fontSize:
                                                                                  12,
                                                                            ),
                                                                            // TextStyle(
                                                                            //   color: Theme.of(context).brightness == Brightness.dark
                                                                            //       ? Color(0xFF586976)
                                                                            //       : Color(0xFF586976),
                                                                            //   fontSize: 12,
                                                                            // ),
                                                                          ),
                                                                        ),
                                                                      )
                                                                    ],
                                                                  ),
                                                                  const Spacer(),
                                                                  Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .end,
                                                                    children: [
                                                                      // InkWell(
                                                                      //     onTap: () {},
                                                                      //     child: Icon(
                                                                      //       Icons
                                                                      //           .more_horiz,
                                                                      //       color:
                                                                      //           Colors.grey,
                                                                      //       size: 20,
                                                                      //     )),
                                                                      ClipRRect(
                                                                        borderRadius:
                                                                            BorderRadius.circular(
                                                                                20),
                                                                        child:
                                                                            MaterialButton(
                                                                          padding:
                                                                              const EdgeInsets.all(0),
                                                                          color: Theme.of(context).brightness ==
                                                                                  Brightness.dark
                                                                              ? !controller.followSuggestionsList[index].isFollow
                                                                                  ? Colors.white
                                                                                  : Colors.black
                                                                              : !controller.followSuggestionsList[index].isFollow
                                                                                  ? Colors.black
                                                                                  : Colors.white,
                                                                          onPressed:
                                                                              () async {
                                                                            if (controller.followSuggestionsList[index].isFollow == false) {
                                                                              controller.followSuggestionsList[index].isFollow = true;
                                                                              controller.userProfile.followings = controller.userProfile.followings +1;
                                                                              controller.update();
                                                                              await controller.addFollowing(controller.followSuggestionsList[index].id, "follow");
                                                                            } else if (controller.followSuggestionsList[index].isFollow == true) {
                                                                              showDialog(
                                                                                  context: context,
                                                                                  builder: (BuildContext con) {
                                                                                    return AlertDialog(


                                                                                        shape: RoundedRectangleBorder(
                                                                                          borderRadius: BorderRadius.circular(15),
                                                                                        ),
                                                                                        backgroundColor: Theme
                                                                                            .of(context)
                                                                                            .brightness == Brightness.dark
                                                                                            ? MyColors.liteDark
                                                                                            : Colors.white,
                                                                                        contentPadding: EdgeInsets.zero,
                                                                                        content: Padding(
                                                                                          padding: const EdgeInsets.only(
                                                                                              left: 20, right: 20, top: 20),
                                                                                          child: SizedBox(
                                                                                            height: 250,
                                                                                            width: 250,
                                                                                            child: SingleChildScrollView(
                                                                                              child: Column(
                                                                                                crossAxisAlignment:
                                                                                                CrossAxisAlignment.start,
                                                                                                children: [
                                                                                                  Text(
                                                                                                    "${Strings.unFollow}",
                                                                                                    style: TextStyle(
                                                                                                      fontSize: 16,
                                                                                                      fontWeight: FontWeight.bold,
                                                                                                      color: Theme
                                                                                                          .of(context)
                                                                                                          .brightness == Brightness.dark
                                                                                                          ? Colors.white
                                                                                                          : Colors.black,
                                                                                                    ),
                                                                                                  ),
                                                                                                  Text(
                                                                                                    Strings
                                                                                                        .unFollowDetailsStrings,
                                                                                                    style: TextStyle(
                                                                                                      height: 1.2,
                                                                                                      fontSize: 14,
                                                                                                      color: Theme
                                                                                                          .of(context)
                                                                                                          .brightness == Brightness.dark
                                                                                                          ? MyColors.grey
                                                                                                          : Colors.black,
                                                                                                    ),
                                                                                                  ),
                                                                                                  const SizedBox(
                                                                                                    height: 20,
                                                                                                  ),
                                                                                                  Row(
                                                                                                    children: [
                                                                                                      Expanded(
                                                                                                        child: ElevatedButton(
                                                                                                          // key: LoginController.formKey,
                                                                                                          onPressed: () async {
                                                                                                            Navigator.pop(context);
                                                                                                            controller.followSuggestionsList[index].isFollow = false;
                                                                                                            await controller.addFollowing(controller.followSuggestionsList[index].id,
                                                                                                                "unFollow");
                                                                                                            controller.userProfile.followings = controller.userProfile.followings -1;
                                                                                                            controller.update();
                                                                                                          },
                                                                                                          style: ElevatedButton.styleFrom(
                                                                                                            shadowColor:
                                                                                                            Theme
                                                                                                                .of(context)
                                                                                                                .brightness == Brightness.dark
                                                                                                                ? Colors.white
                                                                                                                : MyColors.werfieBlue,

                                                                                                            padding: const EdgeInsets.symmetric(

                                                                                                                vertical: 20,
                                                                                                                horizontal: 25),
                                                                                                            elevation: 0.0,
                                                                                                            shape: const StadiumBorder(),
                                                                                                            // minimumSize: Size(100, 40),
                                                                                                          ),
                                                                                                          child: Text(
                                                                                                            Strings.unFollow,
                                                                                                            style: Styles.baseTextTheme
                                                                                                                .headline2.copyWith(
                                                                                                              color: Colors.white,
                                                                                                              fontSize: 14,
                                                                                                              fontWeight: FontWeight.bold,
                                                                                                            ),
                                                                                                          ),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ],
                                                                                                  ),
                                                                                                  const SizedBox(
                                                                                                    height: 10,
                                                                                                  ),
                                                                                                  Row(
                                                                                                    children: [
                                                                                                      Expanded(
                                                                                                        child: ElevatedButton(
                                                                                                          // key: LoginController.formKey,
                                                                                                          onPressed: () async {
                                                                                                            Navigator.pop(context);
                                                                                                          },
                                                                                                          style: ElevatedButton.styleFrom(
                                                                                                            shadowColor:
                                                                                                            Colors.transparent,
                                                                                                            primary: Theme
                                                                                                                .of(context)
                                                                                                                .brightness == Brightness.dark
                                                                                                                ? Colors.black
                                                                                                                : Colors.white,
                                                                                                            padding: const EdgeInsets.symmetric(

                                                                                                                vertical: 20,
                                                                                                                horizontal: 25),
                                                                                                            elevation: 0.0,
                                                                                                            shape: const StadiumBorder(

                                                                                                            ),
                                                                                                            side: const BorderSide(
                                                                                                              width: 1,
                                                                                                              color: MyColors.grey,
                                                                                                            ),
                                                                                                            // minimumSize: Size(100, 40),
                                                                                                          ),
                                                                                                          child: Text(
                                                                                                            Strings.cancel,
                                                                                                            style: Styles.baseTextTheme
                                                                                                                .headline2.copyWith(
                                                                                                              color: Theme
                                                                                                                  .of(context)
                                                                                                                  .brightness ==
                                                                                                                  Brightness.dark ? Colors
                                                                                                                  .white : Colors.black,
                                                                                                              fontSize: 14,
                                                                                                              fontWeight: FontWeight.bold,
                                                                                                            ),
                                                                                                          ),
                                                                                                        ),
                                                                                                      ),
                                                                                                    ],
                                                                                                  ),


                                                                                                ],
                                                                                              ),
                                                                                            ),


                                                                                          ),
                                                                                        )

                                                                                      //     Deactivation(
                                                                                      //   context2: context,
                                                                                      // ),
                                                                                    );
                                                                                  });

                                                                            }

                                                                            // print(
                                                                            //     "Followed Id yahha");
                                                                            // print(
                                                                            //     "${controller.followSuggestionsList[index].id}");
                                                                            // print(
                                                                            //     "Followed Id ni haaa");
                                                                          },
                                                                          child:
                                                                              Text(
                                                                            !controller.followSuggestionsList[index].isFollow
                                                                                ? "${Strings.follow}".capitalizeFirst
                                                                                : "${Strings.unFollow}".capitalizeFirst,
                                                                            style:
                                                                                TextStyle(
                                                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize:
                                                                                  13,
                                                                              fontWeight:
                                                                                  FontWeight.w700,
                                                                              color: Theme.of(context).brightness == Brightness.dark
                                                                                  ? !controller.followSuggestionsList[index].isFollow
                                                                                      ? Colors.black
                                                                                      : Colors.white
                                                                                  : !controller.followSuggestionsList[index].isFollow
                                                                                      ? Colors.white
                                                                                      : Colors.black,
                                                                            ),
                                                                            // style:
                                                                            // TextStyle(
                                                                            //   fontSize:
                                                                            //   10,
                                                                            //   color:
                                                                            //   Colors.white,
                                                                            // ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),

                                                          ],
                                                        ),
                                                      );
                                                    }),
                                                  ),
                                                ),
                                      // Spacer(),
                                      // Container(
                                      //   height: 0.1,
                                      //   width: MediaQuery.of(context).size.width,
                                      //   color: Colors.grey.withOpacity(0.2),
                                      // ),
                                      // Padding(
                                      //   padding: const EdgeInsets.symmetric(
                                      //       horizontal: 20, vertical: 10),
                                      //   child: Align(
                                      //       alignment: Alignment.bottomLeft,
                                      //       child: InkWell(
                                      //         onTap: () {
                                      //           controller.isWhoToFollowScreen = true;
                                      //           controller.isTrendsScreen = false;
                                      //           controller.isNewsFeedScreen = false;
                                      //           controller.isBrowseScreen = false;
                                      //           controller.isNotificationScreen = false;
                                      //           controller.isChatScreen = false;
                                      //           controller.isPostDetails = false;
                                      //           controller.update();
                                      //         },
                                      //         child: Expanded(
                                      //           child: Text(
                                      //             Strings.seeMore,
                                      //             style: Theme.of(context)
                                      //                 .textTheme
                                      //                 .headline6
                                      //                 .copyWith(
                                      //                   fontSize: 14,
                                      //                   fontWeight: FontWeight.w700,
                                      //                   color: Colors.blueAccent,
                                      //                 ),
                                      //           ),
                                      //         ),
                                      //       )),
                                      // ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          )
                        : Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                  // color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.grey.withOpacity(0.06),
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? const Color(0xFF16181c)
                                      : const Color(0XFFeff3f4),
                                  borderRadius: BorderRadius.circular(15)),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 20, right: 20, top: 10, bottom: 10),
                                    child: Align(
                                        alignment: Alignment.centerLeft,
                                        child: Text(Strings.searchFilter,
                                            style: Styles.baseTextTheme.headline2
                                                .copyWith(
                                              color:
                                                  Theme.of(context).brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                              fontWeight: FontWeight.w700,
                                            )
                                            // TextStyle(
                                            //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                            //   fontSize:   18,
                                            //   fontWeight: FontWeight.w700,
                                            // ),
                                            )),
                                  ),
                                  Container(
                                    height: 0.1,
                                    width: MediaQuery.of(context).size.width,
                                    color: Colors.grey.withOpacity(0.2),
                                  ),
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          top: 10.0, left: 10),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            Strings.people,
                                            style: Styles.baseTextTheme.headline2
                                                .copyWith(
                                              color:
                                                  Theme.of(context).brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          FilterPeopleButton(
                                              value: 1,
                                              controller: controller,
                                              title: Strings.fromAnyone,
                                              onTap: (value) {
                                                controller.people = value;
                                                controller.filterUsers(
                                                  id: controller
                                                      .searchSelected.id,
                                                  type: controller
                                                      .searchSelected.type,
                                                  tag: controller.searchText.text
                                                          .isNotEmpty
                                                      ? controller.searchText.text
                                                      : null,
                                                );

                                                controller.update();
                                              }),
                                          FilterPeopleButton(
                                              value: 2,
                                              controller: controller,
                                              title: Strings.peopleYouFollow,
                                              onTap: (value) {
                                                controller.people = value;
                                                controller.filterUsers(
                                                  id: controller
                                                      .searchSelected.id,
                                                  type: controller
                                                      .searchSelected.type,
                                                  tag: controller.searchText.text
                                                          .isNotEmpty
                                                      ? controller.searchText.text
                                                      : null,
                                                );

                                                controller.update();
                                              }),
                                          Text(
                                            Strings.location,
                                            style: Styles.baseTextTheme.headline2
                                                .copyWith(
                                              color:
                                                  Theme.of(context).brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          FilterPlaceButton(
                                              value: 1,
                                              controller: controller,
                                              title: Strings.anywhere,
                                              onTap: (value) {
                                                controller.place = value;
                                                // print("presssed");
                                                // print("$value");
                                                // print("presssed");
                                                controller.filterUsers(
                                                  id: controller
                                                      .searchSelected.id,
                                                  type: controller
                                                      .searchSelected.type,
                                                  tag: controller.searchText.text
                                                          .isNotEmpty
                                                      ? controller.searchText.text
                                                      : null,
                                                );
                                                controller.update();
                                              }),
                                          FilterPlaceButton(
                                              value: 2,
                                              controller: controller,
                                              title: Strings.nearYou,
                                              onTap: (value) {
                                                controller.place = value;
                                                // print("presssed");
                                                // print("$value");
                                                // print("presssed");
                                                controller.filterUsers(
                                                  id: controller
                                                      .searchSelected.id,
                                                  type: controller
                                                      .searchSelected.type,
                                                  tag: controller.searchText.text
                                                          .isNotEmpty
                                                      ? controller.searchText.text
                                                      : null,
                                                );

                                                controller.update();
                                              }),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const Spacer(),
                                  Container(
                                    height: 0.1,
                                    width: MediaQuery.of(context).size.width,
                                    color: Colors.grey.withOpacity(0.2),
                                  ),

                                ],
                              ),
                            ),
                          ),
                SizedBox(
                  height: controller.isWhoToFollowScreen == true ? 0 : 10,
                ),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                        // color: Colors.grey.withOpacity(0.06),
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF16181c)
                            : const Color(0XFFeff3f4),
                        borderRadius: BorderRadius.circular(15)),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 10, top: 10, bottom: 10, right: 10),
                            child: Align(
                                alignment: Alignment.topLeft,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    FittedBox(
                                      child: Text(
                                        Strings.hotTrends,
                                        style: TextStyle(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: controller
                                                      .languageData.appLang.id ==
                                                  2
                                              ? 20
                                              : MediaQuery.of(context)
                                                          .size
                                                          .width <=
                                                      1280
                                                  ? 16
                                                  : 18,
                                          fontWeight:
                                              MediaQuery.of(context).size.width <=
                                                      1280
                                                  ? FontWeight.bold
                                                  : FontWeight.bold,
                                        ),
                                        // style: Theme
                                        //     .of(context)
                                        //     .textTheme
                                        //     .headline6
                                        //     .copyWith(
                                        //   fontSize: 16,
                                        //   fontWeight: FontWeight.w700,
                                        //   color: Colors.black,
                                        // ),
                                      ),
                                    ),
                                    Align(
                                        alignment: Alignment.topRight,
                                        child: InkWell(
                                          onTap: () {
                                            onHomeChange = false;
                                            onBrowsChange = false;
                                            onTrendsChange = true;
                                            onBookMarksChange = false;
                                            onChatsChange = false;
                                            onProfileChange = false;
                                            onSettingChange = false;
                                            onListChange = false;
                                            onNotificationChange = false;
                                            onMoreChange = false;

                                            controller.isWhoToFollowScreen =
                                                false;
                                            controller.isTrendsScreen = true;
                                            controller.isNewsFeedScreen = false;
                                            controller.isBrowseScreen = false;
                                            controller.isNotificationScreen =
                                                false;
                                            controller.isChatScreen = false;
                                            controller.isPostDetails = false;
                                            Get.toNamed('${FluroRouters.mainScreen}/trends');

                                            // controller.update();
                                          },
                                          child: Text(Strings.seeMore,
                                              // style: Theme.of(context).brightness == Brightness.dark
                                              //     ? TextStyle(
                                              //   color: controller.displayColor,
                                              //   fontSize: MediaQuery.of(context).size.width <= 1280 ? 14 : 18,
                                              //   fontWeight: MediaQuery.of(context).size.width <= 1280 ? FontWeight.w400 : FontWeight.w400,                                            )
                                              //     : TextStyle(
                                              //   color: controller.displayColor,
                                              //   fontSize: MediaQuery.of(context).size.width <= 1280 ? 14 : 18,
                                              //   fontWeight: MediaQuery.of(context).size.width <= 1280 ? FontWeight.w400 : FontWeight.w400,
                                              //   ),
                                              style: TextStyle(
                                                color: controller.displayColor,
                                                fontSize: controller.languageData
                                                            .appLang.id ==
                                                        2
                                                    ? 18
                                                    : MediaQuery.of(context)
                                                                .size
                                                                .width <=
                                                            1280
                                                        ? 14
                                                        : 14,
                                                fontWeight: MediaQuery.of(context)
                                                            .size
                                                            .width <=
                                                        1280
                                                    ? FontWeight.w400
                                                    : FontWeight.w400,
                                              )),
                                        )),
                                  ],
                                )),
                          ),
                          // Container(
                          //   height: 0.1,
                          //   width: MediaQuery
                          //       .of(context)
                          //       .size
                          //       .width,
                          //   color: Colors.grey.withOpacity(0.2),
                          // ),
                          controller.isTrendingLoading == true
                              ? const Center(
                                  child: CircularProgressIndicator(
                                      color: MyColors.BlueColor),
                                )
                              : controller.trendingList == null ||
                                      controller.trendingList.trends.isEmpty
                                  ? Center(
                                      child: Padding(
                                      padding: const EdgeInsets.only(top: 10),
                                      child: Text(
                                        Strings.noTrending,
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ))
                                  : Expanded(
                                      child: ListView.builder(
                                        // controller.trendingList.length
                                        // >= 2
                                        //     ? 2
                                        //     :
                                        itemBuilder: (context, index) {
                                          return InkWell(
                                            hoverColor:
                                                Colors.grey.withOpacity(0.1),
                                            onTap: () {
                                              if (kIsWeb) {
                                                Get.toNamed(
                                                    "${FluroRouters.mainScreen}/tagWerfs/${controller.trendingList.trends[index].title}");
                                              } else {
                                                Get.to(HashTagWerfsScreen(
                                                  tag: controller.trendingList.trends[index].title,
                                                  controller: controller,
                                                ));
                                                //LoggingUtils.printValue("tag value", tag);
                                              }
                                              /*SearchSuggestion sugge =
                                              SearchSuggestion();
                                              sugge.id = controller
                                                  .trendingList.trends[index].tagId;
                                              sugge.type = "tag";
                                              controller.searchSelected = sugge;

                                              controller.isProfileScreen = false;
                                              controller.isFilterScreen = true;
                                              controller.searchText.text =
                                                  controller.trendingList.trends[index]
                                                      .title;
                                              controller.isProfileScreen = false;
                                              controller.isSettingsScreen = false;
                                              controller.isSavedPostScreen = false;
                                              controller.isNewsFeedScreen = false;
                                              controller.isOtherUserProfileScreen =
                                              false;
                                              controller.isChatScreen = false;
                                              controller.isChatScreenWeb = false;
                                              controller.isBrowseScreen = false;
                                              controller.isClickWhoToFollow = false;
                                              controller.isFollwerScreen = false;
                                              controller.isPostDetails = false;
                                              Future.delayed(Duration(seconds: 3),
                                                      () {
                                                    kIsWeb
                                                        ? controller.update()
                                                        : Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (
                                                                BuildContext context) =>
                                                                FilteredScreen(
                                                                  newsfeedController: Get
                                                                      .find<
                                                                      NewsfeedController>(),
                                                                )));
                                                  });
                                              await controller.filterUsers(
                                                id: controller.trendingList.trends[index]
                                                    .tagId,
                                                type: "tag",
                                              );*/
                                            },
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding: const EdgeInsets
                                                          .symmetric(
                                                      horizontal: 20,
                                                      vertical: 4),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      const SizedBox(width: 12),
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Text(
                                                              Strings.trendingIn + ' ${controller.trendingList.trends[index].region}',
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                // color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                                                fontSize: kIsWeb
                                                                    ? 14
                                                                    : 12,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                              )
                                                              // TextStyle(
                                                              //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                                              //   fontSize: 12,
                                                              //   ),
                                                              ),
                                                          Text(
                                                              controller.trendingList.trends[index].title,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontSize: 14,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              )
                                                              //  Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                                              //    fontWeight: FontWeight.w500,) : TextStyle(color: Colors.black,
                                                              //
                                                              // ),
                                                              ),
                                                          Text(
                                                            '${controller.trendingList.trends[index].trendingCount} ${Strings.werfs}',
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline4
                                                                .copyWith(
                                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                            ),
                                                            // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,fontSize: 12,
                                                            // ) : TextStyle(color: Colors.black,fontSize: 12,
                                                            //
                                                            // ),
                                                          ),
                                                        ],
                                                      ),
                                                      const Spacer(),
                                                    ],
                                                  ),
                                                ),
                                                // Container(
                                                //   height: 0.1,
                                                //   width: MediaQuery
                                                //       .of(context)
                                                //       .size
                                                //       .width,
                                                //   color:
                                                //   Colors.grey.withOpacity(0.2),
                                                // ),
                                              ],
                                            ),
                                          );
                                        },

                                        itemCount: controller.trendingList
                                                    .trends.length >=
                                                3
                                            ? 2
                                            : controller
                                                .trendingList.trends.length,
                                      ),
                                    ),
                          // Container(
                          //   height: 0.1,
                          //   width: MediaQuery.of(context).size.width,
                          //   color: Colors.grey.withOpacity(0.2),
                          // ),
                          controller.isTrendingLoading == true
                              ? const Spacer()
                              : controller.trendingList == null ||
                                      controller.trendingList.trends.isEmpty
                                  ? const Spacer()
                                  : Container(),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
              ],
            ),
          ),
          controller.isSearch == true
              ? Padding(
                  padding: const EdgeInsets.only(top: 80.0),
                  child: Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                        borderRadius: const BorderRadius.all(Radius.circular(15)),
                      ),
                      height: controller.searchResult == null ||
                              controller.searchResult.isEmpty
                          ? 100
                          : MediaQuery.of(context).size.height / 2.0,
                      width: MediaQuery.of(context).size.width / 2.5,
                      padding: EdgeInsets.all(5),
                      child: controller.searchResult == null ||
                              controller.searchResult.isEmpty
                          ? Align(
                              alignment: Alignment.center,
                              child: Text(
                                Strings.noSearchResult,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ))
                          : SingleChildScrollView(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    Strings.searchResult,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: List.generate(
                                        controller.searchResult.length,
                                        (index) {
                                      if (controller.searchResult[index].username != null) {
                                        return InkWell(
                                          splashColor: Colors.grey,
                                          onTap: () {

                                            controller.searchText.text = controller.searchResult[index].username.trim();
                                            controller.tagText = controller.searchResult[index].username;
                                            controller.isFilterScreen = true;
                                            controller.isNewsFeedScreen = false;
                                            controller.isSearch = false;
                                            controller.isBrowseScreen = false;
                                            controller.isSavedPostScreen = false;
                                            controller.searchSelected = controller.searchResult[index];
                                            controller.otherUserName = controller.searchResult[index].username;
                                            controller.postUserId = controller.searchResult[index].id;
                                            SingleTone.instance.searchId = controller.searchResult[index].id.toString();
                                            SingleTone.instance.searchType = controller.searchResult[index].type;
                                            SingleTone.instance.searchTag = controller.searchResult[index].username.trim();
                                            SingleTone.instance.searchTab = "top";
                                            Get.toNamed("${FluroRouters.mainScreen}/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

                                            // Get.toNamed(FluroRouters.mainScreen + "/filters/"+widget.controller.searchResult[index].username.toString());

                                            /* widget.controller.filterUsers(id: widget.controller.searchResult[index].id,
                                                  type: widget.controller.searchResult[index].type,
                                                  tag: widget.controller.searchResult[index].username);
                                              widget.controller.update();*/

                                            // print(widget
                                            //     .controller
                                            //     .searchResult[index]
                                            //     .username);
                                            // print(widget
                                            //     .controller
                                            //     .searchResult[index]
                                            //     .title);
                                            // print(widget
                                            //     .controller
                                            //     .searchResult[index]
                                            //     .id);
                                          },
                                          child: Container(
                                            width: Get.width,
                                            margin: EdgeInsets.only(bottom: 5),
                                            padding: EdgeInsets.all(8.0),
                                            color:
                                                Colors.grey.withOpacity(0.05),
                                            child: Row(
                                              children: [
                                                CircleAvatar(
                                                  backgroundImage: controller
                                                              .searchResult[
                                                                  index]
                                                              .profileImage !=
                                                          null
                                                      ? NetworkImage(controller
                                                          .searchResult[index]
                                                          .profileImage)
                                                      : const AssetImage(
                                                          "assets/images/person_placeholder.png"),
                                                  radius: 18,
                                                ),
                                                const SizedBox(
                                                  width: 20,
                                                ),
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    ///bluetick

                                                    Row(
                                                      // mainAxisAlignment: MainAxisAlignment.center,
                                                      children: [
                                                        Text(
                                                          controller.searchResult[index].firstname,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 15,
                                                          ),
                                                        ),
                                                        controller
                                                                    .searchResult[
                                                                        index]
                                                                    .accountVerified ==
                                                                "verified"
                                                            ? Row(
                                                                children: [
                                                                  const SizedBox(
                                                                    width: 5,
                                                                  ),
                                                                  BlueTick(
                                                                    height: 15,
                                                                    width: 15,
                                                                    iconSize:
                                                                        10,
                                                                  ),
                                                                ],
                                                              )
                                                            : SizedBox(),
                                                      ],
                                                    ),
                                                    Text(
                                                      controller.searchResult[index].username,
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline2
                                                          .copyWith(
                                                        fontSize:
                                                            kIsWeb ? 14 : 12,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      }
                                      return InkWell(
                                        splashColor: Colors.grey,
                                        onTap: () async {


                                          controller.isFilterScreen = true;
                                          controller.isNewsFeedScreen = false;
                                          controller.isSearch = false;
                                          controller.isBrowseScreen = false;
                                          controller.isSavedPostScreen = false;
                                          controller.searchSelected =
                                              controller.searchResult[index];

                                          SingleTone.instance.searchId =
                                              controller.searchResult[index].id
                                                  .toString();
                                          SingleTone.instance.searchType =
                                              controller
                                                  .searchResult[index].type;
                                          SingleTone.instance.searchTag = "";
                                          SingleTone.instance.searchTab =
                                              controller.seletedTab;
                                          Get.toNamed("${FluroRouters.mainScreen}/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");
                                          // Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${0.toString()}&type=${"tag"}&tag=${string}");

                                          /*widget.controller.filterUsers(
                                              id: widget.controller.searchResult[index].id,
                                              type: widget.controller.searchResult[index].type,
                                            );
                                            widget.controller.update();*/
                                          // print(widget
                                          //     .controller
                                          //     .searchResult[index]
                                          //     .username);
                                          // print(widget
                                          //     .controller
                                          //     .searchResult[index]
                                          //     .title);
                                          // print(widget.controller
                                          //     .searchResult[index].id);
                                        },
                                        child: Container(
                                          width: Get.width,
                                          margin: const EdgeInsets.only(bottom: 5),
                                          padding: const EdgeInsets.all(8.0),
                                          color: Colors.grey.withOpacity(0.05),
                                          child: Row(
                                            children: [
                                              CircleAvatar(
                                                backgroundImage: controller
                                                            .searchResult[index]
                                                            .profileImage !=
                                                        null
                                                    ? NetworkImage(controller
                                                        .searchResult[index]
                                                        .profileImage)
                                                    : const AssetImage(
                                                        "assets/images/person_placeholder.png"),
                                                radius: 18,
                                              ),
                                              const SizedBox(
                                                width: 20,
                                              ),
                                               Text(
                                                controller.searchResult[index].title,
                                                style: Styles
                                                    .baseTextTheme.headline2
                                                    .copyWith(
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    }),
                                  ),
                                ],
                              ),
                            ),
                    ),
                  ),
                )
              : const SizedBox(),
          Obx(() {
            return Padding(

              padding:  EdgeInsets.only(left:

              MediaQuery.of(context).size.width>= 1370? 140:
              ( MediaQuery.of(context).size.width== 1250 &&  MediaQuery.of(context).size.width<=1370)?60 :
            //  ( MediaQuery.of(context).size.width>= 1100 &&  MediaQuery.of(context).size.width<=1240)?10:
              0,
              right: 10
              ),
              child: Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    height: controller.messagePopupSize,
                    //size.value,
                   width: MediaQuery.of(context).size.width <= 1100 ? 290 : 350,
                   // width: 500,
                    decoration: BoxDecoration(
                      // color: Colors.white,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(17.0),
                        topLeft: Radius.circular(17.0),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.4),
                          spreadRadius: 2,
                          blurRadius: 2,
                          offset: const Offset(1, 1), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        controller.isMessagePopupChatSelected && controller.messagePopupSize == 500 ? Padding(
                          padding: const EdgeInsets.only(left: 4, top: 4, bottom:10.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            // mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                  onPressed: () {
                                    if (controller.isMessagePopupRequestChatSelected){
                                      controller.isMessagePopupRequestChatSelected = false;
                                    } else {
                                      controller.isMessagePopupChatSelected = false;
                                      controller.isMessagePopupRequestScreen = false;
                                    }

                                    controller.update();
                                  },
                                  icon: Icon(
                                    Icons.arrow_back,
                                    color: Theme.of(context)
                                        .brightness ==
                                        Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  )),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [

                                  controller.isMessagePopupRequestScreen && !controller.isMessagePopupRequestChatSelected
                                      ? Padding(
                                    padding: const EdgeInsets.only(left: 12, top: 10, bottom:10.0),
                                    child: Text(
                                      Strings.messageRequests,
                                      // style: Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,fontSize: 17,fontWeight: FontWeight.bold
                                      // ) : TextStyle(color: Colors.black,fontSize: 17,fontWeight: FontWeight.bold
                                      //
                                      // ),
                                      style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ) :

                                  controller.tempGroupName != "" ? SizedBox(
                                    width: controller.tempGroupName.length > 15
                                        ? kIsWeb ? 120 : 80
                                        : null,
                                    child: Text(
                                      controller.tempGroupName,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      style: Styles.baseTextTheme.headline2.copyWith(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ) :

                                  controller.isMessagePopupRequestScreen ?
                                  Container(
                                    child: controller.chatRequestUserList[controller
                                        .chatIndex].conversationType == "group" ?
                                    controller.chatRequestUserList[controller
                                        .chatIndex].name != null
                                        ? SizedBox(
                                      width: controller.chatRequestUserList[controller
                                          .chatIndex].name.length > 15
                                          ? kIsWeb ? 120 : 80
                                          : null,
                                      child: Text(
                                        controller.chatRequestUserList[controller
                                            .chatIndex].name,
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: Styles.baseTextTheme.headline4.copyWith(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    )
                                        : controller.chatRequestUserList[controller
                                        .chatIndex].members.length == 1
                                        ? FittedBox(
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              width: controller.chatRequestUserList[controller.chatIndex].members[0].firstname
                                                  .length > 15 ? kIsWeb ? 120 : 80 : null,
                                              child: Text(
                                                controller.chatRequestUserList[controller.chatIndex].members[0]
                                                    .firstname,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline4
                                                    .copyWith(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness == Brightness.dark ? Colors
                                                      .white : Colors.black,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),


                                          ],
                                        )
                                    )
                                        : controller.chatRequestUserList[controller
                                        .chatIndex].members.length == 2
                                        ? FittedBox(
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              width: controller.chatRequestUserList[controller.chatIndex].members[0].firstname
                                                  .length > 15 ? kIsWeb ? 120 : 80 : null,
                                              child: Text(
                                                "${controller.chatRequestUserList[controller.chatIndex].members[0]
                                                    .firstname}, ",
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline4
                                                    .copyWith(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness == Brightness.dark ? Colors
                                                      .white : Colors.black,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: controller.chatRequestUserList[controller.chatIndex].members[1].firstname
                                                  .length > 15 ? kIsWeb ? 120 : 80 : null,
                                              child: Text(
                                                controller.chatRequestUserList[controller.chatIndex].members[1]
                                                    .firstname,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline4
                                                    .copyWith(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness == Brightness.dark ? Colors
                                                      .white : Colors.black,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),

                                          ],
                                        )
                                    )
                                        : controller.chatRequestUserList[controller
                                        .chatIndex].members.length == 3
                                        ? FittedBox(
                                      child: Row(
                                        children: [
                                          SizedBox(
                                            width: controller.chatRequestUserList[
                                                controller.chatIndex].members[0].firstname
                                                .length > 15 ? kIsWeb ? 120 : 80 : null,
                                            child: Text(
                                              "${controller.chatRequestUserList[controller.chatIndex].members[0]
                                                  .firstname}, ",
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness == Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          Text(
                                            "${controller.chatRequestUserList[
                                                controller.chatIndex].members.length -
                                                1} other...",
                                            style: Styles.baseTextTheme.headline4.copyWith(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark ? Colors
                                                  .white : Colors.black,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                        : controller.chatRequestUserList[controller
                                        .chatIndex].members.length >= 4
                                        ? FittedBox(
                                        child: Row(
                                          children: [

                                            SizedBox(
                                              width: controller.chatRequestUserList[
                                                  controller.chatIndex].members[0].firstname
                                                  .length > 15 ? kIsWeb ? 120 : 60 : null,
                                              child: Text(
                                                "${controller.chatRequestUserList[
                                                    controller.chatIndex].members[0]
                                                    .firstname}, ",
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline4
                                                    .copyWith(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness == Brightness.dark ? Colors
                                                      .white : Colors.black,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: controller.chatRequestUserList[
                                                  controller.chatIndex].members[1].firstname
                                                  .length > 15 ? kIsWeb ? 120 : 60 : null,
                                              child: Text(
                                                "${controller.chatRequestUserList[
                                                    controller.chatIndex].members[1]
                                                    .firstname}, ",
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline4
                                                    .copyWith(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness == Brightness.dark ? Colors
                                                      .white : Colors.black,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                            // Text(
                                            //   "${controller.chatUserList[index].members[2].firstname} and ",
                                            //   style: Theme.of(context).brightness == Brightness.dark ?
                                            //   TextStyle(color: Colors.white,
                                            //       fontWeight: FontWeight.w600,overflow:
                                            //       TextOverflow.ellipsis
                                            //   )
                                            //       : TextStyle(color: Colors.black,
                                            //       fontWeight: FontWeight.w600,overflow:
                                            //       TextOverflow.ellipsis
                                            //   ),
                                            // ),
                                            Text(
                                              "${controller.chatRequestUserList[
                                                  controller.chatIndex].members.length -
                                                  2} other...",
                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness == Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        )
                                    )


                                        : const SizedBox() : const SizedBox(),
                                  ):
                                  controller.chatUserList[controller
                                      .chatIndex].conversationType == "group" ?
                                  controller.chatUserList[controller
                                      .chatIndex].name != null
                                      ? SizedBox(
                                    width: controller.chatUserList[controller
                                        .chatIndex].name.length > 15
                                        ? kIsWeb ? 120 : 80
                                        : null,
                                    child: Text(
                                      controller.chatUserList[controller
                                          .chatIndex].name,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      style: Styles.baseTextTheme.headline4.copyWith(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  )
                                      : controller.chatUserList[controller
                                      .chatIndex].members.length == 1
                                      ? FittedBox(
                                      child: Row(
                                        children: [
                                          Container(
                                            width: controller.chatUserList[
                                                controller.chatIndex].members[0].firstname
                                                .length > 15 ? kIsWeb ? 120 : 80 : null,
                                            child: Text(
                                              controller.chatUserList[
                                                  controller.chatIndex].members[0]
                                                  .firstname,
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              style: Styles.baseTextTheme.headline4
                                                  .copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness == Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),


                                        ],
                                      )
                                  )
                                      : controller.chatUserList[controller
                                      .chatIndex].members.length == 2
                                      ? FittedBox(
                                      child: Row(
                                        children: [
                                          SizedBox(
                                            width: controller.chatUserList[
                                                controller.chatIndex].members[0].firstname
                                                .length > 15 ? kIsWeb ? 120 : 80 : null,
                                            child: Text(
                                              "${controller.chatUserList[
                                                  controller.chatIndex].members[0]
                                                  .firstname}, ",
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              style: Styles.baseTextTheme.headline4
                                                  .copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness == Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: controller.chatUserList[
                                                controller.chatIndex].members[1].firstname
                                                .length > 15 ? kIsWeb ? 120 : 80 : null,
                                            child: Text(
                                              controller.chatUserList[
                                                  controller.chatIndex].members[1]
                                                  .firstname,
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              style: Styles.baseTextTheme.headline4
                                                  .copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness == Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),

                                        ],
                                      )
                                  )
                                      : controller.chatUserList[controller
                                      .chatIndex].members.length == 3
                                      ? FittedBox(
                                    child: Row(
                                      children: [
                                        SizedBox(
                                          width: controller.chatUserList[
                                              controller.chatIndex].members[0].firstname
                                              .length > 15 ? kIsWeb ? 120 : 80 : null,
                                          child: Text(
                                            "${controller.chatUserList[
                                                controller.chatIndex].members[0]
                                                .firstname}, ",
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                            style: Styles.baseTextTheme.headline4.copyWith(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark ? Colors
                                                  .white : Colors.black,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          "${controller.chatUserList[
                                              controller.chatIndex].members.length -
                                              1} other...",
                                          style: Styles.baseTextTheme.headline4.copyWith(
                                            color: Theme
                                                .of(context)
                                                .brightness == Brightness.dark ? Colors
                                                .white : Colors.black,
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                      : controller.chatUserList[controller
                                      .chatIndex].members.length >= 4
                                      ? FittedBox(
                                      child: Row(
                                        children: [

                                          SizedBox(
                                            width: controller.chatUserList[
                                                controller.chatIndex].members[0].firstname
                                                .length > 15 ? kIsWeb ? 120 : 60 : null,
                                            child: Text(
                                              "${controller.chatUserList[
                                                  controller.chatIndex].members[0]
                                                  .firstname}, ",
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              style: Styles.baseTextTheme.headline4
                                                  .copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness == Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: controller.chatUserList[
                                                controller.chatIndex].members[1].firstname
                                                .length > 15 ? kIsWeb ? 120 : 60 : null,
                                            child: Text(
                                              "${controller.chatUserList[
                                                  controller.chatIndex].members[1]
                                                  .firstname}, ",
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              style: Styles.baseTextTheme.headline4
                                                  .copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness == Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          // Text(
                                          //   "${controller.chatUserList[index].members[2].firstname} and ",
                                          //   style: Theme.of(context).brightness == Brightness.dark ?
                                          //   TextStyle(color: Colors.white,
                                          //       fontWeight: FontWeight.w600,overflow:
                                          //       TextOverflow.ellipsis
                                          //   )
                                          //       : TextStyle(color: Colors.black,
                                          //       fontWeight: FontWeight.w600,overflow:
                                          //       TextOverflow.ellipsis
                                          //   ),
                                          // ),
                                          Text(
                                            "${controller.chatUserList[
                                                controller.chatIndex].members.length -
                                                2} other...",
                                            style: Styles.baseTextTheme.headline4.copyWith(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark ? Colors
                                                  .white : Colors.black,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      )
                                  )


                                      : const SizedBox() : const SizedBox(),

                                  controller.isMessagePopupRequestScreen && !controller.isMessagePopupRequestChatSelected ? SizedBox()
                                  : controller.isMessagePopupRequestScreen ? controller.chatRequestUserList[controller
                                      .chatIndex].conversationType == "single" ?
                                  SizedBox(
                                    width: controller.chatRequestUserList[controller
                                        .chatIndex].name.length > 15 ? 120 : null,
                                    child: Text(
                                      controller.chatRequestUserList[controller
                                          .chatIndex].name,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      style: Styles.baseTextTheme.headline2.copyWith(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ) : const SizedBox():
                                  controller.chatUserList[controller
                                      .chatIndex].conversationType == "single" ?
                                  SizedBox(
                                    width: controller.chatUserList[controller
                                        .chatIndex].name.length > 15 ? 120 : null,
                                    child: Text(
                                      controller.chatUserList[controller
                                          .chatIndex].name,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      style: Styles.baseTextTheme.headline2.copyWith(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ) : const SizedBox(),

                                  // Text(
                                  //   "${widget.controller.groupName != null ? widget.controller.groupName : widget.controller.chatName.name != null ? widget.controller.chatName.name : ""}",
                                  //   maxLines: 1,
                                  //   style: Theme.of(context).textTheme.bodyText1.copyWith(
                                  //       color: Colors.black,
                                  //       overflow: TextOverflow.ellipsis),
                                  // ),

                                  controller.chatName == null ? Container() :
                                  controller.chatName.accountVerified == null? const SizedBox():
                                  controller.chatName.accountVerified ==
                                      "verified"
                                      ? Row(
                                    children: [
                                      const SizedBox(
                                        width: 5,
                                      ),
                                      BlueTick(
                                        height: 15,
                                        width: 15,
                                        iconSize: 10,
                                      ),
                                    ],
                                  )
                                      : const SizedBox()
                                ],
                              ),
                              const Spacer(),
                              IconButton(
                                padding: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 4.0),
                                onPressed: () {
                                  if (controller.messagePopupSize == 47.0) {
                                    controller.messagePopupSize = 500;
                                    checkIcon.value = true;
                                  } else {
                                    checkIcon.value = false;
                                    controller.messagePopupSize = 47.0;
                                  }
                                },
                                splashRadius: 5,
                                icon: checkIcon.value == false
                                    ? Icon(
                                  Icons.keyboard_double_arrow_up,
                                  color: Theme.of(context).brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  // size: 30,
                                )
                                    : Icon(
                                  Icons.keyboard_double_arrow_down,
                                  color: Theme.of(context).brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  // size: 30,
                                ),
                              )
                            ],
                          ),
                        ) : InkWell(
                          onTap: () {
                            if (controller.messagePopupSize == 47.0) {
                              controller.messagePopupSize = 500;
                              checkIcon.value = true;
                              controller.newMessageCount = 0;
                            } else {
                              checkIcon.value = false;
                              controller.messagePopupSize = 47.0;
                            }
                          },
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            // mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(left: 12, top: 10, bottom:10.0, right: 15.0),
                                    child: Text(
                                      Strings.chats,
                                      // style: Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,fontSize: 17,fontWeight: FontWeight.bold
                                      // ) : TextStyle(color: Colors.black,fontSize: 17,fontWeight: FontWeight.bold
                                      //
                                      // ),
                                      style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  controller.newMessageCount > 0 && controller.messagePopupSize == 47.0 ? Positioned(
                                    top: 10.0,
                                      right: 0,
                                      child: CircleAvatar(
                                        radius: 8,
                                        backgroundColor: MyColors.blue,
                                        child: Text(
                                            controller.newMessageCount > 99 ? "+99" :  controller.newMessageCount.toString(), //badgeCount > 99 ? '+99' : '$badgeCount',
                                            // style: TextStyle(fontSize: 8, color: Colors.white),
                                            style: const TextStyle(color: Colors.white, fontSize: 8)
                                        ),
                                      )) : const SizedBox(),
                                ],
                              ),
                              const Spacer(),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 2),
                                child: GestureDetector(
                                  // splashRadius: 5,
                                  onTap: () {

                                    controller.idList.clear();
                                    controller.chatSearchTEC.clear();
                                    controller.usersList = null;
                                    controller.randomGroup = "";
                                    controller.update();
                                    showDialog(
                                      barrierDismissible: false,
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          contentPadding: EdgeInsets.zero,
                                          insetPadding: EdgeInsets.zero,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(20),
                                          ),
                                          content: NewMessageDialogBox(),
                                        );
                                      },
                                    ).then((value) {
                                      if (value == true){
                                        controller.isMessagePopupChatSelected = true;
                                        controller.messagePopupSize = 500;
                                        checkIcon.value = true;
                                      }
                                    });
                                  },
                                  child: Image.asset(
                                    'assets/chaticons/message_icon.png',
                                    width: 25,
                                    height: 25,
                                    color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                  )
                                  // icon: Icon(
                                  //   Icons.mark_email_unread,
                                  //   color: Theme.of(context).brightness ==
                                  //           Brightness.dark
                                  //       ? Colors.white
                                  //       : Colors.black,
                                  // ),
                                ),
                              ),
                              IconButton(
                                padding: const EdgeInsets.symmetric(vertical: 2.0, horizontal: 4.0),
                                onPressed: () {
                                  if (controller.messagePopupSize == 47.0) {
                                    controller.messagePopupSize = 500;
                                    checkIcon.value = true;
                                    controller.newMessageCount = 0;
                                  } else {
                                    checkIcon.value = false;
                                    controller.messagePopupSize = 47.0;
                                  }
                                },
                                splashRadius: 5,
                                icon: checkIcon.value == false
                                    ? Icon(
                                        Icons.keyboard_double_arrow_up,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        // size: 30,
                                      )
                                    : Icon(
                                        Icons.keyboard_double_arrow_down,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        // size: 30,
                                      ),
                              )
                            ],
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child:
                              controller.isMessagePopupRequestScreen && !controller.isMessagePopupRequestChatSelected
                              ? const MessageRequestScreen(isFromMessagePopup: true,)
                              : controller.isMessagePopupChatSelected && controller.messagePopupSize == 500
                              ? ChatScreenMobile(controller, controller.isMessagePopupRequestScreen, isFromMessagePopup: true,)
                              : InkWell(
                            onTap: () async {
                              // onHomeChange = false;
                              // onBrowsChange = false;
                              // onTrendsChange = false;
                              // onBookMarksChange = false;
                              // onChatsChange = true;
                              // onProfileChange = false;
                              // onSettingChange = false;
                              // onListChange = false;
                              // onNotificationChange = false;
                              // onMoreChange = false;
                              //
                              // // controller.isSearch = false;
                              // // controller.isFilter = false;
                              // // controller.isFilterScreen = false;
                              // // controller.isTrendsScreen = false;
                              // // controller.isNewsFeedScreen = false;
                              // // controller.isBrowseScreen = false;
                              // // controller.isNotificationScreen = false;
                              // // controller.isWhoToFollowScreen = false;
                              // // controller.isSavedPostScreen = false;
                              // // controller.isChatScreen = true;
                              // // controller.isPostDetails = false;
                              // // controller.isProfileScreen = false;
                              // // controller.searchText.text = '';
                              // // controller.isFollwerScreen = false;
                              // // controller.isSettingsScreen = false;
                              // // controller.navRoute = "isChatScreen";
                              // Get.toNamed(FluroRouters.mainScreen + '/chats');
                              // controller.chatUserList =
                              //     await controller.getChat();
                              // print(
                              //     " controller.chatUserList ${controller.chatUserList}");
                              // // print("preesssseddd");
                              // controller.update();
                            },
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  // Container(
                                  //   height: 2,
                                  //   width: Get.width,
                                  //   color: Theme.of(context).brightness ==
                                  //           Brightness.dark
                                  //       ? Colors.white
                                  //       : Colors.black,
                                  // ),
                                  controller != null && controller.chatRequestUserList != null?
                                  ListTile(
                                    onTap: () async{
                                      controller.chatRequestUserList = await controller.getMessageRequest();
                                      controller.isMessagePopupRequestScreen = true;
                                      controller.isMessagePopupChatSelected = true;
                                    },
                                    leading: CircleAvatar(
                                      backgroundColor: Colors.white,
                                      child: Image.asset("assets/chaticons/message_icon.png",
                                        color: Colors.black,
                                        height: 50,
                                        width: 50,
                                      ),
                                    ),
                                    title: Text(Strings.messageRequests,
                                      style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold
                                      ),
                                    ),
                                    subtitle: Text(controller.chatRequestUserList==null || controller==null? "0 "+Strings.pendingRequest:"${controller.chatRequestUserList.length} " +Strings.pendingRequest),

                                  )
                                      : const SizedBox(),
                                  controller.isChatLoad
                                      ? const Center(
                                          child: Padding(
                                            padding:
                                                EdgeInsets.only(top: 10.0),
                                            child: CircularProgressIndicator(
                                                color: MyColors.BlueColor),
                                          ),
                                        )
                                      : controller.chatUserList == null ? Container() : controller.chatUserList != null ||
                                              controller.chatUserList.isNotEmpty
                                          ? Padding(
                                              padding: const EdgeInsets.only(
                                                top: 0.0,
                                              ),
                                              child: SizedBox(
                                                width: Get.width * 0.45,
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Column(
                                                      children: List.generate(
                                                          controller.chatUserList
                                                              .length, (index) {
                                                        String getChatDate;
                                                        getChatDate = controller.chatUserList[index]
                                                            .latestMessageTime ==
                                                            null
                                                            ? ""
                                                            : UtilsMethods.getChatDate(controller
                                                            .chatUserList[index].latestMessageTime);

                                                        String chatUserName =
                                                            controller.chatUserList[index].username;
                                                        String chatAuthorName =
                                                            controller.chatUserList[index].name;
                                                        return InkWell(
                                                          onTap: (){
                                                            controller.isMessagePopupChatSelected = true;
                                                            controller.isImagePickedChat =
                                                            false;
                                                            controller.isVideoPickedChat =
                                                            false;
                                                            controller.isDocumentPickedChat =
                                                            false;
                                                            controller.messageController
                                                                .clear();
                                                            controller.showOverlay = false;
                                                            // print("pressed button on click");
                                                            controller.messageController.text =
                                                            "";

                                                            controller.tempGroupName = "";
                                                            controller
                                                                .tempProfileImageGroupChat =
                                                            null;

                                                            controller.focusNode.requestFocus();
                                                            controller.isChatScreenWeb = true;
                                                            controller.chatName =
                                                            controller.chatUserList[index];
                                                            controller.groupName = controller
                                                                .chatName
                                                                .conversationType ==
                                                                "group"
                                                                ? controller.chatName.name
                                                                : controller.chatName.name;
                                                            controller.infoChatInfo = false;
                                                            controller.getMessagesOfAConversation(controller
                                                                .chatName.conversationId);
                                                            controller.chatIndex = index;
                                                            controller.highlighteTheChat =
                                                                index;

                                                            controller.update();
                                                          },
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 0.0,
                                                                    left: 0,
                                                                    right: 0),
                                                            child: Card(
                                                              elevation: 0.0,
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.black
                                                                  : Colors.white,
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(8.0),
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    controller.chatUserList[index]
                                                                                .conversationType !=
                                                                            "group"
                                                                        ? CircleAvatar(
                                                                            backgroundImage: controller.chatUserList[index].profileImage !=
                                                                                    null
                                                                                ? NetworkImage(controller.chatUserList[index].profileImage)
                                                                                : const AssetImage('assets/images/person_placeholder.png'),
                                                                            radius:
                                                                                22,
                                                                          )
                                                                        : CircleAvatar(
                                                                            backgroundImage: controller.chatUserList[index].groupImage !=
                                                                                    null
                                                                                ? NetworkImage(controller.chatUserList[index].groupImage)
                                                                                : const AssetImage('assets/images/person_placeholder.png'),
                                                                            radius:
                                                                                22,
                                                                          ),
                                                                    const SizedBox(
                                                                      width: 20,
                                                                    ),
                                                                    Expanded(
                                                                      child: Column(
                                                                        crossAxisAlignment:
                                                                        CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                        MainAxisAlignment.start,
                                                                        children: [
                                                                          FittedBox(
                                                                            child: Row(
                                                                              children: [
                                                                                controller
                                                                                    .chatUserList[
                                                                                index]
                                                                                    .conversationType ==
                                                                                    "group"
                                                                                    ? controller
                                                                                    .chatUserList[
                                                                                index]
                                                                                    .name !=
                                                                                    null && controller.chatUserList[index].name != ""
                                                                                    ? Container(
                                                                                  width: chatAuthorName.length >
                                                                                      10
                                                                                      ? 85
                                                                                      : null,
                                                                                  child: Text(
                                                                                    chatAuthorName ?? "Werfie User",
                                                                                    overflow: chatAuthorName.length >
                                                                                        10
                                                                                        ? TextOverflow
                                                                                        .ellipsis
                                                                                        : null,
                                                                                    maxLines:
                                                                                    1,
                                                                                    style: Styles
                                                                                        .baseTextTheme
                                                                                        .headline4
                                                                                        .copyWith(
                                                                                      color: Theme.of(context).brightness ==
                                                                                          Brightness.dark
                                                                                          ? Colors.white
                                                                                          : Colors.black,
                                                                                      fontSize:
                                                                                      15,
                                                                                      fontWeight:
                                                                                      FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                                    : controller
                                                                                    .chatUserList[
                                                                                index]
                                                                                    .members
                                                                                    .length ==
                                                                                    1
                                                                                    ? FittedBox(
                                                                                    child:
                                                                                    Row(
                                                                                      children: [
                                                                                        SizedBox(
                                                                                          width: controller.chatUserList[index].members[0].firstname.length > 10
                                                                                              ? 85
                                                                                              : null,
                                                                                          child:
                                                                                          Text(
                                                                                            controller.chatUserList[index].members[0].firstname,
                                                                                            overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                            maxLines: 1,
                                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                              fontSize: 15,
                                                                                              fontWeight: FontWeight.bold,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ))
                                                                                    : controller.chatUserList[index].members.length ==
                                                                                    2
                                                                                    ? FittedBox(
                                                                                    child:
                                                                                    Row(
                                                                                      children: [
                                                                                        SizedBox(
                                                                                          width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                                                          child: Text(
                                                                                            "${controller.chatUserList[index].members[0].firstname}, ",
                                                                                            overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                            maxLines: 1,
                                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                              fontSize: 15,
                                                                                              fontWeight: FontWeight.bold,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                        SizedBox(
                                                                                          width: controller.chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                                                                          child: Text(
                                                                                            controller.chatUserList[index].members[1].firstname,
                                                                                            overflow: controller.chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                            maxLines: 1,
                                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                              fontSize: 15,
                                                                                              fontWeight: FontWeight.bold,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ))
                                                                                    : controller.chatUserList[index].members.length ==
                                                                                    3
                                                                                    ? FittedBox(
                                                                                  child: Row(
                                                                                    children: [
                                                                                      SizedBox(
                                                                                        width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                                                        child: Text(
                                                                                          "${controller.chatUserList[index].members[0].firstname}, ",
                                                                                          overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                          maxLines: 1,
                                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                            fontSize: 15,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      Text(
                                                                                        "${controller.chatUserList[index].members.length - 1} other...",
                                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                          fontSize: 15,
                                                                                          fontWeight: FontWeight.bold,
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                )
                                                                                    : controller.chatUserList[index].members.length >= 4
                                                                                    ? FittedBox(
                                                                                    child: Row(
                                                                                      children: [
                                                                                        SizedBox(
                                                                                          width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                                                          child: Text(
                                                                                            "${controller.chatUserList[index].members[0].firstname}, ",
                                                                                            overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                            maxLines: 1,
                                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                              fontSize: 15,
                                                                                              fontWeight: FontWeight.bold,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                        SizedBox(
                                                                                          width: controller.chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                                                                          child: Text(
                                                                                            "${controller.chatUserList[index].members[1].firstname}, ",
                                                                                            overflow: controller.chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                            maxLines: 1,
                                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                              fontSize: 15,
                                                                                              fontWeight: FontWeight.bold,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                        // Text(
                                                                                        //   "${controller.chatUserList[index].members[2].firstname} and ",
                                                                                        //   style: Theme.of(context).brightness == Brightness.dark ?
                                                                                        //   TextStyle(color: Colors.white,
                                                                                        //       fontWeight: FontWeight.w600,overflow:
                                                                                        //       TextOverflow.ellipsis
                                                                                        //   )
                                                                                        //       : TextStyle(color: Colors.black,
                                                                                        //       fontWeight: FontWeight.w600,overflow:
                                                                                        //       TextOverflow.ellipsis
                                                                                        //   ),
                                                                                        // ),
                                                                                        Text(
                                                                                          "${controller.chatUserList[index].members.length - 2} other...",
                                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                            fontSize: 15,
                                                                                            fontWeight: FontWeight.bold,
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ))
                                                                                    : const SizedBox()
                                                                                    : const SizedBox(),

                                                                                controller
                                                                                    .chatUserList[
                                                                                index]
                                                                                    .conversationType ==
                                                                                    "single"
                                                                                    ? SizedBox(
                                                                                  width: chatAuthorName
                                                                                      .length >
                                                                                      10
                                                                                      ? 85
                                                                                      : null,
                                                                                  child: Text(
                                                                                    chatAuthorName,
                                                                                    overflow: chatAuthorName
                                                                                        .length >
                                                                                        10
                                                                                        ? TextOverflow
                                                                                        .ellipsis
                                                                                        : null,
                                                                                    maxLines: 1,
                                                                                    style: Styles
                                                                                        .baseTextTheme
                                                                                        .headline4
                                                                                        .copyWith(
                                                                                      color: Theme.of(context).brightness ==
                                                                                          Brightness
                                                                                              .dark
                                                                                          ? Colors
                                                                                          .white
                                                                                          : Colors
                                                                                          .black,
                                                                                      fontSize:
                                                                                      15,
                                                                                      fontWeight:
                                                                                      FontWeight
                                                                                          .bold,
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                                    : const SizedBox(),

                                                                                // controller.chatUserList[index].accountVerified =="verified"?
                                                                                // Row(children: [
                                                                                //   SizedBox(
                                                                                //     width: 5,
                                                                                //   ),
                                                                                //   BlueTick(
                                                                                //     height: 15,
                                                                                //     width: 15,
                                                                                //     iconSize:10,
                                                                                //   ),
                                                                                // ],):SizedBox()
                                                                                controller
                                                                                    .chatUserList[
                                                                                index]
                                                                                    .conversationType ==
                                                                                    "group"
                                                                                    ? Text(
                                                                                  "Group",
                                                                                  style: Styles
                                                                                      .baseTextTheme
                                                                                      .headline2
                                                                                      .copyWith(
                                                                                    fontWeight:
                                                                                    FontWeight
                                                                                        .w400,
                                                                                    fontSize: 15,
                                                                                  ),
                                                                                )
                                                                                    : controller
                                                                                    .chatUserList[
                                                                                index]
                                                                                    .conversationType ==
                                                                                    "single"
                                                                                    ? SizedBox(
                                                                                  width: chatUserName.length >
                                                                                      15
                                                                                      ? 100
                                                                                      : null,
                                                                                  child: Text(
                                                                                    "@$chatUserName",
                                                                                    overflow: chatUserName.length >
                                                                                        15
                                                                                        ? TextOverflow
                                                                                        .ellipsis
                                                                                        : null,
                                                                                    softWrap:
                                                                                    false,
                                                                                    maxLines:
                                                                                    1,
                                                                                    style: Styles
                                                                                        .baseTextTheme
                                                                                        .headline2
                                                                                        .copyWith(
                                                                                      fontWeight:
                                                                                      FontWeight.w400,
                                                                                      fontSize:
                                                                                      15,
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                                    : const SizedBox(),
                                                                                controller
                                                                                    .chatUserList[
                                                                                index]
                                                                                    .latestMessageTime ==
                                                                                    null
                                                                                    ? const SizedBox()
                                                                                    : Row(
                                                                                  children: [
                                                                                    const SizedBox(
                                                                                      width: 2,
                                                                                    ),
                                                                                    Text(
                                                                                      ".",
                                                                                      style: Styles
                                                                                          .baseTextTheme
                                                                                          .headline2
                                                                                          .copyWith(
                                                                                        fontSize:
                                                                                        20,
                                                                                        fontWeight:
                                                                                        FontWeight
                                                                                            .w500,
                                                                                      ),
                                                                                    ),
                                                                                    const SizedBox(
                                                                                      width: 2,
                                                                                    ),
                                                                                    Text(
                                                                                      getChatDate ?? "",
                                                                                      overflow:
                                                                                      TextOverflow
                                                                                          .ellipsis,
                                                                                      maxLines: 1,
                                                                                      style: Styles
                                                                                          .baseTextTheme
                                                                                          .headline2
                                                                                          .copyWith(
                                                                                        fontSize:
                                                                                        15,
                                                                                        fontWeight:
                                                                                        FontWeight
                                                                                            .w400,
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                          Text(
                                                                            controller
                                                                                .chatUserList[
                                                                            index]
                                                                                .latest_message_type ==
                                                                                1
                                                                                ? controller
                                                                                .chatUserList[index]
                                                                                .latestMessage
                                                                                : controller
                                                                                .chatUserList[
                                                                            index]
                                                                                .latest_message_type ==
                                                                                2
                                                                                ? 'Photo'
                                                                                : controller
                                                                                .chatUserList[
                                                                            index]
                                                                                .latest_message_type ==
                                                                                3
                                                                                ? 'Video'
                                                                                : controller.chatUserList[index]
                                                                                .latest_message_type ==
                                                                                9
                                                                                ? 'File'
                                                                                : '',
                                                                            overflow:
                                                                            TextOverflow.ellipsis,
                                                                            maxLines: 1,
                                                                            style: Styles
                                                                                .baseTextTheme.headline2
                                                                                .copyWith(
                                                                              color: Theme.of(context)
                                                                                  .brightness ==
                                                                                  Brightness.dark
                                                                                  ? Colors.white
                                                                                  : Colors.black,
                                                                              fontSize: 15,
                                                                              fontWeight:
                                                                              FontWeight.w400,
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    // Column(
                                                                    //   children: [
                                                                    //     Text(
                                                                    //         "jkbdjsbfjbfjksbdfjbsdf")
                                                                    //   ],
                                                                    // )
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        );
                                                      }),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            )
                                          : Column(
                                              children: [
                                                Text(
                                                  Strings.sendAMessageGetAMessage,
                                                  // style: TextStyle(
                                                  //     fontSize: 18,
                                                  //     color: Colors.black,
                                                  //     fontWeight: FontWeight.w900),
                                                  style: Styles
                                                      .baseTextTheme.headline4
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: kIsWeb ? 14 : 12,
                                                  ),
                                                  //  TextStyle(
                                                  //     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                  //      fontSize: 18,
                                                  //      fontWeight: FontWeight.w900
                                                  // ),
                                                ),
                                                const SizedBox(height: 10),
                                                Text(
                                                  Strings
                                                      .directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore,
                                                  textAlign: TextAlign.center,
                                                  style: Styles
                                                      .baseTextTheme.headline4
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: kIsWeb ? 14 : 12,
                                                  ),
                                                ),
                                                const SizedBox(height: 14),
                                                RoundedButton(
                                                  Strings.startAConversation,
                                                  () {
                                                    showDialog(
                                                      context: context,
                                                      builder:
                                                          (BuildContext context) {
                                                        return AlertDialog(
                                                          contentPadding:
                                                              EdgeInsets.zero,
                                                          insetPadding:
                                                              EdgeInsets.zero,
                                                          shape:
                                                              RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(20),
                                                          ),
                                                          content:
                                                              NewMessageDialogBox(),
                                                        );
                                                      },
                                                    ).then((value) {
                                                      if (value == true){
                                                        controller.isMessagePopupChatSelected = true;
                                                        controller.messagePopupSize == 500;
                                                      }
                                                    });
                                                  },
                                                  horizontalPadding: 40,
                                                  roundedButtonColor:
                                                      controller.displayColor,
                                                ),
                                              ],
                                            )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                  //   return Container(
                  //   height:size.value,
                  //   // width: Get.width * 0.25,
                  //   decoration: BoxDecoration(
                  //     color: Colors.white,
                  //     borderRadius: BorderRadius.only(
                  //       topRight: Radius.circular(17.0),
                  //       topLeft: Radius.circular(17.0),
                  //     ),
                  //     boxShadow: [
                  //       BoxShadow(
                  //         color: Colors.grey.withOpacity(0.5),
                  //         spreadRadius: 5,
                  //         blurRadius: 7,
                  //         offset: Offset(0, 3), // changes position of shadow
                  //       ),
                  //     ],
                  //   ),
                  //   child: Column(
                  //     children: [
                  //       Row(
                  //         crossAxisAlignment: CrossAxisAlignment.start,
                  //         children: [
                  //           Padding(
                  //             padding: const EdgeInsets.only(left: 10,top: 10),
                  //             child: Text("Messages",
                  //               style: TextStyle(
                  //                 fontSize: 17,
                  //                 fontWeight: FontWeight.bold,
                  //               ),
                  //             ),
                  //           ),
                  //           Spacer(),
                  //           Padding(
                  //             padding: const EdgeInsets.only(top: 2),
                  //             child: IconButton(
                  //               splashRadius: 5,
                  //               onPressed: () {
                  //                 print("jkkjbkjb");
                  //                 controller.idList.clear();
                  //                 controller.randomGroup = "";
                  //                 showDialog(
                  //                   barrierDismissible: false,
                  //                   context: context,
                  //                   builder: (BuildContext context) {
                  //                     return AlertDialog(
                  //                       contentPadding: EdgeInsets.zero,
                  //                       insetPadding: EdgeInsets.zero,
                  //                       shape: RoundedRectangleBorder(
                  //                         borderRadius: BorderRadius.circular(20),
                  //                       ),
                  //                       content: NewMessageDialogBox(),
                  //                     );
                  //                   },
                  //                 );
                  //               },
                  //               icon: Icon(Icons.mark_email_unread),
                  //             ),
                  //           ),
                  //           IconButton(onPressed: () {
                  //             if (size.value == 20.0) {
                  //               size.value = 1000;
                  //               checkIcon.value = true;
                  //             }
                  //             else{
                  //               checkIcon.value = false;
                  //               size.value = 20.0;
                  //             }
                  //
                  //
                  //
                  //
                  //
                  //           },
                  //             splashRadius: 5,
                  //             icon: checkIcon.value == false?Icon(
                  //               Icons.expand_less_rounded,
                  //               size: 30,
                  //             ):Icon(
                  //               Icons.expand_more_sharp,
                  //               size: 30,
                  //             ),
                  //           )
                  //
                  //         ],
                  //       ),
                  //       Expanded(
                  //         flex: 1,
                  //         child: InkWell(
                  //           onTap: ()async{
                  //             controller.isSearch = false;
                  //             controller.isFilter = false;
                  //             controller.isFilterScreen = false;
                  //             controller.isTrendsScreen = false;
                  //             controller.isNewsFeedScreen = false;
                  //             controller.isBrowseScreen = false;
                  //             controller.isNotificationScreen = false;
                  //             controller.isWhoToFollowScreen = false;
                  //             controller.isSavedPostScreen = false;
                  //             controller.isChatScreen = true;
                  //             controller.isPostDetails = false;
                  //             controller.isProfileScreen = false;
                  //             controller.searchText.text = '';
                  //             controller.isFollwerScreen = false;
                  //             controller.isSettingsScreen = false;
                  //             controller.navRoute = "isChatScreen";
                  //             controller.chatUserList = await controller.getChat();
                  //             print(" controller.chatUserList ${controller.chatUserList}");
                  //             // print("preesssseddd");
                  //             controller.update();
                  //           },
                  //           child: SingleChildScrollView(
                  //             child: Column(
                  //               children: [
                  //                 Container(
                  //                   height: 2,
                  //                   width: Get.width,
                  //                   color: Colors.grey[300],
                  //                 ),
                  //                 controller.isChatLoad
                  //                     ? Center(
                  //                   child: Padding(
                  //                     padding: const EdgeInsets.only(top: 10.0),
                  //                     child: CircularProgressIndicator(),
                  //                   ),
                  //                 )
                  //                     : controller.chatUserList != null ||
                  //                     controller.chatUserList.isNotEmpty
                  //                     ? Padding(
                  //                   padding: const EdgeInsets.only(
                  //                     top: 0.0,
                  //                   ),
                  //                   child: SizedBox(
                  //                     width: Get.width * 0.45,
                  //                     child: Column(
                  //                       crossAxisAlignment:
                  //                       CrossAxisAlignment.start,
                  //                       children: [
                  //                         Column(
                  //                           children: List.generate(
                  //                               controller.chatUserList.length,
                  //                                   (index) {
                  //                                 return Padding(
                  //                                   padding: const EdgeInsets.only(
                  //                                       top: 0.0, left: 0, right: 0),
                  //                                   child: Card(
                  //                                     elevation: 0.0,
                  //                                     color: Colors.transparent,
                  //                                     child: Padding(
                  //                                       padding:
                  //                                       const EdgeInsets.all(8.0),
                  //                                       child: Row(
                  //                                         crossAxisAlignment:
                  //                                         CrossAxisAlignment
                  //                                             .start,
                  //                                         children: [
                  //                                           controller
                  //                                               .chatUserList[
                  //                                           index]
                  //                                               .conversationType !=
                  //                                               "group"
                  //                                               ? CircleAvatar(
                  //                                             backgroundImage: controller
                  //                                                 .chatUserList[
                  //                                             index]
                  //                                                 .profileImage !=
                  //                                                 null
                  //                                                 ? NetworkImage(controller
                  //                                                 .chatUserList[
                  //                                             index]
                  //                                                 .profileImage)
                  //                                                 : AssetImage(
                  //                                                 'assets/images/person_placeholder.png'),
                  //                                             radius: 22,
                  //                                           )
                  //                                               : CircleAvatar(
                  //                                             backgroundImage: controller
                  //                                                 .chatUserList[
                  //                                             index]
                  //                                                 .groupImage !=
                  //                                                 null
                  //                                                 ? NetworkImage(controller
                  //                                                 .chatUserList[
                  //                                             index]
                  //                                                 .groupImage)
                  //                                                 : AssetImage(
                  //                                                 'assets/images/person_placeholder.png'),
                  //                                             radius: 22,
                  //                                           ),
                  //                                           SizedBox(
                  //                                             width: 20,
                  //                                           ),
                  //                                           Expanded(
                  //                                             child: Column(
                  //                                               crossAxisAlignment:
                  //                                               CrossAxisAlignment
                  //                                                   .start,
                  //                                               mainAxisAlignment:
                  //                                               MainAxisAlignment
                  //                                                   .spaceEvenly,
                  //                                               children: [
                  //                                                 Text(
                  //                                                   controller
                  //                                                       .chatUserList[
                  //                                                   index]
                  //                                                       .name ==
                  //                                                       null
                  //                                                       ? ""
                  //                                                       : controller
                  //                                                       .chatUserList[
                  //                                                   index]
                  //                                                       .name,
                  //                                                   style: TextStyle(
                  //                                                       fontSize: 14,
                  //                                                       fontWeight:
                  //                                                       FontWeight
                  //                                                           .w600,
                  //                                                       overflow:
                  //                                                       TextOverflow
                  //                                                           .ellipsis),
                  //                                                 ),
                  //                                                 SizedBox(
                  //                                                   width: 150,
                  //                                                   child: Text(
                  //                                                     controller
                  //                                                         .chatUserList[
                  //                                                     index]
                  //                                                         .latestMessage ==
                  //                                                         null
                  //                                                         ? ""
                  //                                                         : controller
                  //                                                         .chatUserList[
                  //                                                     index]
                  //                                                         .latestMessage,
                  //                                                     overflow:
                  //                                                     TextOverflow
                  //                                                         .ellipsis,
                  //                                                     maxLines: 1,
                  //                                                   ),
                  //                                                 ),
                  //                                               ],
                  //                                             ),
                  //                                           ),
                  //                                           // Column(
                  //                                           //   children: [
                  //                                           //     Text(
                  //                                           //         "jkbdjsbfjbfjksbdfjbsdf")
                  //                                           //   ],
                  //                                           // )
                  //                                         ],
                  //                                       ),
                  //                                     ),
                  //                                   ),
                  //                                 );
                  //                               }),
                  //                         ),
                  //                       ],
                  //                     ),
                  //                   ),
                  //                 )
                  //                     : Column(
                  //                   children: [
                  //                     Text(
                  //                       Strings.sendAMessageGetAMessage,
                  //                       style: TextStyle(
                  //                           fontSize: 18,
                  //                           color: Colors.black,
                  //                           fontWeight: FontWeight.w900),
                  //                     ),
                  //                     SizedBox(height: 10),
                  //                     Text(
                  //                       Strings
                  //                           .directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore,
                  //                       textAlign: TextAlign.center,
                  //                       style: TextStyle(color: Colors.black),
                  //                     ),
                  //                     SizedBox(height: 14),
                  //                     RoundedButton(
                  //                       Strings.startAConversation,
                  //                           () {
                  //                         showDialog(
                  //                           context: context,
                  //                           builder: (BuildContext context) {
                  //                             return AlertDialog(
                  //                               contentPadding: EdgeInsets.zero,
                  //                               insetPadding: EdgeInsets.zero,
                  //                               shape: RoundedRectangleBorder(
                  //                                 borderRadius:
                  //                                 BorderRadius.circular(20),
                  //                               ),
                  //                               content: NewMessageDialogBox(),
                  //                             );
                  //                           },
                  //                         );
                  //                       },
                  //                       horizontalPadding: 40,
                  //                     ),
                  //                   ],
                  //                 )
                  //               ],
                  //             ),
                  //           ),
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  //
                  // );

                  // child: DraggableScrollableSheet(
                  //   // expand: false,
                  //   minChildSize: size.value,
                  //   initialChildSize: size.value,
                  //   builder: (BuildContext context,
                  //       ScrollController scrollController) {
                  //
                  //   },
                  // ),
                  ),
            );
          }),

          // Align(
          //   alignment: Alignment.bottomCenter,
          //     child:
          //     Container(
          //       height: 50,
          //       width: Get.width * 0.25,
          //       decoration: BoxDecoration(
          //         color: Colors.white,
          //         borderRadius: BorderRadius.only(
          //             topRight: Radius.circular(20.0),
          //             topLeft: Radius.circular(20.0),
          //         ),
          //         boxShadow: [
          //           BoxShadow(
          //             color: Colors.grey.withOpacity(0.5),
          //             spreadRadius: 5,
          //             blurRadius: 7,
          //             offset: Offset(0, 3), // changes position of shadow
          //           ),
          //         ],
          //         ),
          //       child: Padding(
          //         padding: const EdgeInsets.only(left: 10,right: 10),
          //         child: Row(
          //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //           children: [
          //             Text("Messages",
          //               style: TextStyle(
          //                 fontSize: 20,
          //                 fontWeight: FontWeight.bold,
          //               ),
          //            ),
          //               IconButton(onPressed:(){
          //                 showModalBottomSheet<void>(
          //                   backgroundColor: Colors.transparent,
          //                   barrierColor: Colors.transparent,
          //                   context: context,
          //                   builder: (BuildContext context) {
          //                     return Padding(
          //                       padding: EdgeInsets.only(left: MediaQuery.of(context).size.width  * 0.75 ),
          //                       child: Container(
          //                         height: 500,
          //                         width: 100,
          //                         color: Colors.amber,
          //                         child: Center(
          //                           child: Column(
          //                             mainAxisAlignment: MainAxisAlignment.center,
          //                             mainAxisSize: MainAxisSize.min,
          //                             children: <Widget>[
          //                               const Text('Modal BottomSheet'),
          //                               ElevatedButton(
          //                                 child: const Text('Close BottomSheet'),
          //                                 onPressed: () => Navigator.pop(context),
          //                               )
          //                             ],
          //                           ),
          //                         ),
          //                       ),
          //                     );
          //                   },
          //                 );
          //
          //
          //                 // Get.bottomSheet(
          //                 //   BottomSheet(
          //                 //     enableDrag: false,
          //                 //     shape: const RoundedRectangleBorder(
          //                 //       borderRadius: BorderRadius.vertical(
          //                 //         top: Radius.circular(30),
          //                 //       ),
          //                 //     ),
          //                 //     clipBehavior: Clip.antiAliasWithSaveLayer,
          //                 //     onClosing: () {},
          //                 //     builder: (context) =>
          //                 //         SizedBox(
          //                 //            height: 400,  // Get.height / 1.2,
          //                 //
          //                 //         ),
          //                 //   ),
          //                 //
          //                 // );
          //
          //
          //               },
          //                 splashRadius:5 ,
          //                   icon: Icon(
          //                     Icons.expand_less_rounded,
          //                     size: 30,
          //                   ),
          //               )
          //
          //           ],
          //         ),
          //       ),
          //
          //       ),
          //     ),
        ],
      ),
    );
  }

  void _clickWho(GetFollowerModel post) async {



    Get.offNamed("${FluroRouters.mainScreen}/profile/${post.id}");
    SingleTone.instance.userId = post.id.toString();

    Get.put(OtherUserController());

    Get.find<NewsfeedController>().otherUserId = post.id;


    Get.find<NewsfeedController>().update();

    // print(
    //     "other user id >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${Get.find<NewsfeedController>().otherUserId}");

    Get.find<NewsfeedController>().userInfo = UserProfile();
    Get.find<NewsfeedController>().userInfo = await controller.getOtherUserProfile(post.id);

    // print(" post muted value ${Get.find<NewsfeedController>().userInfo.muted}");


    Get.find<OtherUserController>().userPosts=  await Get.find<OtherUserController>().newsFeedController.filterUsersPost("posts");

    // print(" Get.find<OtherUserController>().userPosts  ${ Get.find<OtherUserController>().userPosts.length}");

    Get.find<OtherUserController>().update();


    Get.find<OtherUserController>().userPosts[0].mute =
        Get.find<NewsfeedController>().userInfo?.muted ?? false;

    Get.find<OtherUserController>().userPosts.forEach((element) {
      element.mute = Get.find<NewsfeedController>().userInfo.muted;
      // print("element.mute  ${element.mute}");
    });

    Get.find<OtherUserController>().update();

    // print("post/profile/ ${post.id.toString()}");


    // Get.toNamed(FluroRouters.mainScreen+"?page=profile&postId="+post.id.toString());

    // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "profile",id: post.id.toString()));
    /* print('CCCLLIIICKKKK' + post.id.toString());
    controller.otherUserId = post.id;
    controller.otherUserName = post.username;
    // controller.isOtherUserProfileScreen = false;
    // controller.isClickWhoToFollow = true;
    controller.isWhoToFollowScreen = false;
    controller.isOtherUserProfileScreen = true;
    controller.isTrendsScreen = false;
    controller.isNewsFeedScreen = false;
    controller.isBrowseScreen = false;
    controller.isNotificationScreen = false;
    controller.isChatScreen = false;
    controller.isPostDetails = false;
    controller.isProfileScreen = false;
    try {

      Get.find<NewsfeedController>().userId = post.id;

      print("post.id   ${post.id}  " );

      Get.find<NewsfeedController>().update();

      Get.find<NewsfeedController>().otherUserId = post.id;

      Get.find<NewsfeedController>().update();

      // Get.find<OtherUserController>().filterUsersPostPagged("posts",page:5,userid:post.id);

      Get.find<NewsfeedController>().otherUserId = post.id;

      print("other user id >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${Get.find<NewsfeedController>().otherUserId}");

      Get.find<NewsfeedController>().userInfo = UserProfile();
       Get.find<NewsfeedController>().userInfo = await controller.getOtherUserProfile(post.id);


      print(" post muted value ${Get.find<NewsfeedController>().userInfo.muted}");


      await Get.find<OtherUserController>().filterUsersPostPagged("posts", page: 1);

      Get.find<OtherUserController>().userPosts[0].mute = Get.find<NewsfeedController>().userInfo.muted;

      Get.find<OtherUserController>().userPosts.forEach((element) {
        element.mute = Get.find<NewsfeedController>().userInfo.muted;
        print("element.mute  ${element.mute}");
      });

      Get.find<OtherUserController>().update();





      // Get.find<OtherUserController>().userProfile = await controller.getOtherUserProfile(post.id);
      print(" try  idhar aya  hai");
      // print("Get.find<OtherUserController>().userProfile.username ${Get.find<OtherUserController>().userProfile.username}");

      // Get
      //     .find<OtherUserController>()
      //     .userPosts = [];

    } catch (_) {
      print("aya hai");


    }
    controller.update();
    // try{
    //   if(controller.isOtherUserProfileScreen || controller.isClickWhoToFollow){
    //     final otherUserController = Get.find<OtherUserController>();
    //     controller.otherUserId = post.id;
    //     controller.isOtherUserProfileScreen = false;
    //     controller.isClickWhoToFollow = true;
    //     controller.isWhoToFollowScreen = false;
    //     controller.isOtherUserProfileScreen = false;
    //     controller.isTrendsScreen = false;
    //     controller.isNewsFeedScreen = false;
    //     controller.isQuestScreen = false;
    //     controller.isNotificationScreen = false;
    //     controller.isChatScreen = false;
    //     controller.isPostDetails = false;
    //     otherUserController.update();
    // } else {

    // }finally{*/
  }
}

class FilterPeopleButton extends StatelessWidget {
  const FilterPeopleButton(
      {Key key, @required this.controller,
      @required this.onTap,
      @required this.title,
      @required this.value}) : super(key: key);

  final NewsfeedController controller;
  final String title;
  final Function onTap;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
          ),
        ),
        Radio(
          value: value,
          groupValue: controller.people,
          onChanged: onTap,
        )
      ],
    );
  }
}

class FilterPlaceButton extends StatelessWidget {
  const FilterPlaceButton(
      {Key key, @required this.controller,
      @required this.onTap,
      @required this.title,
      @required this.value}) : super(key: key);

  final NewsfeedController controller;
  final String title;
  final Function onTap;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
          ),
        ),
        Radio(
          value: value,
          groupValue: controller.place,
          onChanged: onTap,
        )
      ],
    );
  }
}
