
import 'package:flutter/material.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/screens/registration_successful.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/custom_image_view.dart';
import '../widgets/sign_in_sign_up_widget/new_login_form.dart'as loginForm;
import '../widgets/sign_up_dialog.dart';

// ignore: must_be_immutable
class WebLoginView extends StatelessWidget {
  LoginController controller;
  var formKey;

  WebLoginView({Key key, @required this.controller, this.formKey})
      : super(key: key);


  @override
  Widget build(BuildContext context) {
    final double mediaHeight = MediaQuery
        .of(context)
        .size
        .height;
    final double mediaWidth = MediaQuery
        .of(context)
        .size
        .width;
    return

      Scaffold(
        backgroundColor: Colors.grey.shade100,
        bottomNavigationBar: _buildFooter(),
        body: Align(
          alignment: Alignment.center,
          child:

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [

              Row(
                children: [
                  mediaWidth < 860 ? const SizedBox()
                      : SizedBox(
                    width: mediaWidth * 0.2,
                    child: CustomImageShow(
                      imagePath: AppImages.loginWebPageLeftBackGround,
                    ),
                  ),
                  mediaWidth < 1102
                      ? const SizedBox()
                      : SizedBox(

                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 300,
                          height: 230,
                          child: CustomImageShow(
                            imagePath: AppImages.loginWebPagePngPic,
                          ),
                        ),
                      ],
                    ),
                  ),

                ],
              ),
              Padding(
                padding:
                mediaWidth < 1200 ?
                const EdgeInsets.only(
                  right: 80,
                ) : const EdgeInsets.only(
                    right: 120
                ),
                child: SizedBox(
                  width: controller.showSignUpForm ? 550 : 500,
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: EdgeInsets.only(
                        top: controller.showSignUpForm
                            ? mediaHeight * 0.05
                            : mediaHeight * 0.05,
                        bottom: mediaHeight * 0.2,
                        left: mediaWidth < 650
                            ? 100
                            : 20.0,
                        right: mediaWidth < 650
                            ? 100
                            : 20.0,
                      ),
                      child: Column(
                        children: [
                          controller.showSignUpForm
                              ? SignUpDialog(
                            controller: controller,
                          )
                              : controller.showRegistrationSuccessful
                              ? RegistrationSuccessful()
                              : SizedBox(

                            child: loginForm.NewLoginForm(
                                context, controller, formKey, 1),
                          ),
                          const SizedBox(height: 30),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
  }

  Widget _buildFooter() {
    return
      Padding(
        padding: const EdgeInsets.only(bottom: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children:  [
            _footerText(text: "Privacy Policy",onTabCall: (){}),
            _footerText(text:"Terms of Service" ,onTabCall: (){}),
            _footerText(text: 'FAQ',onTabCall: (){}),
            _footerText(text: 'Contact Us',onTabCall: (){}),

          ],),
      );
  }

  Widget _footerText({ @required String text, VoidCallback onTabCall}) {
    return Padding(
      padding: const EdgeInsets.only(left: 20),
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          onTap: onTabCall,
          child: Text(text,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 16,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
      ),
    );
  }

}