import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/widgets/post_card.dart';

import '../../../network/controller/guest_user_controller.dart';
import '../../../utils/font.dart';
import '../../../utils/strings.dart';

class GuestUserNewsFeedCarousel extends StatefulWidget {
  GuestUserNewsFeedCarousel({
    this.controller,
    this.post,
    this.imagesListForCarousel,
    this.mediaIndex,
    this.videoListForCarousel,
    this.check,
    this.chatCheck,
    this.postList,
    this.commentScreen,
  });

  final List imagesListForCarousel;
  final int mediaIndex;
  final List videoListForCarousel;
  final Post post;
  List<Post> postList;
  bool commentScreen = false;

  final GuestUserController controller;
  int check;

  int chatCheck = 0;

  @override
  State<GuestUserNewsFeedCarousel> createState() =>
      _GuestUserNewsFeedCarouselState();
}

class _GuestUserNewsFeedCarouselState extends State<GuestUserNewsFeedCarousel> {
  Focus focus;

  Widget build(BuildContext context) {
    return AlertDialog(
      insetPadding: kIsWeb
          ? EdgeInsets.symmetric(horizontal: 40.0, vertical: 24.0)
          : EdgeInsets.symmetric(horizontal: 0.0, vertical: 0.0),
      titlePadding: EdgeInsets.zero,
      title: Align(
        alignment: Alignment.topRight,
        child: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
            widget.post.reactionCheck.value = false;
          },
          icon: Actions(
            actions: {
              EscIntent: CallbackAction<EscIntent>(
                  onInvoke: (Intent) => Navigator.of(context).pop()),
            },
            child: Focus(
              // focusNode: focus,
              autofocus: true,
              child: Icon(Icons.close, color: Colors.amber),
            ),
          ),
        ),
      ),
      backgroundColor: Colors.black,
      contentPadding: EdgeInsets.zero,
      content: kIsWeb
          ? Stack(
              children: [
                Container(
                  color: Colors.black,
                  width: Get.width,
                  height: kIsWeb ? Get.height : Get.height,
                  child: Stack(
                    children: [
                      Swiper(
                        loop: false,
// layout: SwiperLayout.TINDER,
                        index: widget.mediaIndex,
                        containerWidth: kIsWeb ? Get.width * 0.4 : Get.width,
                        itemWidth: kIsWeb ? Get.width * 0.4 : Get.width,
                        itemBuilder: (BuildContext context, int index) {
                          return widget.imagesListForCarousel != null
                              ? Center(
                                  child: InteractiveViewer(
                                    boundaryMargin: const EdgeInsets.all(20.0),
                                    minScale: 0.1,
                                    maxScale: 1.6,
                                    child: Image.network(
                                      widget.imagesListForCarousel[index],
                                      fit: BoxFit.contain,
                                      height: kIsWeb ? Get.height : Get.height,
                                      width:
                                          kIsWeb ? Get.width * 0.4 : Get.width,
                                    ),
                                  ),
                                )
                              : SizedBox();
                          // : ChewieVideoPlayer(
                          // videoUrl: widget.videoListForCarousel[index]);
                        },
                        itemCount: widget.imagesListForCarousel != null
                            ? widget.imagesListForCarousel.length
                            : widget.videoListForCarousel.length,
                        control: SwiperControl(
                          padding: EdgeInsets.only(left: 28, right: 20),
                          size: 50,
                          color: Color(0xFFedab30),
                        ),
                      ),

                      ///

                      widget.chatCheck != 1
                          ? Positioned.fill(
                              child: Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  alignment: Alignment.center,
                                  width: Get.width * 0.4,
                                  height: 74,
                                  color: Colors.black87,
                                  // margin: EdgeInsets.symmetric(horizontal: 20),
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                        left: 20, right: 20, bottom: 20),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [

                                           Row(
                                            children: [
                                              SizedBox(width: 5),
                                              GestureDetector(
                                                onTap: () async {},
                                                child: Container(
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                    horizontal: 5,
                                                    vertical: 1,
                                                  ),
                                                  child: Text(
                                                  //  "12",
                                                    "${widget.post.simpleLikeCount}",
                                                    // style: TextStyle(
                                                    //   color: Colors.grey[600],
                                                    //   fontSize: 14,
                                                    // ),
                                                    style: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 14,
                                                          )
                                                        : TextStyle(
                                                            color: Colors.white,
                                                            fontSize: 14,
                                                          ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Tooltip(
                                              message: 'Reply',
                                              child: InkWell(
                                                onTap: () {},
                                                child: Container(
                                                  width: 20,
                                                  height: 20,
                                                  child: Icon(
                                                    Icons.mode_comment_outlined,
                                                    size: 20,
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.grey,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: () async {},
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                  horizontal: 8,
                                                  vertical: 1,
                                                ),
                                                child: Text(
                                                 // "2",
                                                   widget.post.commentCount
                                                       .toString(),
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 14,
                                                        )
                                                      : TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 14,
                                                        ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            // widget.post.isRetweeted == null
                                            //     ? SizedBox()
                                               // :
                                          Tooltip(
                                                    message: Strings.rewerf,
                                                    child: InkWell(
                                                      onTap: () {},
                                                      child: Container(
                                                        width: 20,
                                                        height: 20,
                                                        child: Image.asset(
                                                          'assets/drawer_icons/rebuzz_grey.png',
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                            GestureDetector(
                                              onTap: () async {},
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                  horizontal: 8,
                                                  vertical: 1,
                                                ),
                                                child: Text(
                                                 // '3',
                                                 widget.post.retweetCount==null?"0"  :widget.post.retweetCount
                                                      .toString(),
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 14,
                                                        )
                                                      : TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 14,
                                                        ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            )
                          : SizedBox()
                    ],
                  ),
                ),
                widget.chatCheck != 1
                    ?

                          GestureDetector(
                          onTap: () {
                            widget.post.reactionCheck.value = false;
                          },
                          child: Container(
                            color: Colors.black,
                            width: Get.width,
                            height: kIsWeb ? Get.height : Get.height,
                            child: Stack(
                              children: [
                                Swiper(
                                  loop: false,
// layout: SwiperLayout.TINDER,
                                  index: widget.mediaIndex,
                                  containerWidth:
                                      kIsWeb ? Get.width * 0.4 : Get.width,
                                  itemWidth:
                                      kIsWeb ? Get.width * 0.4 : Get.width,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return widget.imagesListForCarousel != null
                                        ? Center(
                                            child: InteractiveViewer(
                                              boundaryMargin:
                                                  const EdgeInsets.all(20.0),
                                              minScale: 0.1,
                                              maxScale: 1.6,
                                              child: Image.network(
                                                widget.imagesListForCarousel[
                                                    index],
                                                fit: BoxFit.contain,
                                                height: kIsWeb
                                                    ? Get.height
                                                    : Get.height,
                                                width: kIsWeb
                                                    ? Get.width * 0.4
                                                    : Get.width,
                                              ),
                                            ),
                                          )
                                        : SizedBox();
                                    // : ChewieVideoPlayer(
                                    // videoUrl: widget.videoListForCarousel[index]);
                                  },
                                  itemCount:
                                      widget.imagesListForCarousel != null
                                          ? widget.imagesListForCarousel.length
                                          : widget.videoListForCarousel.length,
                                  control: SwiperControl(
                                    padding:
                                        EdgeInsets.only(left: 28, right: 20),
                                    size: 50,
                                    color: Color(0xFFedab30),
                                  ),
                                ),
                                widget.chatCheck != 1
                                    ? Positioned.fill(
                                        child: Align(
                                          alignment: Alignment.bottomCenter,
                                          child: Container(
                                            alignment: Alignment.center,
                                            width: Get.width * 0.4,
                                            height: 74,
                                            color: Colors.black87,
                                            // margin: EdgeInsets.symmetric(horizontal: 20),
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  left: 20,
                                                  right: 20,
                                                  bottom: 20),

                                              ///reaction row for web
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Obx(() {
                                                    return Row(
                                                      children: [
                                                        SizedBox(
                                                          width: 20,
                                                          height: 20,
                                                          child: Tooltip(
                                                            message: 'React',
                                                            child: InkWell(
                                                              onLongPress:
                                                                  () {},
                                                              onTap:
                                                                  () async {},
                                                              child: widget
                                                                          .post
                                                                          .reactionType
                                                                          .value ==
                                                                      "love"
                                                                  ? Image.asset(
                                                                      'assets/reaction_gif/love-min.png',
                                                                      // : 'assets/reaction_gif/like_gif.gif',
                                                                      width: 30,
                                                                      height:
                                                                          30,
                                                                    )
                                                                  : widget.post.reactionType
                                                                              .value ==
                                                                          "like_simple_like"
                                                                      ? Image
                                                                          .asset(
                                                                          'assets/reaction_gif/like-min.png',
                                                                          width:
                                                                              30,
                                                                          height:
                                                                              30,
                                                                        )
                                                                      : widget.post.reactionType.value ==
                                                                              null
                                                                          ? Image
                                                                              .asset(
                                                                              'assets/drawer_icons/not_like.png',
                                                                              // : 'assets/reaction_gif/like_gif.gif',
                                                                              width: 25,
                                                                              height: 25,
                                                                              color: Colors.white,
                                                                            )
                                                                          : widget.post.reactionType.value == "lough"
                                                                              ? Image.asset(
                                                                                  'assets/reaction_gif/laugh-min.png',
                                                                                  // : 'assets/reaction_gif/like_gif.gif',
                                                                                  width: 30,
                                                                                  height: 30,
                                                                                )
                                                                              : widget.post.reactionType.value == "smile"
                                                                                  ? Image.asset(
                                                                                      'assets/reaction_gif/smile-min.png',
                                                                                      // : 'assets/reaction_gif/like_gif.gif',
                                                                                      width: 30,
                                                                                      height: 30,
                                                                                    )
                                                                                  : widget.post.reactionType.value == "thanks"
                                                                                      ? Image.asset(
                                                                                          'assets/reaction_gif/thanks-min.png',
                                                                                          // : 'assets/reaction_gif/like_gif.gif',
                                                                                          width: 30,
                                                                                          height: 30,
                                                                                        )
                                                                                      : widget.post.reactionType.value == "excited"
                                                                                          ? Image.asset(
                                                                                              'assets/reaction_gif/excited-min.png',
                                                                                              // : 'assets/reaction_gif/like_gif.gif',
                                                                                              width: 30,
                                                                                              height: 30,
                                                                                            )
                                                                                          : widget.post.reactionType.value == "cry"
                                                                                              ? Image.asset(
                                                                                                  'assets/reaction_gif/cry-min.png',
                                                                                                  // : 'assets/reaction_gif/like_gif.gif',
                                                                                                  width: 30,
                                                                                                  height: 30,
                                                                                                )
                                                                                              : Image.asset(
                                                                                                  'assets/drawer_icons/not_like.png',
                                                                                                  // : 'assets/reaction_gif/like_gif.gif',
                                                                                                  width: 25,
                                                                                                  height: 25,
                                                                                                  color: Colors.white,
                                                                                                ),
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(width: 5),
                                                        GestureDetector(
                                                          onTap: () async {},
                                                          child: Container(
                                                            padding:
                                                                const EdgeInsets
                                                                    .symmetric(
                                                              horizontal: 5,
                                                              vertical: 1,
                                                            ),
                                                            // decoration: BoxDecoration(
                                                            //   color: Colors.grey[100],
                                                            //   borderRadius: BorderRadius.circular(20),
                                                            // ),
                                                            child: Text(
                                                              "${widget.post.simpleLikeCount}",
                                                              // style: TextStyle(
                                                              //   color: Colors.grey[600],
                                                              //   fontSize: 14,
                                                              // ),
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline2
                                                                  .copyWith(
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    );
                                                  }),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Tooltip(
                                                        message: 'Reply',
                                                        child: InkWell(
                                                          onTap: () {},
                                                          child: Container(
                                                            width: 20,
                                                            height: 20,
                                                            child: Icon(
                                                              Icons
                                                                  .mode_comment_outlined,
                                                              size: 20,
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors.grey,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      GestureDetector(
                                                        onTap: () async {},
                                                        child: Container(
                                                          padding:
                                                              const EdgeInsets
                                                                  .symmetric(
                                                            horizontal: 8,
                                                            vertical: 1,
                                                          ),
                                                          child: Text(
                                                         widget.post.retweetCount==null?'0'  : widget.post.retweetCount
                                                                .toString(),
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              fontSize: 14,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                   //   widget.post.isRetweeted ==
                                                          //    null
                                                        //  ? SizedBox()
                                                         // :
                                                    Tooltip(
                                                              message: Strings.rewerf,
                                                              child: InkWell(
                                                                onTap: () {},
                                                                child:
                                                                    Container(
                                                                  width: 20,
                                                                  height: 20,
                                                                  child: Image
                                                                      .asset(
                                                                    'assets/drawer_icons/rebuzz_grey.png',
                                                                    color: Colors.white,
                                                                  ),
                                                                ),

                                                              ),
                                                            ),

                                                      GestureDetector(
                                                        onTap: () {},
                                                        child: Container(
                                                          padding:
                                                              const EdgeInsets
                                                                  .symmetric(
                                                            horizontal: 8,
                                                            vertical: 1,
                                                          ),

                                                          child: Text(
                                                          widget.post.retweetCount==null?"0" : widget.post.retweetCount.toString(),
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              fontSize: 14,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      )
                                    : SizedBox()
                              ],
                            ),
                          ),
                        )

                    : SizedBox(),
                widget.chatCheck != 1
                    ? Obx(() {
                        return widget.post.reactionCheck.value == true
                            ? Positioned(
                                bottom: 60,
                                left: kIsWeb ? 180 : 20,
                                child: Container(
                                  height: 45,
                                  width: 260,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(50),
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 5,
                                        blurRadius: 7,
                                        offset: Offset(
                                            0, 3), // changes position of shadow
                                      ),
                                    ],
                                  ),

                                ),
                              )
                            : SizedBox();
                      })
                    : SizedBox()
              ],
            )

      ///web  finish

     : SizedBox()
          // : Stack(
          //     children: [
          //       Container(
          //         color: Colors.black,
          //         width: Get.width,
          //         height: kIsWeb ? Get.height : Get.height,
          //         child: Stack(
          //           children: [
          //             widget.imagesListForCarousel != null
          //                 ? widget.imagesListForCarousel.length >= 2
          //                     ? Swiper(
          //                         loop: false,
          //                         index: widget.mediaIndex,
          //                         containerWidth:
          //                             kIsWeb ? Get.width * 0.4 : Get.width,
          //                         itemWidth:
          //                             kIsWeb ? Get.width * 0.4 : Get.width,
          //                         itemBuilder:
          //                             (BuildContext context, int index) {
          //                           return widget.imagesListForCarousel != null
          //                               ? Center(
          //                                   child: InteractiveViewer(
          //                                     boundaryMargin:
          //                                         const EdgeInsets.all(20.0),
          //                                     minScale: 0.1,
          //                                     maxScale: 1.6,
          //                                     child: Image.network(
          //                                       widget.imagesListForCarousel[
          //                                           index],
          //                                       fit: BoxFit.contain,
          //                                       height: kIsWeb
          //                                           ? Get.height
          //                                           : Get.height,
          //                                       width: kIsWeb
          //                                           ? Get.width * 0.4
          //                                           : Get.width,
          //                                     ),
          //                                   ),
          //                                 )
          //                               : SizedBox();
          //                           // : ChewieVideoPlayer(
          //                           // videoUrl: widget.videoListForCarousel[index]);
          //                         },
          //                         itemCount:
          //                             widget.imagesListForCarousel != null
          //                                 ? widget.imagesListForCarousel.length
          //                                 : widget.videoListForCarousel.length,
          //
          //                         pagination: SwiperPagination(
          //                           builder: FractionPaginationBuilder(
          //                             activeColor: Colors.amber,
          //                             fontSize: 18,
          //                             activeFontSize: 18,
          //                           ),
          //                           alignment: Alignment.topCenter,
          //                         ),
          //                         // control: SwiperControl(
          //                         //   padding: EdgeInsets.only(left: 28, right: 20),
          //                         //   size: 50,
          //                         //   color: Color(0xFFedab30),
          //                         // ),
          //                       )
          //                     : Swiper(
          //                         loop: false,
          //                         index: widget.mediaIndex,
          //                         containerWidth:
          //                             kIsWeb ? Get.width * 0.4 : Get.width,
          //                         itemWidth:
          //                             kIsWeb ? Get.width * 0.4 : Get.width,
          //                         itemBuilder:
          //                             (BuildContext context, int index) {
          //                           return widget.imagesListForCarousel != null
          //                                   ? Center(
          //                                       child: InteractiveViewer(
          //                                         boundaryMargin:
          //                                             const EdgeInsets.all(
          //                                                 20.0),
          //                                         minScale: 0.1,
          //                                         maxScale: 1.6,
          //                                         child: Image.network(
          //                                           widget.imagesListForCarousel[
          //                                               index],
          //                                           fit: BoxFit.contain,
          //                                           height: kIsWeb
          //                                               ? Get.height
          //                                               : Get.height,
          //                                           width: kIsWeb
          //                                               ? Get.width * 0.4
          //                                               : Get.width,
          //                                         ),
          //                                       ),
          //                                     )
          //                                   : SizedBox()
          //                               // ChewieVideoPlayer(
          //                               //     videoUrl: widget.videoListForCarousel[index])
          //                               ;
          //                         },
          //                         itemCount:
          //                             widget.imagesListForCarousel != null
          //                                 ? widget.imagesListForCarousel.length
          //                                 : widget.videoListForCarousel.length,
          //
          //                         // control: SwiperControl(
          //                         //   padding: EdgeInsets.only(left: 28, right: 20),
          //                         //   size: 50,
          //                         //   color: Color(0xFFedab30),
          //                         // ),
          //                       )
          //                 : SizedBox(),
          //             widget.chatCheck != 1
          //                 ? Positioned.fill(
          //                     child: Align(
          //                       alignment: Alignment.bottomCenter,
          //                       child: Container(
          //                         alignment: Alignment.center,
          //                         width: double.infinity,
          //                         height: 74,
          //                         color: Colors.black87,
          //                         // margin: EdgeInsets.symmetric(horizontal: 20),
          //
          //                         ///
          //                         ///
          //                         child: Padding(
          //                           padding: EdgeInsets.only(
          //                               left: 20, right: 20, bottom: 20),
          //                           child: Row(
          //                             mainAxisAlignment:
          //                                 MainAxisAlignment.spaceBetween,
          //                             children: [
          //                               Row(
          //                                   children: [
          //                                     SizedBox(width: 5),
          //                                     GestureDetector(
          //                                       onTap: () async {},
          //                                       child: Container(
          //                                         padding: const EdgeInsets
          //                                             .symmetric(
          //                                           horizontal: 5,
          //                                           vertical: 1,
          //                                         ),
          //                                         child: Text(
          //                                           "${widget.post.simpleLikeCount}",
          //                                           style: Styles
          //                                               .baseTextTheme.headline2
          //                                               .copyWith(
          //                                             fontSize: 14,
          //                                           ),
          //                                         ),
          //                                       ),
          //                                     ),
          //                                   ],
          //                                 ),
          //
          //
          //                               ///Replies
          //                               Row(
          //                                 mainAxisAlignment:
          //                                     MainAxisAlignment.start,
          //                                 children: [
          //                                   Tooltip(
          //                                     message: 'Replies',
          //                                     child: InkWell(
          //                                       onTap: () {},
          //                                       child: Container(
          //                                         width: 20,
          //                                         height: 20,
          //                                         child: Icon(
          //                                           Icons.mode_comment_outlined,
          //                                           size: 20,
          //                                           color: Theme.of(context)
          //                                                       .brightness ==
          //                                                   Brightness.dark
          //                                               ? Colors.white
          //                                               : Colors.grey,
          //                                         ),
          //                                       ),
          //                                     ),
          //                                   ),
          //                                   GestureDetector(
          //                                     onTap: () {},
          //                                     child: Container(
          //                                       padding:
          //                                           const EdgeInsets.symmetric(
          //                                         horizontal: 8,
          //                                         vertical: 1,
          //                                       ),
          //                                       child: Text(
          //                                         widget.post.commentsCount.toString(),
          //                                         style: Styles
          //                                             .baseTextTheme.headline2
          //                                             .copyWith(
          //                                           fontSize: 14,
          //                                         ),
          //                                       ),
          //                                     ),
          //                                   ),
          //                                 ],
          //                               ),
          //
          //                               /// Rewerf
          //                               Row(
          //                                 mainAxisAlignment:
          //                                     MainAxisAlignment.start,
          //                                 children: [
          //                                   widget.post.isRetweeted == null
          //                                       ? SizedBox()
          //                                       : Tooltip(
          //                                           message: Strings.rewerf,
          //                                           child: InkWell(
          //                                             onTap: () {},
          //                                             child: Container(
          //                                               width: 20,
          //                                               height: 20,
          //                                               child: Image.asset(
          //                                                 'assets/drawer_icons/rebuzz.png',
          //                                                 color: widget.post
          //                                                         .rebuzz.value
          //                                                     ? Colors.white
          //                                                     : Colors.white,
          //                                               ),
          //                                             ),
          //                                           ),
          //                                         ),
          //                                   GestureDetector(
          //                                     onTap: () {},
          //                                     child: Container(
          //                                       padding:
          //                                           const EdgeInsets.symmetric(
          //                                         horizontal: 8,
          //                                         vertical: 1,
          //                                       ),
          //                                       child: Text(
          //                                         widget.post.rebuzzCount.value
          //                                             .toString(),
          //                                         style: Styles
          //                                             .baseTextTheme.headline2
          //                                             .copyWith(
          //                                           fontSize: 14,
          //                                         ),
          //                                       ),
          //                                     ),
          //                                   ),
          //                                 ],
          //                               ),
          //                             ],
          //                           ),
          //                         ),
          //                       ),
          //                     ),
          //                   )
          //                 : SizedBox()
          //           ],
          //         ),
          //       ),
          //       widget.chatCheck != 1
          //           ? Obx(() {
          //               return GestureDetector(
          //                 onTap: () {
          //                   widget.post.reactionCheck.value = false;
          //                 },
          //                 child: Container(
          //                   color: Colors.black,
          //                   width: Get.width,
          //                   height: kIsWeb ? Get.height : Get.height,
          //                   child: Stack(
          //                     children: [
          //                       widget.imagesListForCarousel != null
          //                           ? widget.imagesListForCarousel.length >= 2
          //                               ? Swiper(
          //                                   loop: false,
          //                                   index: widget.mediaIndex,
          //                                   containerWidth: kIsWeb
          //                                       ? Get.width * 0.4
          //                                       : Get.width,
          //                                   itemWidth: kIsWeb
          //                                       ? Get.width * 0.4
          //                                       : Get.width,
          //                                   itemBuilder: (BuildContext context,
          //                                       int index) {
          //                                     return widget
          //                                                 .imagesListForCarousel !=
          //                                             null
          //                                         ? Center(
          //                                             child: InteractiveViewer(
          //                                               boundaryMargin:
          //                                                   const EdgeInsets
          //                                                       .all(20.0),
          //                                               minScale: 0.1,
          //                                               maxScale: 1.6,
          //                                               child: Image.network(
          //                                                 widget.imagesListForCarousel[
          //                                                     index],
          //                                                 fit: BoxFit.contain,
          //                                                 height: kIsWeb
          //                                                     ? Get.height
          //                                                     : Get.height,
          //                                                 width: kIsWeb
          //                                                     ? Get.width * 0.4
          //                                                     : Get.width,
          //                                               ),
          //                                             ),
          //                                           )
          //                                         : SizedBox();
          //                                     // : ChewieVideoPlayer(
          //                                     // videoUrl: widget.videoListForCarousel[index]);
          //                                   },
          //                                   itemCount: widget
          //                                               .imagesListForCarousel !=
          //                                           null
          //                                       ? widget.imagesListForCarousel
          //                                           .length
          //                                       : widget.videoListForCarousel
          //                                           .length,
          //
          //                                   pagination: SwiperPagination(
          //                                     builder:
          //                                         FractionPaginationBuilder(
          //                                       activeColor: Colors.amber,
          //                                       fontSize: 18,
          //                                       activeFontSize: 18,
          //                                     ),
          //                                     alignment: Alignment.topCenter,
          //                                   ),
          //                                   // control: SwiperControl(
          //                                   //   padding: EdgeInsets.only(left: 28, right: 20),
          //                                   //   size: 50,
          //                                   //   color: Color(0xFFedab30),
          //                                   // ),
          //                                 )
          //                               : Swiper(
          //                                   loop: false,
          //                                   index: widget.mediaIndex,
          //                                   containerWidth: kIsWeb
          //                                       ? Get.width * 0.4
          //                                       : Get.width,
          //                                   itemWidth: kIsWeb
          //                                       ? Get.width * 0.4
          //                                       : Get.width,
          //                                   itemBuilder: (BuildContext context,
          //                                       int index) {
          //                                     return widget.imagesListForCarousel !=
          //                                                 null
          //                                             ? Center(
          //                                                 child:
          //                                                     InteractiveViewer(
          //                                                   boundaryMargin:
          //                                                       const EdgeInsets
          //                                                           .all(20.0),
          //                                                   minScale: 0.1,
          //                                                   maxScale: 1.6,
          //                                                   child:
          //                                                       Image.network(
          //                                                     widget.imagesListForCarousel[
          //                                                         index],
          //                                                     fit: BoxFit
          //                                                         .contain,
          //                                                     height: kIsWeb
          //                                                         ? Get.height
          //                                                         : Get.height,
          //                                                     width: kIsWeb
          //                                                         ? Get.width *
          //                                                             0.4
          //                                                         : Get.width,
          //                                                   ),
          //                                                 ),
          //                                               )
          //                                             : SizedBox()
          //                                         // ChewieVideoPlayer(
          //                                         //     videoUrl: widget.videoListForCarousel[index])
          //                                         ;
          //                                   },
          //                                   itemCount: widget
          //                                               .imagesListForCarousel !=
          //                                           null
          //                                       ? widget.imagesListForCarousel
          //                                           .length
          //                                       : widget.videoListForCarousel
          //                                           .length,
          //
          //                                   // control: SwiperControl(
          //                                   //   padding: EdgeInsets.only(left: 28, right: 20),
          //                                   //   size: 50,
          //                                   //   color: Color(0xFFedab30),
          //                                   // ),
          //                                 )
          //                           : SizedBox(),
          //                       widget.chatCheck != 1
          //                           ? Positioned.fill(
          //                               child: Align(
          //                                 alignment: Alignment.bottomCenter,
          //                                 child: Container(
          //                                   alignment: Alignment.center,
          //                                   width: double.infinity,
          //                                   height: 74,
          //                                   color: Colors.black87,
          //                                   // margin: EdgeInsets.symmetric(horizontal: 20),
          //                                   child: Padding(
          //                                     padding: EdgeInsets.only(
          //                                         left: 20,
          //                                         right: 20,
          //                                         bottom: 20),
          //                                     child: Row(
          //                                       mainAxisAlignment:
          //                                           MainAxisAlignment
          //                                               .spaceBetween,
          //                                       children: [
          //                                         Obx(() {
          //                                           return
          //
          //                                               /// like row
          //                                               Row(
          //                                             children: [
          //                                               SizedBox(width: 5),
          //                                               GestureDetector(
          //                                                 onTap: () {},
          //                                                 child: Container(
          //                                                   padding:
          //                                                       const EdgeInsets
          //                                                           .symmetric(
          //                                                     horizontal: 5,
          //                                                     vertical: 1,
          //                                                   ),
          //                                                   // decoration: BoxDecoration(
          //                                                   //   color: Colors.grey[100],
          //                                                   //   borderRadius: BorderRadius.circular(20),
          //                                                   // ),
          //                                                   child: Text(
          //                                                     "${widget.post.likeCount.value}",
          //                                                     style: Styles
          //                                                         .baseTextTheme
          //                                                         .headline2
          //                                                         .copyWith(
          //                                                       fontSize: 14,
          //                                                     ),
          //                                                   ),
          //                                                 ),
          //                                               ),
          //                                             ],
          //                                           );
          //                                         }),
          //
          //                                         /// Comment row
          //                                         Row(
          //                                           mainAxisAlignment:
          //                                               MainAxisAlignment.start,
          //                                           children: [
          //                                             Tooltip(
          //                                               message: 'Comment',
          //                                               child: InkWell(
          //                                                 onTap: () {},
          //                                                 child: Container(
          //                                                   width: 20,
          //                                                   height: 20,
          //                                                   child:
          //                                                       new Image.asset(
          //                                                     'assets/drawer_icons/comments.png',
          //                                                     color:
          //                                                         Colors.white,
          //                                                   ),
          //                                                 ),
          //                                               ),
          //                                             ),
          //                                             GestureDetector(
          //                                               onTap: () async {},
          //                                               child: Container(
          //                                                 padding:
          //                                                     const EdgeInsets
          //                                                         .symmetric(
          //                                                   horizontal: 8,
          //                                                   vertical: 1,
          //                                                 ),
          //                                                 child: Text(
          //                                                   widget
          //                                                       .post
          //                                                       .commentCount
          //                                                       .value
          //                                                       .toString(),
          //                                                   style: Styles
          //                                                       .baseTextTheme
          //                                                       .headline2
          //                                                       .copyWith(
          //                                                     fontSize: 14,
          //                                                   ),
          //                                                 ),
          //                                               ),
          //                                             ),
          //                                           ],
          //                                         ),
          //
          //                                         /// rewerf row
          //                                         Row(
          //                                           mainAxisAlignment:
          //                                               MainAxisAlignment.start,
          //                                           children: [
          //                                             widget.post.isRetweeted ==
          //                                                     null
          //                                                 ? SizedBox()
          //                                                 : Tooltip(
          //                                                     message: Strings.rewerf,
          //                                                     child: InkWell(
          //                                                       onTap: () {},
          //                                                       child:
          //                                                           Container(
          //                                                         width: 20,
          //                                                         height: 20,
          //                                                         child: Image
          //                                                             .asset(
          //                                                           'assets/drawer_icons/rebuzz.png',
          //                                                           color: widget
          //                                                                   .post
          //                                                                   .rebuzz
          //                                                                   .value
          //                                                               ? Colors
          //                                                                   .white
          //                                                               : Colors
          //                                                                   .white,
          //                                                         ),
          //                                                       ),
          //                                                     ),
          //                                                   ),
          //                                             GestureDetector(
          //                                               onTap: () {},
          //                                               child: Container(
          //                                                 padding:
          //                                                     const EdgeInsets
          //                                                         .symmetric(
          //                                                   horizontal: 8,
          //                                                   vertical: 1,
          //                                                 ),
          //                                                 child: Text(
          //                                                   widget
          //                                                       .post
          //                                                       .rebuzzCount
          //                                                       .value
          //                                                       .toString(),
          //                                                   style: Styles
          //                                                       .baseTextTheme
          //                                                       .headline2
          //                                                       .copyWith(
          //                                                     fontSize: 14,
          //                                                   ),
          //                                                 ),
          //                                               ),
          //                                             ),
          //                                           ],
          //                                         ),
          //                                       ],
          //                                     ),
          //                                   ),
          //                                 ),
          //                               ),
          //                             )
          //                           : SizedBox()
          //                     ],
          //                   ),
          //                 ),
          //               );
          //             })
          //           : SizedBox(),
          //     ],
          //   ),
    );

    // }
  }
}
