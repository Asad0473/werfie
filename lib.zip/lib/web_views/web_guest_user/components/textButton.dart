import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class TextCustomButton extends StatelessWidget {
  final String image;
  final String buttonText;
  final Function onPressed;
  final int id;
  final double width;
  final FocusNode focusNode;
  final bool callFromLogin;
  const TextCustomButton(
      {Key key,
      this.buttonText,
      this.onPressed,
      this.id,
      this.image,
      this.width,
        this.callFromLogin=false,
      this.focusNode})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final mediaQuery=MediaQuery.of(context).size;
    return Container(
      width: width,
      height: kIsWeb?40:50,
      child: TextButton(
        focusNode: focusNode,
        style: ButtonStyle(
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                  side:
                      BorderSide(color: id == 1 ? Colors.grey : Colors.white))),
          overlayColor: MaterialStateProperty.resolveWith<Color>(
              (Set<MaterialState> states) {
            if (states.contains(MaterialState.focused)) return Colors.grey;
            if (states.contains(MaterialState.hovered)) return Colors.grey;
            if (states.contains(MaterialState.pressed)) return Colors.blue;
            return null; // Defer to the widget's default.
          }),
        ),
        onPressed: onPressed,
        //  icon: icon,
        child: Padding(
          padding:
          callFromLogin==true?
            EdgeInsets.symmetric( horizontal:kIsWeb? mediaQuery.width*0.045:mediaQuery.width*0.15 ):const EdgeInsets.symmetric( horizontal: 0),
          child: Row(
//mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // callFromLogin==true?SizedBox(
              //  // width:kIsWeb? mediaQuery.width*0.06:mediaQuery.width*0.2,
              // ):
              // SizedBox(),
              image != null
                  ? Padding(
                    padding: const EdgeInsets.all(kIsWeb?8 :5),
                    child: Image(
                        image: AssetImage(image),
                        height: 35,
                        width: 35,
                color:id==0? Colors.white:null,
                      ),
                  )
                  : SizedBox(
                      width: id == 1 ? 35 : 0,
                    ),
              SizedBox(
                width: 5,
              ),
              Text(
                buttonText,
                style: TextStyle(
                    color: id == 1 ? Colors.black : Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
