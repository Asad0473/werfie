import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/controller/guest_user_controller.dart';

import '../../../models/post.dart';
import '../../../utils/font.dart';

// ignore: non_constant_identifier_names

Widget GuestUserRichTextView(
  BuildContext context,
  String text,
  bool readMore,
  GuestUserController controller,
  id,
  Color commentColor,
  Post post, {
  final shouldGiveFixedHeight = false,
  bool showMomentScreen = false,
  bool editMomentScreen = false,
  String position,
}) {
  final mediaQueryData = MediaQuery.of(context);

  final scale = mediaQueryData.textScaleFactor.clamp(1.0, 1.5);
  return Container(
    width: MediaQuery.of(context).size.width >= 720
        ? kIsWeb
            ? 420
            : 260
        : kIsWeb
            ? Get.width / 1.7
            : 260,
    //shouldGiveFixedHeight ? Get.width / 1.5 : double.infinity,
    // alignment:

    //controller.languageData.myLang.code == "ar" || controller.languageData.myLang.code == "hi" && controller.languageData.autoTranslateSettings.autoTranslate == 1
    // position =="ltr" ? Alignment.centerLeft:

    // Alignment.centerRight
    // ,
    child: ScrollConfiguration(
      behavior: ScrollConfiguration.of(context).copyWith(
        scrollbars: false,
        physics: NeverScrollableScrollPhysics(),
      ),
      child: SelectableText.rich(
        TextSpan(
          // style: Theme.of(context).textTheme.headline3,
          children:
              medthodToGetString(text, controller, context, id, commentColor)
                  .map(
                    (data) => data.callback == null
                        ? TextSpan(
                            text: data.text,
                            // locale: Locale(controller.languageData.myLang.code),
                            style: data.style,
                          )
                        : TextSpan(
                            text: data.text,
                            style: data.style,
                            recognizer: TapGestureRecognizer()
                              ..onTap = () {
                                data.callback(context, data.text, post);
                              },
                          ),
                  )
                  .toList(),
        ),

        showCursor: false,
        textScaleFactor: scale,
        /* textAlign:
        controller.languageData.myLang.code == "ar" || controller.languageData.myLang.code == "hi" && controller.languageData.autoTranslateSettings.autoTranslate == 1
            ? TextAlign.right
            : TextAlign.left,*/
        // maxLines: readMore ? 7: 2,
        scrollPhysics: NeverScrollableScrollPhysics(),
        toolbarOptions: ToolbarOptions(
          copy: true,
        ),
      ),
    ),
  );
}

List<MyText> medthodToGetString(String str, GuestUserController controller,
    BuildContext context, id, Color commentColor) {
  List<MyText> textSpanList = [];
  List<String> divString = str.split(' ');

  divString.forEach((element) {
    if (element.contains('#')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            fontWeight: FontWeight.w500,
            color: Colors.blue,
          ),
          callback: (context, string, post) async {},
        ),
      );
    } else if (element.contains('\$')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            fontWeight: FontWeight.w500,
            color: Colors.blue,
          ),
          callback: (context, string, post) async {
            // Get.find<NewsfeedController>().isSearch = true;
            try {} catch (_) {}
          },
        ),
      );
    } else if (element.contains('@')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            fontWeight: FontWeight.w500,
            color: Colors.blue,
          ),
          callback: (context, string, post) async {
            try {
              // print('String' + string);
            } catch (_) {
              // print('IN CATCH');
            }
          },
        ),
      );
    } else if (element.contains('.com') ||
        element.contains('https') ||
        element.contains('http')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            fontWeight: FontWeight.w500,
            color: Colors.blue,
          ),
          callback: (context, string, post) async {
            // print("stringsdsada $string");
            if (await canLaunchUrl(Uri.parse(string))) {
              // print("launch");
              // print(string);
              // print("launch");
              if (await canLaunchUrl(Uri.parse(string.trim()))) {
                await launchUrl(
                    Uri.parse(
                      string.trim(),
                    ),
                    mode: LaunchMode.externalApplication);
              }
              // await launchUrl(Uri.parse(string.trim(),),
              // );
            } else {
              // print("not launch");
              // print(string);
              // print("not launch");
              await launchUrl(
                Uri.parse(
                  'https://www.${string.trim()}',
                ),
              );
            }
          },
        ),
      );
    } else {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            fontWeight: FontWeight.w400,
            color: commentColor,
          ),
          callback: (context, string, post) {},
        ),
      );
    }
  });
  return textSpanList;
}

class MyText {
  final String text;
  final TextStyle style;
  final void Function(BuildContext, String, Post) callback;

  MyText({
    this.text,
    this.style,
    this.callback,
  });
}
