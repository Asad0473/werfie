import 'package:flutter/material.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/guest_user_controller.dart';

import 'guest_user_richText.dart';

class GuestUserPostTextDescription extends StatefulWidget {
  GuestUserPostTextDescription({
    Key key,
    @required this.post,
    this.isCommentScreen = false,
    this.controller,
    this.showMomentScreen,
    this.editMomentScreen,
    this.translationCheck,
    // this.translationData
  }) : super(key: key);

  final Post post;
  final bool isCommentScreen;
  final GuestUserController controller;
  bool showMomentScreen = false;
  bool editMomentScreen = false;

  // TranslationData translationData;

  bool translationCheck;

  @override
  _GuestUserPostTextDescriptionState createState() =>
      _GuestUserPostTextDescriptionState();
}

class _GuestUserPostTextDescriptionState
    extends State<GuestUserPostTextDescription> {
  List<String> str = [];
  bool _readMore = false;

  @override
  Widget build(BuildContext context) {
    // print("translationCheck guest user  ${widget.translationCheck}");

    return Align(
      alignment: Alignment.topLeft,
      child: GuestUserRichTextView(
          context,
          widget.post.body,
          _readMore,
          widget.controller,
          widget.post.authorId,
          Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Colors.black,
          widget.post,
          //  position:widget.translationCheck == false?"ltr":widget.translationData!=null? widget.translationData.data[0].languageDirection:"ltr",

          shouldGiveFixedHeight: true),
    );
  }
}
