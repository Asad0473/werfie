
import 'package:flutter_svg/svg.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/utils_methods.dart';
import 'package:werfieapp/widgets/blue_tick.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/new_login_form.dart';
import 'package:werfieapp/widgets/chewie_videoplayer.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:get_storage/get_storage.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/models/post.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../network/controller/guest_user_controller.dart';
import '../../../network/controller/login_controller.dart';
import '../../../utils/asset_string.dart';
import '../../../utils/colors.dart';
import '../../../utils/font.dart';
import '../../../widgets/login_form.dart';
import 'guest_user_carousel.dart';
import 'guest_user_text_description.dart';

// ignore: must_be_immutable
class EscIntent extends Intent {}


final userData = GetStorage();


class GuestUserPostCard extends StatefulWidget {
  final Post post;
  final int index;
  List<Post> postList;
  final GlobalKey<ScaffoldState> scaffoldKey;
  final GuestUserController controller;
  final int savedItemId;
  bool userProfileCheck = false;
  int deletePostId;
  bool saveCard = false;



  GuestUserPostCard({
    @required this.post,
    this.scaffoldKey,
    @required this.index,

    @required this.controller,

    this.savedItemId,
    this.userProfileCheck,
    this.postList,
    this.deletePostId,
    this.saveCard,

  });

  @override
  State<GuestUserPostCard> createState() => _GuestUserPostCardState();
}

class _GuestUserPostCardState extends State<GuestUserPostCard> {
  var isCommentField = false;
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  var isRetweetSuccess = false;

  RxString reactionName = "".obs;

  final GlobalKey<ScaffoldState> _scaffoldKey =  GlobalKey<ScaffoldState>();

  String link, linkTitle, linkMeta, linkImage;

  @override
  Widget build(BuildContext context) {
    String getDate;

    if (widget.post.postedOn != null) {
      getDate = UtilsMethods.getDate(widget.post.postedOn);
    }


    var screenHeight = MediaQuery
        .of(context)
        .size
        .height;
    var screenWidth = MediaQuery
        .of(context)
        .size
        .width;
    var containerSizeForImage = Get.width / 3;
    return Material(
      color: Theme
          .of(context)
          .scaffoldBackgroundColor,
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          onTap: () {

          },

          child: ListTile(
            mouseCursor: MouseCursor.defer,
            dense: true,
            // tileColor: Colors.yellow,
            minVerticalPadding: 0.00,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 5,
              //  vertical: 8,
            ),
            title: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [

                MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                //PROFILE IMAGE
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10.00),
                                  child: MouseRegion(
                                    cursor: SystemMouseCursors.click,
                                    child: GestureDetector(
                                      onTap: () async {

                                      },
                                      child: CircleAvatar(
                                        backgroundImage: widget.post
                                            .profileImage != null
                                            ? NetworkImage(
                                            widget.post.profileImage)
                                            : const AssetImage(
                                            "assets/images/person_placeholder.png"),
                                        radius: 22,
                                      ),
                                    ),
                                  ),
                                ),

                                const SizedBox(width: 5),


                                //USERNAME AND POST TIME
                                Padding(
                                  padding: const EdgeInsets.only(
                                    top: 6.0,
                                    // bottom: kIsWeb ? 0 :8.0,
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    mainAxisAlignment: MainAxisAlignment
                                        .start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      MouseRegion(
                                        cursor: SystemMouseCursors
                                            .click,
                                        child: GestureDetector(
                                          onTap: () async {


                                          },
                                          child: Row(
                                            children: [

                                              ///bluetick
                                              Row(
                                                children: [

                                                  SizedBox(
                                                    width: MediaQuery
                                                        .of(context)
                                                        .size
                                                        .width <= 700 ? widget.post
                                                        .authorName.length >
                                                        15 ? kIsWeb
                                                        ? 180
                                                        : 120 : null : null,
                                                    child: Text(
                                                      widget.post.authorName,
                                                      maxLines: 1,
                                                      overflow: TextOverflow
                                                          .ellipsis,
                                                      style: TextStyle(
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness
                                                                .dark
                                                            ? Colors
                                                            .white
                                                            : Colors
                                                            .black,
                                                        fontWeight: FontWeight
                                                            .bold,
                                                        fontSize: kIsWeb
                                                            ? 18
                                                            : 12,
                                                      ),
                                                    ),
                                                  ),
                                                  widget.post.userInfo
                                                      .accountVerified ==
                                                      "verified" ?
                                                  Row(children: [
                                                    // SizedBox(
                                                    //   width: 5,
                                                    // ),
                                                    BlueTick(
                                                      height: 15,
                                                      width: 15,
                                                      iconSize: 10,
                                                    ),
                                                  ],)
                                                      : const SizedBox(),
                                                  const SizedBox(
                                                    width: 5,
                                                  ),
                                                  Row(
                                                    children: [
                                                      SizedBox(
                                                        width: MediaQuery
                                                            .of(context)
                                                            .size
                                                            .width > 700
                                                            ? null
                                                            : 80,
                                                        child: Text(
                                                          '@${widget.post.username}',
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 15
                                                                : 13,
                                                          ),
                                                          maxLines: 1,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                        ),
                                                      ),

                                                    ],
                                                  ),
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .only(
                                                        bottom: 10,
                                                        left: 2),
                                                    child: Text(
                                                      ".",
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline2
                                                          .copyWith(
                                                        fontSize: 20,
                                                        fontWeight: FontWeight
                                                            .w500,
                                                      ),
                                                    ),
                                                  ),
                                                  Text(getDate ?? '',
                                                    style: Styles
                                                        .baseTextTheme
                                                        .headline2
                                                        .copyWith(
                                                      fontSize: kIsWeb
                                                          ? 15
                                                          : 13,
                                                    ),
                                                  ),

                                                ],
                                              ),


                                            ],
                                          ),
                                        ),
                                      ),
                                      // SizedBox(height: kIsWeb ? 0 : 5),
                                      kIsWeb && widget.post.body.length > 0 ?
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: GuestUserPostTextDescription(
                                          post: widget.post,
                                          controller: widget.controller,

                                        ),
                                      )
                                          : const SizedBox(),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                    ],
                  ),
                ),
                MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: Padding(
                    padding: const EdgeInsets.only(
                      top: 0.0,
                      left: 50,
                      //right: kIsWeb ? 20: Get.width / 55
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        widget.post.body != null
                            ? widget.post.link != null
                            ? GestureDetector(
                          onTap: () async {
                            if (await canLaunchUrl(
                                Uri.parse(widget.post.link.toString()))) {
                              await launchUrl(
                                  Uri.parse(widget.post.link.trim()));
                            }
                            else {
                              await launchUrl(Uri.parse(
                                  'https://${widget.post.link.trim()}'));
                            }
                          },
                          child: Card(
                            elevation: 2,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Column(
                              children: [
                                Container(

                                  height: kIsWeb
                                      ? Get.height / 2.1
                                      : Get.height / 4.5,
                                  width: Get.width,

                                  // color: Colors.black,
                                  decoration: BoxDecoration(
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(15),
                                      topRight: Radius.circular(15),),
                                    color: Colors.black,
                                    // borderRadius: BorderRadius.circular(20),
                                    image: DecorationImage(
                                        image: widget.post.linkImage != null
                                            ? NetworkImage(widget.post
                                            .linkImage
                                            .toString())
                                            : const AssetImage(
                                            "assets/images/no_image.jpeg"),
                                        fit: BoxFit.contain),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    top: 0,
                                    left: 20,
                                    right: 20,
                                  ),
                                  child:

                                  widget.post.linkTitle != null ?
                                  Text(widget.post.linkTitle.toString(),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    style: TextStyle(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontFamily: 'Cairo',
                                      fontSize: kIsWeb ? 18 : 17,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ) : const SizedBox(),
                                ),
                                widget.post.linkMeta == null
                                    ? const SizedBox()
                                    : Padding(
                                  padding: const EdgeInsets.only(
                                      top: 0,
                                      left: 20,
                                      right: 20),
                                  child: Text(
                                    widget.post.linkMeta.toString(),
                                    maxLines: 1,
                                    overflow:
                                    TextOverflow.ellipsis,
                                    style:
                                    TextStyle(color: Theme
                                        .of(context)
                                        .brightness == Brightness.dark
                                        ? Colors.white
                                        : const Color(0xff536471),
                                      fontFamily: 'Cairo',
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 0,
                                      left: 20,
                                      right: 20,
                                      bottom: 10),
                                  child: Text(widget.post.link.toString(),
                                    textAlign: TextAlign.left,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style:
                                    TextStyle(color: Theme
                                        .of(context)
                                        .brightness == Brightness.dark
                                        ? Colors.white
                                        : const Color(0xff536471),
                                      fontFamily: 'Cairo',
                                      fontSize: 15,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                            : const SizedBox()
                            : const SizedBox(),
                        widget.post.type == 'poll'
                            ? Container()
                            : const SizedBox(),
                        widget.post.postType == 'image' &&
                            widget.post.postFiles.length > 0
                            ? ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: InkWell(
                            onTap: () {
                              widget.controller.mapToList(widget.post);
                              showDialog(

                                context: context,
                                builder: (BuildContext context) {
                                  return Shortcuts(
                                    shortcuts: {
                                      LogicalKeySet(LogicalKeyboardKey
                                          .escape): EscIntent()
                                    },
                                    child: GuestUserNewsFeedCarousel(
                                      imagesListForCarousel: widget.controller
                                          .imagesListForCarousel,
                                      mediaIndex: 0,
                                      controller: widget.controller,
                                      post: widget.post,
                                    ),
                                  );
                                },
                              );
                            },
                            child: kIsWeb
                                ? ClipRRect(
                                borderRadius: BorderRadius.circular(15),
                                child: ConstrainedBox(
                                  constraints: BoxConstraints(
                                    maxWidth: Get.width,
                                    maxHeight: 650,
                                    minHeight: 284,
                                    minWidth: 384,
                                  ),
                                  child: Image.network(
                                    widget.post.postFiles[0]['file_path'],
                                    // height: kIsWeb ? 480 : 240,
                                    fit: BoxFit.cover,
                                    // width: Get.width,
                                    errorBuilder: (BuildContext context,
                                        Object exception,
                                        StackTrace stackTrace) {
                                      return const Icon(Icons.error,
                                          size: 40);
                                    },
                                  ),
                                )
                            )
                                : ClipRRect(
                              borderRadius: BorderRadius.circular(15),
                              child: ConstrainedBox(
                                constraints: BoxConstraints(
                                  maxHeight: 500,
                                  maxWidth: Get.width,
                                  minHeight: 200,
                                  minWidth: Get.width,
                                ),
                                child: Image.network(
                                  widget.post.postFiles[0]['file_path'],
                                  // height: kIsWeb ? 480 : 240,
                                  fit: BoxFit.cover,
                                  // width: Get.width,
                                  errorBuilder: (BuildContext context,
                                      Object exception,
                                      StackTrace stackTrace) {
                                    return const Icon(Icons.error,
                                        size: 40);
                                  },
                                ),
                              ),
                            ),

                          ),
                        )
                            : widget.post.postType == 'gallery' &&
                            widget.post.postFiles.length == 2 &&
                            widget.post.postFiles[0]['file_type'] == 'image'
                            ? StaggeredGridView.countBuilder(
                            crossAxisCount: 2,
                            crossAxisSpacing: 3,
                            mainAxisSpacing: 3,
                            shrinkWrap: true,
                            physics: const ScrollPhysics(),
                            itemCount: widget.post.postFiles.length,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  widget.controller.mapToList(widget.post);
                                  showDialog(
                                    // barrierDismissible: false,
                                    context: context,
                                    builder: (BuildContext context) {
                                      return Shortcuts(
                                        shortcuts: {
                                          LogicalKeySet(LogicalKeyboardKey
                                              .escape): EscIntent(),
                                        },
                                        child: GuestUserNewsFeedCarousel(
                                          imagesListForCarousel: widget.controller
                                              .imagesListForCarousel,
                                          mediaIndex: index,
                                          controller: widget.controller,
                                          post: widget.post,
                                        ),
                                      );
                                    },
                                  );
                                },
                                child: Container(
                                  height: kIsWeb ? 480 : 240,
                                  decoration: const BoxDecoration(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(15))),
                                  child: ClipRRect(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(15)),
                                    child: Image.network(
                                      widget.post.postFiles[index]['file_path'],
                                      fit: BoxFit.cover,
                                      height: kIsWeb ? 480 : 240,

                                    ),
                                  ),
                                ),
                              );
                            },
                            staggeredTileBuilder: (index) {
                              return StaggeredTile.count(
                                  1, index.isEven ? 1 : 1);
                            })
                            : widget.post.postType == 'gallery' &&
                            widget.post.postFiles.length == 3 &&
                            widget.post.postFiles[0]['file_type'] == 'image'
                            ? StaggeredGridView.countBuilder(
                            crossAxisCount: 2,
                            crossAxisSpacing: 3,
                            mainAxisSpacing: 3,
                            shrinkWrap: true,
                            physics: const ScrollPhysics(),
                            itemCount: widget.post.postFiles.length,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  widget.controller.mapToList(widget.post);
                                  showDialog(
                                    // barrierDismissible: false,
                                    context: context,
                                    builder: (BuildContext context) {
                                      return Shortcuts(
                                        shortcuts: {
                                          LogicalKeySet(LogicalKeyboardKey
                                              .escape): EscIntent(),
                                        },
                                        child: GuestUserNewsFeedCarousel(
                                          imagesListForCarousel:
                                          widget.controller
                                              .imagesListForCarousel,
                                          mediaIndex: index,
                                          controller: widget.controller,
                                          post: widget.post,
                                        ),
                                      );
                                    },
                                  );
                                },
                                child: Container(
                                  decoration: const BoxDecoration(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(15))),
                                  child: ClipRRect(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(15)),
                                    child: Image.network(
                                      widget.post.postFiles[index]
                                      ['file_path'],
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              );
                            },
                            staggeredTileBuilder: (index) {
                              return StaggeredTile.count(
                                  1, index == 0 ? 1 : 0.5);
                            })
                            : widget.post.postType == 'gallery' &&
                            widget.post.postFiles.length == 4 &&
                            widget.post.postFiles[0]['file_type'] == 'image'
                            ? StaggeredGridView.countBuilder(
                            crossAxisCount: 2,
                            crossAxisSpacing: 3,
                            mainAxisSpacing: 3,
                            shrinkWrap: true,
                            physics: const ScrollPhysics(),
                            itemCount: widget.post.postFiles.length,
                            itemBuilder: (context, index) {
                              return InkWell(
                                onTap: () {
                                  widget.controller.mapToList(widget.post);
                                  showDialog(
                                    // barrierDismissible: false,
                                    context: context,
                                    builder:
                                        (BuildContext context) {
                                      return Shortcuts(
                                        shortcuts: {
                                          LogicalKeySet(LogicalKeyboardKey
                                              .escape): EscIntent()
                                        },
                                        child: GuestUserNewsFeedCarousel(
                                          imagesListForCarousel:
                                          widget.controller
                                              .imagesListForCarousel,
                                          mediaIndex: index,
                                          controller: widget.controller,
                                          post: widget.post,
                                        ),
                                      );
                                    },
                                  );
                                },
                                child: Container(
                                  decoration: const BoxDecoration(
                                      color: Colors.transparent,
                                      borderRadius:
                                      BorderRadius.all(
                                          Radius.circular(
                                              15))),
                                  child: ClipRRect(
                                    borderRadius:
                                    const BorderRadius.all(
                                        Radius.circular(15)),
                                    child: Image.network(
                                      widget.post.postFiles[index]
                                      ['file_path'],
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              );
                            },
                            staggeredTileBuilder: (index) {
                              return StaggeredTile.count(
                                  1, index.isEven ? 0.6 : 0.6);
                            })
                            : widget.post.postType == 'gallery' &&
                            widget.post.postFiles.length > 4 &&
                            widget.post.postFiles[0]['file_type'] ==
                                'image'
                            ? StaggeredGridView.countBuilder(
                            crossAxisCount: 2,
                            crossAxisSpacing: 3,
                            mainAxisSpacing: 3,
                            shrinkWrap: true,
                            physics: const ScrollPhysics(),
                            itemCount:
                            widget.post.postFiles.length >= 5
                                ? 4
                                : widget.post.postFiles.length,
                            itemBuilder: (context, index) {
                              return widget.post.postFiles.length >= 5 &&
                                  index == 3
                                  ? InkWell(
                                onTap: () {
                                  widget.controller
                                      .mapToList(widget.post);
                                  showDialog(
                                    // barrierDismissible:false,
                                    context: context,
                                    builder:
                                        (BuildContext
                                    context) {
                                      return Shortcuts(
                                        shortcuts: {
                                          LogicalKeySet(LogicalKeyboardKey
                                              .escape): EscIntent()
                                        },
                                        child: GuestUserNewsFeedCarousel(
                                          imagesListForCarousel:
                                          widget.controller.imagesListForCarousel,
                                          mediaIndex:
                                          index,
                                          controller:
                                          widget.controller,
                                          post: widget.post,
                                        ),
                                      );
                                    },
                                  );
                                },
                                child: Container(
                                  decoration: const BoxDecoration(
                                      color: Colors
                                          .transparent,
                                      borderRadius: BorderRadius
                                          .all(Radius
                                          .circular(
                                          15))),
                                  child: ClipRRect(
                                    borderRadius:
                                    const BorderRadius
                                        .all(Radius
                                        .circular(
                                        15)),
                                    child: Stack(
                                      fit: StackFit
                                          .expand,
                                      children: [
                                        Image.network(
                                          widget.post.postFiles[
                                          index]
                                          [
                                          'file_path'],
                                          fit: BoxFit
                                              .cover,
                                        ),
                                        if (widget.post.postFiles
                                            .length >=
                                            5)
                                          Container(
                                            color: Colors
                                                .black38,
                                          ),
                                        if (widget.post.postFiles
                                            .length >=
                                            5)
                                          Align(
                                            alignment:
                                            Alignment
                                                .center,
                                            child: Text(
                                              '+${widget.post.postFiles.length -
                                                  4}',
                                              // style: Theme
                                              //     .of(
                                              //     context)
                                              //     .textTheme
                                              //     .headline3
                                              //     .copyWith(
                                              //   color:
                                              //   Colors.white,
                                              //   fontSize:
                                              //   24,
                                              // ),
                                              style:
                                              TextStyle(
                                                color: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 24,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                                  : InkWell(
                                onTap: () {
                                  widget.controller
                                      .mapToList(widget.post);
                                  showDialog(
                                    // barrierDismissible: false,
                                    context: context,
                                    builder:
                                        (BuildContext
                                    context) {
                                      return Shortcuts(
                                        shortcuts: {
                                          LogicalKeySet(LogicalKeyboardKey
                                              .escape): EscIntent()
                                        },
                                        child: Shortcuts(
                                          shortcuts: {
                                            LogicalKeySet(
                                                LogicalKeyboardKey
                                                    .escape): EscIntent()
                                          },
                                          child: GuestUserNewsFeedCarousel(
                                            imagesListForCarousel:
                                            widget.controller.imagesListForCarousel,
                                            mediaIndex:
                                            index,
                                            controller: widget.controller,
                                            post: widget.post,
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                },
                                child: Container(
                                  decoration: const BoxDecoration(
                                      color: Colors
                                          .transparent,
                                      borderRadius: BorderRadius
                                          .all(Radius
                                          .circular(
                                          15))),
                                  child: ClipRRect(
                                    borderRadius:
                                    const BorderRadius
                                        .all(Radius
                                        .circular(
                                        8)),
                                    child:
                                    Image.network(
                                      widget.post.postFiles[
                                      index]
                                      ['file_path'],
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              );
                            },
                            staggeredTileBuilder: (index) {
                              return StaggeredTile.count(1,
                                  index.isEven ? 0.6 : 0.6);
                            })


                            : widget.post.postType == 'video' &&
                            widget.post.postFiles.length == 1 ? kIsWeb

                        /// for web
                            ? ChewieVideoPlayer( //1
                          post: widget.post,
                          index: 0,
                          thumbnailUrl: widget.post.postFiles[0]['thumbnail_path'] ?? 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                          playPressed: () {
                            // print("playpressed");
                          },
                        )
                            : ChewieVideoPlayer(
                            thumbnailUrl: widget.post
                                .postFiles[0]['thumbnail_path'] ?? 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                            isFullScreenOnMobile: true,
                            allowFullScreen: false,
                            borderRadius: 0,
                            // aspectRatio:
                            //     4 / 3,
                            post: widget.post,
                            index: 0)
                            : widget.post.postType ==
                            'attachment' &&
                            widget.post.postFiles
                                .length ==
                                1
                            ? ListTile(
                          onTap: () {
                            launch(widget.post
                                .postFiles[0]
                            [
                            'file_path']);
                          },
                          shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius
                                  .circular(
                                  12)),
                          tileColor: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.black
                              : Colors.white
                          ,
                          leading: SizedBox(
                            height: 28,
                            width: 28,
                            child: Image.asset(
                                'assets/images/document.png'),
                          ),
                          title: Text(
                            "${widget.post.postFiles[0]['original_name']}",
                            style: TextStyle(
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark ? Colors
                                  .white : Colors.black,
                              fontSize: 14,
                            ),
                          ),
                        )
                            : widget.post.postType ==
                            'gallery' &&
                            widget.post.postFiles
                                .length >
                                1 &&
                            widget.post.postFiles[0]
                            ['file_type'] ==
                                'attachment'
                            ? Column(
                          children: [
                            for (var i =
                            0;
                            i < widget.post.postFiles.length;
                            i++)
                              Padding(
                                padding:
                                const EdgeInsets.symmetric(vertical: 4.0),
                                child:
                                ListTile(
                                  onTap:
                                      () {
                                    launch(
                                        widget.post.postFiles[i]['file_path']);
                                  },
                                  shape:
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          12)),
                                  tileColor:
                                  Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors
                                      .black
                                      : Colors.white
                                  ,
                                  leading: SizedBox(
                                      height: 28,
                                      width: 28,
                                      child: Image.asset(
                                          'assets/images/document.png')),
                                  title:
                                  Text(
                                    "${widget.post
                                        .postFiles[i]['original_name']}",
                                    style:
                                    TextStyle(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        )
                            : Container(),
                        const SizedBox(
                          height: 8.0,
                        ),

                        ///quote werf
                        widget.post.type == 'quote' && widget.post.quoteInfo != null
                            ? InkWell(
                          onTap: () {

                          },
                          child: Container(
                            // width: 610,
                            // padding: EdgeInsets.only(
                            //   left: 12,
                            //   right: 16,
                            //   bottom: 8,
                            //   top: 2,
                            // ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(
                                color: Colors.grey[300],
                              ),
                            ),
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 10, right: 5),
                                  child: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding:
                                        const EdgeInsets.only(
                                            top: 10.00),
                                        child: CircleAvatar(
                                          backgroundImage: widget.post
                                              .quoteInfo
                                              .profileImage !=
                                              null
                                              ? NetworkImage(widget.post
                                              .quoteInfo
                                              .profileImage)
                                              : const AssetImage(
                                              "assets/images/person_placeholder.png"),
                                          radius: 22,
                                        ),
                                      ),
                                      const SizedBox(width: 5),

                                      //USERNAME AND POST TIME
                                      Padding(
                                        padding:
                                        const EdgeInsets.only(
                                            top: 10.0),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,

                                          children: [
                                            Row(
                                              children: [
                                                Text(
                                                  widget.post.quoteInfo
                                                      .authorName,
                                                  // style: Theme
                                                  //     .of(
                                                  //     context)
                                                  //     .textTheme
                                                  //     .headline3,
                                                  style: TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness
                                                            .dark
                                                        ? Colors
                                                        .white
                                                        : Colors
                                                        .black,
                                                    fontWeight: FontWeight
                                                        .bold,
                                                    fontSize: kIsWeb
                                                        ? 18
                                                        : 16,
                                                  ),
                                                ),
                                                const SizedBox(
                                                  width: 5,),
                                                SizedBox(
                                                  width: kIsWeb
                                                      ? MediaQuery
                                                      .of(context)
                                                      .size
                                                      .width > 600
                                                      ? null
                                                      : 70
                                                      : 60,
                                                  child: Text(
                                                    '@${widget.post
                                                        .quoteInfo
                                                        .username}',
                                                    // style: Theme
                                                    //     .of(context)
                                                    //     .textTheme
                                                    //     .bodyText2
                                                    //     .copyWith(
                                                    //     height: 1.2),
                                                    style: Styles
                                                        .baseTextTheme
                                                        .headline2
                                                        .copyWith(
                                                      fontSize: kIsWeb
                                                          ? 14
                                                          : 13,
                                                    ),
                                                    softWrap: false,
                                                    maxLines: 1,
                                                    overflow: TextOverflow
                                                        .ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            // SizedBox(height: 10),
                                            widget.post.quoteInfo.body.length > 0
                                                ? SizedBox(
                                              width: kIsWeb ? MediaQuery
                                                  .of(context)
                                                  .size
                                                  .width >= 720 ? 420 : Get
                                                  .width / 1.9 : 250,
                                              child: Text(
                                                widget.post.quoteInfo.body,
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                ),
                                              ),
                                            )
                                                : const SizedBox(),
                                          ],
                                        ),
                                      ),
                                      // POPUP MENU BUTTON
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 5),

                                widget.post.quoteInfo.postType == 'image' &&
                                    widget.post.quoteInfo.postFiles.length > 0
                                    ? ClipRRect(
                                  borderRadius:
                                  const BorderRadius.only(
                                      bottomLeft: Radius.circular(15),
                                      bottomRight: Radius.circular(15)),
                                  child: kIsWeb
                                      ? ConstrainedBox(
                                    constraints: BoxConstraints(
                                      maxWidth: Get.width,
                                      maxHeight: 650,
                                      minHeight: 284,
                                      minWidth: 384,
                                    ),
                                    child: Image.network(
                                      widget.post.quoteInfo
                                          .postFiles[0]
                                      ['file_path'],
                                      // height: kIsWeb ? 480 : 240,
                                      fit: BoxFit.cover,
                                      // width: Get.width,
                                      errorBuilder: (BuildContext context,
                                          Object exception,
                                          StackTrace stackTrace) {
                                        return const Icon(Icons.error,
                                            size: 40);
                                      },
                                    ),
                                  )

                                      : ConstrainedBox(
                                    constraints: BoxConstraints(
                                      maxHeight: 500,
                                      maxWidth: Get.width,
                                      minHeight: 200,
                                      minWidth: Get.width,
                                    ),
                                    child: Image.network(
                                      widget.post.quoteInfo
                                          .postFiles[0]
                                      ['file_path'],
                                      // height: kIsWeb ? 480 : 240,
                                      fit: BoxFit.cover,
                                      // width: Get.width,
                                      errorBuilder: (BuildContext context,
                                          Object exception,
                                          StackTrace stackTrace) {
                                        return const Icon(Icons.error,
                                            size: 40);
                                      },
                                    ),
                                  ),

                                )
                                    : widget.post.quoteInfo.postType ==
                                    'gallery' &&
                                    widget.post.quoteInfo.postFiles.length ==
                                        2 &&
                                    widget.post.quoteInfo.postFiles[0]
                                    ['file_type'] ==
                                        'image'
                                    ? StaggeredGridView.countBuilder(
                                    crossAxisCount: 2,
                                    crossAxisSpacing: 3,
                                    mainAxisSpacing: 3,
                                    shrinkWrap: true,
                                    physics: ScrollPhysics(),
                                    itemCount: widget.post
                                        .quoteInfo.postFiles.length,
                                    itemBuilder: (context, index) {
                                      return Container(
                                        height: 480,
                                        decoration: const BoxDecoration(
                                            color:
                                            Colors.transparent,
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(
                                                    15))),
                                        child: ClipRRect(
                                          borderRadius:
                                          const BorderRadius.all(
                                              Radius.circular(
                                                  15)),
                                          child: Image.network(
                                            widget.post.quoteInfo
                                                .postFiles[
                                            index]['file_path'],
                                            fit: BoxFit.cover,
                                            height: 480,
                                          ),
                                        ),
                                      );
                                    },
                                    staggeredTileBuilder: (index) {
                                      return StaggeredTile.count(
                                          1, index.isEven ? 1 : 1);
                                    })
                                    : widget.post.quoteInfo.postType ==
                                    'gallery' &&
                                    widget.post.quoteInfo.postFiles.length ==
                                        3 &&
                                    widget.post.quoteInfo.postFiles[0]
                                    ['file_type'] ==
                                        'image'
                                    ? StaggeredGridView
                                    .countBuilder(
                                  crossAxisCount: 2,
                                  crossAxisSpacing: 3,
                                  mainAxisSpacing: 3,
                                  shrinkWrap: true,
                                  physics: const ScrollPhysics(),
                                  itemCount: widget.post.quoteInfo
                                      .postFiles.length,
                                  itemBuilder:
                                      (context, index) {
                                    return Container(
                                      decoration: const BoxDecoration(
                                          color: Colors
                                              .transparent,
                                          borderRadius:
                                          BorderRadius
                                              .all(Radius
                                              .circular(
                                              15))),
                                      child: ClipRRect(
                                        borderRadius:
                                        const BorderRadius.all(
                                            Radius
                                                .circular(
                                                15)),
                                        child: Image.network(
                                          widget.post.quoteInfo
                                              .postFiles[
                                          index]
                                          ['file_path'],
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    );
                                  },
                                  staggeredTileBuilder:
                                      (index) {
                                    return StaggeredTile
                                        .count(
                                        1,
                                        index == 0
                                            ? 1
                                            : 0.5);
                                  },
                                )
                                    : widget.post.quoteInfo.postType ==
                                    'gallery' &&
                                    widget.post.quoteInfo.postFiles
                                        .length ==
                                        4 &&
                                    widget.post.quoteInfo
                                        .postFiles[0]
                                    ['file_type'] ==
                                        'image'
                                    ? StaggeredGridView.countBuilder(
                                  crossAxisCount: 2,
                                  crossAxisSpacing: 3,
                                  mainAxisSpacing: 3,
                                  shrinkWrap: true,
                                  physics:
                                  const ScrollPhysics(),
                                  itemCount: widget.post
                                      .quoteInfo
                                      .postFiles
                                      .length,
                                  itemBuilder:
                                      (context, index) {
                                    return Container(
                                      decoration: const BoxDecoration(
                                          color: Colors
                                              .transparent,
                                          borderRadius: BorderRadius
                                              .all(Radius
                                              .circular(
                                              15))),
                                      child: ClipRRect(
                                        borderRadius: const BorderRadius
                                            .all(Radius
                                            .circular(
                                            15)),
                                        child:
                                        Image.network(
                                          widget.post.quoteInfo
                                              .postFiles[
                                          index][
                                          'file_path'],
                                          fit: BoxFit
                                              .cover,
                                        ),
                                      ),
                                    );
                                  },
                                  staggeredTileBuilder:
                                      (index) {
                                    return StaggeredTile
                                        .count(
                                        1,
                                        index.isEven
                                            ? 0.6
                                            : 0.6);
                                  },
                                )
                                    : widget.post.quoteInfo.postType ==
                                    'gallery' &&
                                    widget.post.quoteInfo.postFiles.length > 4 &&
                                    widget.post.quoteInfo
                                        .postFiles[0]['file_type'] ==
                                        'image'
                                    ? StaggeredGridView.countBuilder(
                                    crossAxisCount: 2,
                                    crossAxisSpacing: 3,
                                    mainAxisSpacing: 3,
                                    shrinkWrap: true,
                                    physics: const ScrollPhysics(),
                                    itemCount: widget.post.quoteInfo.postFiles
                                        .length >= 5 ? 4 : widget.post.quoteInfo
                                        .postFiles.length,
                                    itemBuilder: (context, index) {
                                      return widget.post.quoteInfo.postFiles
                                          .length >=
                                          5 &&
                                          index == 3
                                          ? Container(
                                        decoration: const BoxDecoration(
                                            color: Colors
                                                .transparent,
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(15))),
                                        child:
                                        ClipRRect(
                                          borderRadius:
                                          const BorderRadius.all(
                                              Radius.circular(15)),
                                          child: Image
                                              .network(
                                            widget.post.quoteInfo
                                                .postFiles[index]
                                            [
                                            'file_path'],
                                            fit: BoxFit
                                                .cover,
                                          ),
                                        ),
                                      )
                                          : Container(
                                        decoration: const BoxDecoration(
                                            color: Colors
                                                .transparent,
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(15))),
                                        child:
                                        ClipRRect(
                                          borderRadius:
                                          const BorderRadius.all(
                                              Radius.circular(15)),
                                          child: Image
                                              .network(
                                            widget.post.quoteInfo
                                                .postFiles[index]
                                            [
                                            'file_path'],
                                            fit: BoxFit
                                                .cover,
                                          ),
                                        ),
                                      );
                                    },
                                    staggeredTileBuilder: (index) {
                                      return StaggeredTile
                                          .count(
                                          1,
                                          index.isEven
                                              ? 0.6
                                              : 0.6);
                                    })
                                    : widget.post.postType == 'video' &&
                                    widget.post.postFiles.length == 1 ? kIsWeb

                                /// for web
                                    ? ChewieVideoPlayer( //1
                                  post: widget.post,
                                  index: 0,
                                  thumbnailUrl: widget.post.postFiles[0]['thumbnail_path'] ?? 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                  playPressed: () {
                                    // print("playpressed");
                                  },
                                )
                                    : ChewieVideoPlayer(
                                    thumbnailUrl: widget.post
                                        .postFiles[0]['thumbnail_path'] ?? 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                    isFullScreenOnMobile: true,
                                    allowFullScreen: false,
                                    borderRadius: 0,
                                    // aspectRatio:
                                    //     4 / 3,
                                    post: widget.post,
                                    index: 0)
                                    : widget.post.quoteInfo.postType ==
                                    'gallery' &&

                                    widget.post.quoteInfo.postType ==
                                        'attachment' &&
                                    widget.post.quoteInfo.postFiles.length == 1
                                    ? ListTile(
                                  onTap:
                                      () {
                                    launch(widget.post.quoteInfo
                                        .postFiles[0]['file_path']);
                                  },
                                  shape:
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          15)),
                                  tileColor:
                                  Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors
                                      .black
                                      : Colors.white
                                  ,
                                  leading:
                                  SizedBox(
                                    height: 28,
                                    width: 28,
                                    child: Image.asset(
                                        'assets/images/document.png'),
                                  ),
                                  title:
                                  Text("${widget.post.quoteInfo
                                      .postFiles[0]['original_name']}",
                                    style: TextStyle(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                )
                                    : widget.post.quoteInfo.postType ==
                                    'gallery' &&
                                    widget.post.quoteInfo.postFiles.length > 1 &&
                                    widget.post.quoteInfo
                                        .postFiles[0]['file_type'] ==
                                        'attachment'
                                    ? Column(
                                  children: [
                                    for (var i = 0; i <
                                        widget.post.quoteInfo.postFiles
                                            .length; i++)
                                      Padding(
                                        padding: const EdgeInsets
                                            .symmetric(
                                            vertical: 4.0),
                                        child: ListTile(
                                          onTap: () {
                                            launch(widget.post.quoteInfo
                                                .postFiles[i]['file_path']);
                                          },
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius
                                                  .circular(10)),
                                          tileColor: Theme
                                              .of(context)
                                              .brightness ==
                                              Brightness.dark
                                              ? Colors.black
                                              : Colors.white
                                          ,
                                          leading: SizedBox(height: 28,
                                              width: 28,
                                              child: Image.asset(
                                                  'assets/images/document.png')),
                                          title: Text(
                                            "${widget.post.quoteInfo
                                                .postFiles[i]['original_name']}",
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness ==
                                                  Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                )
                                    : Container(),
                              ],
                            ),
                          ),
                        )
                            : const SizedBox(),
                        widget.post.postType == 'video' ||
                            widget.post.postType == 'gallery'
                                // post.postFiles[0]['file_type'] ==
                                //     'image'
                                && widget.post.postFiles.length > 0 ?
                        widget.post.postFiles[0]['mention_users'] != null
                            ? SizedBox(
                          width: kIsWeb ? 150 : 80,
                          child: InkWell(onTap: () {


                          }, child: Row(
                            children: [
                              const Icon(
                                Icons.person, size: 15,
                                color: Colors.blue,),
                              Text(
                                widget.post.postFiles[0]['mention_users']
                                    .isNotEmpty
                                    ? "${widget.post
                                    .postFiles[0]['mention_users']
                                    .length > 1 ? widget.post
                                    .postFiles[0]['mention_users'][0]["firstname"] +
                                    " and ${widget.post
                                        .postFiles[0]['mention_users']
                                        .length - 1} Others" : "${widget.post
                                    .postFiles[0]['mention_users'][0]["firstname"]}" } "
                                    : "Tag People",
                                // style:TextStyle(color: Colors.blue,fontSize: 12)
                                style: TextStyle(
                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.blue,
                                  fontSize: 12,
                                ),


                              ),
                            ],
                          )),
                        )
                            : const SizedBox() : const SizedBox(),

                        ///reaction
                        buildReactionRow(context, widget.controller),

                        const SizedBox(
                          height: 4,
                        ),

                        /// comments  List view
                      ],
                    ),
                  ),
                ),
                MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: GestureDetector(

                    child: const Divider(
                      thickness: 1.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // REACTION ROW BUILDER METHOD
  dynamic buildReactionRow(BuildContext context,
      GuestUserController controller) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Tooltip(
                  message: Strings.like,
                  child: InkWell(
                    onTap:  loginPress,
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: Image.asset(
                        'assets/drawer_icons/not_like.png',
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 5),
                GestureDetector(
                  onTap: loginPress,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 5,
                      vertical: 1,
                    ),
                    // decoration: BoxDecoration(
                    //   color: Colors.grey[100],
                    //   borderRadius: BorderRadius.circular(20),
                    // ),
                    child: Text(
                      "${widget.post.simpleLikeCount}",
                      // style: TextStyle(
                      //   color: Colors.grey[600],
                      //   fontSize: 14,
                      // ),
                      style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.grey[600],
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Tooltip(
                  message: Strings.reply,
                  child: InkWell(
                    onTap: loginPress,
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: Icon(
                        Icons.mode_comment_outlined, size: 20, color: Theme
                          .of(context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : Colors.grey,),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {

                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 1,
                    ),
                    child: Text(
                      widget.post.commentsCount.toString(),
                      style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.grey[600],
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ],
            ),

              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [

                  Tooltip(
                    message: Strings.rewerf,
                    child: PopupMenuButton(
                      initialValue: 1,
                      onSelected: (value) {
                        loginPress();
                      },
                      itemBuilder: (context) =>
                      [
                        PopupMenuItem(
                          value: 1,
                          child: ListTile(
                            leading: SizedBox(
                              width: 20,
                              height: 20,
                              child: Icon(Icons.repeat, size: 20, color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.grey,),
                            ),
                            title: Text(
                              Strings.rewerf,
                              // style: TextStyle(
                              //     color: Colors.black, fontSize: 14),
                              style: TextStyle(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        PopupMenuItem(
                          value: 2,
                          child: ListTile(
                            leading: const Icon(
                              Icons.edit_outlined,
                              size: 20,
                            ),
                            title: Text(
                              Strings.quoteRewerf,
                              style: TextStyle(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ],
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: Icon(Icons.repeat, size: 20, color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.grey,),
                      ),
                    ),
                  ),

                  GestureDetector(
                    onTap: () {},
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 1,
                      ),

                      child: Text(


                     widget.post.retweetCount==null?"0"   :widget.post.retweetCount.toString(),
                        // style: TextStyle(
                        //   color: Colors.grey[600],
                        //   fontSize: 14,
                        // ),
                        style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.grey[600],
                          fontSize: 14,
                          //fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

            Tooltip(
              message: Strings.view,
              child: InkWell(
                onTap: loginPress,
                child: Row(
                    children: [

                      Icon(Icons.remove_red_eye_outlined,
                          size: 20, color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.grey),
                      const SizedBox(
                        width: 3,
                      ),
                      widget.post.postViews != null ?
                      Text(
                        widget.post.postViews.toString(),
                        style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.grey[600],
                          fontSize: 14,
                          //fontWeight: FontWeight.bold,
                        ),

                      ) : Text(""),

                    ]
                ),
              ),
            ),
            PopupMenuButton(
                tooltip: Strings.share,
                position: PopupMenuPosition.under,
                padding: EdgeInsets.zero,
                icon: Icon(Icons.share_outlined, size: 20, color: Theme
                    .of(context)
                    .brightness == Brightness.dark
                    ? Colors.white
                    : Colors.grey,),

                color: Theme
                    .of(context)
                    .brightness == Brightness.dark ? Colors.black : Colors
                    .white,
                // Callback that sets the selected popup menu item.
                onSelected: (value) {
                loginPress();
                },
                itemBuilder: (BuildContext context) =>
                [
                  if(widget.post.saved == false || widget.post.saved == null)
                    PopupMenuItem(
                      value: 1,
                      child: Row(

                        children: [
                          Container(
                              width: 20,
                              height: 20,
                              child: SvgPicture.asset(
                                'assets/svg_drawer_icons/saved.svg',
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )
                          ),
                          const SizedBox(width: 5,),
                          Text(Strings.bookmarks,
                            style: TextStyle(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors
                                    .black,
                                fontSize: 14
                            ),
                          ),
                        ],
                      ),),

                  if(widget.post.saved == true)
                    PopupMenuItem(
                      value: 2,
                      child: Row(

                        children: [
                          SizedBox(
                              width: 20,
                              height: 20,
                              child: SvgPicture.asset(
                                'assets/svg_drawer_icons/saved.svg',
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )
                          ),
                          const SizedBox(width: 5,),
                          Text(Strings.removeWerfFromBookMark,
                            style: TextStyle(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors
                                    .black,
                                fontSize: 14
                            ),
                          ),
                        ],
                      ),),

                  PopupMenuItem(
                    value: 3,
                    child: Row(
                        children: [
                          SizedBox(
                              width: 20,
                              height: 20,
                              child: Image.asset(
                                AppImages.copylink,
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )
                          ),
                          const SizedBox(width: 5),
                          Text(
                            Strings.copylinkToWerf,
                            style:
                            TextStyle(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors
                                    .black,
                                fontSize: 14
                            ),),
                        ]),),


                ]
            ),

          ],
        ),
      ),
    );
  }

  loginPress(){

    LoginController loginController;
    if (Get.isRegistered<LoginController>()) {
      loginController = Get.find<LoginController>();
    } else {
      loginController = Get.put(LoginController());
    }
    showDialog(
        context: context,
        builder: (BuildContext context) =>
            AlertDialog(
              backgroundColor:Colors.grey.shade100 ,
              shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                      Radius.circular(15.0))),
              insetPadding: const EdgeInsets.symmetric(
                  horizontal: 0, vertical: 0),
              contentPadding:
              const EdgeInsets.symmetric(horizontal: 12),
              content: SizedBox(
                  height: 600,
                  width: 450,
                  child: StatefulBuilder(
                      builder: (BuildContext context,
                          StateSetter setState) =>

                      ///origin code
                      Column(
                        children: [
                          MouseRegion(
                            cursor: SystemMouseCursors
                                .click,
                            child: GestureDetector(
                              onTap: () {
                                loginController.email
                                    .clear();
                                loginController
                                    .password
                                    .clear();

                                /// clear the text box
                                // loginController

                                Navigator.pop(
                                    context);
                              },
                              child: const Padding(
                                padding:
                                EdgeInsets
                                    .only(
                                  top: 5,
                                ),
                                child: Align(
                                  alignment: Alignment
                                      .topRight,
                                  child: Icon(
                                    Icons.clear,
                                    size: 25,
                                    color:
                                    Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding:
                            const EdgeInsets.only(
                              // top: 30,
                              left: 30,
                              right: 30,
                            ),
                            child: NewLoginForm(
                                context,
                                loginController,
                                formKey,
                                2),
                          ),
                        ],
                      )

                    /// origin code
                  )),
            ));
  }
}


