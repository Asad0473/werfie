import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../utils/font.dart';

class GuestUserTabButton extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Function onTap;

  const GuestUserTabButton({Key key, this.title, this.isSelected, this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: onTap,
      child: Column(
        children: [
          isSelected
              ? FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb ? 16 : 14,
                    ),
                    maxLines: 1,
                  ),
                )
              : FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 16 : 14,
                    ),
                    maxLines: 1,
                  ),
                ),
          const SizedBox(
            height: 3,
          ),
          isSelected
              ? Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: Colors.blue,
                  ),
                  height: 5,
                  width: title.removeAllWhitespace.length * 9.toDouble(),
                )
              : const SizedBox(),
        ],
      ),
    );
  }
}
