import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../network/controller/guest_user_controller.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import 'components/guest_user_post_card.dart';
import 'components/guest_user_tab_button.dart';

class GuestUserNewsfeedScreen extends StatelessWidget {
  final guestUserController = Get.put(GuestUserController());
  final GlobalKey<ScaffoldState> _scaffoldKey =  GlobalKey<ScaffoldState>();
  final GlobalKey<ScaffoldState> _scaffoldPost =  GlobalKey<ScaffoldState>();

  GuestUserNewsfeedScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<GuestUserController>(builder: (controller) {
      return
        controller.isTrendsDataLoading == true
          ? const Center(child: CircularProgressIndicator())
          :
        Scaffold(
              key: _scaffoldKey,
              appBar: PreferredSize(
                preferredSize: controller.searchFilter == true
                    ? controller.guestUserSearchModel.tags.isEmpty &&
                            controller.guestUserSearchModel.users.isEmpty
                        ? const Size.fromHeight(150.0)
                        : const Size.fromHeight(350.0)
                    : const Size.fromHeight(140.0),
                child: Stack(
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 20,
                        ),

                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: SizedBox(
                                  height: 45,
                                  width:
                                      MediaQuery.of(context).size.width >= 720
                                          ? 500
                                          : Get.width / 1.4,
                                  child: TextField(
                                    controller:
                                        controller.searchFieldController,
                                    style: LightStyles.baseTextTheme.headline2
                                        .copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      // fontSize: 14,
                                      // fontWeight: FontWeight.bold,
                                    ),
                                    cursorColor:
                                        Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                    textAlignVertical:
                                        TextAlignVertical.bottom,
                                    onChanged: (value) {
                                      //  controller. searchFieldController.text=value;
                                      controller.delaySearch.run(() async {
                                        // print('hello delay');
                                        if (value.isNotEmpty &&
                                            value.toString().length > 0) {
                                          controller
                                              .getGuestUserSearch(value);
                                        } else if (value.isEmpty &&
                                            value.toString().length == 0) {
                                          controller.searchFilter = false;
                                          controller.update();
                                        }
                                      });
                                    },
                                    // autofocus: controller.searchField,
                                    onTap: () {
                                      controller.delaySearch.run(() async {
                                        // print('hello delay');
                                        if (controller.searchFieldController
                                                .text.isNotEmpty &&
                                            controller.searchFieldController
                                                    .text
                                                    .toString()
                                                    .length >
                                                0) {
                                          controller.getGuestUserSearch(
                                              controller.searchFieldController
                                                  .text);
                                        } else if (controller
                                                .searchFieldController
                                                .text
                                                .isEmpty &&
                                            controller.searchFieldController
                                                    .text
                                                    .toString()
                                                    .length ==
                                                0) {
                                          controller.searchFilter = false;
                                          controller.update();
                                        }
                                      });

                                      //  controller.searchFilter = true;
                                      // controller.update();
                                    },
                                    decoration: InputDecoration(
                                      hintText: Strings.search,
                                      prefixIcon: Icon(
                                        Icons.search,
                                        size: 20,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                      hintStyle:
                                          LightStyles.baseTextTheme.headline3,
                                      border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(40),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(40),
                                        borderSide: const BorderSide(
                                            color: Colors.grey, width: 1),
                                      ),
                                      fillColor: Colors.grey[250],
                                      filled: true,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        // Divider(),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.symmetric(
                                horizontal:
                                    BorderSide(color: Colors.grey[200])),
                          ),
                          width: Get.width,
                          height: 50,
                          child: Padding(
                            padding:
                                const EdgeInsets.only(top: 10, bottom: 10),
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  controller.searchPostsView == true
                                      ? GuestUserTabButton(
                                          title: Strings.top,
                                          onTap: () {
                                            controller.searchTab();
                                          },
                                          isSelected: controller.isSearchTab,
                                        )
                                      : GuestUserTabButton(
                                          title: Strings.trending,
                                          onTap: () {
                                            controller.trendingTab();
                                          },
                                          isSelected:
                                              controller.isTrendingTab,
                                        ),
                                  const SizedBox(
                                    width: 7,
                                  ),
                                  GuestUserTabButton(
                                    title: Strings.newsSocial,
                                    onTap: () {
                                      controller.newsAndSocialTabs();
                                    },
                                    isSelected: controller.isTopicTab,
                                  ),
                                  const SizedBox(
                                    width: 7,
                                  ),
                                  GuestUserTabButton(
                                    title: Strings.filmTV,
                                    onTap: () {
                                      controller.filmsTvTabs();
                                    },
                                    isSelected: controller.isSuggestedTab,
                                  ),
                                  const SizedBox(
                                    width: 7,
                                  ),
                                  GuestUserTabButton(
                                    title: Strings.music,
                                    onTap: () {
                                      controller.musicTab();
                                    },
                                    isSelected: controller.isMusicTab,
                                  ),
                                  const SizedBox(
                                    width: 7,
                                  ),
                                  GuestUserTabButton(
                                    title: Strings.travelAdventure,
                                    onTap: () {
                                      controller.travelTab();
                                    },
                                    isSelected: controller.isTravelTab,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    controller.searchFilter == true
                        ? Positioned(
                            top: 70,
                            left: 40,
                            child: Container(
                              height: controller
                                          .guestUserSearchModel.tags.isEmpty &&
                                      controller
                                          .guestUserSearchModel.users.isEmpty
                                  ? 100
                                  : 300,
                              width: MediaQuery.of(context).size.width >= 720
                                  ? 500
                                  : Get.width / 1.4,
                              decoration: BoxDecoration(
                                  color: Colors.grey.shade200,
                                  borderRadius: BorderRadius.circular(20)),
                              child:
                                  controller.guestUserSearchModel.tags
                                              .isEmpty &&
                                          controller.guestUserSearchModel.users
                                              .isEmpty
                                      ?  SizedBox(
                                          child: Center(
                                              child: Text(Strings.noUserNoTag)),
                                        )
                                      : SingleChildScrollView(
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              top: 20, left: 30),
                                          child: Column(
                                            children: [
                                              controller
                                                      .guestUserSearchModel
                                                      .tags
                                                      .isNotEmpty
                                                  ? Column(
                                                      children:
                                                          List.generate(
                                                              controller
                                                                  .guestUserSearchModel
                                                                  .tags
                                                                  .length,
                                                              (index) =>
                                                                  InkWell(
                                                                    onTap:
                                                                        () {
                                                                      /*   controller.searchTab(
                                                                          type: 'tag',
                                                                          id: controller.guestUserSearchModel.tags[index].id);*/
                                                                    },
                                                                    child:
                                                                        Row(
                                                                      children: [
                                                                        const Icon(
                                                                          Icons.search,
                                                                          size: 30,
                                                                          color: Colors.black,
                                                                        ),
                                                                        const SizedBox(
                                                                          width: 30,
                                                                        ),
                                                                        Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            Text(
                                                                              controller.guestUserSearchModel.tags[index].title,
                                                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black),
                                                                            ),
                                                                            Text(
                                                                              '${controller.guestUserSearchModel.tags[index].usedCount.toString()} Werfs',
                                                                              style: const TextStyle(fontWeight: FontWeight.normal, fontSize: 16, color: Colors.grey),
                                                                            )
                                                                          ],
                                                                        )
                                                                      ],
                                                                    ),
                                                                  )))
                                                  : const SizedBox(),
                                              controller
                                                      .guestUserSearchModel
                                                      .users
                                                      .isNotEmpty
                                                  ? Column(
                                                      children:
                                                          List.generate(
                                                              controller
                                                                  .guestUserSearchModel
                                                                  .users
                                                                  .length,
                                                              (index) =>
                                                                  InkWell(
                                                                    onTap:
                                                                        () {
                                                                      controller.searchTab(
                                                                          type: 'user',
                                                                          id: controller.guestUserSearchModel.users[index].id);
                                                                    },
                                                                    child:
                                                                        Row(
                                                                      children: [
                                                                        CircleAvatar(
                                                                          backgroundImage: controller.guestUserSearchModel.users[index].profileImage != null ? NetworkImage(controller.guestUserSearchModel.users[index].profileImage) : AssetImage("assets/images/person_placeholder.png"),
                                                                          radius: 18,
                                                                        ),
                                                                        const SizedBox(
                                                                          width: 20,
                                                                        ),
                                                                        Column(
                                                                          children: [
                                                                            Text(
                                                                              controller.guestUserSearchModel.users[index].username,
                                                                              style: const TextStyle(
                                                                                color: Colors.black,
                                                                                fontSize: 16,
                                                                                fontWeight: FontWeight.bold,
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              "@${controller.guestUserSearchModel.users[index].username}",
                                                                              style: const TextStyle(
                                                                                color: Colors.grey,
                                                                                fontWeight: FontWeight.normal,
                                                                                fontSize: 16,
                                                                              ),
                                                                            )
                                                                          ],
                                                                        )
                                                                      ],
                                                                    ),
                                                                  )),
                                                    )
                                                  : const SizedBox()
                                            ],
                                          ),
                                        ),
                                      ),
                            ),
                          )
                        : const SizedBox(),
                  ],
                ),
              ),
              body: CustomScrollView(
                slivers: [
                  controller.trendingShowWidget == true
                      ? const SliverToBoxAdapter(
                child: SizedBox(
                height: 10,
                  ))
                      : const SliverToBoxAdapter(
                          child: SizedBox(
                          height: 10,
                        )),
                  controller.trendingShowWidget == true
                      ?  SliverToBoxAdapter(
                          child: Padding(
                          padding: const EdgeInsets.only(left: 15),
                          child: Text(
                            Strings.trendsForYou,
                            style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                        ))
                      : const SliverToBoxAdapter(child: SizedBox()),
                  controller.trendingShowWidget == true
                      ? SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (_, int index) {
                              return Padding(
                                padding: const EdgeInsets.only(left: 15),
                                child: controller.userTrendsData.length == 0 ||
                                        controller.userTrendsData.isEmpty
                                    ?  Text(Strings.noTrendsInThisRegion)
                                    : Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            Strings.trendingIn + ' ' + 'region',
                                            //  ' ${controller.trendingList.trends[index].region}',
                                            style: Styles
                                                .baseTextTheme.headline4
                                                .copyWith(
                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                              fontSize: kIsWeb ? 14 : 12,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          MouseRegion(
                                            cursor: SystemMouseCursors.click,
                                            child: GestureDetector(
                                              onTap: () {
                                                /*   controller.searchTab(
                                                    type: 'tag',
                                                    id: controller
                                                        .userTrendsData[index]
                                                        .id);*/
                                              },
                                              child: Text(
                                                  '${controller.userTrendsData[index].title}',
                                                  style: Styles
                                                      .baseTextTheme.headline4
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.bold,
                                                  )),
                                            ),
                                          ),
                                          Text(
                                            '${controller.userTrendsData[index].usedCount} ' +
                                                Strings.werfs,
                                            style: Styles
                                                .baseTextTheme.headline4
                                                .copyWith(
                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                              fontSize: kIsWeb ? 14 : 12,
                                              fontWeight: FontWeight.w400,
                                            ),
                                            // style: TextStyle(fontSize: 12),
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          // controller.userTrendsData.length >=5 ? Text('Show more'): SizedBox(),
                                        ],
                                      ),
                              );
                            },
                            childCount: controller.userTrendsData.length,
                          ),
                        )
                      : const SliverToBoxAdapter(child: SizedBox()),
                  controller.trendingShowWidget == true
                      ? const SliverToBoxAdapter(
                          child: Divider(
                          thickness: 2,
                        ))
                      : const SliverToBoxAdapter(child: SizedBox()),
                  controller.searchPostsView == true
                      ? GetBuilder<GuestUserController>(
                          id: 'searchFilter',
                          builder: (con) {
                            return con.isGuestUserLoading == true
                                ? const SliverToBoxAdapter(
                                    child: Center(
                                        child: Padding(
                                      padding: EdgeInsets.only(top: 20),
                                      child: CircularProgressIndicator(),
                                    )))
                                :  con.guestUserSearchResultModel==null? SliverToBoxAdapter(
                                child: Center(
                                  child: Text(Strings.weAreExperiencingSomeDifficulties),
                                ))
                                : SliverToBoxAdapter(
                                    child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          Strings.top,
                                          style: const TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        con.guestUserSearchResultModel.posts.isEmpty
                                            ?  SizedBox(child: Text(Strings.noPost))
                                            : ListView.builder(
                                                shrinkWrap: true,
                                                itemCount: con
                                                    .guestUserSearchResultModel
                                                    .posts
                                                    .length,
                                                itemBuilder:
                                                    (BuildContext context,
                                                        int index) {
                                                  return SizedBox(
                                                    // height: 400,
                                                    // width: 600,
                                                    child: GuestUserPostCard(
                                                      post: con
                                                          .guestUserSearchResultModel
                                                          .posts[index],
                                                      scaffoldKey:
                                                          _scaffoldPost,
                                                      controller: con,
                                                      index: index,
                                                    ),
                                                  );
                                                }),
                                      ],
                                    ),
                                  ));
                          })
                      : GetBuilder<GuestUserController>(
                          id: 'topicData',
                          builder: (con) {
                            return con.isGuestUserLoading == true
                                ? const SliverToBoxAdapter(
                                    child: Center(
                                        child: Padding(
                                      padding: EdgeInsets.only(top: 20),
                                      child: CircularProgressIndicator(),
                                    )))
                            :con.userModelData==null? SliverToBoxAdapter(
                                child: Center(
                                  child: Text(Strings.weAreExperiencingSomeDifficulties),
                                    ))
                                : SliverToBoxAdapter(
                                    child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          con.userModelData.topic.topic,
                                          style: const TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        con.userModelData.items.isEmpty
                                            ?  SizedBox(child: Text(Strings.noPost))
                                            : ListView.builder(
                                                shrinkWrap: true,
                                                itemCount: con
                                                    .userModelData.items.length,
                                                itemBuilder:
                                                    (BuildContext context,
                                                        int index) {
                                                  return SizedBox(
                                                    // height: 400,
                                                    // width: 600,
                                                    child: GuestUserPostCard(
                                                      post: con.userModelData
                                                          .items[index],
                                                      scaffoldKey: _scaffoldKey,
                                                      controller: con,
                                                      index: index,
                                                    ),
                                                  );
                                                }),
                                      ],
                                    ),
                                  ));
                          }),
                ],
              ),
            );
    });
  }
}
