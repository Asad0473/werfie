import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/metaTags/MetaTags.dart';
import 'package:werfieapp/utils/metaTags/MetaTagsValues.dart';
import 'package:werfieapp/utils/utils_methods.dart';
import 'package:werfieapp/widgets/login_form.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/new_login_form.dart';

import '../../network/controller/guest_user_controller.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../network/singleTone.dart';
import '../../screens/main_screen.dart';
import '../../utils/app_languages.dart';
import '../../utils/asset_string.dart';
import '../../utils/fluro_router.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../utils/urls.dart';
import '../../widgets/dialogs/LoginWithWorldNoorDialog.dart';
import '../../widgets/sign_up_dialog.dart';
import '../../widgets/sign_up_form.dart';
import 'components/textButton.dart';
import 'guest_user_newsfeed_screen.dart';

class GuestUserMainScreen extends StatefulWidget {
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  bool isFromPosh = false;
  String poshID;
  String WNToken;

  GuestUserMainScreen({Key key, this.isFromPosh = false, this.poshID, this.WNToken}) : super(key: key);

  @override
  State<GuestUserMainScreen> createState() => _GuestUserMainScreenState();
}

class _GuestUserMainScreenState extends State<GuestUserMainScreen> {
  final controller = Get.put(GuestUserController());

  SharedPreferences shared;

  final storage = GetStorage();

  bool isCheckedGlobal = false;

  LoginController loginController;
  String code;
  int index;
  // List of items in our dropdown menu

  @override
  void initState() {
    addLoginSignUpMetaTags();
    super.initState();
    if (Get.isRegistered<LoginController>()) {
      loginController = Get.find<LoginController>();
    } else {
      loginController = Get.put(LoginController());
    }

    WidgetsBinding.instance
        .addPostFrameCallback((_) {
      if(widget.isFromPosh){
        loginWithPosh(context);
      }
    });
  }

  addLoginSignUpMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.signUpAndLoginPageTitle,
        metaTagDescription: MetaTagValues.signUpAndLoginMetaDescription,
        metaTagKeywords: MetaTagValues.signUpAndLoginMetaKeywords,
        ogTitle: MetaTagValues.signUpAndLoginOGTitle,
        ogDescription: MetaTagValues.signUpAndLoginMetaDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    controller.searchFilter = false;
                    controller.update();
                  },
                  child: GuestUserLeftSection(
                      context: context, controller: controller),
                ),
                Container(
                  width: 2,
                  color: Colors.grey[200],
                ),
                SizedBox(
                  width: MediaQuery
                      .of(context)
                      .size
                      .width >= 720
                      ? 600
                      : Get.width / 1.2,
                  child: GestureDetector(
                      onTap: () {
                        controller.searchFilter = false;
                        controller.update();
                      },
                      child: GuestUserNewsfeedScreen()),
                ),
                Container(
                  width: 2,
                  color: Colors.grey[200],
                ),
                MediaQuery
                    .of(context)
                    .size
                    .width >= 1100
                    ? GestureDetector(
                  onTap: () {
                    controller.searchFilter = false;
                    controller.update();
                  },
                  child: GuestUserRightSection(
                      context: context,
                      controller: controller,
                      shared: shared,
                      isCheckedGlobal: isCheckedGlobal,
                      storage: storage),
                )
                    : const SizedBox(),
              ],
            ),
          ),
        ],
      ),
      // bottomNavigationBar: GestureDetector(
      //   onTap: () {
      //     controller.searchFilter = false;
      //     controller.update();
      //   },
      //   child: Container(
      //     height: 70,
      //     color: Colors.blue,
      //     child: Padding(
      //       padding: const EdgeInsets.only(left: 30, right: 30),
      //       child: Row(
      //         mainAxisAlignment: MediaQuery
      //             .of(context)
      //             .size
      //             .width >= 720
      //             ? MainAxisAlignment.spaceAround
      //             : MainAxisAlignment.center,
      //         children: [
      //           MediaQuery
      //               .of(context)
      //               .size
      //               .width >= 720
      //               ? Column(
      //             mainAxisAlignment: MainAxisAlignment.center,
      //             crossAxisAlignment: CrossAxisAlignment.start,
      //             children: [
      //               Text(
      //                 Strings.doNotMissWhatsHappening,
      //                 style: const TextStyle(
      //                     fontSize: 20,
      //                     color: Colors.white,
      //                     fontWeight: FontWeight.bold),
      //               ),
      //               Text(
      //              Strings.peopleOnWerfieAreTheFirstToKnow,
      //                 style: const TextStyle(
      //                     color: Colors.white,
      //                     fontSize: 15,
      //                     fontWeight: FontWeight.w400),
      //               ),
      //             ],
      //           )
      //               : const SizedBox(),
      //           Row(
      //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //             children: [
      //               TextCustomButton(
      //                 width: MediaQuery
      //                     .of(context)
      //                     .size
      //                     .width >= 720
      //                     ? null
      //                     : Get.width / 2.5,
      //                 buttonText: Strings.login,
      //                 id: 2,
      //                 onPressed: loginPress,
      //               ),
      //               const SizedBox(
      //                 width: 20,
      //               ),
      //               TextCustomButton(
      //                 width: MediaQuery
      //                     .of(context)
      //                     .size
      //                     .width >= 720
      //                     ? null
      //                     : Get.width / 2.5,
      //                 buttonText: Strings.signUp,
      //                 id: 2,
      //                 onPressed: signUpPress,
      //               ),
      //             ],
      //           ),
      //         ],
      //       ),
      //     ),
      //   ),
      // ),
    );
  }
 loginPress(){
   controller.searchFilter = false;
   controller.update();
   LoginController loginController;
   if (Get.isRegistered<LoginController>()) {
     loginController = Get.find<LoginController>();
   } else {
     loginController = Get.put(LoginController());
   }
   showDialog(
       context: context,
       builder: (BuildContext context) =>
           AlertDialog(
             backgroundColor:Colors.grey.shade100 ,
             shape: const RoundedRectangleBorder(
                 borderRadius: BorderRadius.all(
                     Radius.circular(15.0))),
             insetPadding: const EdgeInsets.symmetric(
                 horizontal: 0, vertical: 0),
             contentPadding:
             const EdgeInsets.symmetric(horizontal: 12),
             content: SizedBox(
                 height: 600,
                 width: 450,
                 child: StatefulBuilder(
                     builder: (BuildContext context,
                         StateSetter setState) =>

                     ///origin code
                     Column(
                       children: [
                         MouseRegion(
                           cursor: SystemMouseCursors
                               .click,
                           child: GestureDetector(
                             onTap: () {
                               loginController.email
                                   .clear();
                               loginController
                                   .password
                                   .clear();

                               /// clear the text box
                               // loginController

                               Navigator.pop(
                                   context);
                             },
                             child: const Padding(
                               padding:
                               EdgeInsets
                                   .only(
                                   top: 5,
                                   ),
                               child: Align(
                                 alignment: Alignment
                                     .topRight,
                                 child: Icon(
                                   Icons.clear,
                                   size: 25,
                                   color:
                                   Colors.black,
                                 ),
                               ),
                             ),
                           ),
                         ),
                         Padding(
                           padding:
                           const EdgeInsets.only(
                            // top: 30,
                             left: 30,
                             right: 30,
                           ),
                           child: NewLoginForm(
                               context,
                               loginController,
                               GuestUserMainScreen
                                   .formKey,
                               2),
                         ),
                       ],
                     )

                   /// origin code
                 )),
           ));
 }
 signUpPress() {
   controller.searchFilter = false;
   controller.update();
   LoginController loginController;
   if (Get.isRegistered<LoginController>()) {
     loginController = Get.find<LoginController>();
   } else {
     loginController = Get.put(LoginController());
   }
   showDialog(
       context: context,
       builder: (BuildContext context) =>
           AlertDialog(
             backgroundColor: Colors.grey.shade100,
             insetPadding: const EdgeInsets.symmetric(
                 horizontal: 0, vertical: 0),
             contentPadding:
             const EdgeInsets.symmetric(horizontal: 12),
             shape: const RoundedRectangleBorder(
                 borderRadius: BorderRadius.all(
                     Radius.circular(15.0))),
             content: SizedBox(
                 height: 600,
                 width: 450,
                 child: StatefulBuilder(
                   builder: (BuildContext cont,
                       StateSetter setState) =>
                   ///origin code
                   Column(
                     mainAxisAlignment: MainAxisAlignment
                         .center,
                     children: [
                       MouseRegion(
                         cursor: SystemMouseCursors
                             .click,
                         child: GestureDetector(
                           onTap: () {
                             loginController.email
                                 .clear();
                             loginController
                                 .password
                                 .clear();

                             /// clear the text box
                             // loginController

                             Navigator.pop(
                                 context);
                           },
                           child: const Padding(
                             padding:
                             EdgeInsets
                                 .only(
                                 top: 5,
                                 left: 10),
                             child: Align(
                               alignment: Alignment
                                   .topRight,
                               child: Icon(
                                 Icons.clear,
                                 size: 25,
                                 color:
                                 Colors.black,
                               ),
                             ),
                           ),
                         ),
                       ),
                       Expanded(
                         child: Padding(
                           padding: const EdgeInsets
                               .symmetric(
                               horizontal: 12
                           ),
                           child: SignUpDialog(
                             controller: loginController,
                           ),
                         ),
                       ),

                     ],
                   ),

                 )),
           ));
 }
 Widget GuestUserLeftSection({BuildContext context,
    GuestUserController controller,
    Function onTabbed}) {
    return SizedBox(
      width: MediaQuery
          .of(context)
          .size
          .width < 1280 ? 70 : 250,
      child: Padding(
        padding: const EdgeInsets.only(left: 0, right: 0, top: 10),
        child: ListView(
          children: [
            const SizedBox(height: 6),
            Row(
              children: [
                Container(
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.only(
                      left: 0,
                    ),
                    width: 100,
                    height: 45,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding:
                        const EdgeInsets.only(right: 8, top: 8, bottom: 8),
                        child: Image.asset(
                          AppImages.logoPng,
                          alignment: Alignment.centerLeft,
                          // color: Color((0xFF47b867)),
                        ),
                      ),
                    )),

                _buildLanguageDropDown(),
              ],
            ),

            ListTile(
              contentPadding: const EdgeInsets.only(left: 0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(0),
              ),
              // horizontalTitleGap: 8,
              leading: SizedBox(
                width: 35,
                height: 35,
                child: SvgPicture.asset(
                  'assets/svg_drawer_icons/HashtagFill.svg',
                  color: Theme
                      .of(context)
                      .brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                ),
              ),
              title: MediaQuery
                  .of(context)
                  .size
                  .width < 1280
                  ? const SizedBox()
                  : Text(
                Strings.explore,
                style: TextStyle(
                    color: Theme
                        .of(context)
                        .brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.bold),

              ),

              onTap: () {
                controller.trendingTab();

                controller.update();
              },
            ),
          ],
        ),
      ),
    );
  }
Widget _buildLanguageDropDown(){
    return DropdownButtonHideUnderline(
      child: DropdownButton<AppLanguage>(
        focusColor: Colors.transparent,
        // Initial Value
        value: controller.dropDownValue??controller.languageList[0],

        // Down Arrow Icon
        icon: const Icon(Icons.keyboard_arrow_down),

        // Array list of items
        items:controller.languageList.map((AppLanguage  language) {
          return DropdownMenuItem<AppLanguage>(
            value: language,
            child: Text(language.name),
          );
        }).toList(),
        isExpanded: false,
        isDense: true,

        onChanged: ( AppLanguage newValue) {
          setState(() {
            controller.dropDownValue = newValue;
            index = AppLanguage().languagesList.indexWhere((element) => element["name"]==newValue.name);
          code  = AppLanguage().languagesList[index]["code"];
            final loginController = Get.find<LoginController>();
            loginController.updateLanguage(code);
            controller.update();
          });
        },
      ),
    );
}

  ///Guest user Right Section
  Widget GuestUserRightSection({BuildContext context,
    GuestUserController controller,
    bool isCheckedGlobal,
    SharedPreferences shared,
    var storage}) {
    return Container(
      padding: const EdgeInsets.only(left: 20, right: 15),
      width: MediaQuery
          .of(context)
          .size
          .width <= 1100 ?controller.dropDownValue.code=='ar'? 450 :320: 410,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SizedBox(
            height: 15,
          ),
          Container(
            decoration: BoxDecoration(
              // color: Colors.blue,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.grey.shade200, width: 1)),
            height: MediaQuery
                .of(context)
                .size
                .height <= 400
                ? Get.height * 0.6
                : 400,
            width: MediaQuery
                .of(context)
                .size
                .width <= 1100 ?controller.dropDownValue.code=='ar'? 450:410 : 450,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      Strings.newToWerfie,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      Strings.signUpNowToGetYourOwnPersonalizedTimeline,
                      style: const TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 13,
                        color: Color(0xFF586976),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    TextCustomButton(
                      buttonText: Strings.signUpWithGoogle,
                      id: 1,
                      image: 'assets/images/google.png',
                      onPressed: () async {
                        LoginController loginController;
                        if (Get.isRegistered<LoginController>()) {
                          loginController = Get.find<LoginController>();
                        } else {
                          loginController = Get.put(LoginController());
                        }
                        var response;
                        UtilsMethods utillMethod = UtilsMethods();

                        await utillMethod
                            .signInWithGoogle()
                            .then((value) async {
                          showDialog(
                            // barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  backgroundColor:
                                  const Color(0xFFFFFFFF).withOpacity(0.2),
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0))),
                                  insetPadding: const EdgeInsets.symmetric(
                                      horizontal: 0, vertical: 0),
                                  contentPadding: EdgeInsets.zero,
                                  content: SizedBox(
                                    height: 100,
                                    width: 80,
                                    child: Column(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                      children: [
                                        SpinKitCircle(
                                          color: Theme
                                              .of(context)
                                              .primaryColor,
                                          size: 50.0,
                                        ),
                                        Text(
                                          Strings.pleaseWait,
                                          style: const TextStyle(color: Colors.white),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              });

                          response = await loginController.SocialLogin(
                              queryParameters: {
                                "email": value.email,
                                "firstname": value.displayName ?? "",
                                "login_type": 'google',
                                "social_id": value.uid,
                              },
                              token: {
                                "Authorization": " Bearer ${Url.webAPIKey}"
                              });
                          var jsonResponse = jsonDecode(response.toString());
                          // print("jsonResponse $jsonResponse");
                          var responseCode = jsonResponse['meta']['code'];
                          var userName = jsonResponse['data']['username'];
                          var token = jsonResponse['data']['token'];
                          // print("token : $token");
                          // print("responseCode : $responseCode");
                          var userId = jsonResponse['data']['id'];
                          shared = await SharedPreferences.getInstance();
                          // if (responseCode == 200) {

                          shared.setString("token", token.toString());
                          shared.setString("userName", userName.toString());
                          storage.write('id', userId);
                          storage.write("token", token.toString());
                          shared.setBool('socialLogin', true);

                          storage.write("userName", userName.toString());

                          storage.write("remember", isCheckedGlobal);

                          loginController.generateFCMToken(context);
                          loginController.updateInitialWelcomeMsg(true);

                          Get.put(NewsfeedController(
                            // linkId: controller.postId != null ? controller.postId : null,
                            // profileId: controller.profileId != null ? controller.profileId : null,
                          ));
                          Get
                              .find<NewsfeedController>()
                              .languageData =
                          await Get.find<NewsfeedController>()
                              .getLanguages();
                          Get
                              .find<NewsfeedController>()
                              .selectedAppLanguageInfoId =
                              Get
                                  .find<NewsfeedController>()
                                  .languageData
                                  .appLang
                                  .id;

                          Get.find<NewsfeedController>().upDateLocale(
                              Get
                                  .find<NewsfeedController>()
                                  .languageData
                                  .appLang
                                  .code);
                          Get.find<NewsfeedController>().update();
                          // print("responseCodesss : $responseCode");
                          if (kIsWeb) {
                            SingleTone.instance.socialLogin = true;
                            // Routemaster.of(context).pop();
                            String userName = shared.getString("userName");
                            // print({"userName on mainScreen :  $userName"});
                            // print('postsid:${loginController.postId}');
                            // print('profileId:${loginController.profileId}');

                            Get.offNamed(FluroRouters.mainScreen);
                            // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                            //
                            //
                            //   "userName": shared.getString("userName"),
                            //   "postId": loginController.postId != null
                            //       ? loginController.postId
                            //       : null,
                            //   "profileId": loginController.profileId != null
                            //       ? loginController.profileId
                            //       : null
                            // });
                          } else {
                            // print('route is else here');
                            Get.back();

                            Get.offAll(MainScreen(), arguments: {
                              "userName": shared.getString("userName"),
                              "postId": loginController.postId != null
                                  ? loginController.postId
                                  : null,
                              "profileId": loginController.profileId != null
                                  ? loginController.profileId
                                  : null
                            });
                          }
                        }

                          // }
                        );
                      },
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    TextCustomButton(
                      buttonText: Strings.signUpWithApple,
                      id: 1,
                      image: 'assets/images/apple.png',
                      onPressed: () async {
                        LoginController controller;
                        if (Get.isRegistered<LoginController>()) {
                          controller = Get.find<LoginController>();
                        } else {
                          controller = Get.put(LoginController());
                        }
                        var response;
                        final appleProvider = AppleAuthProvider();

                        final userCredential = await FirebaseAuth.instance
                            .signInWithPopup(appleProvider);
                        final value = userCredential.user;
                        int id = 2;

                        if (value.email == null ||
                            /*value.displayName == null ||*/
                            value.uid == null ||
                            value.email.isEmpty ||
                            /*value.displayName.isEmpty ||*/
                            value.uid.isEmpty) {
                          Get.snackbar(Strings.error,
                              Strings.somThingWentWrongWithConfiguration);
                        } else if (value.email.contains("privaterelay")) {
                          Get.snackbar(Strings.alert,
                             Strings.pleaseAllowEmailToContinueWithWerfie);
                          await FirebaseAuth.instance.signOut();
                        } else {
                          showDialog(
                            // barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  backgroundColor:
                                  const Color(0xFFFFFFFF).withOpacity(0.2),
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0))),
                                  insetPadding: EdgeInsets.symmetric(
                                      horizontal: 0, vertical: 0),
                                  contentPadding: EdgeInsets.zero,
                                  content: Container(
                                    height: 100,
                                    width: 80,
                                    child: Column(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                      children: [
                                        SpinKitCircle(
                                          color: Theme
                                              .of(context)
                                              .primaryColor,
                                          size: 50.0,
                                        ),
                                        Text(
                                          Strings.pleaseWait,
                                          style: TextStyle(color: Colors.white),
                                        )
                                      ],
                                    ),
                                  ),
                                );
                              });

                        }
                        showDialog(
                          // barrierDismissible: false,
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                backgroundColor:
                                Color(0xFFFFFFFF).withOpacity(0.2),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(10.0))),
                                insetPadding: EdgeInsets.symmetric(
                                    horizontal: 0, vertical: 0),
                                contentPadding: EdgeInsets.zero,
                                content: Container(
                                  height: 100,
                                  width: 80,
                                  child: Column(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                    children: [
                                      SpinKitCircle(
                                        color: Theme
                                            .of(context)
                                            .primaryColor,
                                        size: 50.0,
                                      ),
                                      Text(
                                        Strings.pleaseWait,
                                        style: TextStyle(color: Colors.white),
                                      )
                                    ],
                                  ),
                                ),
                              );
                            });



                        response =
                        await controller.SocialLogin(queryParameters: {
                          "email": value.email,
                          "firstname": value.displayName ?? "",
                          "login_type": 'apple',
                          "social_id": value.uid,
                        }, token: {
                          "Authorization": " Bearer ${Url.webAPIKey}"
                        });
                        var jsonResponse = jsonDecode(response.toString());
                        // print("jsonResponse $jsonResponse");
                        // storage.write("email", value.email.toString());
                        // shared.setString("email", value.email.toString());

                        var responseCode = jsonResponse['meta']['code'];
                        var userName = jsonResponse['data']['username'];
                        var token = jsonResponse['data']['token'];
                        // print("token : $token");
                        var userId = jsonResponse['data']['id'];
                        var email = jsonResponse['data']['email'];
                        shared = await SharedPreferences.getInstance();
                        if (responseCode == 200) {
                          storage.write("email", email.toString());

                          shared.setString("token", token.toString());
                          shared.setString("userName", userName.toString());
                          storage.write('id', userId);
                          storage.write("token", token.toString());
                          shared.setBool('guestUser', true);
                          shared.setBool('socialLogin', true);
                          storage.write("userName", userName.toString());

                          storage.write("remember", isCheckedGlobal);

                          controller.generateFCMToken(context);
                          loginController.updateInitialWelcomeMsg(true);
                          Get.put(NewsfeedController(
                            // linkId: controller.postId != null ? controller.postId : null,
                            // profileId: controller.profileId != null ? controller.profileId : null,
                          ));
                          Get
                              .find<NewsfeedController>()
                              .languageData =
                          await Get.find<NewsfeedController>()
                              .getLanguages();
                          Get
                              .find<NewsfeedController>()
                              .selectedAppLanguageInfoId =
                              Get
                                  .find<NewsfeedController>()
                                  .languageData
                                  .appLang
                                  .id;

                          Get.find<NewsfeedController>().upDateLocale(
                              Get
                                  .find<NewsfeedController>()
                                  .languageData
                                  .appLang
                                  .code);
                          Get.find<NewsfeedController>().update();
                          {
                            if (kIsWeb) {
                              if (id == 2) {
                                SingleTone.instance.socialLogin = true;
                                Navigator.pop(context);
                                // Routemaster.of(context).pop();
                                String userName = shared.getString("userName");

                                Get.offNamed(FluroRouters.mainScreen);
                              } else {
                                SingleTone.instance.socialLogin = true;
                                Navigator.pop(context);
                                String userName = shared.getString("userName");
                                // print({"userName on mainScreen :  $userName"});
                                // print('postsid:${controller.postId}');
                                // print('profileId:${controller.profileId}');
                                Get.offNamed(FluroRouters.mainScreen);
                              }
                            } else {
                              SingleTone.instance.socialLogin = true;
                              // print('route is else here');
                              Get.back();

                              Get.offAll(MainScreen(), arguments: {
                                "userName": shared.getString("userName"),
                                "postId": controller.postId != null
                                    ? controller.postId
                                    : null,
                                "profileId": controller.profileId != null
                                    ? controller.profileId
                                    : null
                              });
                            }
                          }
                        }
                      },
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    TextCustomButton(
                      buttonText: Strings.loginWithEmail,
                      id: 1,
                      image: 'assets/images/email.png',
                      onPressed:loginPress

                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    TextCustomButton(
                      buttonText: Strings.signUpWithEmailOrMobile,
                      id: 1,
                      image: 'assets/images/email.png',
                      onPressed: signUpPress,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      height: 40,
                      child: TextCustomButton(
                        buttonText: Strings.loginWithWorldNoor,
                        image: 'assets/worldnoor/worldnoor_logo.png',
                        id: Theme.of(context).brightness == Brightness.dark
                            ? 0
                            : 1,
                        onPressed: (){
                          LoginWithWorldNoor().dialogLoginWithWorldNoorUsingCredentials(context);

                        },
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    RichText(
                      overflow: TextOverflow.clip,

                      // Controls how the text should be aligned horizontally
                      textAlign: TextAlign.end,

                      // Control the text direction
                      textDirection: TextDirection.rtl,

                      // Whether the text should break at soft line breaks
                      softWrap: true,
                      text: TextSpan(
                        text: Strings.bySigningUpYouAgreeOur,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF586976),
                        ),
                        // style: DefaultTextStyle.of(context).style,
                        children: <TextSpan>[
                          TextSpan(
                              text: '${Strings.termsOfService} ',
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                // decoration: TextDecoration.underline,
                                fontSize: 13,
                                color: Colors.blue,
                              ),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () async {
                                  var url = "https://api.werfie.com/terms";
                                  // if (await canLaunch(url))
                                  await launchUrl(Uri.parse(
                                    url,
                                  ));
                                }),
                          TextSpan(
                              text: Strings.and,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF586976),
                                // fontWeight: FontWeight.bold
                              )),
                          TextSpan(
                              text: ' ${Strings.privacyPolicy}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                // decoration: TextDecoration.underline,
                                fontSize: 13,
                                color: Colors.blue,
                              ),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () async {
                                  var url = "https://api.werfie.com/privacy";
                                  // if (await canLaunch(url))
                                  await launchUrl(Uri.parse(
                                    url,
                                  ));
                                }),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  loginWithPosh(BuildContext context)async {
    {
      LoginController loginController;
      if (Get.isRegistered<LoginController>()) {
        loginController = Get.find<LoginController>();
      } else {
        loginController = Get.put(LoginController());
      }
      var response;

      {
        try {


          response = await loginController.SocialLogin(
              queryParameters: {

                "login_type": 'posh',
                "social_id": widget.poshID,
                "wntoken": widget.WNToken
              },
              token: {
                "Authorization": " Bearer ${Url.webAPIKey}"
              });
          var jsonResponse = jsonDecode(response.toString());
          // print("jsonResponse $jsonResponse");
          // storage.write("email", value.email.toString());
          // shared.setString("email", value.email.toString());

          var responseCode = jsonResponse['meta']['code'];
          var userName = jsonResponse['data']['username'];
          var token = jsonResponse['data']['token'];
          // print("token : $token");
          var userId = jsonResponse['data']['id'];
          var email = jsonResponse['data']['email'];
          shared = await SharedPreferences.getInstance();
          if (responseCode == 200) {
            storage.write("email", email.toString());

            shared.setString("token", token.toString());
            shared.setString("userName", userName.toString());
            storage.write('id', userId);
            storage.write("token", token.toString());
            //shared.setBool('guestUser', true);
            shared.setBool('socialLogin', true);
            shared.setString('poshID', widget.poshID);
            storage.write("userName", userName.toString());

            storage.write("remember", isCheckedGlobal);

            loginController.generateFCMToken(context);
            loginController.updateInitialWelcomeMsg(true);

            //showing loading indicator
            DialogBuilder(context).showLoadingIndicator();

            await Get.put(NewsfeedController(
                // linkId: controller.postId != null ? controller.postId : null,
                // profileId: controller.profileId != null ? controller.profileId : null,
              ));
              Get
                  .find<NewsfeedController>()
                  .languageData =
              await Get.find<NewsfeedController>()
                  .getLanguages();
              Get
                  .find<NewsfeedController>()
                  .selectedAppLanguageInfoId =
                  Get
                      .find<NewsfeedController>()
                      .languageData
                      .appLang
                      .id;

              Get.find<NewsfeedController>().upDateLocale(
                  Get
                      .find<NewsfeedController>()
                      .languageData
                      .appLang
                      .code);
              Get.find<NewsfeedController>().update();
              //Navigator.of(context).pop();
                  {
                if (kIsWeb) {
                  SingleTone.instance.socialLogin = true;
                  //Navigator.pop(context);

                  Future.delayed(Duration(milliseconds: 3000), () async {
                    // DialogBuilder(context).hideOpenDialog();

                    Get.offNamed(FluroRouters.mainScreen,);
                  });
                  //Get.offNamed(FluroRouters.mainScreen);
                } else {
                  SingleTone.instance.socialLogin = true;
                  // print('route is else here');
                  Get.back();

                  Get.offAll(MainScreen(), arguments: {
                    "userName": shared.getString("userName"),
                    "postId": loginController.postId,
                    "profileId": loginController.profileId
                  });
                }
              }
          } else {
            Fluttertoast.showToast(
              msg: jsonResponse['meta']['message'].toString(),
              toastLength: Toast.LENGTH_SHORT, // or Toast.LENGTH_LONG
              gravity: ToastGravity.BOTTOM, // Location of the toast message
              timeInSecForIosWeb: 1, // Time duration for which the message will be displayed
              backgroundColor: Colors.grey,
              textColor: Colors.white,
              fontSize: 16.0,
            );
          }
        }catch(e){
          Fluttertoast.showToast(
            msg: Strings.sorryForTheInconvenience,
            toastLength: Toast.LENGTH_SHORT, // or Toast.LENGTH_LONG
            gravity: ToastGravity.BOTTOM, // Location of the toast message
            timeInSecForIosWeb: 1, // Time duration for which the message will be displayed
            backgroundColor: Colors.grey,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      }

      // }

    }
  }
}